package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;

import com.ultralinked.uluc.enterprise.App;


public class CountryCodeStorageHelper {
	private CountryCodeStorage storage;
	private  CountryCodeStorageHelper(){


	}
	private static CountryCodeStorageHelper instance;


	public static CountryCodeStorageHelper getInstance(){

		if(instance==null){

			instance=new CountryCodeStorageHelper();

		}
		return instance;

	}

	public CountryCodeStorage getCountryCodeStorage(Context context) {
		if (storage == null) {
			storage = new CountryCodeStorage(context);
		}
		return storage;
	}
	public void closeCountryCodeStorage() {
		if (storage != null) {
			storage.close();
			storage=null;
		}

		if(instance !=null){
			instance=null;
		}
	}


	public static void init(final App app) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				CountryCodeStorageHelper.getInstance().getCountryCodeStorage(app).getAllCountryInfo();
			}
		}).start();
	}
}
