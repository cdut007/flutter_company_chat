package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.login.bean.ContactInfo;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

/**
 * Created by Ultralinked on 2016/7/29 0029.
 */
public class SingleChatDetailsFragment extends BaseChatDetailsFragment {

    private static final String TAG = "SingleChatDetailsFragment";

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_detals_layout_single;
    }

    View  userInfo;
    @Override
    public void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);

        name = bind(R.id.tvName);
        iv = bind(R.id.image);
        userInfo = bind(R.id.user_info_layout);

    }

    private ContactInfo contactInfo;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         View view = super.onCreateView(inflater, container, savedInstanceState);
        if (mConversation == null) {
            activity.finish();
            Log.e(TAG,"mConversation is null.");
            return view;
        }

        Bundle data = getArguments();
        initData(data);


        return view;
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

        }
    }

    @Override
    protected void initData(Bundle data) {
        super.initData(data);
        contactInfo = new ContactInfo();
        contactInfo.setUserId(mConversation.getContactNumber());
        contactInfo.setName(mConversation.getContactName());
        initContactInfo();

    }

    private TextView name;
    private ImageView iv;


    PeopleEntity peopleEntity;
    private void initContactInfo() {
        name.setText(mConversation.getContactName());
        iv.setImageResource(ImageUtils.getDefaultContactImageResource(mConversation.getContactNumber()));
        userInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (peopleEntity==null||TextUtils.isEmpty(peopleEntity.subuser_id)) {
                    Log.i(TAG, "userid is null");
                    return;
                }

                DetailPersonActivity.gotoDetailPersonActivity(getActivity(), peopleEntity);
            }
        });
        Log.i(TAG, "user id:" + contactInfo.getUserId());
        peopleEntity = PeopleEntityQuery.getInstance().getByID(contactInfo.getUserId());
        if (peopleEntity != null) {
            Log.i(TAG, "peopleinfo:" + peopleEntity.toString());
            String iconUrl = peopleEntity.icon_url;
            if (iconUrl != null) {
                ImageUtils.loadCircleImage(mContext, iv, iconUrl, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));
            } else {
                Log.i(TAG, "icon url is null.");
            }
            String tmpName = PeopleEntityQuery.getDisplayName(peopleEntity);
            if (!TextUtils.isEmpty(tmpName)) {
                name.setText(tmpName);
            } else {
                Log.i(TAG, "name is null from peopleEntity");
            }

        } else {
            Log.i(TAG,"peopleEntity is null.");
        }



    }


}
