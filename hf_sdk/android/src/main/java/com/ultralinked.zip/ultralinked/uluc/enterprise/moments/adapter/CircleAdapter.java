package com.ultralinked.uluc.enterprise.moments.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.WelcomeActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.moments.activity.ImagePagerActivity;
import com.ultralinked.uluc.enterprise.moments.activity.MomentCommentsActivity;
import com.ultralinked.uluc.enterprise.moments.activity.SignatureActivity;
import com.ultralinked.uluc.enterprise.moments.activity.UserFeedActivity;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.CircleViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.ImageViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.TextViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.URLViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.VideoViewHolder;
import com.ultralinked.uluc.enterprise.moments.bean.ActionItem;
import com.ultralinked.uluc.enterprise.moments.bean.CircleItem;
import com.ultralinked.uluc.enterprise.moments.bean.CommentConfig;
import com.ultralinked.uluc.enterprise.moments.bean.CommentItem;
import com.ultralinked.uluc.enterprise.moments.bean.FavortItem;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.moments.mvp.presenter.CirclePresenter;
import com.ultralinked.uluc.enterprise.moments.utils.DatasUtil;
import com.ultralinked.uluc.enterprise.moments.utils.UrlUtils;
import com.ultralinked.uluc.enterprise.moments.widgets.CircleVideoView;
import com.ultralinked.uluc.enterprise.moments.widgets.CommentListView;
import com.ultralinked.uluc.enterprise.moments.widgets.MultiImageView;
import com.ultralinked.uluc.enterprise.moments.widgets.PraiseListView;
import com.ultralinked.uluc.enterprise.moments.widgets.SnsPopupWindow;
import com.ultralinked.uluc.enterprise.moments.widgets.dialog.CommentDialog;
import com.ultralinked.uluc.enterprise.more.FragmentMore;
import com.ultralinked.uluc.enterprise.utils.GlideCircleTransform;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.List;

/**
 * Created by yiwei on 16/5/17.
 */
public class CircleAdapter extends BaseRecycleViewAdapter {

    public final static int TYPE_HEAD = 0;

    private static final int STATE_IDLE = 0;
    private static final int STATE_ACTIVED = 1;
    private static final int STATE_DEACTIVED = 2;
    private int videoState = STATE_IDLE;
    public static final int HEADVIEW_SIZE = 1;

    int curPlayIndex=-1;

    private CirclePresenter presenter;
    private Context context;
    public void setCirclePresenter(CirclePresenter presenter){
        this.presenter = presenter;
    }

    public CircleAdapter(Context context){
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        if(position == 0){
            return TYPE_HEAD;
        }

        int itemType = 0;
        CircleItem item = (CircleItem) datas.get(position-1);
        if (CircleItem.TYPE_URL.equals(item.getType())) {
            itemType = CircleViewHolder.TYPE_URL;
        } else if (CircleItem.TYPE_TEXT.equals(item.getType())) {
            itemType = CircleViewHolder.TYPE_TEXT;
        } else if (CircleItem.TYPE_IMG.equals(item.getType())) {
            itemType = CircleViewHolder.TYPE_IMAGE;
        } else if(CircleItem.TYPE_VIDEO.equals(item.getType())){
            itemType = CircleViewHolder.TYPE_VIDEO;
        }
        return itemType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        if(viewType == TYPE_HEAD){
            View headView = LayoutInflater.from(parent.getContext()).inflate(R.layout.comments_head_circle, parent, false);
            viewHolder = new HeaderViewHolder(headView);
        }else{
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comments_adapter_circle_item, parent, false);

            if(viewType == CircleViewHolder.TYPE_URL){
                viewHolder = new URLViewHolder(view);
            }else if(viewType == CircleViewHolder.TYPE_IMAGE){
                viewHolder = new ImageViewHolder(view);
            }else if(viewType == CircleViewHolder.TYPE_TEXT){
                viewHolder = new TextViewHolder(view);
            }else if(viewType == CircleViewHolder.TYPE_VIDEO){
                viewHolder = new VideoViewHolder(view);
            }
        }

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int position) {

        if(getItemViewType(position)==TYPE_HEAD){
            HeaderViewHolder holder = (HeaderViewHolder) viewHolder;
            ImageView userIcon = (ImageView) holder.itemView.findViewById(R.id.comment_user_small_icon);

            ImageView largeIcon = (ImageView) holder.itemView.findViewById(R.id.comment_large_bg);
            TextView  signature = (TextView) holder.itemView.findViewById(R.id.comment_user_signature);
            View newMomentsInfo = holder.itemView.findViewById(R.id.new_moments_info);
            View  newMomentsItems = holder.itemView.findViewById(R.id.moments);
            String userId = SPUtil.getUserID();
            final User user = SPUtil.getMomentInfo(userId);
            String cover = user.cover;
            if (TextUtils.isEmpty(cover)){
                cover = "http://img10.3lian.com/sc6/show02/38/65/386515.jpg";
            }

            if (!TextUtils.isEmpty(user.signature) && !user.signature.equals("null")){
                signature.setText(user.signature);
            }

            signature.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SignatureActivity.go2FeedPage(context,user);
                }
            });

            ImageUtils.loadImageByString(context,largeIcon, cover);

            largeIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    presenter.chooseImageBackgroud();
                }
            });

            TextView userName = (TextView) holder.itemView.findViewById(R.id.comment_user_name);

            PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userId);
            if (peopleEntity != null) {
                String name = PeopleEntityQuery.getDisplayName(peopleEntity);
                userName.setText(name);
                ImageUtils.loadCircleImage(context,userIcon, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(name));
            }

            if (FragmentMore.newMommetsItems.size()>0){
                newMomentsInfo.setVisibility(View.VISIBLE);//
                ImageView newMomentsHead = (ImageView) holder.itemView.findViewById(R.id.user_head);
                TextView  newMomentsText = (TextView) holder.itemView.findViewById(R.id.txt_moments);
                ImageUtils.loadCircleImage(context,newMomentsHead, FragmentMore.newMommetsItems.get(0).icon_url, ImageUtils.getDefaultContactImageResource( FragmentMore.newMommetsItems.get(0).nickname));
                newMomentsText.setText(FragmentMore.newMommetsItems.size()+" "+context.getString(R.string.new_message_count));

                newMomentsItems.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //go to see detail moments/
                        context.startActivity(new Intent(context, MomentCommentsActivity.class));
                    }
                });
            }else{
                newMomentsInfo.setVisibility(View.INVISIBLE);
            }


        }else{

            final int circlePosition = position - HEADVIEW_SIZE;
            final CircleViewHolder holder = (CircleViewHolder) viewHolder;
            final CircleItem circleItem = (CircleItem) datas.get(circlePosition);
            final String circleId = circleItem.getId();
            String name = circleItem.getUser().getName();
            String headImg = circleItem.getUser().getHeadUrl();
            final String content = circleItem.getContent();
            String createTime = circleItem.getCreateTime();
            final List<FavortItem> favortDatas = circleItem.getFavorters();
            final List<CommentItem> commentsDatas = circleItem.getComments();
            boolean hasFavort = circleItem.hasFavort();
            boolean hasComment = circleItem.hasComment();

            ImageUtils.loadCircleImage(context,holder.headIv, headImg, ImageUtils.getDefaultContactImageResource(name));

              holder.headIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    UserFeedActivity.go2FeedPage(context,circleItem.getUser());
                }
            });
            holder.nameTv.setText(name);
            holder.nameTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    UserFeedActivity.go2FeedPage(context,circleItem.getUser());
                }
            });
            holder.timeTv.setText(createTime);

            if(!TextUtils.isEmpty(content)){
                holder.contentTv.setText(UrlUtils.formatUrlString(content));
            }
            holder.contentTv.setVisibility(TextUtils.isEmpty(content) ? View.GONE : View.VISIBLE);

            if(DatasUtil.curUser.getId().equals(circleItem.getUser().getId())){
                holder.deleteBtn.setVisibility(View.VISIBLE);
            }else{
                holder.deleteBtn.setVisibility(View.GONE);
            }
            holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //删除
                    if(presenter!=null){
                        presenter.deleteCircle(circleId);
                    }
                }
            });
            if(hasFavort || hasComment){
                if(hasFavort){//处理点赞列表
                    holder.praiseListView.setOnItemClickListener(new PraiseListView.OnItemClickListener() {
                        @Override
                        public void onClick(int position) {
                            String userName = favortDatas.get(position).getUser().getName();
                            String userId = favortDatas.get(position).getUser().getId();
                            UserFeedActivity.go2FeedPage(context,favortDatas.get(position).getUser());
                          //  Toast.makeText(MyApplication.getContext(), userName + " &id = " + userId, Toast.LENGTH_SHORT).show();
                        }
                    });
                    holder.praiseListView.setDatas(favortDatas);
                    holder.praiseListView.setVisibility(View.VISIBLE);
                }else{
                    holder.praiseListView.setVisibility(View.GONE);
                }

                if(hasComment){//处理评论列表
                    holder.commentList.setOnItemClickListener(new CommentListView.OnItemClickListener() {
                        @Override
                        public void onItemClick(int commentPosition) {
                            CommentItem commentItem = commentsDatas.get(commentPosition);
                            if(DatasUtil.curUser.getId().equals(commentItem.getUser().getId())){//复制或者删除自己的评论

                                CommentDialog dialog = new CommentDialog(context, presenter, commentItem, circlePosition);
                                dialog.show();
                            }else{//回复别人的评论
                                if(presenter != null){
                                    CommentConfig config = new CommentConfig();
                                    config.circlePosition = circlePosition;
                                    config.commentPosition = commentPosition;
                                    config.mCircleItem = circleItem;
                                    config.commentType = CommentConfig.Type.REPLY;
                                    config.replyUser = commentItem.getUser();
                                    presenter.showEditTextBody(config);
                                }
                            }
                        }
                    });
                    holder.commentList.setOnItemLongClickListener(new CommentListView.OnItemLongClickListener() {
                        @Override
                        public void onItemLongClick(int commentPosition) {
                            //长按进行复制或者删除
                            CommentItem commentItem = commentsDatas.get(commentPosition);
                            CommentDialog dialog = new CommentDialog(context, presenter, commentItem, circlePosition);
                            dialog.show();
                        }
                    });
                    holder.commentList.setDatas(commentsDatas);
                    holder.commentList.setVisibility(View.VISIBLE);

                }else {
                    holder.commentList.setVisibility(View.GONE);
                }
                holder.digCommentBody.setVisibility(View.VISIBLE);
            }else{
                holder.digCommentBody.setVisibility(View.GONE);
            }

            holder.digLine.setVisibility(hasFavort && hasComment ? View.VISIBLE : View.GONE);

            final SnsPopupWindow snsPopupWindow = holder.snsPopupWindow;
            //判断是否已点赞
            String curUserFavortId = circleItem.getCurUserFavortId(DatasUtil.curUser.getId());
            if(!TextUtils.isEmpty(curUserFavortId)){
                snsPopupWindow.getmActionItems().get(0).mTitle = App.getInstance().getString(R.string.cancel);
            }else{
                snsPopupWindow.getmActionItems().get(0).mTitle =  App.getInstance().getString(R.string.like);
            }
            snsPopupWindow.update();
            snsPopupWindow.setmItemClickListener(new PopupItemClickListener(circlePosition, circleItem, curUserFavortId));
            holder.snsBtn.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //弹出popupwindow
                    snsPopupWindow.showPopupWindow(view);
                }
            });

            holder.urlTipTv.setVisibility(View.GONE);
            switch (holder.viewType) {
                case CircleViewHolder.TYPE_URL:// 处理链接动态的链接内容和和图片
                    if(holder instanceof URLViewHolder){
                        String linkImg = circleItem.getLinkImg();
                        final String linkTitle = circleItem.getLinkTitle();
                        Glide.with(context).load(linkImg).into(((URLViewHolder)holder).urlImageIv);
                        ((URLViewHolder)holder).urlContentTv.setText(linkTitle);
                        ((URLViewHolder)holder).urlContentTv.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                MobileBrowserActivity.actionStart(context,circleItem.getLinkUrl(),linkTitle);
                            }
                        });
                        ((URLViewHolder)holder).urlBody.setVisibility(View.VISIBLE);
                        ((URLViewHolder)holder).urlTipTv.setVisibility(View.VISIBLE);
                    }

                    break;
                case CircleViewHolder.TYPE_TEXT:// 处理文字
                    if(holder instanceof TextViewHolder){
                        String linkImg = circleItem.getLinkImg();
                        final String linkTitle = circleItem.getLinkTitle();
                        Glide.with(context).load(linkImg).into(((TextViewHolder)holder).urlImageIv);
                        ((TextViewHolder)holder).urlContentTv.setText(linkTitle);
//                        ((TextViewHolder)holder).urlContentTv.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                MobileBrowserActivity.actionStart(context,circleItem.getLinkUrl(),linkTitle);
//                            }
//                        });
                        ((TextViewHolder)holder).urlBody.setVisibility(View.GONE);
                        ((TextViewHolder)holder).urlTipTv.setVisibility(View.GONE);
                    }

                    break;
                case CircleViewHolder.TYPE_IMAGE:// 处理图片

                        final List<String> photos = circleItem.getThumbImages();
                        if (photos != null && photos.size() > 0) {
                            ((ImageViewHolder)holder).multiImageView.setVisibility(View.VISIBLE);
                            ((ImageViewHolder)holder).multiImageView.setList(photos);
                            ((ImageViewHolder)holder).multiImageView.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                                @Override
                                public void onItemClick(View view, int position) {

                                    //for,test game.
                                    if (GameModel.isChesse(circleItem.getContent())){
                                        UserFeedActivity.startChessGame((BaseActivity) context,circleItem.getUser().getId());
                                    }else{
                                        //imagesize是作为loading时的图片size
                                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                                        ImagePagerActivity.startImagePagerActivity(context, circleItem.getPhotos(), position, imageSize);

                                    }

                                       }
                            });
                        } else {
                            ((ImageViewHolder)holder).multiImageView.setVisibility(View.GONE);
                        }


                    break;
                case CircleViewHolder.TYPE_VIDEO:
                    if(holder instanceof VideoViewHolder){
                        ((VideoViewHolder)holder).videoView.setVideoUrl(circleItem.getVideoUrl());
                        ((VideoViewHolder)holder).videoView.setVideoImgUrl(circleItem.getVideoImgUrl());//视频封面图片
                        ((VideoViewHolder)holder).videoView.setPostion(position);
                        ((VideoViewHolder)holder).videoView.setOnPlayClickListener(new CircleVideoView.OnPlayClickListener() {
                            @Override
                            public void onPlayClick(int pos) {
                                curPlayIndex = pos;
                            }
                        });
                    }

                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public int getItemCount() {
        return datas.size()+1;//有head需要加1
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder{

        public HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

    private class PopupItemClickListener implements SnsPopupWindow.OnItemClickListener{
        private String mFavorId;
        //动态在列表中的位置
        private int mCirclePosition;
        private long mLasttime = 0;
        private CircleItem mCircleItem;

        public PopupItemClickListener(int circlePosition, CircleItem circleItem, String favorId){
            this.mFavorId = favorId;
            this.mCirclePosition = circlePosition;
            this.mCircleItem = circleItem;
        }

        @Override
        public void onItemClick(ActionItem actionitem, int position) {
            switch (position) {
                case 0://点赞、取消点赞
                    if(System.currentTimeMillis()-mLasttime<700)//防止快速点击操作
                        return;
                    mLasttime = System.currentTimeMillis();
                    if(presenter != null){
                        if (App.getInstance().getString(R.string.like).equals(actionitem.mTitle.toString())) {
                            presenter.addFavort(mCirclePosition,mCircleItem);
                        } else {//取消点赞
                            presenter.deleteFavort(mCirclePosition, mCircleItem.getId());
                        }
                    }
                    break;
                case 1://发布评论
                    if(presenter != null){
                        CommentConfig config = new CommentConfig();
                        config.circlePosition = mCirclePosition;
                        config.commentType = CommentConfig.Type.PUBLIC;
                        config.mCircleItem = mCircleItem;
                        presenter.showEditTextBody(config);
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
