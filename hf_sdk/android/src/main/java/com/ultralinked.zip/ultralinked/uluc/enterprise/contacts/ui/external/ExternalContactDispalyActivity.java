package com.ultralinked.uluc.enterprise.contacts.ui.external;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.FragmentCompanyContacts;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailListActivity;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * only show current Company's external partner
 */
public class ExternalContactDispalyActivity extends AppCompatActivity {

    public static final String TAG = "ExternalContactD";

    private ListView mDisplayExternalList;
    private ExternalContactAdapter mAdapter;

    private int mStep = 0;
    private HashMap<Integer, ArrayList<DepartUtils.CompanyElement>> UserClickPath = new HashMap<>();
    private HashMap<Integer, String> UserClickPathTitle = new HashMap<>();
    private TextView titleCenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.activity_external_contact_dispaly);

        initTitleBar();

        mAdapter = new ExternalContactAdapter(this);
        mDisplayExternalList = (ListView) findViewById(R.id.displayExternalList);

        final String _Id = getIntent().getStringExtra(FragmentCompanyContacts.CURRENT_COMPANY_ID);

        final ArrayList<DepartUtils.CompanyElement> data = getInitialDataByID(_Id);

        //record each step's data
        UserClickPath.put(mStep, data);
        UserClickPathTitle.put(mStep, getString(R.string.organization));

        mAdapter.setData(data);

        mDisplayExternalList.setAdapter(mAdapter);

        mDisplayExternalList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                DepartUtils.CompanyElement element = (DepartUtils.CompanyElement) parent.getAdapter().getItem(position);

                if (element.children2 == null || element.children2.length() == 0) {// it is a leaf, open detail page
                    Log.i(TAG, "I am a leaf with name " + element.name + "; id =" + element._id);

                    Intent gotoDetal = new Intent(ExternalContactDispalyActivity.this, DetailListActivity.class);
                    gotoDetal.putExtra(DetailListActivity.KEY_DETAIL, element);

                    gotoDetal.putExtra(DetailListActivity.KEY_PAENET_DEPT_NAME, element.name);
                    startActivity(gotoDetal);

                    return;
                } else {// has child
                    Log.i(TAG, " children2 " + element.children2.length());
                    ArrayList<DepartUtils.CompanyElement> subChildren = DepartUtils.getInstance().readCompanyStructure(element.children2);
                    Log.i(TAG, " subChildren " + subChildren.size());
                    mStep += 1;
                    UserClickPath.put(mStep, subChildren);
                    UserClickPathTitle.put(mStep, element.name);
                    titleCenter.setText(element.name);

                    mAdapter.setData(subChildren);
                    mAdapter.notifyDataSetChanged();
                    Log.i(TAG, "notifyDataSetChanged ");
                }
            }
        });

    }

    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.external));


        TextView titleRight = (TextView) findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onBackPressed() {

        goBack();

    }

    private void goBack() {
        if (mStep == 0) {

            UserClickPath.clear();
            UserClickPath = null;
            finish();

        } else {
            UserClickPath.put(mStep, null);
            UserClickPathTitle.put(mStep,null);
            mStep -= 1;
            titleCenter.setText(UserClickPathTitle.get(mStep));
            mAdapter.setData(UserClickPath.get(mStep));
            mAdapter.notifyDataSetChanged();
        }
    }


    private ArrayList<DepartUtils.CompanyElement> getInitialDataByID(String id) {
        //all these companys are stored
        ArrayList<DepartUtils.CompanyElement> data = DepartUtils.getInstance().getCompanyMap();
        for (DepartUtils.CompanyElement item : data) {

            if (item._id.equals(id)) {

                return DepartUtils.getInstance().readCompanyStructure(item.children2);
            }
        }
        return data;
    }

}
