package com.ultralinked.uluc.enterprise.utils;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.provider.Telephony;
import android.text.TextUtils;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by ultralinked on 16/9/20.
 */
public class ShareUtils {



    public static void tellFriend(Context context,String content) {
        tellFriend(context,content,null);

    }

    public static void tellFriend(Context context,String content,String sharedUserMobile) {

        if (TextUtils.isEmpty(content)){
            return;
        }
        String contentBrief = "";
        String shareUrl = "";
        Intent it = new Intent(Intent.ACTION_SEND);
        it.setType("text/plain");

        final List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(it, 0);

        final PackageManager packageManager = context.getPackageManager();

        Collections.sort(resInfo, new ResolveInfo.DisplayNameComparator(packageManager));

        // LogUtils.removeDuplicateWithOrder(resInfo);
        int i = 0;
        if (!resInfo.isEmpty()) {
            List<Intent> targetedShareIntents = new ArrayList<Intent>();
            String packageName = context.getPackageName();
            for (ResolveInfo info : resInfo) {
                Intent targeted = new Intent(Intent.ACTION_SEND);
                targeted.setType("text/plain");
                ActivityInfo activityInfo = info.activityInfo;
                // judgments : activityInfo.packageName, activityInfo.name, etc.
                if (activityInfo.packageName.equals(packageName)

                        ) {
                    continue;
                }
                if (activityInfo.packageName.contains("mail") || "com.google.android.gm".equals(activityInfo.packageName)) {
                    targeted.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.tell_friend_tips));
                    targeted.putExtra(Intent.EXTRA_TEXT, getTellFrindString(context,content ,null));

                } else if ((activityInfo.packageName.contains("sms")||activityInfo.packageName.contains("mms"))&&!TextUtils.isEmpty(sharedUserMobile)){
                  targeted = getSMSIntent(context,content,new String[]{sharedUserMobile});
                }else {
                    targeted.putExtra(Intent.EXTRA_TEXT, getTellFrindString(context,content ,null));
                }

                targeted.setClassName(activityInfo.packageName, activityInfo.name);
                targeted.setPackage(activityInfo.packageName);
                targetedShareIntents.add(targeted);//
                i++;
            }

            Intent chooserIntent = Intent.createChooser(targetedShareIntents.remove(0), context.getString(R.string.share_content));
            if (chooserIntent == null) {
                return;
            }
            // A Parcelable[] of Intent or LabeledIntent objects as set with
            // putExtra(String, Parcelable[]) of additional activities to place
            // a the front of the list of choices, when shown to the user with a
            // ACTION_CHOOSER.
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetedShareIntents.toArray(new Parcelable[] {}));
            try {
                context.startActivity(chooserIntent);
            } catch (android.content.ActivityNotFoundException ex) {

            }
        }

    }

    static String getTellFrindString(Context context, String content ,String language) {
            return content;


    }

    /**
     * @param activity
     *            which display the contact detail info instance
     * @param
     */
    public static void inviteToMessageULUC(Activity activity, String[] nonRCSAccounts ,String content) {

        String sharedContent = getTellFrindString(activity, content,null);

        sendSMS(activity,sharedContent,nonRCSAccounts);

    }

    public static void sendSMS(Activity activity, String sharedContent,String userAccount) {
        sendSMS(activity, sharedContent, new String[]{userAccount});
    }


    private static Intent getSMSIntent(Context context, String sharedContent,String[] nonRCSAccounts) {
        String accounts = "";
        String separator = ";";
		/*
		 * if(android.os.Build.MANUFACTURER!=null&&android.os.Build.MANUFACTURER.
		 * equalsIgnoreCase("samsung")){ separator = ","; }
		 */
        if (nonRCSAccounts.length == 1) {
            accounts = nonRCSAccounts[0];
        } else {
            for (int i = 0; i < nonRCSAccounts.length - 1; i++) {

                accounts += nonRCSAccounts[i] + separator;
            }
            accounts += nonRCSAccounts[nonRCSAccounts.length - 1];
        }

        Log.i("inviteToULUC", "accounts==" + accounts);
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) // Android 4.4
        // and up
        {
            String defaultSmsPackageName = Telephony.Sms.getDefaultSmsPackage(context);

            intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(accounts)));
            if (sharedContent!=null) {
                intent.putExtra("sms_body", sharedContent);
            }

            if (defaultSmsPackageName != null) // Can be null in case that there
            // is no default, then the user
            // would be able to choose any
            // app that supports this
            // intent.
            {
                intent.setPackage(defaultSmsPackageName);
            }
        } else {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setType("vnd.android-dir/mms-sms");
            intent.putExtra("address", accounts);
            if (sharedContent!=null) {
                intent.putExtra("sms_body", sharedContent);
            }
        }

       return  intent;
    }


    private static void sendSMS(Activity activity, String sharedContent,String[] nonRCSAccounts) {
        String accounts = "";
        String separator = ";";
		/*
		 * if(android.os.Build.MANUFACTURER!=null&&android.os.Build.MANUFACTURER.
		 * equalsIgnoreCase("samsung")){ separator = ","; }
		 */
        if (nonRCSAccounts.length == 1) {
            accounts = nonRCSAccounts[0];
        } else {
            for (int i = 0; i < nonRCSAccounts.length - 1; i++) {

                accounts += nonRCSAccounts[i] + separator;
            }
            accounts += nonRCSAccounts[nonRCSAccounts.length - 1];
        }

        Log.i("inviteToULUC", "accounts==" + accounts);
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) // Android 4.4
        // and up
        {
            String defaultSmsPackageName = Telephony.Sms.getDefaultSmsPackage(activity);

            intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(accounts)));
            if (sharedContent!=null) {
                intent.putExtra("sms_body", sharedContent);
            }

            if (defaultSmsPackageName != null) // Can be null in case that there
            // is no default, then the user
            // would be able to choose any
            // app that supports this
            // intent.
            {
                intent.setPackage(defaultSmsPackageName);
            }
        } else {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setType("vnd.android-dir/mms-sms");
            intent.putExtra("address", accounts);
            if (sharedContent!=null) {
                intent.putExtra("sms_body", sharedContent);
            }
        }
        activity.startActivity(intent);

    }

    public static String getUsername(Context context) {

        if (true) {
            String userName = MLoginApi.currentAccount.nickName;
            if (userName == null) {
                return "";
            }
            return userName+" ";//add space.
        }

        AccountManager manager = AccountManager.get(context);
        Account[] accounts = manager.getAccounts();
        List<String> possibleEmails = new LinkedList<String>();

        for (Account account : accounts) {
            // TODO: Check possibleEmail against an email regex or treat
            // account.name as an email address only for certain account.type
            // values.
            possibleEmails.add(account.name);
        }

        if (!possibleEmails.isEmpty() && possibleEmails.get(0) != null) {
            String email = possibleEmails.get(0);
            String[] parts = email.split("@");
            if (parts.length > 0 && parts[0] != null)
                return parts[0] + " ";
            else
                return "";
        } else
            return "";
    }


    public static void shareMessage(Context context, Message message) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("*/*");
        int msgType = message.getType();
        if (message instanceof FileMessage) {
            if (!com.ultralinked.voip.api.utils.FileUtils.isFileExist(((FileMessage) message).getFilePath())){
                Log.i("share","can not find the share file:"+message.toString());
                return;
            }
            if (msgType == Message.MESSAGE_TYPE_VIDEO) {
                i.setType("video/*");
            } else if (msgType == Message.MESSAGE_TYPE_VCARD) {
                i.setType("text/x-vcard");
            } else if (msgType == Message.MESSAGE_TYPE_IMAGE) {
                i.setType("image/*");
            } else if (msgType == Message.MESSAGE_TYPE_VOICE) {
                i.setType("audio/amr");
            }
        } else {
            i.setType("text/plain");
        }

        String title = "";
        final List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(i, 0);

        final PackageManager packageManager = context.getPackageManager();

        Collections.sort(resInfo, new ResolveInfo.DisplayNameComparator(packageManager));
        // LogUtils.removeDuplicateWithOrder(resInfo);
        if (!resInfo.isEmpty()) {
            List<Intent> targetedShareIntents = new ArrayList<Intent>();
            for (ResolveInfo info : resInfo) {
                Intent targeted = new Intent(Intent.ACTION_SEND);

                ActivityInfo activityInfo = info.activityInfo;
                if (message instanceof FileMessage) {
                    String userName = getUsername(context);
                    FileMessage mFileMessage = (FileMessage) message;
                    int messageType = message.getType();
                    File file = new File(mFileMessage.getFilePath());
                    String app_name = "";
                    if (msgType == Message.MESSAGE_TYPE_VIDEO) {
                        targeted.setType("video/*");
                        title = userName + context.getString(R.string.share_has_sent_you,context.getString(R.string.video));
                    } else if (messageType == Message.MESSAGE_TYPE_VCARD) {
                        targeted.setType("text/x-vcard");
                        title = userName + context.getString(R.string.share_has_sent_you,context.getString(R.string.vcard));
                    } else if (msgType == Message.MESSAGE_TYPE_IMAGE) {
                        targeted.setType("image/*");
                        title = userName + context.getString(R.string.share_has_sent_you,context.getString(R.string.image));
                    } else if (messageType == Message.MESSAGE_TYPE_VOICE) {
                        targeted.setType("audio/amr");
                        title = userName +context.getString(R.string.share_has_sent_you,context.getString(R.string.voice));
                    }
                    // mail need add title
                    if (activityInfo.packageName.contains("mail") || "com.google.android.gm".equals(activityInfo.packageName)) {
                        targeted.putExtra(Intent.EXTRA_SUBJECT, title);
                    }

                    targeted.putExtra(
                            Intent.EXTRA_TEXT,
                            title
                                    + "\n\n"
                                    + context.getString(R.string.no_conversations,context.getString(R.string.app_name))+". http://www.sealedchat.com");
                    targeted.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
                } else {
                    targeted.setType("text/plain");
                    targeted.putExtra(Intent.EXTRA_TEXT, "" + message.getBody());
                }

                targeted.setClassName(activityInfo.packageName, activityInfo.name);
                targeted.setPackage(activityInfo.packageName);
                targetedShareIntents.add(targeted);

            }

            Intent chooserIntent = Intent.createChooser(targetedShareIntents.remove(0), context.getString(R.string.share_content));
            if (chooserIntent == null) {
                return;
            }
            // A Parcelable[] of Intent or LabeledIntent objects as set with
            // putExtra(String, Parcelable[]) of additional activities to place
            // a the front of the list of choices, when shown to the user with a
            // ACTION_CHOOSER.
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetedShareIntents.toArray(new Parcelable[] {}));
            try {
                context.startActivity(chooserIntent);
            } catch (android.content.ActivityNotFoundException ex) {
               Log.i("share","No share application found");
            }
        }

    }
}
