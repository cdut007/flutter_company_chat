package com.ultralinked.uluc.enterprise.more;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.baseui.widget.OTPButton;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class ChangeMobileActivity extends BaseActivity implements View.OnClickListener{

    EditText edPassword,etOtp;
    EditViewPlus etMobile;
    OTPButton otpButton;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_change_mobile;
    }


    @Override
    public void initView(Bundle savedInstanceState) {
        etMobile=bind(R.id.etChangeMobile);
        etMobile.setHint(getString(com.holdingfuture.flutterapp.hfsdk.R.string.hint_mobile));
        edPassword =bind(R.id.etPassword);
        otpButton = bind(R.id.btRequest);

        if (SPUtil.getLoginModel()==SPUtil.LOGIN_BY_OTP && !SPUtil.getUserHasPsd()){
            goneView(edPassword);
            //goneView(bind(R.id.etPasswordLine));
        }

//        RegexValidateUtils.bindMobile(etMobile);
//        RegexValidateUtils.bindMobile(edPassword);

        etOtp=bind(R.id.etOTP);
        initListener(this,R.id.etChangeMobile,R.id.left_back,R.id.btChange,R.id.btRequest);
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.change_mobile_number);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.etChangeMobile:
                Intent intent = new Intent(this, CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
                break;

            case R.id.left_back:
                finish();
                break;

            case R.id.btRequest:
                String mobile=etMobile.getTextAll();
                if(!RegexValidateUtils.checkCellphone(mobile)){
                    showToast(R.string.check_mobile);
                    return;
                }
                otpButton.click(new OTPButton.OnRequestTypeListener() {
                    @Override
                    public void clickType(String type) {
                                request_otp(type);
                    }
                });

                break;

            case R.id.btChange:
               final String number=etMobile.getTextAll();
                String password= edPassword.getText().toString();
                String otp=etOtp.getText().toString();
                if(!RegexValidateUtils.checkCellphone(number)){
                    showToast(R.string.check_mobile);
                    return;
                }

                if(SPUtil.getUserHasPsd() && TextUtils.isEmpty(password)){
                    showToast(R.string.check_password);
                    return;
                }
                if(TextUtils.isEmpty(otp)){
                    showToast(R.string.check_otp);
                    return;
                }
                showDialog(getString(R.string.loading));
                ApiManager.getInstance().change_mobile(
                        RegexValidateUtils.normalizeNumber(number),otp,password)
                        .compose(this.<ResponseBody>bindToLifecycle())
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .throttleFirst(2,TimeUnit.SECONDS)
                        .subscribe(new Subscriber<ResponseBody>() {
                            @Override
                            public void onCompleted() {
                                Log.i(TAG,"verfiyChangeMobileActivityComplted");
                            }
                            @Override
                            public void onError(Throwable e) {
                                String eMsg = HttpErrorException.handErrorMessage(e);
                                closeDialog();
                                showToast(eMsg+"");
                                android.util.Log.e(TAG, "verfiyChangeMobileActivityComplted error " + eMsg);
                            }
                            @Override
                            public void onNext(ResponseBody responseBody) {
                                String body = "";
                                try {
                                    body = responseBody.string();
                                    JSONObject object = new JSONObject(body);
                                    int code = object.optInt("code");
                                    if (200 == code) {
                                        showToast(getString(R.string.option_success));
                                        //update the mobile.
                                        SPUtil.saveMobile(RegexValidateUtils.normalizeNumber(number));
                                        //update contact
                                        RxBus.getDefault().post(new PeopleEntity());
                                    }else{
                                        showToast("errorcode:"+code+"\n"+object.optString("description"));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    showToast(android.util.Log.getStackTraceString(e));
                                }
                                Log.i(TAG, body);
                                closeDialog();

                                finish();
                            }

                        });
                break;
        }
    }

    private void request_otp(final String type) {
        ApiManager.getInstance().request_otp(etMobile.getTextAll(),"change_mobile",type)
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"changeMobileComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        otpButton.cancelCountDown();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "changeMobile error " + eMsg);
                        showToast(eMsg+"");
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String body="";
                        try {
                            body=responseBody.string();
                            JSONObject object = new JSONObject(body);
                            int code = object.optInt("code");
                            if (200 == code) {
                                if ("voice".equals(type)){
                                    showToast(getString(R.string.voice_sms_code_has_sent_you));

                                }else {
                                    showToast(getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).substring(0, getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).indexOf("%s")) + etMobile.getTextAll());
                                }
                            }else{
                                showToast("errorcode:"+code+"\n"+object.optString("description"));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            showToast(android.util.Log.getStackTraceString(e)+"\n"+body);
                        }
                        Log.i(TAG,body);
                    }
                });



        //
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG,requestCode+"  "+resultCode);
        if(data!=null)
            etMobile.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
    }
}
