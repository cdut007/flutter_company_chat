package com.ultralinked.uluc.enterprise.more;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.call.CallActivity;
import com.ultralinked.uluc.enterprise.call.CallLog;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.bean.DeviceInfo;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.StringUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class SettingRemoteDestrcutActivity extends BaseActivity implements View.OnClickListener {

    private DeviceInfoAdapter adapter;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_setting_remote_destruct;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    DeviceInfo currentDeviceInfo =null;
    ListView remoteDevicesListView;
    @Override
    public void initView(Bundle savedInstanceState) {
        ((TextView)bind(R.id.titleCenter)).setText(R.string.remote_destrcut);
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(this);
        initRemoteInfosView();
        try {
            currentDeviceInfo = DeviceInfo.getInfos();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    private void initRemoteInfosView() {
        remoteDevicesListView = bind(R.id.remote_devices_list);
        remoteDevicesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                final DeviceInfo deviceInfo = adapter.getItem(position);
                if (currentDeviceInfo!=null&&currentDeviceInfo.device_id.equals(deviceInfo.device_id)){
                    return;
                }

                if (SPUtil.getLoginModel()==SPUtil.LOGIN_BY_OTP && !SPUtil.getUserHasPsd()){
                    showToast(R.string.set_user_password);
                }else{
                    String hint_psd = getString(com.holdingfuture.flutterapp.hfsdk.R.string.contact_private_password);
                    DialogManager.showInputDialog(getActivity(), getString(com.holdingfuture.flutterapp.hfsdk.R.string.contact_private_inputpassword), new String[]{hint_psd},
                            new DialogManager.OnDialogListener() {

                                @Override
                                public void onCancelClick(View v) {

                                }

                                @Override
                                public void onOkClick(View v, CharSequence[] intems, Dialog dialog) {

                                    if (deviceInfo.status == DeviceInfo.NORMAL){
                                        destroyDevice(deviceInfo,intems[0].toString());
                                    }else if(deviceInfo.status == DeviceInfo.DESTROYED||
                                            deviceInfo.status == DeviceInfo.PENDING
                                            ){
                                        //recovery
                                        recoveryDevice(deviceInfo,intems[0].toString());
                                    }else{
                                        //pending do nothing,
                                    }
                                    dialog.dismiss();

                                }
                            });
                }

            }
        });

       fetchDevicesDatas();
    }

    private void recoveryDevice(final DeviceInfo deviceInfo,String password) {
        String str1 = getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();
        ApiManager.getInstance().recoveryDevice(password,deviceInfo.device_id)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"recoveryDeviceComplted");
                        progressDialog.cancel();
                    }
                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, HttpErrorException.handErrorMessage(e));
                        progressDialog.cancel();

                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String body = "";
                        try {
                            body = responseBody.string();
                            JSONObject object = new JSONObject(body);
                            int code = object.optInt("code");
                            if (200 == code) {
                                deviceInfo.status = DeviceInfo.NORMAL;
                                adapter.updateItem(deviceInfo);
                                showToast(object.optString("result"));
                            }else{
                                showToast("errorcode:"+code+"\n"+object.optString("description"));
                                Log.i(TAG,"recoveryDevice error:"+"errorcode:"+code+"\n"+object.optString("description"));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            showToast(android.util.Log.getStackTraceString(e));
                        }
                        Log.i(TAG,"recoveryDevice=="+body);
                    }

                });

    }

    private void destroyDevice(final DeviceInfo deviceInfo, String password) {
        String str1 = getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();
        ApiManager.getInstance().destroyDevice(password,deviceInfo.device_id)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"destroyDeviceComplted");
                        progressDialog.cancel();
                    }
                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, HttpErrorException.handErrorMessage(e));
                        progressDialog.cancel();
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String body = "";
                        try {
                            body = responseBody.string();
                            JSONObject object = new JSONObject(body);
                            int code = object.optInt("code");
                            if (200 == code) {
                                deviceInfo.status = DeviceInfo.PENDING;
                                adapter.updateItem(deviceInfo);
                                showToast(object.optString("result"));
                            }else{
                                showToast("errorcode:"+code+"\n"+object.optString("description"));
                                Log.i(TAG,"destroyDevice error:"+"errorcode:"+code+"\n"+object.optString("description"));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            showToast(android.util.Log.getStackTraceString(e));
                        }
                        Log.i(TAG,"destroyDevice=="+body);
                    }

                });

    }


    private void fetchDevicesDatas() {

            ApiManager.getInstance().getTheUserDevices()
                    .subscribeOn(Schedulers.io())
                    .compose(this.<ResponseBody>bindToLifecycle())
                    .throttleFirst(2, TimeUnit.SECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<ResponseBody>() {
                        @Override
                        public void onCompleted() {
                            Log.i(TAG,"getTheUserDevicesComplted");
                        }
                        @Override
                        public void onError(Throwable e) {
                            Log.e(TAG, HttpErrorException.handErrorMessage(e));

                        }
                        @Override
                        public void onNext(ResponseBody responseBody) {

                            String body = "";
                            try {
                                body = responseBody.string();
                                JSONObject object = new JSONObject(body);
                                int code = object.optInt("code");
                                if (200 == code) {
                                    List<DeviceInfo> deviceInfoList = new ArrayList<DeviceInfo>();
                                    Gson gson = new Gson();
                                    deviceInfoList = gson.fromJson(object.optString("result"),
                                            new TypeToken<List<DeviceInfo>>() { }.getType());
                                     updateDatas(deviceInfoList);
                                }else{
                                   Log.i(TAG,"fetchDevices error:"+"errorcode:"+code+"\n"+object.optString("description"));
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                showToast(android.util.Log.getStackTraceString(e));
                            }
                            Log.i(TAG,"fetchDevicesDatas=="+body);
                        }

                    });

    }


    void updateDatas(List<DeviceInfo> deviceInfos){
        if (adapter == null) {
            adapter = new DeviceInfoAdapter(SettingRemoteDestrcutActivity.this, R.layout.item_remote_device, null);
            remoteDevicesListView.setAdapter(adapter);
        }
        adapter.updateList(deviceInfos);
    }

    class DeviceInfoAdapter extends MyBaseAdapter<DeviceInfo> {
        public DeviceInfoAdapter(Context context, int resource, List<DeviceInfo> list) {
            super(context, resource, list);
        }

        @Override
        public void setHolder(MyHolder holder, DeviceInfo deviceInfo) {
            if (deviceInfo == null)
                return;

            if (currentDeviceInfo!=null&&currentDeviceInfo.device_id.equals(deviceInfo.device_id)){
                holder.setText(R.id.device_name, deviceInfo.device_name+"("+getString(R.string.local_device)+")");
            }else{
                holder.setText(R.id.device_name, deviceInfo.device_name);
            }


            if (deviceInfo.status == DeviceInfo.DESTROYED){
                holder.setTextColor(R.id.device_name, getResources().getColor(R.color.color_red));
            }else if(deviceInfo.status == DeviceInfo.PENDING){
                holder.setTextColor(R.id.device_name, getResources().getColor(R.color.color_f0b012));
            }else{
                holder.setTextColor(R.id.device_name, getResources().getColor(R.color.color_000000));
            }
            holder.setText(R.id.device_type, deviceInfo.device_type);


        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;

        }
    }
}
