package com.ultralinked.uluc.enterprise.pay;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/9.
 */

public class TransactionRecordsActivity extends BaseActivity implements View.OnClickListener,BaseRecyclerAdapter.OnItemClickListener{

    RecyclerView mRecyclerView;
    HistoryAdapter adapter;
    List<RechargeRecordModel> mRechargeList;

    Subscription mRefreshSubscription;


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_recharge_record;
    }

    @Override
    protected void setTopBar() {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.transaction_records);
        initListener(this, R.id.left_back);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        createRefreshSubscription();
        mRecyclerView = bind(R.id.recycler_recharge_record);
        getRechargeRecord();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
        }
    }

    private void createRefreshSubscription() {
        if (mRefreshSubscription == null) {
            mRefreshSubscription = RxBus.getDefault().toObservable(String.class)
                    .subscribe(new Action1<String>() {
                        @Override
                        public void call(String text) {
                            if (text.equals(BillingDetailsActivity.SUCCESS)) {
                                getRechargeRecord();
                            }
                        }
                    }, new Action1<Throwable>() {
                        @Override
                        public void call(Throwable throwable) {
                            Log.e(TAG, "Recharge subscription error!");
                        }
                    });
        }
    }

    @Override
    protected void onDestroy() {
        if (mRefreshSubscription != null && !mRefreshSubscription.isUnsubscribed()) {
            mRefreshSubscription.unsubscribe();
        }
        super.onDestroy();
    }

    private void getRechargeRecord() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getRechargeRecord()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        if(mRechargeList==null)
                            mRechargeList = new ArrayList<>();
                        if(adapter == null){
                            mRecyclerView.setLayoutManager(new LinearLayoutManager(TransactionRecordsActivity.this));
                            mRecyclerView.addItemDecoration(new DividerLinearDecoration(TransactionRecordsActivity.this, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_10_0_dp, R.dimen.px_10_0_dp));
                            adapter = new HistoryAdapter(TransactionRecordsActivity.this, mRechargeList);
                            adapter.setOnItemClickListener(TransactionRecordsActivity.this);
                            mRecyclerView.setAdapter(adapter);
                        }else{
                            adapter.updateData(mRechargeList);
                        }
                        Log.i(TAG, "getRechargeRecord successfully");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getRechargeRecord unsuccessfully： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            JSONObject object = new JSONObject(response);
                            if (object.optInt("code") == 200) {
                                mRechargeList = new Gson().fromJson(object.optString("objects"), new TypeToken<List<RechargeRecordModel>>() {
                                }.getType());
                            } else {
                                Log.e(TAG, "Recharge record return code doesn't equal 200!");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    @Override
    public void onItemClick(View itemView, int pos) {
        Intent intent = new Intent(this,BillingDetailsActivity.class);
        intent.putExtra("recordModel",mRechargeList.get(pos));
        startActivity(intent);
    }

    class HistoryAdapter extends BaseRecyclerAdapter<RechargeRecordModel, RecyclerViewHolder> {

        HistoryAdapter(Context ctx, List<RechargeRecordModel> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_recharge_record;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, RechargeRecordModel itemData) {
            try {
                String time = itemData.getCreated_at();
                holder.getTextView(R.id.txt_recharge_time).setText(time.substring(0, time.indexOf(" ")).replace("-", "."));
            }catch (Exception ex){
                Log.e(TAG,android.util.Log.getStackTraceString(ex));
            }
//                holder.getTextView(R.id.txt_recharge_time).setText(itemData.getCreated_at().replace(" ","\n"));
            String direction = itemData.getDirection();
            if(!TextUtils.isEmpty(direction)){
                switch (direction){
                    case "out":
                        holder.getTextView(R.id.txt_recharge_amount).setText(String.format(getString(R.string.out_recharge_amount), itemData.getPayment_value()));
                        break;
                    case "in":
                        holder.getTextView(R.id.txt_recharge_amount).setText(String.format(getString(R.string.recharge_amount), itemData.getPayment_value()));
                        break;
                    default:
                        holder.getTextView(R.id.txt_recharge_amount).setText(String.format(getString(R.string.recharge_amount), itemData.getPayment_value()));
                        break;
                }
            }else{
                holder.getTextView(R.id.txt_recharge_amount).setText(String.format(getString(R.string.recharge_amount), itemData.getPayment_value()));
            }
            if(!TextUtils.isEmpty(itemData.getProduct_type())){
                holder.getTextView(R.id.txt_recharge_description).setText(itemData.getProduct_type());
            }else{
                holder.getTextView(R.id.txt_recharge_description).setText("");
            }
            String paymentProviderId = itemData.getPayment_providerid();
            if(TextUtils.isEmpty(paymentProviderId)){
                holder.getImageView(R.id.img_recharge_method).setImageDrawable(null);
            }else{
                int providerId = -1000;
                try {
                    providerId = Integer.valueOf(paymentProviderId);
                }catch (NumberFormatException ex){
                    Log.e(TAG,"paymentProviderId error: "+android.util.Log.getStackTraceString(ex));
                }
                switch (providerId) {
                    case 1:
                        holder.getImageView(R.id.img_recharge_method).setImageDrawable(null);
                        break;
                    case 2:
                        holder.getImageView(R.id.img_recharge_method).setImageResource(R.mipmap.history_wechat_icon);
                        break;
                    case 3:
                        holder.getImageView(R.id.img_recharge_method).setImageResource(R.mipmap.history_paypal_icon);
                        break;
                    case 4:
                        holder.getImageView(R.id.img_recharge_method).setImageResource(R.mipmap.history_cash_icon);
                        break;
                    case 5:
                        holder.getImageView(R.id.img_recharge_method).setImageResource(R.mipmap.history_balance_pay_icon);
                        break;
                    default:
                        holder.getImageView(R.id.img_recharge_method).setImageDrawable(null);
                        break;
                }
            }
            TextView mStatus = holder.getTextView(R.id.txt_recharge_status);
            if (TextUtils.isEmpty(itemData.getPayment_success())) {
                mStatus.setText("");
            } else {
                int status = -1000;
                try {
                    status = Integer.parseInt(itemData.getPayment_success());
                } catch (NumberFormatException ex) {
                    Log.e(TAG, android.util.Log.getStackTraceString(ex));
                }
                switch (status) {
                    case PaymentActivity.CANCEL:
                        mStatus.setText(R.string.canceled);
                        break;
                    case PaymentActivity.UNCOMPLETED:
                        mStatus.setText(R.string.failed);
                        break;
                    case PaymentActivity.WAITING_CONFIRM:
                        mStatus.setText(R.string.waiting_confirm);
                        break;
                    case PaymentActivity.COMPLETED:
                        mStatus.setText(R.string.success);
                        break;
                    default:
                        mStatus.setText("");
                        break;
                }
                if (status == PaymentActivity.WAITING_CONFIRM) {
                    mStatus.setTextColor(getResources().getColor(R.color.color_f32f00));
                } else {
                    mStatus.setTextColor(getResources().getColor(R.color.color_858a91));
                }
            }
        }

    }

}
