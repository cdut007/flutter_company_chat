package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ultralinked on 16/7/15.
 */
public class ReadMembersTask {

    private static final String EXIST_USER = "(a." + PersonnelContract.PersonnelColumn.DELETE_DATE + " is NULL OR  a."
            + PersonnelContract.PersonnelColumn.DELETE_DATE + " ='' OR  a."
            + PersonnelContract.PersonnelColumn.DELETE_DATE + " ='None' " +
            ") ";
    private static String mSelection;
    private final int ID;

    public ReadMembersTask(final Context context, int ID) {

        mContext = context;

        this.ID = ID;
        mLoader = new LoaderManager.LoaderCallbacks<Cursor>() {

            @Override
            public Loader<Cursor> onCreateLoader(int id, Bundle args) {
                Log.i(TAG, "onCreateLoader");

                if (SPUtil.getFindContactsSetting()) {
                    Uri contentUri;
                    if (TextUtils.isEmpty(searchWord)) {
                        // Since there's no search string, use the content URI that searches the entire
                        // Contacts table
                        contentUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
                    } else {
                        // Since there's a search string, use the special content Uri that searches the
                        // Contacts table. The URI consists of a base Uri and the search string.
                        contentUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(searchWord));
                    }


                    return new CursorLoader(context, contentUri,
                            null, ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + " > 0", null, "sort_key");
                }

                //read the join talble of personnel and relation
                return new CursorLoader(context, PersonnelContract.CONTENT_URI.buildUpon().appendPath("all").build(), null,
                        mSelection /* selection */,
                        null /* selectionArgs */,
                        PersonnelContract.PersonnelColumn.PINYIN /* sortOrder */);
            }

            @Override
            public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

                Log.i(TAG, "onLoadFinished " + loader.getId());
                if (data == null) {
                    Log.i(TAG, "onLoadFinished but cursor is null");
                } else {
                    Log.i(TAG, "onLoadFinished the cursor count is :" + data.getCount());
                }
                readContact(data);
            }


            @Override
            public void onLoaderReset(Loader<Cursor> loader) {

                Log.i(TAG, "onLoaderReset" + loader.getId());
            }
        };
    }

    String companyId;

    public void restCompany(String companyId) {

        this.companyId = companyId;
        reset();
    }

    String searchWord;

    public void resetLoader(String searchWord) {

        this.searchWord = searchWord;
        reset();
    }

    private void reset() {
        //reset the sql ,do not remove.
        Log.i(TAG, "resetLoader " + searchWord + ";companyId==" + companyId + ";get the database name:" + DbSQLHelper.DATABASE_NAME);

        if (!TextUtils.isEmpty(searchWord)) {

            searchWord = searchWord.trim();
            searchWord = searchWord.replaceAll("\'", "");//fix bug
        }
        Log.i(TAG, "searchWord " + searchWord);
        if (TextUtils.isEmpty(searchWord)) {

            mSelection = null;//EXIST_USER;

        } else {

            mSelection = searchWord;

        }


        if (mContext instanceof FragmentActivity) {
            Log.i(TAG, "resetLoader restartLoader");
            ((FragmentActivity) mContext).getSupportLoaderManager().restartLoader(ID, null, mLoader);
        }
    }

    public interface onContactReadFinishListener {

        void setAdapter(List<PeopleEntity> internal, List<PeopleEntity> external);

    }


    public static final String TAG = "ReadMembersTask";

    LoaderManager.LoaderCallbacks<Cursor> mLoader;

    private HashMap<String, PeopleEntity> mMap_Internal = new HashMap<>();
    private HashMap<String, PeopleEntity> mMap_External = new HashMap<>();


    private List<PeopleEntity> mDatas_Internal = new ArrayList<>();
    private List<PeopleEntity> mDatas_External = new ArrayList<>();

    private Context mContext;
    private onContactReadFinishListener mListener;

    public void registerListener(onContactReadFinishListener listener) {

        mListener = listener;
    }

    public void unregisterListener(Context context) {

        mContext = null;
        mListener = null;
    }

    public LoaderManager.LoaderCallbacks<Cursor> getLoader() {

        return mLoader;
    }

    /**
     * read personnel info into list of people entity
     *
     * @param cursor
     */
    private void readContact(Cursor cursor) {


        mMap_Internal.clear();
        mMap_External.clear();


        if (cursor == null || cursor.getCount() == 0) {
            Log.i(TAG, " readContact null ");

            mDatas_Internal = new ArrayList<>(mMap_Internal.values());
            mDatas_External = new ArrayList<>(mMap_External.values());
            if (mListener != null) {

                mListener.setAdapter(mDatas_Internal, mDatas_External);
            }
            return;
        }


        cursor.moveToFirst();

        String CountryCode = SPUtil.getCode();
        if (SPUtil.getFindContactsSetting()) {
            do {

                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                if (TextUtils.isEmpty(phone)){
                    Log.i(TAG,"phone number is empty ,user contact name:"+name);
                    continue;
                }
                PeopleEntity peopleEntity = new PeopleEntity();
                peopleEntity.name = name;
                peopleEntity.nickname = name;
                peopleEntity.mobile = phone;

                String numberPrfex = CountryCode;

                String matchPhone = PhoneNumberUtils.normalizeMatchNumber(numberPrfex,phone);

                PeopleEntity matchPhoneEntity = SPUtil.registerAccount.get(matchPhone);
                if (PeopleEntityQuery.hasFoundPeople(matchPhoneEntity)) {
                    peopleEntity = matchPhoneEntity;
                    peopleEntity.name = name;
                    peopleEntity.nickname = name;
                }else{
                    continue;
                }

                if (!"External".equalsIgnoreCase(peopleEntity.deparment_type)) {
                    peopleEntity.deparment_type = "Internal";
                }

                if ("Internal".equalsIgnoreCase(peopleEntity.deparment_type) || TextUtils.isEmpty(peopleEntity.deparment_type)) {//contains friend.


                    if (!mMap_Internal.containsKey(peopleEntity.subuser_id)) {

                        mMap_Internal.put(peopleEntity.subuser_id, peopleEntity);
                    } else {
                        if (!TextUtils.isEmpty(peopleEntity.icon_url)) {//maybe from the frist friend.?
                            mMap_Internal.put(peopleEntity.subuser_id, peopleEntity);
                        }
                    }

                } else {

                    if (!mMap_External.containsKey(peopleEntity.subuser_id)) {

                        mMap_External.put(peopleEntity.subuser_id, peopleEntity);
                    }
                }

            } while (cursor.moveToNext());
        } else {
            do {
                PeopleEntity peopleEntity = DbSQLHelper.readPeopleBaseColumns(cursor);


                peopleEntity.deparment_type = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_TYPE));
                peopleEntity.deparment_id = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPART_ID));

                peopleEntity.companyid = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.COMPANY_ID));
                peopleEntity.deparment_name = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_NAME));
                peopleEntity.companyName = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.COMPANY_NAME));


                if (!"External".equalsIgnoreCase(peopleEntity.deparment_type)) {
                    peopleEntity.deparment_type = "Internal";
                }

                if ("Internal".equalsIgnoreCase(peopleEntity.deparment_type) || TextUtils.isEmpty(peopleEntity.deparment_type)) {//contains friend.


                    if (!mMap_Internal.containsKey(peopleEntity.subuser_id)) {

                        mMap_Internal.put(peopleEntity.subuser_id, peopleEntity);
                    } else {
                        if (!TextUtils.isEmpty(peopleEntity.icon_url)) {//maybe from the frist friend.?
                            mMap_Internal.put(peopleEntity.subuser_id, peopleEntity);
                        }
                    }

                } else {

                    if (!mMap_External.containsKey(peopleEntity.subuser_id)) {

                        mMap_External.put(peopleEntity.subuser_id, peopleEntity);
                    }
                }

            } while (cursor.moveToNext());
        }


        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

        mDatas_Internal = new ArrayList<>(mMap_Internal.values());
        mDatas_External = new ArrayList<>(mMap_External.values());
        sort(mDatas_Internal);
        sort(mDatas_External);

        if (mListener != null) {
            mListener.setAdapter(mDatas_Internal, mDatas_External);
        }

    }

    private void sort(List<PeopleEntity> data) {
        try {
            Collections.sort(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
