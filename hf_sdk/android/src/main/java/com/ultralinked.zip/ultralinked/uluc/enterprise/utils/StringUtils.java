package com.ultralinked.uluc.enterprise.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ultralinked.voip.api.BitmapUtils;

import android.R.integer;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.Html.ImageGetter;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.UnderlineSpan;

public class StringUtils {
    private static final String TAG = "StringUtils";
    private HashMap<String, Integer> CharMapId;
    private Context mContext;

    public static StringUtils getInstance(HashMap<String, Integer> CharMapId, Context ctx) {
        return new StringUtils(CharMapId, ctx);
    }

    protected StringUtils(HashMap<String, Integer> CharMapId, Context ctx) {
        this.CharMapId = CharMapId;
        this.mContext = ctx;
    }


    public static SpannableStringBuilder getSpanedStringText(SpannableString text, String keyword) {
//		Pattern patten = Pattern.compile(keyword, Pattern.CASE_INSENSITIVE);
//		Matcher matcher = patten.matcher(text);
        SpannableStringBuilder style = new SpannableStringBuilder(text);
        String textStr = text.toString();
        int index = textStr.indexOf(keyword, 0);
        int len = keyword.length();
        while (index >= 0) {
            style.setSpan(new ForegroundColorSpan(Color.RED), index, index + len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            index = textStr.indexOf(keyword, index + 1);
        }
        return style;
    }

    public static SpannableStringBuilder getSpanedStringText(String text, String keyword) {
//		
//		Pattern patten = Pattern.compile(keyword, Pattern.CASE_INSENSITIVE);
//		Matcher matcher = patten.matcher(text);
        SpannableStringBuilder style = new SpannableStringBuilder(text);
        int index = text.indexOf(keyword, 0);
        int len = keyword.length();
        while (index >= 0) {
            style.setSpan(new ForegroundColorSpan(Color.RED), index, index + len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            index = text.indexOf(keyword, index + 1);
        }
        return style;
    }

    public Spanned getSpannedString(String content, int width, int height) {

        String[] emotions = content.split(" ");

        Map<String, Integer> emotionStrMapId = new HashMap<String, Integer>();
        for (String emotion : emotions) {
            String temp = emotion.trim();
            if (temp.length() != 0 && CharMapId.containsKey(temp)) {
                emotionStrMapId.put(temp, CharMapId.get(temp));
            }
        }

        StringBuffer sb = new StringBuffer(content);
        for (Entry<String, Integer> entry : emotionStrMapId.entrySet()) {
            int emotionId = entry.getValue();
            String key = entry.getKey();
            int emotionPosition = sb.indexOf(key);
        }

        Log.i(TAG, "resize pic");
        return null;

    }


    //get SpannableString
    private SpannableString getSpannableStr(String content, String appendedStr, Drawable drawable) {
        SpannableString spannable = new SpannableString(content + appendedStr);
        ImageSpan span = new ImageSpan(drawable, ImageSpan.ALIGN_BASELINE);
        spannable.setSpan(span, content.length(), content.length() + appendedStr.length(), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        return spannable;
    }

    //get compressed emotion
    private Drawable getCompressedBitmap(int resourceId, int width, int height) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;

        BitmapFactory.decodeResource(mContext.getResources(), resourceId, opts);
        opts.inSampleSize = BitmapUtils.computeSampleSize(opts, -1, width * height);
        opts.inJustDecodeBounds = false;

        try {
            Bitmap emotion = BitmapFactory.decodeResource(mContext.getResources(), resourceId, opts);
            BitmapDrawable drawable = new BitmapDrawable(emotion);
            drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
            return drawable;
        } catch (OutOfMemoryError err) {
        }
        return null;
    }


    public static CharSequence getMatchKeyword(String content, String searchContent, int start, int end) {
        SpannableStringBuilder style = new SpannableStringBuilder(content);
        if (content.equals(searchContent)) {
            style.setSpan(new ForegroundColorSpan(Color.RED), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            return style;
        }
        // if start < 0, start > end or end > length().
        if (start < 0) {
            Log.i(TAG, "search not match ===" + searchContent);
            return style;
        }
        String searchKey = searchContent.substring(start, end);

        int startIndex = content.indexOf(searchKey);
        if (startIndex > -1) {
            style.setSpan(new ForegroundColorSpan(Color.RED), startIndex, startIndex + searchKey.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            return style;
        } else {
            Log.i(TAG, "search not match searchKey===" + searchKey);
            return content;
        }
    }

    /**
     * @param text  The original text.
     * @param parts  The part of text need to change color.
     * @param color The color that part changes to.
     * @return
     */
    public static SpannableString getDifferColorString(String text, String[] parts, int color, boolean isUnderlined) {
        SpannableString result = new SpannableString(text);
        for (String part : parts) {
            int start = text.indexOf(part);
            if (start != -1) {
                result.setSpan(new ForegroundColorSpan(color), start, start + part.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (isUnderlined) {
                    result.setSpan(new UnderlineSpan(), start, start + part.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }
        return result;
    }

}
