package com.ultralinked.uluc.enterprise.baseui.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.ImageView;

import com.holdingfuture.flutterapp.hfsdk.R;

/**
 * 进度条imageview
 * Created by zhouweilong on 16/5/10.
 */
public class StickerImageView extends ImageView {


    private final Context mContext;


    public StickerImageView(Context context) {
        this(context,null);
    }

    public StickerImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StickerImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;

    }

}
