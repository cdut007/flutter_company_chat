package com.ultralinked.uluc.enterprise.call;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.Manifest;
import android.R.integer;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.widget.Toast;

import com.ultralinked.contact.util.ToastUtil;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.CallSession;

import static com.ultralinked.uluc.enterprise.contacts.ui.external.ExternalContactDispalyActivity.TAG;


public class CallModel {


    private static String tag = "CallModel";

    private CallSession callSession;

    public int callType = CallSession.STATUS_IDLE;

    public String networkStatus;

    public void handup() {
//		if (InCallActivity.isInstanciated()) {
//			InCallActivity.instance().hangUp();
//		}
        //

    }

    public static boolean isAllowedToCall(String calleeNum) {
        // TODO Auto-generated method stub
        CallModel type = getCallModel();
//		if (type.callType ==GlobalConst.SWAP_CALL || type.callType ==GlobalConst.CONFERENCE_CALL ) {
//			return false;
//		}
//		List<CallSession> sessionList = CallApi.getCallSessionList();
//		//判读拨打的号码是否已在通话中
//		if(sessionList!=null){
//			for (int i = 0; i < sessionList.size(); i++) {
//				String lastNumber = sessionList.get(i).getPeer().getNumber();
//				if(SysApi.PhoneUtils.compareUri(calleeNum, lastNumber)){
//					return false;
//				}
//			}
//		}

        return true;

    }

    public static CallModel getCallModel() {
        CallModel callModel = new CallModel();
//		if (InCallActivity.isInstanciated()) {
//
//			if (InCallActivity.instance().callSession != null) {
//				callModel.callSession = InCallActivity.instance().callSession;
//				callModel.callType = getCallType(callModel.callSession);
//				return  callModel;
//			}else {
//				Log.i(tag, "incall session is null");
//				return callModel;
//			}
//
//		}else if (SwapCallActivity.isInstanciated()) {
//			callModel.callType = GlobalConst.SWAP_CALL;
//			Log.i(tag, "callName:SWAP_CALL ");
//			return  callModel;
//
//		}else if (ConferenceActivity.isInstanciated()) {
//				callModel.callType = GlobalConst.CONFERENCE_CALL;
//				Log.i(tag, "confrences session ");
//				return  callModel;
//
//		}

        Log.i(tag, "unkonw call maybe idle");
        return callModel;

    }

    public static int getCallType(CallSession callSession) {
        int callType = callSession.type;

        int GrCallType = -1;
        String callName = "unkonw";
        switch (callType) {
            case CallSession.TYPE_AUDIO: {
//			if (callSession.isConf()) {
//				callName="audio confrence";
//				GrCallType = GlobalConst.CONFERENCE_CALL;
//			} else {
//				callName="audio";
//				GrCallType = GlobalConst.VOIP_CALL;
//			}

            }
            break;


            case CallSession.TYPE_VIDEO: {
                callName = "video";
                //GrCallType = GlobalConst.VIDEO_CALL;
            }
            break;
//		case CallSession.TYPE_VIDEO_SHARE:
//		{
//			callName="video share";
//			//GrCallType = GlobalConst.VIDEO_SHARE_CALL;
//		}
//			break;
//
            default:
                break;
        }

        Log.i(tag, "callName:" + callName);
        return GrCallType;
    }

    public static boolean IsNewCall(CallSession session) {
//		 List<CallSession> calless = CallApi.getCallSessionList();
//		 if (calless == null) {
//			 Log.i(tag, "calless list is null");
//			 return false;
//		}
//		 if (calless.size()>1) {
//			 for (CallSession callSession : calless) {
//				 if (callSession.getPeer()!=null) {
//					 Log.i(tag, "current callName:"+callSession.getPeer().getNumber());
//				}else {
//					Log.i(tag, "current callName getPeer is null , Is conf:"+callSession.isConf());
//				}
//
//			}
//			 return true;
//		}else {
//			Log.i(tag, "session List has only one ");
//		}
        return false;
    }

    public static boolean isIp2CSCallNumber(String number) {
        // TODO Auto-generated method stub
        String prefxStr = "1234";
        return number.startsWith(prefxStr);
    }


    public static String revertIp2CSCallNumberToNormal(String number) {
        // TODO Auto-generated method stub
        String prefxStr = "1234";
        if (number.startsWith(prefxStr)) {
            return number.substring(prefxStr.length());
        }
        return number;
    }

    public static String getIp2CSCallNumber(String calleeNumber) {
        // TODO Auto-generated method stub
        if (calleeNumber.startsWith("+")) {
            calleeNumber = "00" + calleeNumber.substring(1);
        }
        String callee_IP2CS_Call = "1234" + calleeNumber;
        return callee_IP2CS_Call;
        //	return callee_IP2CS_Call.replaceAll("\\+", "");
    }


    public static String queryPhoneNameFromLocalContact(Context context, String phoneNumber) {
        // TODO Auto-generated method stub

        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                Log.i("callModel", "user has not allow the query contact permission");
                return null;
            }
            String searchNumer = phoneNumber;
            Cursor cursor = null;
            if (phoneNumber.length() > 8) {//模糊匹配
                searchNumer = phoneNumber.substring(phoneNumber.length() - 8, phoneNumber.length());
                cursor = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                        ContactsContract.CommonDataKinds.Phone.NUMBER + " LIKE ?", new String[]{"%" + searchNumer + ""}, null);
            } else {//精确匹配
                cursor = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                        ContactsContract.CommonDataKinds.Phone.NUMBER + " = ?", new String[]{searchNumer}, null);
            }


            while (cursor != null && cursor.moveToFirst()) {
                int colIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                String name = cursor.getString(colIndex);
                cursor.close();
                return name;
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    private static MediaPlayer createRingToneFromRaw(Context context, int resid, int streamType) {
        AssetFileDescriptor afd = null;
        MediaPlayer mp = null;
        try {
            afd = context.getResources().openRawResourceFd(resid);

            if (afd == null) {

                return null;

            }

            mp = new MediaPlayer();

            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());

            afd.close();

            mp.setAudioStreamType(streamType);

            mp.setLooping(true);

            mp.prepare();

            return mp;

        } catch (IOException ex) {

            try {

                mp.stop();


            } catch (IllegalStateException e) {

                Log.e(TAG, "createRingToneFromRaw IOException IllegalStateException " + e);
            }

            Log.e(TAG, "createRingToneFromRaw IOException" + ex);

        } catch (IllegalArgumentException ex) {

            Log.e(TAG, "createRingToneFromRaw IllegalArgumentException" + ex);

        } catch (SecurityException ex) {

            Log.e(TAG, "createRingToneFromRaw SecurityException" + ex);

        } finally {

            if (afd != null) {

                try {

                    afd.close();

                } catch (IOException ex) {

                    Log.e(TAG, "createRingToneFromRaw IOException" + ex);

                }

            }

        }

        return null;

    }

    private static MediaPlayer mediaPlayerTerminate = null;

    public static void stopTerminateTone() {
        try {
            if (timer != null) {
                timer.cancel();
                timer = null;
            }
            if (mediaPlayerTerminate != null) {

                mediaPlayerTerminate.stop();
                mediaPlayerTerminate.release();
                mediaPlayerTerminate = null;
            }
        } catch (Exception e) {
            Log.i(TAG, "stopTerminateTone error:" + android.util.Log.getStackTraceString(e));
        }
    }

    static Timer timer;

    public static void queryIdleReasonInfo(String releaseReason, final boolean speakerOn) {
        if (!TextUtils.isEmpty(releaseReason)) {

            if (!releaseReason.contains("200")) {
                stopTerminateTone();
                mediaPlayerTerminate = createRingToneFromRaw(App.getInstance(), R.raw.call_failed, AudioManager.STREAM_VOICE_CALL);
                try {
                    AudioManager audioManager = (AudioManager) App.getInstance().getSystemService(Context.AUDIO_SERVICE);
                    if (!speakerOn) {
                        audioManager.setMode(AudioManager.STREAM_RING);
                    }

                    audioManager.setSpeakerphoneOn(speakerOn);

                    if (null != mediaPlayerTerminate) {
                        mediaPlayerTerminate.start();
                    }

                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            stopTerminateTone();
                        }
                    }, 3000);
                } catch (Exception e) {
                    Log.i(TAG, "playTerminateCall sound error:" + android.util.Log.getStackTraceString(e));
                }

//                SoundPool soundPool = new SoundPool(10, AudioManager.STREAM_VOICE_CALL, 5);
//
//                soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
//                    @Override
//                    public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
//                        AudioManager audioManager = (AudioManager) App.getInstance().getSystemService(Context.AUDIO_SERVICE);
//                        if (!speakerOn) {
//                            audioManager.setMode(AudioManager.STREAM_RING);
//                        }
//                        audioManager.setSpeakerphoneOn(speakerOn);
//                        if (soundPool != null) {
//                            soundPool.play(1, 1, 1, 999999999, 3, 1);
//                        }
//                        Log.i(TAG, "audioManager.isSpeakerphoneOn(): " + audioManager.isSpeakerphoneOn());
//                    }
//                });
//                soundPool.load(App.getInstance(), R.raw.call_failed, 1);
            }

        }


        if (!TextUtils.isEmpty(releaseReason)) {

            if (releaseReason.contains("500") || releaseReason.contains("403")) {
                ToastUtil.showToast(App.getInstance(), App.getInstance().getString(R.string.login_error), Toast.LENGTH_LONG);
            }


            if (releaseReason.contains("486")) {//callbusy call
                if (releaseReason.contains("Busy Here")) {
//					soundPool.load(IncallActivity.this, R.raw.busytone, 1);
//					if (phoneNum.contains("+"))
//						phoneNum = phoneNum.substring(1);
                    ToastUtil.showToast(App.getInstance(), App.getInstance().getString(R.string.busy_call_tips), Toast.LENGTH_LONG);
                }
            }
            if (releaseReason.contains("603")) {//decline
                if (releaseReason.contains("Decline")) {
//					soundPool.load(IncallActivity.this, R.raw.busytone, 1);
//					if (phoneNum.contains("+"))
//						phoneNum = phoneNum.substring(1);
                    ToastUtil.showToast(App.getInstance(), App.getInstance().getString(R.string.busy_call_tips), Toast.LENGTH_LONG);

                }
            }
            if (releaseReason.contains("480") || releaseReason.contains("404") || releaseReason.contains("408")) {//关机
//				soundPool.load(IncallActivity.this, R.raw.power_off, 1);
//				if (phoneNum.contains("+"))
//					phoneNum = phoneNum.substring(1);
                ToastUtil.showToast(App.getInstance(), App.getInstance().getString(R.string.offline_call_tips), Toast.LENGTH_LONG);

            }


            if (releaseReason.contains("707")) {//time out.
                ToastUtil.showToast(App.getInstance(), App.getInstance().getString(R.string.no_answer_call_tips), Toast.LENGTH_LONG);

            }
            //707 timeout
        }
    }
}
