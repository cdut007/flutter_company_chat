package com.ultralinked.uluc.enterprise.call;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ultralinked on 2016/7/21 0021.
 */
public class CallLog implements Parcelable {
    private String name;
    private String mobile;
    private String icon_url;
    private String end_time;
    private String duration;
    private String type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.mobile);
        dest.writeString(this.icon_url);
        dest.writeString(this.end_time);
        dest.writeString(this.duration);
        dest.writeString(this.type);
    }

    public CallLog() {
    }

    protected CallLog(Parcel in) {
        this.name = in.readString();
        this.mobile = in.readString();
        this.icon_url = in.readString();
        this.end_time = in.readString();
        this.duration = in.readString();
        this.type = in.readString();
    }

    public static final Parcelable.Creator<CallLog> CREATOR = new Parcelable.Creator<CallLog>() {
        @Override
        public CallLog createFromParcel(Parcel source) {
            return new CallLog(source);
        }

        @Override
        public CallLog[] newArray(int size) {
            return new CallLog[size];
        }
    };
}
