package com.ultralinked.uluc.enterprise.http;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.login.bean.DeviceInfo;
import com.ultralinked.uluc.enterprise.pay.RechargeRecordModel;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLSocketFactory;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;

/**
 * Created by ultralinked on 2016/6/16 0016.
 */

public class ApiManager {

    private final String TAG = getClass().getSimpleName();
    //private final static String BASE_URL = "https://uc.sealedchat.com/api/";
    private final static String BASE_URL = "https://uc.aitelian.cn/api/";
    private final static String BASE_STAGE_URL = "https://ucstage.sealedchat.com/api/";
    private ApiService apiService;


    public static void setBaseUrl(boolean staging, String url) {
        // TODO Auto-generated method stub
        if (App.getInstance() == null) {
            return;
        }
        SharedPreferences sharedPreferences = App.getInstance().getSharedPreferences("staging", Context.MODE_PRIVATE);
        if (staging) {
            if (TextUtils.isEmpty(url)) {
                url = BASE_STAGE_URL;
            }
            sharedPreferences.edit().putString("staging_url", url).commit();
            sharedPreferences.edit().putBoolean("staging", true).commit();
        } else {
            sharedPreferences.edit().putString("staging_url", BASE_URL).commit();
            sharedPreferences.edit().putBoolean("staging", false).commit();
        }

    }


    public static boolean IsStage() {
        return BASE_STAGE_URL.equals(getBaseUrl());
    }

    public static String getBaseUrl() {
        // TODO Auto-generated method stub
        if (App.getInstance() == null) {
            return BASE_URL;
        }
        SharedPreferences sharedPreferences = App.getInstance().getSharedPreferences("staging", Context.MODE_PRIVATE);
        if (sharedPreferences.getBoolean("staging", false)) {
            return sharedPreferences.getString("staging_url", BASE_STAGE_URL);
        }

        return BASE_URL;

    }

    private ApiManager() {
        SSLSocketFactory sslSocketFactory = SSLContextUtils.getSSLSocketFactory();
        Log.i(TAG, "" + ACache.cacheDir);
        //缓存目录
        Cache cache = new Cache(new File(ACache.cacheDir), 10 * 1024 * 1024);
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        String currentLanguage = Locale.getDefault().getLanguage();
                        if (currentLanguage == null) {
                            currentLanguage = "en";
                        }
                        String versionName = "";
                        try {

                            versionName = App.getInstance().getPackageManager().getPackageInfo(App.getInstance().getPackageName(), 0).versionName;
                            versionName += ",model=" + android.os.Build.MODEL;
                            versionName += ",os=" + Build.VERSION.RELEASE;
                        } catch (PackageManager.NameNotFoundException e) {

                            e.printStackTrace();
                        }

                        Request request = chain.request()
                                .newBuilder()
                                .addHeader("Accept-Language", currentLanguage + ";q=1")
                                .addHeader("User-Agent", "android_" + versionName)
                                .build();
                        return chain.proceed(request);
                    }

                })
                //添加证书
                .sslSocketFactory(sslSocketFactory)
                .hostnameVerifier(SSLContextUtils.getHostnameVerifier())//配置
                //必须是设置Cache目录
                .cache(cache)
                //失败重连
                .retryOnConnectionFailure(true)
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS);
        //stetho,可以在chrome中查看请求
//        if (App.swtichStetho) {
//            builder.addNetworkInterceptor(new StethoInterceptor());
//        }

        Retrofit.Builder retrofit = new Retrofit.Builder()
                .baseUrl(getBaseUrl())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create());

        retrofit.client(builder.build());
        apiService = retrofit.build().create(ApiService.class);
    }


    private static class Singleton {
        private static final ApiManager apiManager = new ApiManager();
    }

    public static ApiManager getInstance() {
        return Singleton.apiManager;
    }


    private HashMap<String, String> getParams() {
        HashMap<String, String> params = new HashMap<>();
        params.put("domain", getDomain());
//        String currentLanguage= Locale.getDefault().getLanguage();
//        if (currentLanguage == null){
//            currentLanguage = "en";
//        }
        //params.put("language",currentLanguage);
        return params;
    }


    public static void setDomain(String val) {
        // TODO Auto-generated method stub
        if (App.getInstance() == null) {
            return;
        }
        SharedPreferences sharedPreferences = App.getInstance().getSharedPreferences("api_config", Context.MODE_PRIVATE);

        sharedPreferences.edit().putString("api_domain", val).commit();

    }

    public static String getDomain() {
        // TODO Auto-generated method stub
        SharedPreferences sharedPreferences = App.getInstance().getSharedPreferences("api_config", Context.MODE_PRIVATE);
        return sharedPreferences.getString("api_domain", "uc");

    }

    /**
     * otp 注册请求  验证 注册
     *
     * @param mobile
     * @param company
     * @param email
     * @param username
     * @param passwd
     * @return
     */
    public Observable<ResponseBody> otpRegistWithCompany(String mobile, String company, String email, String username, String passwd) {
        HashMap<String, String> params = getParams();
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        params.put("mobile", mobile);

        params.put("company", company);
        params.put("email", email);
        params.put("nickname", username);
        params.put("passwd", passwd);


        printParams(params);
        return apiService.otpRegist(params);
    }


    /**
     * otp 注册请求  验证 注册
     *
     * @param mobile
     * @param company
     * @param passwd
     * @return
     */
    public Observable<ResponseBody> otpCreateWithCompany(String mobile, String company, String passwd) {
        HashMap<String, String> params = getParams();
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        params.put("mobile", mobile);
        params.put("company", company);
        params.put("passwd", passwd);
        printParams(params);
        return apiService.otpRegistCompany(SPUtil.getToken(), params);
    }


    /**
     * otp 注册请求  验证 注册
     *
     * @param mobile
     * @param username
     * @param passwd
     * @return
     */
    public Observable<ResponseBody> otpRegist(String mobile, String username, String passwd) {
        Log.i(TAG, "request otpRegist");
        HashMap<String, String> params = getParams();
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        params.put("mobile", mobile);
        params.put("nickname", username);
        params.put("passwd", passwd);
        printParams(params);
        return apiService.otpRegist(params);
    }


    /**
     * 设置用户备注名
     *
     * @param userId
     * @param remarkName
     * @return
     */
    public Observable<ResponseBody> setRemarkName(String userId, String remarkName) {
        Log.i(TAG, "request setRemarkName");
        HashMap<String, String> params = getParams();
        params.put("user_id", userId);
        params.put("remarkname", remarkName);
        printParams(params);
        return apiService.setRemarkName(SPUtil.getToken(),params);
    }


    public Observable<ResponseBody> deleteRemark(String userId) {
        Log.i(TAG, "request deleteRemark");
        return apiService.deleteRemarkName(SPUtil.getToken(),userId);
    }


    /**
     * 注册
     *
     * @param params
     * @return
     */
    public Observable<ResponseBody> createUser(HashMap<String, String> params) {
        return apiService.createUser(params);
    }

    /**
     * 登录
     *
     * @param mobile
     * @param password
     * @return
     */
    public Observable<ResponseBody> login(String mobile, String password) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(mobile);
        Map<String, String> map = getParams();

        if (isNum.matches()) {
            map.put("mobile", mobile);
        } else {
            map.put("username", mobile);
        }
        map.put("password", password);
        //device_id
        Map<String, Object> objectHashMap = convertMap(map);
        try {
            DeviceInfo deviceInfo = DeviceInfo.getInfos();
            Log.i(TAG, "deviceInfo:" + deviceInfo.toString());
            objectHashMap.put("user_device", deviceInfo);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        Log.i(TAG, mobile);
        printParams(map);
        return apiService.login(objectHashMap);
    }


    private static Map<String, Object> convertMap(Map<String, String> map) {
        Map<String, Object> objectMap = new HashMap<>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            objectMap.put(entry.getKey(), entry.getValue());
            System.out.println("convertMap key= " + entry.getKey() + " and convertMap value= " + entry.getValue());
        }
        return objectMap;
    }

    /**
     * otp 验证
     *
     * @param mobile
     * @param otp
     * @return
     */
    public Observable<ResponseBody> otpVerify(String mobile, String otp) {
        HashMap<String, String> params = getParams();
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        params.put("mobile", mobile);
        params.put("passwd", otp);
        //device_id

        Map<String, Object> objectHashMap = convertMap(params);
        try {
            DeviceInfo deviceInfo = DeviceInfo.getInfos();
            Log.i(TAG, "deviceInfo:" + deviceInfo.toString());
            objectHashMap.put("user_device", deviceInfo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return apiService.otpVerify(objectHashMap);
    }

    /**
     * refresh token
     *
     * @return
     */
    public Observable<ResponseBody> refreshToken() {
        // Map<String, String> params = getParams();
        return apiService.refreshConfig(SPUtil.getToken());
    }

    /**
     * 改私有密码
     *
     * @param psd
     * @return
     */
    public Observable<ResponseBody> changePrivatePsd(String psd) {
        Map<String, String> params = getParams();
        params.put("private_contact_password", psd);
        return apiService.changePrivatePsd(SPUtil.getToken(), params);
    }


    /**
     * 查看当前用户设置呼叫号码
     *
     * @return
     */
    public Observable<ResponseBody> queryCurrentOutgoingCallDisplayNumberSetting() {
        return apiService.queryCurrentOutgoingCallDisplayNumberSetting(SPUtil.getToken(), "currentOutgoingCallDisplayNumber");
    }


    /**
     * like moments
     *
     * @return
     */
    public Observable<ResponseBody> likeMoments(String action, String post_id) {

        Map<String, String> params = getParams();
        params.put("action", action);
        params.put("post_id", post_id);
        return apiService.likeMoments(SPUtil.getToken(), params);

    }


    /**
     * delete moments
     *
     * @return
     */
    public Observable<ResponseBody> deleteMoments(String post_id) {

//        Map<String, String> params = getParams();
//        params.put("post_id", post_id);
        return apiService.deleteMoments(SPUtil.getToken(), post_id);

    }

    /**
     * delete moments comments
     *
     * @return
     */
    public Observable<ResponseBody> deleteMomentsComment(String post_id,String comment_id) {

//        Map<String, String> params = getParams();
//        params.put("post_id", post_id);
        Log.i(TAG,"delete comment_id="+comment_id);
        return apiService.deleteMomentsComment(SPUtil.getToken(),post_id, comment_id);

    }



    /**
     * post moments comments
     *
     * @return
     */
    public Observable<ResponseBody> commentMoments(String content, String post_id, String reply_user_id) {

        Map<String, String> params = getParams();
        params.put("content", content);
        params.put("post_id", post_id);
        if (!TextUtils.isEmpty(reply_user_id)) {
            params.put("reply_user_id", reply_user_id);
        }

        return apiService.commentMoments(SPUtil.getToken(), params);

    }


    /**
     * share moments
     *
     * @return
     */
    public Observable<ResponseBody> shareMoments(String type, String content, List<String> imgUrls, List<String> thumb_imgUrls) {

        Map<String, String> params = getParams();
        Map<String, Object> objectHashMap = convertMap(params);
        objectHashMap.put("type", type);
        objectHashMap.put("image_urls", imgUrls);
        objectHashMap.put("thumb_urls", thumb_imgUrls);
        objectHashMap.put("message", content);
        return apiService.shareMoments(SPUtil.getToken(), objectHashMap);

    }


    /**
     * query other user moments
     *
     * @return
     */
    public Observable<ResponseBody> queryOtherUserMoments(String pageCount, String userId, String cursorIndex) {

        return apiService.queryUserPostedMoments(SPUtil.getToken(), cursorIndex, userId);

    }

    /**
     * query moments
     *
     * @return
     */
    public Observable<ResponseBody> queryMoments(String pageCount, String cursorIndex) {

        return apiService.queryMoments(SPUtil.getToken(), cursorIndex);

    }


    /**
     * 转移transfer
     *
     * @return
     */
    public Observable<ResponseBody> requestBalanceTransfer(String password, String amount, String tranferUserId) {

        Map<String, String> params = getParams();
        params.put("amount", amount);
        params.put("password", password);
        params.put("to_user_mobile", tranferUserId);
        return apiService.requestBalanceTransfer(SPUtil.getToken(), params);

    }


    /**
     * sealchat支付
     *
     * @return
     */
    public Observable<ResponseBody> requestSealedChatPay(String password, String paymentOrderId) {

        Map<String, String> params = getParams();
        params.put("payment_id", paymentOrderId);
        params.put("password", password);
        return apiService.requestSealedChatPay(SPUtil.getToken(), params);

    }

    /**
     * 设置当前用户呼叫号码
     *
     * @param -1000 设置为无
     * @return
     */
    public Observable<ResponseBody> requestCurrentOutgoingCallDisplayNumberSetting(String number) {
        Map<String, String> params = getParams();
        params.put("currentOutgoingCallDisplayNumber", number);

        return apiService.requestCurrentOutgoingCallDisplayNumberSetting(SPUtil.getToken(), params);
    }



    /**
     * 查看用户最新朋友圈状态
     *
     * @return
     */
    public Observable<ResponseBody> queryMomentsStatus() {
        return apiService.querySettingConfirmByType(SPUtil.getToken(), "has_new_moments");
    }




    /**
     * 删除查看过的未读朋友圈消息
     *
     * @return
     */
    public Observable<ResponseBody> deleteUnreadMomentsItems(List<String> deleteKeys) {
        String info = "";
        for (String key : deleteKeys
                ) {
            info += key + ",";
        }
        return apiService.deleteUnreadMomentsList(SPUtil.getToken(),info);
    }

    /**
     * 查询是否有未读朋友圈消息
     *
     * @return
     */
    public Observable<ResponseBody> queryHasUnreadMomentsItems() {
        return apiService.getUnreadMomentsList(SPUtil.getToken());
    }



    /**
     * 查看当前用户好友验证验证是否开启
     *
     * @return
     */
    public Observable<ResponseBody> queryFriendConfrrmSetting() {
        return apiService.querySettingConfirmByType(SPUtil.getToken(), "add_friend_setting");
    }


    /**
     * 查看用户朋友圈个人信息
     *
     * @return
     */
    public Observable<ResponseBody> queryUserMomentProfile(String userid, List<String> queryKeys) {
        String info = "";
        for (String key : queryKeys
                ) {
            info += key + ",";
        }
        return apiService.queryUserMomentsProfile(SPUtil.getToken(), userid, info);
    }


    /**
     * 设置用户的signature
     *
     * @return
     */
    public Observable<ResponseBody> requestSignature(String signature) {
        Map<String, String> params = getParams();
        params.put("signature", signature);
        return apiService.requestSetSignture(SPUtil.getToken(), params);
    }


    /**
     * 设置朋友圈图片url
     *
     * @return
     */
    public Observable<ResponseBody> requestSetMomentBackgroud(String backgroud) {
        Map<String, String> params = getParams();
        params.put("backgroud_url", backgroud);
        return apiService.requestSetMomentBackgroud(SPUtil.getToken(), params);
    }


    /**
     * 设置加好友验证
     *
     * @param enable
     * @return
     */
    public Observable<ResponseBody> requestFriendConfirmSetting(boolean enable) {
        Map<String, String> params = getParams();
        if (enable) {
            params.put("add_friend_setting", "need_auth");
        } else {
            params.put("add_friend_setting", "anyone");
        }

        return apiService.requestFriendConfirmSetting(SPUtil.getToken(), params);
    }

    /**
     * 获取用户信息
     *
     * @return UserInfo
     */
    public Observable<UserInfo> getUserInfo() {
        return apiService.getUserInfo(SPUtil.getToken(), SPUtil.getUserID());
    }

    public Observable<UserInfo> updateUserInfo(Map<String, String> map) {
        return apiService.updateUserInfo(SPUtil.getToken(), SPUtil.getUserID(), map);
    }


    /**
     * 获取当前设备
     *
     * @return
     */
    public Observable<ResponseBody> getCurrentDeviceStatus(DeviceInfo deviceInfo) {
        Map<String, String> map = getParams();
        map.put("device_id", deviceInfo.device_id);
        map.put("device_name", deviceInfo.device_name);
        map.put("device_type", deviceInfo.device_type);
        printParams(map);
        return apiService.getDestroyDevice(SPUtil.getToken(), deviceInfo.device_id, deviceInfo.device_name, deviceInfo.device_type);
    }


    /**
     * 摧毁指定设备
     *
     * @return
     */
    public Observable<ResponseBody> destroyDevice(String password, String deviceId) {
        Map<String, String> map = getParams();
        map.put("password", password);
        map.put("device_id", deviceId);
        printParams(map);
        return apiService.setDestroyDevice(SPUtil.getToken(), map);
    }


    /**
     * 解除摧毁指定设备
     *
     * @return
     */
    public Observable<ResponseBody> recoveryDevice(String password, String deviceId) {
        Map<String, String> map = getParams();
        map.put("password", password);
        map.put("device_id", deviceId);
        printParams(map);
        return apiService.recoveryDestroyDevice(SPUtil.getToken(), password, deviceId);
    }


    /**
     * 获取用户登录设备列表
     *
     * @return
     */
    public Observable<ResponseBody> getTheUserDevices() {
        Map<String, String> map = getParams();
        printParams(map);
        return apiService.getTheUserDevices(SPUtil.getToken());
    }


    /**
     * 修改用户密码
     *
     * @return
     */
    public Observable<ResponseBody> changeUserPassword(String old_password, String new_password) {
        Map<String, String> map = getParams();

        if (!TextUtils.isEmpty(old_password)) {
            map.put("old_password", old_password);
        }

        map.put("new_password", new_password);
        printParams(map);
        return apiService.changeUserPassword(SPUtil.getToken(), SPUtil.getUserID(), map);
    }


    /**
     * 获取department 组
     *
     * @return
     */
    public Observable<ResponseBody> getDepart(boolean root) {
        return apiService.getDepartment(SPUtil.getToken());
    }

    /**
     * 获取pending 列表
     *
     * @return
     */
    public Observable<ResponseBody> getPendingList() {
        return apiService.getPendingList(SPUtil.getToken());
    }


    /**
     * 获取 friend pending 列表
     *
     * @return
     */
    public Observable<ResponseBody> getFriendPendingList() {
        return apiService.getFriendPendingList(SPUtil.getToken(), "friend");
    }

    /**
     * 获取联系人
     *
     * @return
     */
    public Observable<ResponseBody> getUsers() {
        Map<String, String> map = getParams();
        return apiService.getUsers(SPUtil.getToken(), map);
    }

    public Observable<ResponseBody> upImg(Map<String, RequestBody> body) {
        return apiService.uploadImg(SPUtil.getToken(), body);
    }


    public Observable<ResponseBody> uploadImagesToMoments(MultipartBody multipartBody) {

        return apiService.uploadImagesToMoments(SPUtil.getToken(), multipartBody);
    }


    /**
     * 邀请成为internal/ external 联系人
     *
     * @param name
     * @param mobile
     * @param email
     * @param mDepartIDSelected
     * @return
     */
    public Observable<ResponseBody> inVite(String name, String mobile, String email, String mDepartIDSelected) {

        mobile = RegexValidateUtils.normalizeNumber(mobile);
        HashMap<String, String> params = getParams();
        params.put("name", name);
        params.put("mobile", mobile);
        params.put("email", email);
        params.put("department_id", mDepartIDSelected);
        printParams(params);
        return apiService.invite(SPUtil.getToken(), params);
    }


    /**
     * make qrcode url
     *
     * @return
     */
    public Observable<ResponseBody> parseQrCodeUrl(String url, HashMap<String, String> requestMap) {

        HashMap<String, String> params = getParams();
        printParams(params);
        return apiService.parseQrCodeUrl(SPUtil.getToken(), url);
    }

    /**
     * make qrcode url
     *
     * @return
     */
    public Observable<ResponseBody> createQrCodeUrl(String type, HashMap<String, String> requestMap) {

        HashMap<String, String> params = getParams();
        params.put("type", type);
        Iterator iter = requestMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            String val = (String) entry.getValue();
            params.put(key, val);
        }

        printParams(params);
        return apiService.getQrcodeUrl(SPUtil.getToken(), params);
    }

    /**
     * accept成为friend
     *
     * @return
     */
    public Observable<ResponseBody> acceptFriend(String userId) {

        HashMap<String, String> params = getParams();
        params.put("invite_id", userId);
        params.put("action", "friend");
        params.put("command", "accept");
        printParams(params);
        return apiService.invitationCommand(SPUtil.getToken(), params);
    }

    /**
     * reject成为friend
     *
     * @return
     */
    public Observable<ResponseBody> rejectFriend(String userId) {

        HashMap<String, String> params = getParams();
        params.put("invite_id", userId);
        params.put("action", "friend");
        params.put("command", "reject");
        printParams(params);
        return apiService.invitationCommand(SPUtil.getToken(), params);
    }


    /**
     * 查询用户
     *
     * @return
     */
    public Observable<ResponseBody> queryUser(String mobile) {

        //replace by queryUsersByMoblie  ,pass only one.
        HashMap<String, String> params = getParams();
        params.put("search_key", mobile);
        printParams(params);
        return apiService.searchUser(SPUtil.getToken(), params);
    }


    /**
     * 查询用户moblies
     *
     * @return
     */
    public Observable<ResponseBody> queryUsersByMoblie(List<String> mobiles) {

        HashMap<String, String> params = getParams();
        Map<String, Object> objectHashMap = convertMap(params);
        objectHashMap.put("contacts", mobiles);
        printParams(params);
        return apiService.searchUsersByMobile(SPUtil.getToken(), objectHashMap);
    }

    /**
     * 查询用户moblies
     *
     * @return
     */
    public Observable<ResponseBody> queryUsersByMoblieWithAction(List<String> mobiles) {

        HashMap<String, String> params = getParams();
        Map<String, Object> objectHashMap = convertMap(params);
        objectHashMap.put("contacts", mobiles);
        objectHashMap.put("action","friend");
        printParams(params);
        return apiService.searchUsersByMobile(SPUtil.getToken(), objectHashMap);
    }



    /**
     * 查询用户ids
     *
     * @return
     */
    public Observable<ResponseBody> queryUsers(List userIds) {

        HashMap<String, String> params = getParams();

        Map<String, Object> objectHashMap = convertMap(params);
        objectHashMap.put("user_ids", userIds);
        printParams(params);
        return apiService.searchUserIds(SPUtil.getToken(), objectHashMap);
    }


    /**
     * 邀请成为friend
     *
     * @return
     */
    public Observable<ResponseBody> inViteFriend(String userId, String invite_msg) {

        HashMap<String, String> params = getParams();
        params.put("user_id", userId);
        params.put("action", "friend");
        params.put("invite_message", invite_msg);
        printParams(params);
        return apiService.invite(SPUtil.getToken(), params);
    }

    /**
     * 删除friend
     *
     * @return
     */
    public Observable<ResponseBody> deleteFriend(String userId) {

        HashMap<String, String> params = getParams();
        params.put("user_id", userId);
        params.put("action", "friend");
        printParams(params);
        return apiService.deleteFriend(SPUtil.getToken(), params);
    }


    /**
     * ai
     *
     * @return
     */
    public Observable<ResponseBody> queryAsisantInfo(String content) {

        HashMap<String, String> params = new HashMap<>();
        params.put("info", content);
        return apiService.queryAsisantInfo(content);
    }


    private static void printParams(Map<String, String> params) {
        Iterator iter = params.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            String val = (String) entry.getValue();
            Log.i("printParams", "key= " + key + ";val= " + val);
        }


    }

    /**
     * get private contact by token
     *
     * @return
     */
    public Observable<ResponseBody> getPrivate() {

        return apiService.getprivate(SPUtil.getToken());
    }

    /**
     * get friends contact by token
     *
     * @return
     */
    public Observable<ResponseBody> getFriends() {

        return apiService.getFriend(SPUtil.getToken());
    }


    /**
     * add a existing person as private contact
     */
    public Observable<ResponseBody> setPrivate(String subuserId) {
        HashMap<String, String> params = getParams();
        params.put("user_id", subuserId);
        return apiService.setprivate(SPUtil.getToken(), params);
    }

    public Observable<ResponseBody> delPrivate(String subuserId) {
        HashMap<String, String> params = getParams();
        params.put("user_id", subuserId);
        return apiService.deleprivate(SPUtil.getToken(), params);
    }


    public Observable<ResponseBody> setPrivatePsd(String psd) {
        HashMap<String, String> params = getParams();
        params.put("private_contact_password", psd);
        return apiService.setPrivatePsd(SPUtil.getToken(), params);
    }

    /**
     * request otp
     *
     * @return
     */
    public Observable<ResponseBody> request_otp(String mobile, String action, String type) {
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        Log.i(TAG, "request otp");
        Map<String, String> map = getParams();
        map.put("action", action);
        map.put("mobile", mobile);
        if (!TextUtils.isEmpty(type)) {
            map.put("type", type);
        }
        Log.i(TAG, "request otp start");
        return apiService.request_otp(SPUtil.getToken(), map);
    }

    /**
     * change mobile number
     *
     * @param mobile new mobile number
     * @param passwd otp
     * @param
     * @return
     */
    public Observable<ResponseBody> change_mobile(String mobile, String passwd, String login_passwd) {
        Map<String, String> map = getParams();
        mobile = RegexValidateUtils.normalizeNumber(mobile);
        map.put("mobile", mobile);
        map.put("passwd", passwd);

        if (!TextUtils.isEmpty(login_passwd)) {

            map.put("login_passwd", login_passwd);
        }

        return apiService.changeMobile(SPUtil.getToken(), map);
    }

    /**
     * call via api callback
     *
     * @param destnumber_a
     * @param destnumber_b
     * @return
     */
    public Observable<ResponseBody> callback(String destnumber_a, String destnumber_b) {
        Map<String, String> map = getParams();
        map.put("destNumber_a", destnumber_a);
        map.put("destNumber_b", destnumber_b);
        printParams(map);
        return apiService.callback(SPUtil.getToken(), map);
    }

    public Observable<ResponseBody> getMapPoint(String coodrs) {

        return apiService.getMap(coodrs);
    }

    public Observable<ResponseBody> getProductList() {
        return apiService.getProduct(SPUtil.getToken(), "charge");
    }

    public Observable<ResponseBody> getPhoneProductList() {
        return apiService.getProduct(SPUtil.getToken(), "phone_no");
    }

    public Observable<ResponseBody> getBoughtPhoneProductList() {
        return apiService.getProduct(SPUtil.getToken(), "bought_number");
    }


    public Observable<ResponseBody> changePaymentProviderSignedData(Map<String, String> map) {
        return apiService.changePaymentProviderSignedData(SPUtil.getToken(), map);
    }

    public Observable<ResponseBody> getPaymentSignedData(Map<String, String> map) {
        return apiService.getPaymentSignedData(SPUtil.getToken(), map);
    }

    public Observable<ResponseBody> submitPayPalId(String payment_id, Map<String, String> map) {
        return apiService.submitPayPalId(SPUtil.getToken(), payment_id, map);
    }

    public Observable<ResponseBody> getAccountBalance() {
        return apiService.getAccountBalance(SPUtil.getToken());
    }

    public Observable<ResponseBody> getCurrencyRate() {
        return apiService.getCurrencyRate(SPUtil.getToken());
    }

    public Observable<ResponseBody> getInvitationUrl() {
        return apiService.getInvitationUrl(SPUtil.getToken());
    }

    public Observable<ResponseBody> getRechargeRecord() {
        return apiService.getRechargeRecord(SPUtil.getToken());
    }

    public Observable<ResponseBody> submitPaymentStatus(Map<String, String> map) {
        return apiService.submitPaymentStatus(SPUtil.getToken(), map);
    }

    public Observable<ResponseBody> getShareUrl() {
        return apiService.getShareUrl(SPUtil.getToken());
    }

    public Observable<ResponseBody> queryOrder(RechargeRecordModel model) {
        return apiService.queryOrder(SPUtil.getToken(), model);
    }

    public Observable<ResponseBody> queryCallRecords(Map<String,Integer> map) {
        return apiService.queryCallRecords(SPUtil.getToken(), map);
    }
}

