package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.style.ImageSpan;

public class StickerImageSpan extends ImageSpan{
	 public StickerImageSpan(Context context,Bitmap bitmap,int alignFlag) {
	        super(context, bitmap,ALIGN_BOTTOM);
	    }
	
	 public StickerImageSpan(Context context,Bitmap bitmap) {
	        super(context, bitmap,ImageSpan.ALIGN_BOTTOM);
	    }
	
	 
    public StickerImageSpan(Drawable b) {
        super(b, ImageSpan.ALIGN_BOTTOM);

    }

//    @Override
//    public void draw(Canvas canvas, CharSequence text,
//                     int start, int end, float x,
//                     int top, int y, int bottom, Paint paint) {
//    	//super.draw(canvas, text, start, end, x, top, y, bottom, paint);
//    	  Drawable b = getDrawable();
//          canvas.save();
//          
//          int transY = bottom - b.getBounds().bottom;
//          if (mVerticalAlignment == ALIGN_BASELINE) {
//              transY -= paint.getFontMetricsInt().descent;
//          }
//          canvas.translate(x, transY);
//          b.draw(canvas);
//          canvas.restore();
//    }

}
