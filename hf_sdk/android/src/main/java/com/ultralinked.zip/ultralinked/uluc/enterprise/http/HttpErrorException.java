package com.ultralinked.uluc.enterprise.http;

import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.google.gson.Gson;

import java.io.IOException;

import retrofit2.adapter.rxjava.HttpException;

/**
 * Created by ultralinked on 2016/7/12 0012.
 */
public class HttpErrorException {

    /**
     * code : 400
     * description : InputError:domain not in system,No row was found for one()
     * message : 400: Bad Request
     */

    private int code;
    private String description;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static String handErrorMessage(Throwable throwable){
        String error;
        error= android.util.Log.getStackTraceString(throwable);
        Log.e("HttpErrorException",error);
        if(throwable instanceof HttpException){
            HttpException exception = (HttpException) throwable;
            try {
                error=exception.response().errorBody().string();
                Log.e("HttpErrorException response",error);
                Gson gson=new Gson();
                HttpErrorException httpErrorException = gson.fromJson(error, HttpErrorException.class);
                error=httpErrorException.getDescription();

                if (httpErrorException!=null && httpErrorException.getCode() == 401
                        && httpErrorException.description!=null
                        && httpErrorException.description.contains("expired token")){
                    //invilad token , go 2 login page.
                    App.getInstance().goToLoginActivity(true);
                }

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("HttpParseErrorException",e.getMessage());
            }
        }else{
        }


        if (TextUtils.isEmpty(error)){
            error = App.getInstance().getString(R.string.network_unavailable);
        }else{
            if ( error.contains("ConnectException")
                    ||error.contains("SocketTimeout")
                    ||error.contains("SSLException")
                    ||error.contains("UnknownHostException")
                    ||error.contains("Connection timed out")
                    ||error.contains("handshake")
                    ){
                //Connection timed out
                error = App.getInstance().getString(R.string.network_unavailable);
            }else if(error.contains("Internal server error")){

                error = App.getInstance().getString(R.string.login_error);
            }
        }

        return error;
    }
}
