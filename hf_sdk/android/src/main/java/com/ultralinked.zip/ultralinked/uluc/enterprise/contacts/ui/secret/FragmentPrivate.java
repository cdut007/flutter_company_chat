package com.ultralinked.uluc.enterprise.contacts.ui.secret;


import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.chat.ChatPresenter;
import com.ultralinked.uluc.enterprise.chat.ChatViewFab;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.chat.group.GroupChatListActivity;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.ContactsExpandableAdapter;
import com.ultralinked.uluc.enterprise.contacts.FragmentFriend;
import com.ultralinked.uluc.enterprise.contacts.FriendAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadPrivateContactTask;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class FragmentPrivate extends BaseFragment implements View.OnClickListener, ReadPrivateContactTask.onContactReadFinishListener, ChatViewFab {

    private static final String TAG = "FragmentPrivate";
    private PrivateAdapter mPrivateAdapter = new PrivateAdapter(getContext());

    protected TextView titleCenter;
    protected TextView titleRight;
    protected ImageView titleLeft;

    private ReadPrivateContactTask mReadContactTask;
    private String mSearchWord;

    private static final int LOADER_ID = 0x28;

    private ListView mPrivateListView;

    private ContentObserver contactChangeObserver;

    @Override
    public int getRootLayoutId() {
        return R.layout.contacts_private_layout;
    }



    EditText mSearch_edittext;

    BaseActivity baseActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        baseActivity = (BaseActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadPrivateData();
        TCAgent.onPageStart(getActivity(),"安全空间");
    }


    private void loadPrivateData() {


        if (mReadContactTask != null) {

            mReadContactTask.resetLoader(null);

        }
    }

    TextView add;
    ChatPresenter presenter;



    @Override
    public void initView(Bundle savedInstanceState) {

        titleLeft = bind(R.id.left_back);
        titleRight = bind(R.id.titleRight);
        titleCenter = bind(R.id.titleCenter);
        titleCenter.setText(R.string.contact_private);

        presenter = new ChatPresenter(this);

        add = bind(R.id.titleRight);
        add.setText("");
        try{
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) add.getLayoutParams();
            layoutParams.rightMargin = ScreenUtils.dp2px(getActivity(),10);
            add.setLayoutParams(layoutParams);
        }catch (Exception e){
            e.printStackTrace();
        }
        Drawable drawable = getResources().getDrawable(com.holdingfuture.flutterapp.hfsdk.R.mipmap.add);
        int iconSize = getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_20_0_dp);
        drawable.setBounds(0, 0, iconSize, iconSize); //设置边界
        add.setCompoundDrawables(null, null, drawable, null);//画在右边
        ImageUtils.buttonEffect(add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),AddSecretActivity.class);
                if (mPrivateAdapter!=null){
                    intent.putParcelableArrayListExtra("privates", (ArrayList<? extends Parcelable>) mPrivateAdapter.getList());
                }
                startActivity(intent);
            }
        });

        mPrivateListView = bind(R.id.friend_list_view);


        initListener(this, R.id.searchParent,R.id.left_back);


        initListView();


        mSearch_edittext = bind(R.id.search_edittext);
        mSearch_edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (mReadContactTask != null) {

                    if (TextUtils.isEmpty(s)) {
                        mSearchWord = "";
                        mReadContactTask.resetLoader(null);
                    } else {
                        mSearchWord = s.toString();
                        mReadContactTask.resetLoader(mSearchWord);
                    }

                }
                //todo:expand the list

            }
        });

        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MsgIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_INCOMING));


    }


    private SideBar indexBar;
    private TextView mDialogText;
    private WindowManager mWindowManager;
    private void initListView() {
        mWindowManager = (WindowManager) getActivity()
                .getSystemService(Context.WINDOW_SERVICE);

        mDialogText = (TextView) LayoutInflater.from(getActivity()).inflate(
                R.layout.side_bar_list_position, null);
        mDialogText.setVisibility(View.INVISIBLE);
        indexBar = bind(R.id.sideBar);
        indexBar.setListView(mPrivateListView);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
       try {
           mWindowManager.addView(mDialogText, lp);
           indexBar.setTextView(mDialogText);
       }catch (Exception e){
           e.printStackTrace();
       }
//        layout_head = ctx.getLayoutInflater().inflate(
//                R.layout.layout_head_friend, null);
//        mFriendListView.addHeaderView(layout_head);

        mPrivateAdapter = new PrivateAdapter(getActivity());
        mPrivateListView.setAdapter(mPrivateAdapter);

        mPrivateListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PeopleEntity entity = (PeopleEntity) parent.getItemAtPosition(position);
                Conversation conversation = MessagingApi.createConversationWithFlag(entity.subuser_id, Conversation.CONVERSATION_FLAG_PRIVATE);
                if (conversation == null) {
                    Log.i(TAG, "userid:" + entity.subuser_id);
                    return;
                }

                SingleChatImActivity.launchToSingleChatIm(getActivity(), conversation.getContactNumber(), conversation.conversationFlag);


            }
        });

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"安全空间");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mReadContactTask = new ReadPrivateContactTask(getActivity(), LOADER_ID);
        mReadContactTask.registerListener(this);
        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, mReadContactTask.getLoader());


        Uri uri = FriendContract.CONTENT_URI;
        contactChangeObserver = new FragmentPrivate.ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri,true,contactChangeObserver);
    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
    }

    @Override
    public void updateConversation(List<Conversation> conversations) {
        //bind unread message for contacts. who has.
        if (mPrivateAdapter!=null && conversations!=null && conversations.size()>0){
            HashMap<String, Integer> unreadMsgMap = mPrivateAdapter.getUnreadMsgMap();
            for (Conversation conversation:conversations
                 ) {
                unreadMsgMap.put(conversation.getContactId(),conversation.getUnReadMsgCount());
            }
            mPrivateAdapter.setUnreadMsgMap(unreadMsgMap);
        }
    }

    @Override
    public void updateUnreadMessageCount(int count, int flags) {
        //for total count.
    }

    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }
        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG,"contact hasChanged..");
            loadPrivateData();
        }
    }


    private BroadcastReceiver MsgIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

                if (msg == null) {
                    Log.i(TAG, "incoming msg is null ");
                    return;
                }
                Log.i(TAG, "MsgIncomingReceiver~~ msgKeyId:" + msg.getKeyId() + " conversationId:" + msg.getConversationId());
                presenter.initData(false,true);

            }

        }
    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        try{
            mWindowManager.removeView(mDialogText);
        }
        catch (Exception e){
            e.printStackTrace();
        }

        mReadContactTask.unregisterListener(getContext());
        getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID);
        if (contactChangeObserver!=null){
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MsgIncomingReceiver);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.left_back:
                baseActivity.finish();
                break;


            case R.id.searchParent:
                mSearch_edittext.requestFocus();
                KeyBoardUtils.openKeybord(mSearch_edittext, getActivity());
                break;
        }

    }



    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }




    @Override
    public void onResume() {
        super.onResume();


        Log.i(TAG, " onResume ");
        updateBadge();

        presenter.initData(false,true);

    }


    public void updateBadge() {
        if (!isAdded()){
            return;
        }

    }


    @Override
    public void setAdapter(List<PeopleEntity> friend,char[] alphaLetters) {
        Log.i(TAG, "setAdapter");
        if (isDetached() || getActivity() == null || getActivity().isFinishing()){
            return;
        }

        mPrivateAdapter.setData(friend);

        indexBar.resetLetters(alphaLetters);

    }



}
