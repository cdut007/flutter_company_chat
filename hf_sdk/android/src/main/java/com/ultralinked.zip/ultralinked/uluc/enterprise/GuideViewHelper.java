package com.ultralinked.uluc.enterprise;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.MotionEvent;
import android.view.View;

import com.github.amlcurran.showcaseview.OnShowcaseEventListener;
import com.github.amlcurran.showcaseview.ShowcaseView;
import com.github.amlcurran.showcaseview.SimpleShowcaseEventListener;
import com.github.amlcurran.showcaseview.targets.ActionViewTarget;
import com.github.amlcurran.showcaseview.targets.ViewTarget;
import com.ultralinked.uluc.enterprise.utils.SPUtil;


/**
 * Created by ultralinked on 16/10/8.
 */

public class GuideViewHelper {

    private static  SharedPreferences guideSp = null;
    private  static SharedPreferences getGuideSp(){
        if (guideSp == null){
            guideSp= App.getInstance().getSharedPreferences("guide_info", Context.MODE_PRIVATE);
        }
        return guideSp;
    }



    public static void setAppVersion(int version){
        String lastUserGuide =  getGuideSp().getString("guide","");
        getGuideSp().edit().putInt("appVersion",version).apply();

    }



    public static int getAppVersion(){
        return  getGuideSp().getInt("appVersion",-1);
    }



    public static void addUserGuide(String userGuide){
        String lastUserGuide = getUserGuide();
        getGuideSp().edit().putString("guide",lastUserGuide+userGuide+",").apply();

    }



    private static String getUserGuide(){
        return  getGuideSp().getString("guide","");
    }


    public  static  boolean  checkHasThisGuideLabel(String labelId){
        String userGuide = getUserGuide();
        return userGuide.contains(labelId);

    }


    public  static  void checkNeedDisPlayUserGuideInfo(Activity activity, View targetView, final String guideLabelId,String title, String infoTips, final OnShowcaseEventListener listener){

        if (!checkHasThisGuideLabel(guideLabelId)){

            new ShowcaseView.Builder(activity)
                    .setTarget(new ViewTarget(targetView))
                    .setContentTitle(title)
                    .setContentText(infoTips)
                    .setShowcaseEventListener(new OnShowcaseEventListener() {
                        @Override
                        public void onShowcaseViewHide(ShowcaseView showcaseView) {
                            if (listener!=null){
                                listener.onShowcaseViewHide(showcaseView);
                            }
                        }

                        @Override
                        public void onShowcaseViewDidHide(ShowcaseView showcaseView) {
                            if (listener!=null){
                                listener.onShowcaseViewDidHide(showcaseView);
                            }
                            addUserGuide(guideLabelId);
                        }

                        @Override
                        public void onShowcaseViewShow(ShowcaseView showcaseView) {
                            if (listener!=null){
                                listener.onShowcaseViewShow(showcaseView);
                            }
                        }

                        @Override
                        public void onShowcaseViewTouchBlocked(MotionEvent motionEvent) {
                            if (listener!=null){
                                listener.onShowcaseViewTouchBlocked(motionEvent);
                            }
                        }
                    })
                    .hideOnTouchOutside()
                    .build();


        }


    }
}
