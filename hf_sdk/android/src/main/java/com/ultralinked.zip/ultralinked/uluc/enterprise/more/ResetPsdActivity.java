package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MyCustomDialog;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class ResetPsdActivity extends BaseActivity implements View.OnClickListener {

    EditText etOldPsd,etNewPsd,etComPsd;
    MyCustomDialog dialog;

    private String lunchType;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_reset_psd;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        etOldPsd=bind(R.id.etOldPassword);
        etNewPsd=bind(R.id.etNewPassword);
        etComPsd=bind(R.id.etConPassword);

        lunchType=getIntent().getExtras().getString("lunch_model");
        Log.i(TAG,"type======"+lunchType);

//        if ("login_psd".equals(lunchType)){
//             if (SPUtil.getLoginModel()==SPUtil.LOGIN_BY_OTP && !SPUtil.getUserHasPsd()){
//                 goneView(etOldPsd);
//                 goneView(bind(R.id.OldPasswordLine));
//             }
//        }
        goneView(etOldPsd);
        //goneView(bind(R.id.OldPasswordLine));

        initListener(this,R.id.btRequest,R.id.tvSetPsd,R.id.left_back);
    }


    private void setLoginPsd(String oldpas,String psd1) {
        ApiManager.getInstance().changeUserPassword(oldpas,psd1)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"setLoginPsdComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, HttpErrorException.handErrorMessage(e));
                        showToast(com.holdingfuture.flutterapp.hfsdk.R.string.option_error);
                        dialog.dismiss();
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);

                        showToast(com.holdingfuture.flutterapp.hfsdk.R.string.option_success);
                        SPUtil.saveLoginModel(SPUtil.LOGIN_BY_PSD);
                        dialog.dismiss();
                        finish();
                    }

                });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btRequest:

               final String oldPsd=etOldPsd.getText().toString();
                String newPsd=etNewPsd.getText().toString();
                final String comPsd=etComPsd.getText().toString();

                if(/*TextUtils.isEmpty(oldPsd) ||*/ TextUtils.isEmpty(newPsd) || TextUtils.isEmpty(comPsd)){
                    showToast(R.string.check_password);
                    return;
                }

                if(!newPsd.equals(comPsd)){
                    showToast(getString(R.string.check_not_same_password));
                    return;
                }

                dialog= MyCustomDialog.getInstance(this);
                dialog.showWaiting("Request",false);

                if("login_psd".equals(lunchType)){
                    setLoginPsd(oldPsd,comPsd);
                }else if("private_psd".equals(lunchType)){
                    if(!oldPsd.equals(SPUtil.getUserPrivatePsd())){
                        showToast(getString(R.string.old_password_error));
                        dialog.dismiss();
                    }else{
                        dialog.dismiss();
                        setPrivatePsd(comPsd);
                    }
                }



                // TODO: 2016/8/3 0003 密码重置

                break;
            case R.id.tvSetPsd:
//                lunchActivity(SetPasswordActivity.class);
//                finish();
                break;

            case R.id.left_back:
                finish();
                break;
        }
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        ((TextView)bind(R.id.titleCenter)).setText(R.string.reset_password);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    private void setPrivatePsd(final String psd1) {
        //private psd
        ApiManager.getInstance().changePrivatePsd(psd1)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"getUserComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, HttpErrorException.handErrorMessage(e));
                        showToast(getString(R.string.option_error));
                        dialog.dismiss();
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        SPUtil.saveUserPrivatePsd(psd1);
                        showToast(getString(R.string.option_success));
                        dialog.dismiss();
                        finish();
                    }

                });
    }



}
