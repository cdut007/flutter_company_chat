package com.ultralinked.uluc.enterprise.utils;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

/**
 * Created by ulpc1 on 2016/11/9.
 */

public class DividerGridDecoration extends RecyclerView.ItemDecoration {

    private int dividerHeight;
    private int columnCount;
    private boolean isNoShowFooterDivider;

    public DividerGridDecoration(int columnCount, int dividerHeight, boolean isNoShowFooterDivider) {
        this.columnCount = columnCount;
        this.dividerHeight = dividerHeight;
        this.isNoShowFooterDivider = isNoShowFooterDivider;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        if(isNoShowFooterDivider&&isLastRow(view,parent))
            return;
        outRect.bottom = dividerHeight;
    }

    //Judge if the view belongs to last row.
    private boolean isLastRow(View view ,RecyclerView parent){
        return (parent.getChildLayoutPosition(view)>=(parent.getAdapter().getItemCount()-columnCount));
    }
}
