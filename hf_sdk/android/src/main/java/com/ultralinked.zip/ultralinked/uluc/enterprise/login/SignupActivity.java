package com.ultralinked.uluc.enterprise.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MyCustomDialog;

public class SignupActivity extends LoginActivity{


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.titleRight).setVisibility(View.GONE);
        titleCenter = bind(R.id.titleCenter);
        titleLeft = bind(R.id.left_back);
        titleLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        if (getIntent().getBooleanExtra("company",false)){
            titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.sign_up_for_company);
            getSupportFragmentManager()
                    .beginTransaction()
                  //  .setCustomAnimations(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out, com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out)
                    .replace(R.id.container,new CreateWithCompanyFragment(),"CreateWithCompanyFragment")
                    .commit();

        }else{
            titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.sign_up);
            getSupportFragmentManager()
                    .beginTransaction()
                    //.setCustomAnimations(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out, com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out)
                    .replace(R.id.container,new SignupFragment(),"SignupFragment")
                    .commit();

        }



        fragmentManager = getSupportFragmentManager();

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
        boolean flag = getIntent().getBooleanExtra("is_force_logout", false);
        if (flag) {
            showLogoutDialog();

        }
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.force_logout_info)).setMessage(getString(R.string.force_logout_detail)).setCancelable(true).setPositiveButton("OK", null).create().show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("signup", "onDestroy~~~");
    }

    @Override
    public void onBackPressed() {
       if (isTaskRoot()){
           startActivity(new Intent(this,GuideActivity.class));
       }
        finish();
    }


    @Override
    public void loginSuccess() {

    }

    @Override
    public void loginError(String e) {
        showToast(e);
    }


    public void setResultAndFinish(int result){
        setResult(result);
        this.finish();
    }



}
