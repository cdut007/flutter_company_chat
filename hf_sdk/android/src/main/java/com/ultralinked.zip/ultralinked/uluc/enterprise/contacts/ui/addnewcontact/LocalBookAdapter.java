package com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;

/**
 * Created by ultralinked on 16/7/19.
 */
public class LocalBookAdapter extends MyBaseAdapter<PeopleEntity>  implements SectionIndexer{



    private static final String TAG = "LocalBookAdapter";


    public LocalBookAdapter(Context context) {

        super(context,R.layout.localbook_list_item,new ArrayList<PeopleEntity>());

    }




    @Override
    public void setHolder(MyHolder holder, PeopleEntity localContact) {



        ImageView ivAvatar =  holder.getView(R.id.contactitem_avatar_iv);
        TextView tvCatalog =  holder.getView(R.id.contactitem_catalog);
        TextView tvNick = holder.getView(R.id.contactitem_nick);
        TextView phone = holder.getView(R.id.phone);



        char catalog = localContact.getLetter();

        tvCatalog.setText(String.valueOf(catalog));

        if (holder.getPosition() == 0) {
            tvCatalog.setVisibility(View.VISIBLE);
        } else {
            int index = holder.getPosition() - 1;
            if (index <getList().size() && index >= 0){
                PeopleEntity NextUser = getList().get(index);
                char lastCatalog = NextUser.getLetter();

                if (catalog == lastCatalog) {
                    tvCatalog.setVisibility(View.GONE);
                } else {
                    tvCatalog.setVisibility(View.VISIBLE);
                }
            }else{
                tvCatalog.setVisibility(View.GONE);
            }

        }

        ImageUtils.loadCircleImage(getContext(),ivAvatar, localContact.icon_url, ImageUtils.getDefaultContactImageResource(localContact.mobile));


        tvNick.setText(localContact.name);
        phone.setText(localContact.mobile);
    }



    @Override
    public Object[] getSections() {
        return null;
    }

    @Override
    public int getPositionForSection(int section) {
        for (int i = 0; i < getList().size(); i++) {
            PeopleEntity user = getList().get(i);
            Character letter = user.getLetter();

            char firstChar = letter;
            if (firstChar == section) {
                return i;
            }
        }
        return 0;
    }


    @Override
    public int getSectionForPosition(int position) {
        return 0;
    }

}
