package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.Conversation;

/**
 * Created by Administrator on 2016/8/19 0019.
 */
public class SingleChatImActivity extends BaseChatImActivity{

    private static final String TAG = "SingleChatImActivity";

    /**
     * 启动到单聊界面
     * @param context
     * @param number
     */
    public static void launchToSingleChatIm(@NonNull Context context, @NonNull String number, int chatFlag){
        launchToSingleChatImWithIntentFlags(context,number,chatFlag,-1);
    }


    /**
     * 启动到单聊界面
     * @param context
     * @param number
     */
    public static void launchToSingleChatImWithIntentFlags(@NonNull Context context, @NonNull String number, int chatFlag,int IntentFlags){
        Bundle data = new Bundle();
        data.putString(Constants.PHONE_NUMBER_KEY,number);
        data.putInt(Constants.CHAT_TYPE_KEY, Conversation.SINGLE_CHAT);
        data.putInt(Constants.CHAT_FLAG,chatFlag);
        data.putInt(Constants.LAUNCH_FLAG,Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Intent intent = new Intent(context, SingleChatImActivity.class);
        intent.putExtras(data);
        if (IntentFlags!=-1){
            intent.addFlags(IntentFlags);
        }

        context.startActivity(intent);
        Log.i(TAG,"number:"+number);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TCAgent.onPageStart(getActivity(),"单聊");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"单聊");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG,"onNewIntent~~~");



    }
}
