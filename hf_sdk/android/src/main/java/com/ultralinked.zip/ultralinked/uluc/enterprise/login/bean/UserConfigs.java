package com.ultralinked.uluc.enterprise.login.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.Roles;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/7/18 0018.
 */
public class UserConfigs implements Parcelable {



    private String access_token;
    private String domain;
    private String id;
    private String private_contact_password;

    private SettingsBean settings;
    private String username;
    private String nickname;
    private boolean has_password;
    private boolean has_company;
   // private ArrayList<Roles> roles;

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrivate_contact_password() {
        return private_contact_password;
    }

    public void setPrivate_contact_password(String private_contact_password) {
        this.private_contact_password = private_contact_password;
    }

    public SettingsBean getSettings() {
        return settings;
    }

    public void setSettings(SettingsBean settings) {
        this.settings = settings;
    }

    public String getUsername() {
        return username;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isHas_password() {
        return has_password;
    }

    public void setHas_password(boolean has_password) {
        this.has_password = has_password;
    }

    public boolean isHas_company() {
        return has_company;
    }

    public void setHas_company(boolean has_company) {
        this.has_company = has_company;
    }

    public String getNickname() {
        return nickname;
    }

//    public List<Roles> getRoles() {
//        return roles;
//    }
//
//    public void setRoles(ArrayList<Roles> roles) {
//        this.roles = roles;
//    }


    public static class SettingsBean {
        private String android_production_push_key;
        private String android_stage_push_key;
        private String api_websocket_addr;
        private String audio_codecs;
        private String audio_ice_enable;
        private String connection_mode;
        private String ddd1;
        private String domain;
        private String http_proxy_ip;
        private String http_proxy_port;
        private String im_domain;
        private String im_server_ip;
        private String im_server_port;
        private String im_tls_port;
        private String im_websocket_ip;
        private String im_websocket_port;
        private String ios_production_push_cert;
        private String ios_production_push_key;
        private String ios_stage_push_cert;
        private String ios_stage_push_key;
        private String key5;
        private String sip_proxy_ip;
        private String sip_proxy_port;
        private String sip_websocket_ip;
        private String sip_websocket_port;
        private String stage_test_accounts;
        private String task1;
        private String teskkey3;
        private String tunnel_ip;
        private String tunnel_port;
        private String turn_ip;
        private String turn_password;
        private String turn_port;
        private String turn_username;

        public List<PeopleEntity> assistant;

        public  String ulweb_manager_url;

        public  String qrcode_url;

        public String getAndroid_production_push_key() {
            return android_production_push_key;
        }

        public void setAndroid_production_push_key(String android_production_push_key) {
            this.android_production_push_key = android_production_push_key;
        }

        public String getAndroid_stage_push_key() {
            return android_stage_push_key;
        }

        public void setAndroid_stage_push_key(String android_stage_push_key) {
            this.android_stage_push_key = android_stage_push_key;
        }

        public String getApi_websocket_addr() {
            return api_websocket_addr;
        }

        public void setApi_websocket_addr(String api_websocket_addr) {
            this.api_websocket_addr = api_websocket_addr;
        }

        public String getAudio_codecs() {
            return audio_codecs;
        }

        public void setAudio_codecs(String audio_codecs) {
            this.audio_codecs = audio_codecs;
        }

        public String getAudio_ice_enable() {
            return audio_ice_enable;
        }

        public void setAudio_ice_enable(String audio_ice_enable) {
            this.audio_ice_enable = audio_ice_enable;
        }

        public String getConnection_mode() {
            return connection_mode;
        }

        public void setConnection_mode(String connection_mode) {
            this.connection_mode = connection_mode;
        }

        public String getDdd1() {
            return ddd1;
        }

        public void setDdd1(String ddd1) {
            this.ddd1 = ddd1;
        }

        public String getDomain() {
            return domain;
        }

        public void setDomain(String domain) {
            this.domain = domain;
        }

        public String getHttp_proxy_ip() {
            return http_proxy_ip;
        }

        public void setHttp_proxy_ip(String http_proxy_ip) {
            this.http_proxy_ip = http_proxy_ip;
        }

        public String getHttp_proxy_port() {
            return http_proxy_port;
        }

        public void setHttp_proxy_port(String http_proxy_port) {
            this.http_proxy_port = http_proxy_port;
        }

        public String getIm_domain() {
            return im_domain;
        }

        public void setIm_domain(String im_domain) {
            this.im_domain = im_domain;
        }

        public String getIm_server_ip() {
            return im_server_ip;
        }

        public void setIm_server_ip(String im_server_ip) {
            this.im_server_ip = im_server_ip;
        }

        public String getIm_server_port() {
            return im_server_port;
        }

        public void setIm_server_port(String im_server_port) {
            this.im_server_port = im_server_port;
        }

        public String getIm_tls_port() {
            return im_tls_port;
        }

        public void setIm_tls_port(String im_tls_port) {
            this.im_tls_port = im_tls_port;
        }

        public String getIm_websocket_ip() {
            return im_websocket_ip;
        }

        public void setIm_websocket_ip(String im_websocket_ip) {
            this.im_websocket_ip = im_websocket_ip;
        }

        public String getIm_websocket_port() {
            return im_websocket_port;
        }

        public void setIm_websocket_port(String im_websocket_port) {
            this.im_websocket_port = im_websocket_port;
        }

        public String getIos_production_push_cert() {
            return ios_production_push_cert;
        }

        public void setIos_production_push_cert(String ios_production_push_cert) {
            this.ios_production_push_cert = ios_production_push_cert;
        }

        public String getIos_production_push_key() {
            return ios_production_push_key;
        }

        public void setIos_production_push_key(String ios_production_push_key) {
            this.ios_production_push_key = ios_production_push_key;
        }

        public String getIos_stage_push_cert() {
            return ios_stage_push_cert;
        }

        public void setIos_stage_push_cert(String ios_stage_push_cert) {
            this.ios_stage_push_cert = ios_stage_push_cert;
        }

        public String getIos_stage_push_key() {
            return ios_stage_push_key;
        }

        public void setIos_stage_push_key(String ios_stage_push_key) {
            this.ios_stage_push_key = ios_stage_push_key;
        }

        public String getKey5() {
            return key5;
        }

        public void setKey5(String key5) {
            this.key5 = key5;
        }

        public String getSip_proxy_ip() {
            return sip_proxy_ip;
        }

        public void setSip_proxy_ip(String sip_proxy_ip) {
            this.sip_proxy_ip = sip_proxy_ip;
        }

        public String getSip_proxy_port() {
            return sip_proxy_port;
        }

        public void setSip_proxy_port(String sip_proxy_port) {
            this.sip_proxy_port = sip_proxy_port;
        }

        public String getSip_websocket_ip() {
            return sip_websocket_ip;
        }

        public void setSip_websocket_ip(String sip_websocket_ip) {
            this.sip_websocket_ip = sip_websocket_ip;
        }

        public String getSip_websocket_port() {
            return sip_websocket_port;
        }

        public void setSip_websocket_port(String sip_websocket_port) {
            this.sip_websocket_port = sip_websocket_port;
        }

        public String getStage_test_accounts() {
            return stage_test_accounts;
        }

        public void setStage_test_accounts(String stage_test_accounts) {
            this.stage_test_accounts = stage_test_accounts;
        }

        public String getTask1() {
            return task1;
        }

        public void setTask1(String task1) {
            this.task1 = task1;
        }

        public String getTeskkey3() {
            return teskkey3;
        }

        public void setTeskkey3(String teskkey3) {
            this.teskkey3 = teskkey3;
        }

        public String getTunnel_ip() {
            return tunnel_ip;
        }

        public void setTunnel_ip(String tunnel_ip) {
            this.tunnel_ip = tunnel_ip;
        }

        public String getTunnel_port() {
            return tunnel_port;
        }

        public void setTunnel_port(String tunnel_port) {
            this.tunnel_port = tunnel_port;
        }

        public String getTurn_ip() {
            return turn_ip;
        }

        public void setTurn_ip(String turn_ip) {
            this.turn_ip = turn_ip;
        }

        public String getTurn_password() {
            return turn_password;
        }

        public void setTurn_password(String turn_password) {
            this.turn_password = turn_password;
        }

        public String getTurn_port() {
            return turn_port;
        }

        public void setTurn_port(String turn_port) {
            this.turn_port = turn_port;
        }

        public String getTurn_username() {
            return turn_username;
        }

        public void setTurn_username(String turn_username) {
            this.turn_username = turn_username;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.access_token);
        dest.writeString(this.domain);
        dest.writeString(this.id);
        dest.writeString(this.private_contact_password);
        dest.writeString(this.username);
        dest.writeString(this.nickname);
        dest.writeInt(this.has_password?1:0);
        dest.writeInt(this.has_company?1:0);
       // dest.writeSerializable(roles);
        dest.writeParcelable((Parcelable) this.settings, flags);

    }

    public UserConfigs() {
    }

    protected UserConfigs(Parcel in) {
        this.access_token = in.readString();
        this.domain = in.readString();
        this.id = in.readString();
        this.private_contact_password = in.readString();
        this.username = in.readString();
        this.nickname = in.readString();
        this.has_password = in.readInt() == 1;
        this.has_company = in.readInt() == 1;
     //   this.roles = (ArrayList<Roles>) in.readSerializable();
        this.settings = in.readParcelable(SettingsBean.class.getClassLoader());

    }

    public static final Parcelable.Creator<UserConfigs> CREATOR = new Parcelable.Creator<UserConfigs>() {
        @Override
        public UserConfigs createFromParcel(Parcel source) {
            return new UserConfigs(source);
        }

        @Override
        public UserConfigs[] newArray(int size) {
            return new UserConfigs[size];
        }
    };
}
