package com.ultralinked.uluc.enterprise.chat.chatim.paint;

import android.content.Context;

/**
 * Created by ultralinked on 16/9/30.
 */

public class DrawResource {

    public  static Context context;

    public static float getDimensionPixelSize(int drawingViewBrushDefaultSize) {
        return (float) (context.getResources().getDimensionPixelSize(drawingViewBrushDefaultSize));
    }

    public static int dpToPixel(int dp) {
        return  dp;
    }

    public static Context getContext() {
        return context;
    }
}
