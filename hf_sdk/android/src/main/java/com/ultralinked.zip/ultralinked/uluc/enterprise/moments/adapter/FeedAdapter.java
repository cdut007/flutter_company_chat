package com.ultralinked.uluc.enterprise.moments.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.TTSActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.moments.activity.ImagePagerActivity;
import com.ultralinked.uluc.enterprise.moments.activity.UserFeedActivity;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedGameViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedImageViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedTextViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedURLViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedVideoViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.FeedViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.ImageViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.URLViewHolder;
import com.ultralinked.uluc.enterprise.moments.adapter.viewholder.VideoViewHolder;
import com.ultralinked.uluc.enterprise.moments.bean.FeedUserLineItem;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.moments.utils.DatasUtil;
import com.ultralinked.uluc.enterprise.moments.widgets.CircleVideoView;
import com.ultralinked.uluc.enterprise.moments.widgets.CommentListView;
import com.ultralinked.uluc.enterprise.moments.widgets.MultiImageView;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.TextMessage;

import java.util.ArrayList;
import java.util.List;

public class FeedAdapter extends BaseRecycleViewAdapter {

    public final static int TYPE_HEAD = 0;

    private static final int STATE_IDLE = 0;
    private static final int STATE_ACTIVED = 1;
    private static final int STATE_DEACTIVED = 2;
    private int videoState = STATE_IDLE;
    public static final int HEADVIEW_SIZE = 1;

    int curPlayIndex = -1;

    private Context context;
    private User headInfo;

    public FeedAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return TYPE_HEAD;
        }

        int itemType = 0;
        FeedUserLineItem item = (FeedUserLineItem) datas.get(position - 1);
        if (FeedUserLineItem.TYPE_URL.equals(item.type)) {
            itemType = FeedViewHolder.TYPE_URL;
        } else if (FeedUserLineItem.TYPE_IMG.equals(item.type)) {
            itemType = FeedViewHolder.TYPE_IMAGE;
        } else if (FeedUserLineItem.TYPE_GAME.equals(item.type)) {
            itemType = FeedViewHolder.TYPE_GAME;
        } else if (FeedUserLineItem.TYPE_VIDEO.equals(item.type)) {
            itemType = FeedViewHolder.TYPE_VIDEO;
        } else if (FeedUserLineItem.TYPE_TEXT.equals(item.type)) {
            itemType = FeedViewHolder.TYPE_TEXT;
        } else {
            itemType = FeedViewHolder.TYPE_IMAGE;//default.
        }
        return itemType;
    }

    public void setHeadInfo(User headInfo) {
        this.headInfo = headInfo;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        if (viewType == TYPE_HEAD) {
            View headView = LayoutInflater.from(parent.getContext()).inflate(R.layout.comments_head_circle, parent, false);
            viewHolder = new HeaderViewHolder(headView);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.feed_base_user_cell, parent, false);

            if (viewType == FeedViewHolder.TYPE_URL) {
                viewHolder = new FeedURLViewHolder(view);
            } else if (viewType == FeedViewHolder.TYPE_IMAGE) {
                viewHolder = new FeedImageViewHolder(view);
                FeedImageViewHolder feedImageViewHolder = (FeedImageViewHolder) viewHolder;
                feedImageViewHolder.contentView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (itemListener != null) {
                            int pos = Integer.parseInt(view.getTag().toString());
                            itemListener.onItemClick(pos);
                        }
                    }
                });
            } else if (viewType == FeedViewHolder.TYPE_GAME) {
                viewHolder = new FeedGameViewHolder(view);
                FeedGameViewHolder feedGameViewHolder = (FeedGameViewHolder) viewHolder;
                feedGameViewHolder.contentView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (itemListener != null) {
                            int pos = Integer.parseInt(view.getTag().toString());
                            itemListener.onItemClick(pos);
                        }
                    }
                });
            } else if (viewType == FeedViewHolder.TYPE_VIDEO) {
                viewHolder = new FeedVideoViewHolder(view);
            } else if (viewType == FeedViewHolder.TYPE_TEXT) {
                viewHolder = new FeedTextViewHolder(view);
            }


        }


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int position) {

        if (getItemViewType(position) == TYPE_HEAD) {
            HeaderViewHolder holder = (HeaderViewHolder) viewHolder;

            ImageView largeIcon = (ImageView) holder.itemView.findViewById(R.id.comment_large_bg);


            ImageView userIcon = (ImageView) holder.itemView.findViewById(R.id.comment_user_small_icon);
            TextView userName = (TextView) holder.itemView.findViewById(R.id.comment_user_name);

            TextView signature = (TextView) holder.itemView.findViewById(R.id.comment_user_signature);

            String userId = "";

            if (headInfo != null) {
                userId = headInfo.getId();
                userName.setText(headInfo.getName());
                ImageUtils.loadCircleImage(context, userIcon, headInfo.getHeadUrl(), ImageUtils.getDefaultContactImageResource(""));
            }


            User user = SPUtil.getMomentInfo(userId);
            String cover = user.cover;
            if (TextUtils.isEmpty(cover)) {
                cover = "http://img10.3lian.com/sc6/show02/38/65/386515.jpg";
            }
            ImageUtils.loadImageByString(context, largeIcon, cover);

            if (!TextUtils.isEmpty(user.signature) && !user.signature.equals("null")) {
                signature.setText(user.signature);
            }


        } else {

            final int feedPosition = position - HEADVIEW_SIZE;
            final FeedViewHolder holder = (FeedViewHolder) viewHolder;

            final FeedUserLineItem feedUserLineItem = (FeedUserLineItem) datas.get(feedPosition);


            holder.timeDayTv.setText("" + feedUserLineItem.day);
            holder.timeMonthTv.setText("" + feedUserLineItem.month);

            switch (holder.viewType) {

                case FeedViewHolder.TYPE_GAME:// 处理game
                    if (holder instanceof FeedGameViewHolder) {
                        final List<String> photos = new ArrayList<>();
                        if (!TextUtils.isEmpty(feedUserLineItem.cover)) {
                            photos.add(feedUserLineItem.cover);
                        }
                        FeedGameViewHolder feedGameViewHolder = ((FeedGameViewHolder) holder);
                        feedGameViewHolder.contentView.setTag(feedPosition + "");
                        if (photos != null && photos.size() > 0) {
                            feedGameViewHolder.multiImageView.setList(photos);
                            feedGameViewHolder.multiImageView.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                                @Override
                                public void onItemClick(View view, int position) {
                                    //imagesize是作为loading时的图片size
                                    ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                                    ImagePagerActivity.startImagePagerActivity(context, photos, position, imageSize);
                                }
                            });
                        } else {
                            if (feedUserLineItem.photoCount > 1) {
                                feedGameViewHolder.photoCountView.setText(String.format("%d ", feedUserLineItem.photoCount));
                            } else {
                                feedGameViewHolder.photoCountView.setText("");
                            }

                            feedGameViewHolder.textView.setMaxLines(3);

                        }
                        if (photos.isEmpty()) {
                            feedGameViewHolder.multiImageView.setVisibility(View.GONE);
                            feedGameViewHolder.photoCountView.setVisibility(View.GONE);
                            feedGameViewHolder.contentView.setBackgroundColor(Color.rgb(240, 240, 240));
                        } else {

                            feedGameViewHolder.multiImageView.setVisibility(View.VISIBLE);
                            feedGameViewHolder.photoCountView.setVisibility(View.VISIBLE);
                            feedGameViewHolder.contentView.setBackgroundColor(Color.TRANSPARENT);
                        }
                        feedGameViewHolder.textView.setText(feedUserLineItem.text);
                    }

                    break;


                case FeedViewHolder.TYPE_IMAGE:// 处理图片
                    if (holder instanceof FeedImageViewHolder) {
                        final List<String> photos = feedUserLineItem.photos;

                        FeedImageViewHolder feedImageViewHolder = ((FeedImageViewHolder) holder);
                        feedImageViewHolder.contentView.setTag(feedPosition + "");
                        if (photos != null && photos.size() > 0) {
                            feedImageViewHolder.multiImageView.setList(photos);
                            feedImageViewHolder.multiImageView.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                                @Override
                                public void onItemClick(View view, int position) {
                                    if (GameModel.isChesse(feedUserLineItem.text) && headInfo != null) {
                                        String userId = headInfo.getId();
                                        UserFeedActivity.startChessGame((BaseActivity) context, userId);
                                    } else {
                                        //imagesize是作为loading时的图片size
                                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                                        ImagePagerActivity.startImagePagerActivity(context, photos, position, imageSize);
                                    }

                                }
                            });
                        } else {
                            if (feedUserLineItem.photoCount >= 1) {
                                feedImageViewHolder.photoCountView.setText(String.format("%d ", feedUserLineItem.photoCount));
                            } else {
                                feedImageViewHolder.photoCountView.setText("");
                            }

                            feedImageViewHolder.textView.setMaxLines(3);

                        }
                        if (photos.isEmpty()) {
                            feedImageViewHolder.multiImageView.setVisibility(View.GONE);
                            feedImageViewHolder.photoCountView.setVisibility(View.GONE);
                            feedImageViewHolder.contentView.setBackgroundColor(Color.rgb(240, 240, 240));
                        } else {

                            feedImageViewHolder.multiImageView.setVisibility(View.VISIBLE);
                            feedImageViewHolder.photoCountView.setVisibility(View.VISIBLE);
                            feedImageViewHolder.contentView.setBackgroundColor(Color.TRANSPARENT);
                        }
                        feedImageViewHolder.textView.setText(feedUserLineItem.text);
                    }

                    break;
                case FeedViewHolder.TYPE_TEXT:
                    FeedTextViewHolder feedTextViewHolder = ((FeedTextViewHolder) holder);
                    feedTextViewHolder.textView.setText(feedUserLineItem.text);
                    feedTextViewHolder.hiddenImages();
                    feedTextViewHolder.multiImageView.setVisibility(View.GONE);
                    feedTextViewHolder.photoCountView.setVisibility(View.GONE);
                    feedTextViewHolder.contentView.setBackgroundColor(Color.rgb(240, 240, 240));
                    feedTextViewHolder.textView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent mIntent = new Intent(context, TTSActivity.class);
                            mIntent.putExtra("text", feedUserLineItem.text);
                            mIntent.putExtra("sound", false);
                            context.startActivity(mIntent);
                        }
                    });
                    break;

                default:
                    break;
            }

        }
    }

    @Override
    public int getItemCount() {
        return datas.size() + 1;//有head需要加1
    }


    public class HeaderViewHolder extends RecyclerView.ViewHolder {

        public HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

}
