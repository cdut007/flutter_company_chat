package com.ultralinked.uluc.enterprise.login;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MyCustomDialog;

public class LoginActivity extends BaseActivity  implements  LoginView{

    private MyCustomDialog loadDialog;
    public Fragment login1Fragment;
    public TextView titleCenter;
    public ImageView titleLeft;
    FragmentManager fragmentManager;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.titleRight).setVisibility(View.GONE);
        titleCenter = bind(R.id.titleCenter);
        titleLeft = bind(R.id.left_back);
       // titleLeft.setVisibility(View.GONE);
        titleLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        titleCenter.setText(R.string.signin);
        login1Fragment=new Login1Fragment();
        fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container,login1Fragment, "Login1Fragment");
        fragmentTransaction.commit();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
        boolean flag = getIntent().getBooleanExtra("is_force_logout", false);
        if (flag) {
            showLogoutDialog();

        }
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.force_logout_info)).setMessage(getString(R.string.force_logout_detail)).setCancelable(true).setPositiveButton("OK", null).create().show();

    }



    public void showDialog() {
        if (null == loadDialog) {
            loadDialog = MyCustomDialog.getInstance(this);
        }
        loadDialog.showWaiting(getString(R.string.waiting),false);
    }

    @Override
    public void hideDialog() {
        if (loadDialog != null) {
            loadDialog.dismiss();
        }
    }


    @Override
    public void loginSuccess() {

    }

    @Override
    public void loginError(String e) {
        showToast(e);
    }


    @Override
    protected void onDestroy() {
        if (loadDialog != null && loadDialog.isShowing()) {
            loadDialog.dismiss();
            loadDialog=null;
        }
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().findFragmentByTag("Login1Fragment") == null){
            titleCenter.setText(R.string.signin);
            //titleLeft.setVisibility(View.GONE);
            fragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.left_in, R.anim.left_out,R.anim.left_in, R.anim.left_out)
                    .replace(R.id.container, login1Fragment,"Login1Fragment")
                    .commit();

        }else{
            //super.onBackPressed();
            if (isTaskRoot()){
                startActivity(new Intent(this,GuideActivity.class));
            }
            finish();
        }
    }


    public void replaceFg(@NonNull Fragment fragment,@NonNull String tag){
        fragmentManager.beginTransaction()
                .setCustomAnimations(R.anim.left_in, R.anim.left_out,R.anim.left_in, R.anim.left_out)
                .replace(R.id.container, fragment,tag)
                .commit();
    }


}
