package com.ultralinked.uluc.enterprise.baseui.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.support.v7.widget.PopupMenu;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.LinearInterpolator;
import android.widget.Button;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;

/**
 * Created by lly on 2016/9/18.
 */
public class OTPButton extends Button{

    ValueAnimator animator;

    public OTPButton(Context context) {
        this(context,null);

    }

    public OTPButton(final Context context, AttributeSet attrs) {
        super(context,attrs);
        setBackgroundResource(R.drawable.corners_bg_otp);
        setTextColor(getResources().getColor(R.color.white));
        setPadding(ScreenUtils.dp2px(context,12),ScreenUtils.dp2px(context,4),ScreenUtils.dp2px(context,12),ScreenUtils.dp2px(context,4));
        ImageUtils.buttonEffect(this);
        animator = ValueAnimator.ofInt(60,0);
        animator.setDuration(60000);
        animator.setRepeatCount(0);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                try {
                    resetInfo(false);
                } catch (Exception e) {

                    com.ultralinked.uluc.enterprise.utils.Log.i("resetInfo","resetInfo timer:"+Log.getStackTraceString(e));
                }
            }
        });
    }

    private void resetInfo(boolean forceReset) throws Exception{
        setText(String.format(getContext().getString(R.string.otp_request_waiting),animator.getAnimatedValue().toString()));
        if(((int)animator.getAnimatedValue())==0 || forceReset){
            setEnabled(true);
            setText(getContext().getString(R.string.request_otp));
        }
    }


    public  void cancelCountDown(){
       try{
           if (animator!=null &&(animator.isRunning() || animator.isRunning())){
               animator.cancel();
           }
           resetInfo(true);
       }catch (Exception e){
          com.ultralinked.uluc.enterprise.utils.Log.i("cancelCountDonwn","cancel countdown timer:"+Log.getStackTraceString(e));
       }
    }

 public  interface  OnRequestTypeListener{
     void clickType(String type);
 }



    public void click(final OnRequestTypeListener listener) {

        PopupMenu popupMenu = new PopupMenu(getContext(), this);
        Menu menu = popupMenu.getMenu();

//        // 通过代码添加菜单项
//        menu.add(Menu.NONE, Menu.FIRST + 0, 0, "复制");
//        menu.add(Menu.NONE, Menu.FIRST + 1, 1, "粘贴");

        // 通过XML文件添加菜单项
        MenuInflater menuInflater = popupMenu.getMenuInflater();
        menuInflater.inflate(R.menu.pop_menu, menu);

        // 监听事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.otp: {

                        try {

                            listener.clickType(null);
                            setEnabled(false);
                            animator.start();
                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.i("otpbutton", "get the countDown error:" + Log.getStackTraceString(e));
                        }

                    }
                    break;
                    case R.id.voice_opt: {

                        try {
                            listener.clickType("voice");
                            setEnabled(false);
                            animator.start();
                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.i("otpbutton", "get the voice countDown error:" + Log.getStackTraceString(e));
                        }

                    }
                    break;
//                    case Menu.FIRST + 0:
//                        Toast.makeText(PopupMenuActivity.this, "复制",
//                                Toast.LENGTH_LONG).show();
//                        break;
//                    case Menu.FIRST + 1:
//                        Toast.makeText(PopupMenuActivity.this, "粘贴",
//                                Toast.LENGTH_LONG).show();
//                        break;
                    default:
                        break;
                }
                return false;
            }
        });
        popupMenu.show(); //showing popup menu
    }



}
