package com.ultralinked.uluc.enterprise.contacts.ui.pendinglist;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 16/7/19.
 */
public class PendingInviteAdapter extends MyBaseAdapter<PeopleEntity> {

    private Context context;
    private PeopleEntityFilter mFilter;
    private ArrayList<PeopleEntity> mUnfilteredData;

    public PendingInviteAdapter(Context context, int resource, List<PeopleEntity> list) {
        super(context, resource, list);
        this.context=context;
    }

    @Override
    public void updateList(List<PeopleEntity> list) {
        super.updateList(list);
        if (mUnfilteredData != null) {
            mUnfilteredData = null;
        }
    }

    @Override
    public void setHolder(MyHolder viewHolder, PeopleEntity peopleEntity) {


        viewHolder.setText(R.id.pending_title,PeopleEntityQuery.getDisplayName(peopleEntity));
        viewHolder.setText(R.id.pending_description,peopleEntity.mobile);
        String status = context.getString(R.string.pending);
        int color = context.getResources().getColor(R.color.color_e0635a);
        if ("accept".equals(peopleEntity.status)){
            status = context.getString(R.string.accept);
            color = context.getResources().getColor(R.color.color_53e79d);
        }
        viewHolder.setText(R.id.pending_status,status);

        viewHolder.setTextColor(R.id.pending_status,color);

        ImageUtils.loadCircleImage(context,(ImageView) viewHolder.getView(R.id.pending_image), peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));


    }



    private static final String TAG = "PendingInviteAdapter";

    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new PeopleEntityFilter();
        }
        return mFilter;
    }

    // 异步过滤数据，避免数据多耗时长堵塞主线程
    class PeopleEntityFilter extends Filter {
        // 执行筛选
        @Override
        protected FilterResults performFiltering(CharSequence prefix) {
            FilterResults results = new FilterResults();

            if (mUnfilteredData == null) {
                mUnfilteredData = new ArrayList<PeopleEntity>(list);
            }

            if (prefix == null || prefix.length() == 0) {
                ArrayList<PeopleEntity> list = mUnfilteredData;
                results.values = list;
                results.count = list.size();
            } else {
                String prefixString = prefix.toString().toLowerCase();

                ArrayList<PeopleEntity> unfilteredValues = mUnfilteredData;
                int count = unfilteredValues.size();

                ArrayList<PeopleEntity> newValues = new ArrayList<PeopleEntity>(count);

                for (int i = 0; i < count; i++) {
                    PeopleEntity h = unfilteredValues.get(i);
                    if (h != null) {
                        String str =  PeopleEntityQuery.getDisplayName(h);
                        if (str != null) {
                            str = str.toLowerCase();
                        }
                        if (!TextUtils.isEmpty(str)&&str.contains(prefixString)) {
                            newValues.add(h);
                        }

                    }
                }

                results.values = newValues;
                results.count = newValues.size();
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            //noinspection unchecked
            list = (List<PeopleEntity>) results.values;
            if (results.count > 0) {
                notifyDataSetChanged();
            } else {
                notifyDataSetInvalidated();
            }
        }
    }
}
