package com.ultralinked.uluc.enterprise.chat.chatim;



import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.holdingfuture.flutterapp.hfsdk.R;


public class EmotionAdapter extends BaseAdapter {
	private Context mContext;
	private int emotions[];
	private LayoutInflater mInflater;
	
	int size;
	public EmotionAdapter(Context context ,int emotions[],int size) {
		this.mContext = context;
		this.emotions = emotions;
		this.size = size;
		this.mInflater=	 LayoutInflater.from(context); 
	}

	
//	public EmotionAdapter(Context context ,Bitmap emotions[]) {
//		this.mContext = context;
//		this.emotions = emotions;
//		this.mInflater=	 LayoutInflater.from(context); 
//	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return emotions.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return emotions[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		
		 ViewHolder viewHolder;
		if(convertView == null) {
	            viewHolder=new ViewHolder();
	     
				convertView=mInflater.inflate(R.layout.item_face, null);
				
	            viewHolder.iv_face=(ImageView)convertView.findViewById(R.id.item_iv_face);
	            
	            convertView.setTag(viewHolder);
	            
	        } else {
	        	
	            viewHolder=(ViewHolder)convertView.getTag();
	            
	        }

	//	viewHolder.iv_face.setImageBitmap(emotions[position]);
		if (emotions[position]!=0) {
			Drawable drawable=ImEmotionMap.getDrawable(emotions[position], size);
			if (drawable!=null) {
				viewHolder.iv_face.setImageDrawable(drawable);
			}
			
			convertView.setBackgroundResource(R.drawable.iv_face);
			
			
		}else {
			convertView.setBackgroundDrawable(null);
		}
		
		
		convertView.setTag(viewHolder);
		
		return convertView;
	}
	
	public class ViewHolder{
		
		ImageView iv_face;
		
	}
}
