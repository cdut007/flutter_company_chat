package com.ultralinked.uluc.enterprise.chat.bean;

/**
 * Created by Administrator on 2016/8/16 0016.
 */
public class DLocation {
    /**
     * 经度
     */
    public double longitude;
    /**
     * 纬度
     */
    public double latitude;

    public DLocation(double longitude, double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
    }
}
