package com.ultralinked.uluc.enterprise.chat.bean;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

import java.io.File;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.property.Email;
import ezvcard.property.FormattedName;
import ezvcard.property.Organization;
import ezvcard.property.Telephone;
import ezvcard.property.Title;
import ezvcard.property.Url;

/**
 * Created by Chenlu on 2016/8/11 0011.
 */
public class VCardInfo {
    private VCard vCard;
    private String vCardPath;
    public static VCardInfo instance;

    private PeopleEntity peopleEntity;



    public static VCardInfo getInstance(String vCardPath) {
        instance = new VCardInfo(vCardPath);
        return instance;
    }

    private VCardInfo(String vCardPath) {
        this.vCardPath = vCardPath;

    }

    private static VCard parseVcardFromFile(String vCardPath) {
        try {
            File e = new File(vCardPath);
            VCard vcard = Ezvcard.parse(e).first();
            return vcard;
        } catch (Exception var3) {
            var3.printStackTrace();
            android.util.Log.i("parseVcard", "parse vcard error = " + var3.getLocalizedMessage());
            return null;
        }
    }

    public PeopleEntity getPeopleEntity() {
        if (vCard == null) {
            vCard = parseVcardFromFile(vCardPath);
        }
        if (vCard == null) {
            return null;
        }
        if (peopleEntity == null) {
            peopleEntity = new PeopleEntity();
            List<Title> titles = vCard.getTitles();
            if (titles != null && titles.size() > 0) {
                peopleEntity.subuser_id = titles.get(0).getValue();
            }
            /**
             * organization:ezvcard.property.Organization [ group=null | parameters={} | values=[ultralinked, ultralinked] ]
             * formattedName:ezvcard.property.FormattedName [ group=null | parameters={} | value=changqing ]
             * nickname:ezvcard.property.Nickname [ group=null | parameters={} | values=[] ]
             * emails is:[ezvcard.property.Email [ group=null | parameters={TYPE=[work]} | value=changqing@ultralinked.com ]]
             */
            FormattedName formattedName = vCard.getFormattedName();
            if (formattedName != null) {
                peopleEntity.nickname = formattedName.getValue();
                peopleEntity.name = formattedName.getValue();
            }
            Organization organization = vCard.getOrganization();
            if (organization != null) {
                List<String> values = organization.getValues();
                if (values != null && values.size() > 0) {
                    peopleEntity.companyName = values.get(0);

                }
                if (values != null && values.size() > 1) {
                    peopleEntity.deparment_name = values.get(1);
                }
            }
            List<Email> emails = vCard.getEmails();
            if (emails != null && emails.size() > 0) {
                peopleEntity.email = emails.get(0).getValue();
            }
            List<Telephone> telephoneNumbers = vCard.getTelephoneNumbers();
            if (telephoneNumbers != null && telephoneNumbers.size() > 0) {
                peopleEntity.mobile = telephoneNumbers.get(0).getText();
            }
            List<Url> urls = vCard.getUrls();
            if (urls != null && urls.size() > 0) {
                peopleEntity.icon_url = urls.get(0).getValue();
            }
        }

        return peopleEntity;
    }
}
