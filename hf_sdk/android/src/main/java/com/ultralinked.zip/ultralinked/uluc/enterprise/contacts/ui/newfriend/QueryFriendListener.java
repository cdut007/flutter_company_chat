package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

import java.util.List;

/**
 * Created by mac on 16/11/24.
 */

public interface QueryFriendListener {
    void onResultFriendList(List<PeopleEntity> entities);
    void onQueryFailed(List<String> requestUserIds);

}
