package com.ultralinked.uluc.enterprise.chat.chatim;

import android.text.TextUtils;

import com.baidu.location.Address;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.utils.GPSUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.LocationMessage;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

/**
 * Created by ultralinked on 16/10/7.
 */
public class LocationModel {
    public static final int REQUEST = 1;
    public static final int ACCEPT = 2;
    public static final int REJECT = 3;
    public static final String TYPE_LOCATION = "location";
    private int locAction;

    JSONObject jsonObject = new JSONObject();
    JSONObject locationData;

    public LocationClient mLocationClient = null;


    public LocationModel(){

    }

    long lastCheckLocationTime;
    public void locate(final String contactNumber){

        if (!App.getInstance().baiduSDkInited){
            App.getInstance().initBaiduSDK();
        }

        if (mLocationClient!=null){
            if (mLocationClient.isStarted()){
                mLocationClient.stop();
            }
        }

        mLocationClient = new LocationClient(App.getInstance());     //声明LocationClient类

        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationClientOption.LocationMode.Battery_Saving
        );//可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("bd09ll");//可选，默认gcj02，设置返回的定位结果坐标系
        int span=1000*5;
        // option.setScanSpan(span);//可选，默认0，即仅定位一次，设置发起定位请求的间隔需要大于等于1000ms才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认false,设置是否使用gps
        option.setLocationNotify(false);//可选，默认false，设置是否当gps有效时按照1S1次频率输出GPS结果
        option.setIsNeedLocationDescribe(true);//可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到
        option.setIgnoreKillProcess(false);//可选，默认true，定位SDK内部是一个SERVICE，并放到了独立进程，设置是否在stop的时候杀死这个进程，默认不杀死
        option.SetIgnoreCacheException(true);//可选，默认false，设置是否收集CRASH信息，默认收集
        option.setEnableSimulateGps(false);//可选，默认false，设置是否需要过滤gps仿真结果，默认需要
        option.setNeedDeviceDirect(true);// 返回的定位结果包含手机机头的方向
        option.setTimeOut(10 * 1000); // 超时

        mLocationClient.setLocOption(option);

        mLocationClient.registerLocationListener(new BDLocationListener() {
            @Override
            public void onReceiveLocation(BDLocation bdLocation) {

                if (bdLocation == null) {
                    return;
                }

                String city = bdLocation.getCity();
                String cityCode = bdLocation.getCityCode();
                String province = bdLocation.getProvince();
                Address address = bdLocation.getAddress();
                String addrStr = bdLocation.getAddrStr();
                String buildingName = bdLocation.getBuildingName();
                String locationDescribe = bdLocation.getLocationDescribe();
                String street = bdLocation.getStreet();
                String streetNumber = bdLocation.getStreetNumber();
                String coorType = bdLocation.getCoorType();
                List poiList = bdLocation.getPoiList();
                String firstPoi = poiList != null && poiList.size() > 0 ? poiList.get(0).toString() : "null";
                String content= new StringBuffer().append("city:" + city + " cityCode:" + cityCode + " province:" + province + " address:" + address + " addrStr:" + addrStr + " buildingName:" + buildingName)
                        .append(" locationDescrible:").append(locationDescribe)
                        .append(" sreet:").append(street)
                        .append(" streetNumber:").append(streetNumber)
                        .append("coorType:").append(coorType)
                        .append(" firstPoi:").append(firstPoi).toString();

                Log.i(GPSUtils.TAG, "当前定位的位置(经纬度)：" + bdLocation.getLongitude() + "," + bdLocation.getLatitude() + "--->" + content);
                double[] doubles = GPSUtils.bd09_To_gps84(bdLocation.getLatitude(), bdLocation.getLongitude());

                double latitude = doubles[0];
                double longitude = doubles[1];
                String title = TextUtils.isEmpty(bdLocation.getBuildingName()) ? App.getInstance().getString(R.string.share_location) : bdLocation.getBuildingName();
                String subTitle = TextUtils.isEmpty(bdLocation.getAddrStr()) ? App.getInstance().getString(R.string.unknow_adress) : bdLocation.getAddrStr();


                HashMap<String, String> map = new HashMap<>();
                map.put(LocationMessage.LATITUDE, latitude + "");
                map.put(LocationMessage.LONGITUDE, longitude + "");
                map.put(LocationMessage.TITLE, title);
                map.put(LocationMessage.SUBTITLE, subTitle);
                //Conversation conversation = MessagingApi.getConversation(contactNumber);
                //conversation.sendLocation(map, new Message.Options());
                Conversation conversation = MessagingApi.getConversation(contactNumber);
                if (conversation != null) {
                    LocationModel locationModel = new LocationModel();
                    JSONObject locationObj = new JSONObject();
                    try {
                        locationObj.put("content","当前定位的位置(经纬度)：" + bdLocation.getLongitude() + "," + bdLocation.getLatitude() + "--->" + content);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    mLocationClient.stop();
                    mLocationClient.unRegisterLocationListener(this);
                    //
                    long checkTime = System.currentTimeMillis();

                    if (checkTime - lastCheckLocationTime < 3000){

                        return;
                    }
                    lastCheckLocationTime = checkTime;

                    conversation.sendCustomBroadcast(LocationModel.TYPE_LOCATION, locationModel.accept(locationObj));//accept
                }



            }
        });
        mLocationClient.start();
    }


    public LocationModel(String locationInfo) {
        try {
            jsonObject = new JSONObject(locationInfo);
            String action = jsonObject.optString("action");
            if ("request".equals(action)){
                locAction = REQUEST;
            }else if("accept".equals(action)){
                locAction = ACCEPT;
            }else if("reject".equals(action)){
                locAction = REJECT;
            }
            locationData = jsonObject.optJSONObject("locationData");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public JSONObject getLocationData() {
        return locationData;
    }

    public int geLocationAction() {

        return locAction;
    }

    public JSONObject accept(JSONObject locationData) {
        try {
            jsonObject.put("action","accept");
            jsonObject.put("locationData",locationData);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    public JSONObject reject() {
        try {
            jsonObject.put("action","reject");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }


    public JSONObject request() {
        try {
            jsonObject.put("action","request");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }


    public void insertSecurityTips(String chatId, String info) {
        MessagingApi.insertTextMessage(chatId,chatId, SPUtil.getUserID(), info, Conversation.SINGLE_CHAT);
    }
}
