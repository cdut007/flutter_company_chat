package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.call.CallModel;
import com.ultralinked.uluc.enterprise.chat.viewpagerindicator.IconPagerAdapter;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;

import java.util.ArrayList;
import java.util.List;

public class ChatEmotionPagerAdapter extends PagerAdapter implements
		IconPagerAdapter {
	private static final String TAG = "ChatEmotionPagerAdapter";
	public static final int pageCount = 21,stickerPageCount = 8;
	private Context mContext;
	private List<View> viewList;
	private final OnChildItemSelectId alertDo;
	private final OnGroupItemSelected itemSelected;

	private int conversationType = Conversation.SINGLE_CHAT;




	public static final int  TYPE_EMOTION=0;
	public static final int  TYPE_STICKER=1;


	public ChatEmotionPagerAdapter(Context ctx, int conversationType,
								   OnChildItemSelectId childItemId, OnGroupItemSelected itemSelected) {
		this.mContext = ctx;
		viewList = new ArrayList<View>();
		this.alertDo = childItemId;
		this.itemSelected = itemSelected;
		this.conversationType = conversationType;

	}

	public void releaseResource() {
		// TODO Auto-generated method stub
	//	mContext.unregisterReceiver(receiver);

	}


	public interface OnChildItemSelectId {
		void onClick(int whichButton, int resourceType, int page, String resDesc);
	}

	public interface OnGroupItemSelected {
		void onClick(int whichButton);
	}

	// switch to different emotion page
	public void switchTo(int positon) {
		switch (positon) {
		case 0: // normal emotions
			initEmotionsDate();
			Log.i(TAG, "show emotions");
			break;
		case 1:// gif emotions
			break;
		case 2: // tubasiji emotions
			break;
		case 3:// internet emotions
			break;
		default:
			break;
		}
		this.notifyDataSetChanged();
	}


	public void changeMenuItemState(int idle) {
		// TODO Auto-generated method stub
//		mode.callType = idle;
//		if (menuAdapter != null) {
//			menuAdapter.changeResourceID(idle, conversationType, resourceids);// setback
//
//		}
	}
	


	static class ViewHolder {
		public TextView menuItem;
		public ImageView menuImage;
	}

	//Bitmap pageEmotions[];
  int pageEmotionIDs[];
	// emotions
  
	private void initEmotionsDate() {
		viewList.clear();
		int i = 0;
		int size =mContext.getResources().getDimensionPixelSize(R.dimen.px_32_0_dp);
		int emotionSize = ImEmotionMap.getEmotionNum();
		do {
			View viewgView = View.inflate(mContext, R.layout.chat_im_bottom_emotion_gird, null);
			GridView gv = (GridView) viewgView.findViewById(R.id.chat_emotion_gird);
			viewgView.setBackgroundColor(mContext.getResources().getColor(R.color.chat_menu_emotion_bg));
			gv.setBackgroundColor(mContext.getResources().getColor(R.color.chat_menu_emotion_bg));
			gv.setSelector(R.drawable.transparent);
			
			gv.setNumColumns(pageCount / 3);
			pageEmotionIDs = new int[pageCount];

			
			for (int count = 0; count <= pageCount - 1; count++) {
				if (i * (pageCount ) + count <= emotionSize - 1) {
					pageEmotionIDs[count] = ImEmotionMap.getEmotionResId(i
							* (pageCount ) + count);
				}
			}
			// page number
			final int page = i;
			gv.setAdapter(new EmotionAdapter(mContext, pageEmotionIDs,size));
			gv.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					alertDo.onClick(position,TYPE_EMOTION, page,null);
				}
			});
			viewList.add(viewgView);
			i++;
		} while (i * (pageCount - 1) < emotionSize);
		
		//for sticker
		createSticker(ImStickerMap.im_programmer_gif);
		createSticker(ImStickerMap.im_seals_gif);
		
	}

	private void createSticker(final String stickerNameTag) {
		ImStickerMap stickerMap = ImStickerMap.getInstance(mContext);
		int stickerSize = stickerMap.getStickerNum(stickerNameTag);
		int size = ScreenUtils.dp2px(mContext, 64.4f);
		int i = 0;
		do {
			View viewgView = View.inflate(mContext, R.layout.chat_im_bottom_emotion_gird, null);
			GridView gv = (GridView) viewgView.findViewById(R.id.chat_emotion_gird);
			viewgView.setBackgroundColor(mContext.getResources().getColor(R.color.chat_menu_emotion_bg));
			gv.setBackgroundColor(mContext.getResources().getColor(R.color.chat_menu_emotion_bg));
			gv.setSelector(R.drawable.transparent);
			gv.setNumColumns(stickerPageCount / 2);
			final String[] pageStickerIDs = new String[stickerPageCount];
			//pageEmotions = new Bitmap[pageCount];
			
			for (int count = 0; count <= stickerPageCount - 1; count++) {
				if (i * (stickerPageCount ) + count <= stickerSize - 1) {
					pageStickerIDs[count] = ImStickerMap.getStickerResId(stickerNameTag,i
							* (stickerPageCount ) + count);
				}
			}
			// page number
			final int page = i;
			
			final StickerAdapter stickerAdapter = new StickerAdapter(mContext, pageStickerIDs,size);
			gv.setAdapter(stickerAdapter);
			gv.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					alertDo.onClick(position,TYPE_STICKER, page,pageStickerIDs[position]);
				}
			});
			gv.addOnAttachStateChangeListener(new OnAttachStateChangeListener() {
				
				@Override
				public void onViewDetachedFromWindow(View v) {
					// TODO Auto-generated method stub
						stickerAdapter.clearCache();
						Log.i(TAG, "recycle ");

				}
				
				@Override
				public void onViewAttachedToWindow(View v) {
					// TODO Auto-generated method stub
					
				}
			});
			
			viewList.add(viewgView);
			i++;
		} while (i * (stickerPageCount - 1) < (stickerSize-1));
	
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		// page count
		return viewList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		// TODO Auto-generated method stub
		return arg0 == arg1;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		try {
			container.removeView(viewList.get(position));
		} catch (Exception e) {
			Log.i(TAG, "current page count is less then previous count");
		}
	}

	@Override
	public int getItemPosition(Object object) {

		return super.getItemPosition(object);
	}

	@Override
	public CharSequence getPageTitle(int position) {

		return super.getPageTitle(position);
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		container.addView(viewList.get(position));

		return viewList.get(position);
	}

	@Override
	public int getIconResId(int index) {
		// TODO Auto-generated method stub
		return R.drawable.dot_state;
	}



}
