package com.ultralinked.uluc.enterprise.contacts.ui.selectmember;

import android.content.Context;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ultralinked on 16/7/26.
 */

public class SelectMemberAdapter extends MyBaseAdapter<PeopleEntity> {

    private Context context;

    public SelectMemberAdapter(Context context) {
        super(context, R.layout.expand_list_item_select, new ArrayList<PeopleEntity>());
        this.context = context;
    }



    @Override
    public void setHolder(MyHolder holder, PeopleEntity entity) {

        TextView tvTitle = (TextView) holder.getView(R.id.expandedListItem);
        ImageView IvHead = (ImageView) holder.getView(R.id.expandedListItem_Head);
        CheckBox checkBox = (CheckBox) holder.getView(R.id.expandedListItem_CheckBox);

        String expandedListText = PeopleEntityQuery.getDisplayName(entity);
        tvTitle.setText(expandedListText);

        int defaultId = ImageUtils.getDefaultContactImageResource(entity.subuser_id);
        ImageUtils.loadCircleImage(context, IvHead, entity.icon_url, defaultId);


        if (entity.isSelected) {
            checkBox.setBackgroundResource(R.mipmap.choose_click);
            checkBox.setChecked(true);
        } else {
            checkBox.setBackgroundResource(R.mipmap.choose);
            checkBox.setChecked(false);
        }


    }




    //                用于存放Indicator的集合
    private SparseArray<ImageView> mIndicators = new SparseArray<>();

    //            根据分组的展开闭合状态设置指示器
    public void setIndicatorState(int groupPosition, boolean isExpanded) {
        if (isExpanded) {
            mIndicators.get(groupPosition).setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.triangle_down);
        } else {
            mIndicators.get(groupPosition).setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.triangle_right);
        }
    }
}
