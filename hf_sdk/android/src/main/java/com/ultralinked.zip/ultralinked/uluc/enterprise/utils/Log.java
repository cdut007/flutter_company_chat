package com.ultralinked.uluc.enterprise.utils;



/**
 * Created by ultralinked on 2016/6/8 0008.
 * ULUC 日志工具类
 */


        import android.content.Context;
        import android.os.Environment;
        import android.os.Handler;
        import android.os.HandlerThread;
        import android.os.Process;
        import android.preference.PreferenceManager;
        import android.support.compat.BuildConfig;

        import com.ultralinked.voip.api.CallApi;
        import com.ultralinked.voip.api.ConfigApi;
        import com.ultralinked.voip.api.utils.*;

        import org.android.Config;

        import java.io.File;
        import java.io.FileWriter;
        import java.io.PrintWriter;
        import java.text.SimpleDateFormat;
        import java.util.Date;


public class Log {


    private static final int VERBOSE = android.util.Log.VERBOSE;
    private static final int DEBUG = android.util.Log.DEBUG;
    private static final int INFO = android.util.Log.INFO;
    private static final int WARN = android.util.Log.WARN;
    private static final int ERROR = android.util.Log.ERROR;
    private static final int ASSERT = android.util.Log.ASSERT;
    private static final long MAX_LOG_FILE = 1024 * 1024 * 3; //3MB

    private static boolean sDebug = false;
    private static boolean sFileLog = false;
    private static final SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    private static final SimpleDateFormat sFormat1 = new SimpleDateFormat("yyyyMMdd");

    private static File sDir = new File(Environment.getExternalStorageDirectory(), ConfigApi.appName+"/Logs/");



    static {
        sFileLog = sDir.exists() && sDir.isDirectory();
        sDebug = sFileLog;

    }

    public  static  void init(Context context){
        String appName =  ConfigApi.appName;
        String imLogPath = com.ultralinked.voip.api.utils.FileUtils.getSDPath() + File.separator + appName + File.separator + "IMLogs";
        com.ultralinked.voip.api.utils.FileUtils.createFileDir(imLogPath);
        sDir = new File(imLogPath);
        sFileLog = sDir.exists() && sDir.isDirectory();
        sDebug = sFileLog;

    }


    public static boolean isDebug() {
        return sDebug;
    }

    private static boolean isFileLog() {
        return sFileLog;
    }

    public static boolean isLoggable(int i) {
        return isDebug();
    }

    public static boolean isLoggable() {
        return isDebug();
    }

    private static String levelToStr(int level) {
        switch (level) {
            case VERBOSE:
                return "V";
            case DEBUG:
                return "D";
            case INFO:
                return "I";
            case WARN:
                return "W";
            case ERROR:
                return "E";
            case ASSERT:
                return "A";
            default:
                return "UNKNOWN";
        }
    }

    private static File getLogFile() {
        File file = new File(sDir.getAbsolutePath()+ File.separator + "Log_UI.log");
        File dir = file.getParentFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return file;
    }

    private static HandlerThread sHandlerThread;
    private static Handler sHandler;

    static {
        sHandlerThread = new HandlerThread("ULUC@FileLogThread");
        sHandlerThread.start();
        sHandler = new Handler(sHandlerThread.getLooper());
    }

    private static void logToFile(final int level, final String tag, final String format, final Throwable tr) {
        sHandler.post(new Runnable() {
            @Override
            public void run() {
                logToFileInner(level, tag, format, tr);
            }
        });
    }

    private static void logToFileInner(int level, String tag, String format, Throwable tr) {
        PrintWriter writer = null;
        try {


            File logFile = getLogFile();
            if (logFile.length() > MAX_LOG_FILE) {
                logFile.delete();
            }
            if (format == null){
                return;
            }

            writer = new PrintWriter(new FileWriter(logFile, true));
            String msg = format;
            String log = String.format("%s %s-%s/%s %s/%s %s", sFormat.format(new Date()), Process.myPid(), Process.myUid(), getProcessName(), levelToStr(level), tag, msg);
            writer.println(log);
            if (tr != null) {
                tr.printStackTrace(writer);
                writer.println();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    private static String getProcessName() {
        return "ULUC_UI";
    }

    private static void println(final int level, final String tag, final String format, final Throwable tr) {

        logToFile(level, tag, format, tr);

    }

    public static void v(String tag, String format, Object... args) {
        v(tag, format, null, args);
    }

    public static void v(String tag, String format, Throwable tr, Object... args) {
        if (!isLoggable(VERBOSE)) {
            return;
        }

        println(VERBOSE, tag, format, tr);
    }




    public static void wtf(String tag, String format) {
        wtf(tag, format, null);
    }

    public static void wtf(String tag, Throwable tr) {
        wtf(tag, "wtf", tr);
    }

    public static void wtf(String tag, String format, Throwable tr) {
        if (!isLoggable()) {
            return;
        }
        println(ASSERT, tag, format, tr);
    }


    private Log() {}

    //日志打印开关
    public static boolean isLogEnable = com.ultralinked.uluc.enterprise.BuildConfig.DEBUG;

    /**
     * Debug
     *
     * @param tag
     * @param msg
     */
    public static void d(String tag, String msg) {

        if (msg == null){
            msg = "null";
        }

        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.d(tag, rebuildMsg(stackTraceElement, msg));
        }

        println(DEBUG, tag, msg, null);
    }

    /**
     * Information
     *
     * @param tag
     * @param msg
     */
    public static void i(String tag, String msg) {
        if (msg == null){
            msg = "null";
        }

        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.i(tag, rebuildMsg(stackTraceElement, msg));
        }

        println(INFO, tag, msg, null);
    }

    /**
     * Information
     * show method name
     * @param tag
     */
    public static void i(String tag) {
        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.i(tag, rebuildMsg(stackTraceElement,""));
        }
        i(tag,"only print tag");
    }

    /**
     * Verbose
     *
     * @param tag
     * @param msg
     */
    public static void v(String tag, String msg) {
        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.v(tag, rebuildMsg(stackTraceElement, msg));
        }



        println(VERBOSE, tag, msg, null);

    }

    public static void w(String tag, String msg) {
        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.w(tag, rebuildMsg(stackTraceElement, msg));
        }


        println(WARN, tag, msg, null);
    }


    public static void e(String tag, String msg) {
        if (isLogEnable) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            android.util.Log.e(tag, rebuildMsg(stackTraceElement, msg));
        }


        println(ERROR, tag, msg, null);
    }

    /**
     * 格式化msg形式
     *
     * @param msg
     * @return
     */
    private static String rebuildMsg(StackTraceElement stackTraceElement, String msg) {
        StringBuffer sb = new StringBuffer();
        sb.append("begin loginfo."+stackTraceElement.getFileName());
        sb.append(" (");
        sb.append(stackTraceElement.getLineNumber());
        sb.append(") ");
        sb.append(stackTraceElement.getMethodName());
        sb.append(" : ");
        sb.append(msg);
        return sb.toString();
    }

}
