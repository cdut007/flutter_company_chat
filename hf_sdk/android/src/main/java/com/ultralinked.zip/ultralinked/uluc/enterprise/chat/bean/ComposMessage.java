package com.ultralinked.uluc.enterprise.chat.bean;

import com.ultralinked.voip.api.CustomMessage;

/**
 * Created by Administrator on 2016/8/8 0008.
 */
public class ComposMessage extends CustomMessage {
    public static final int MESSAGE_TYPE_COMPOSMESSAGE = 100;

    public boolean isComposing() {
        return isComposing;
    }

    public void setComposing(boolean composing) {
        isComposing = composing;
    }

    private boolean isComposing;


    public ComposMessage() {
        isSender = false;
        setKeyId(Integer.MIN_VALUE);
        setType(MESSAGE_TYPE_COMPOSMESSAGE);
    }
}
