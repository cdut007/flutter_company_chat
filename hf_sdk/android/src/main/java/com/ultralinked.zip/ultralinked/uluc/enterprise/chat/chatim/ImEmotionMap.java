package com.ultralinked.uluc.enterprise.chat.chatim;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.R.integer;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.DisplayMetrics;

import android.util.Xml;
import android.webkit.WebView.FindListener;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.ultralinked.uluc.enterprise.utils.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class ImEmotionMap {
	// We don't use namespaces
	private static HashMap<String, String> emotionMap = null;
	private static HashMap<String, String> emotion_CN_Map = null;
	//public static HashMap<String, SoftReference<Bitmap>> emotionCache = null;
	public static HashMap<String, Integer> emotionResids = null;
	private static HashMap<String, String> emotionPicMap = null;
	private static Context app_context = null;
	private static final String ns = null;
	private static List<String> emotions = null, emotionsFromSender = null;

	// private static String locale_String = null;

	public static List xml_parse(InputStream in, int type)
			throws XmlPullParserException, IOException {

		try {
			XmlPullParser parser = Xml.newPullParser();
			parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
			parser.setInput(in, null);
			return xml_readPlist(parser, type);
		} finally {
			in.close();
		}
	}

	private static void xml_skip(XmlPullParser parser)
			throws XmlPullParserException, IOException {
		if (parser.getEventType() != XmlPullParser.START_TAG) {
			throw new IllegalStateException();
		}
		int depth = 1;
		while (depth != 0) {
			switch (parser.next()) {
			case XmlPullParser.END_TAG:
				depth--;
				break;
			case XmlPullParser.START_TAG:
				depth++;
				break;
			}
		}
	}

	private static String xml_readText(XmlPullParser parser)
			throws IOException, XmlPullParserException {
		String result = "";
		if (parser.next() == XmlPullParser.TEXT) {
			result = parser.getText();
			parser.nextTag();
		}
		return result;
	}

	static final int CN = 0, ENGLISH = 1;

	private static List xml_readPlist(XmlPullParser parser, int type)
			throws XmlPullParserException, IOException {
		while (true) {
			parser.nextTag();
			if ((parser.getEventType() == XmlPullParser.START_TAG)
					&& parser.getName().equals("dict")) {
				parser.nextTag();
				break;
			}
		}
		String plist_key = "";
		String plist_string = "";
		while (true) {
			if ((parser.getEventType() == XmlPullParser.END_TAG)
					&& (parser.getName().equals("dict"))) {
				break;
			}
			if (parser.getEventType() != XmlPullParser.START_TAG) {
				parser.nextTag();
				continue;
			}
			String name = parser.getName();
			if (name.equals("key")) {
				plist_key = xml_readText(parser);
			} else if (name.equals("string")) {
				plist_string = xml_readText(parser);
				if (type == CN) {
					emotion_CN_Map.put(plist_string, plist_key);
					emotionsFromSender.add(plist_string);
				} else {
					emotionMap.put(plist_string, plist_key);
					emotionPicMap.put(plist_key, plist_string);
					emotions.add(plist_string);
					// getEmotionBitmap(plist_string);
					getEmotionResId(plist_string);
				}
			} else {
				xml_skip(parser);
			}
		}
		return null;
	}

	// get current dpi

	public static void getCurrentDPI(Activity context) {
		DisplayMetrics metric = new DisplayMetrics();
		context.getWindowManager().getDefaultDisplay().getMetrics(metric);
		int densityDpi = metric.densityDpi;
		currentDpi = densityDpi;
	}

	public static void initEmotionMap(Context context) {
		if (emotionMap != null){
			return;
		}
		Log.i("emotion", "init");
		app_context = context;

		emotions = new ArrayList<String>();
		emotionsFromSender = new ArrayList<String>();
		emotion_CN_Map = new HashMap<String, String>();
		emotionMap = new HashMap<String, String>();
		//emotionCache = new HashMap<String, SoftReference<Bitmap>>();
		emotionResids = new HashMap<String, Integer>();
		emotionPicMap = new HashMap<String, String>();
		// add support mlti language
		String localLanguage = Locale.getDefault().getLanguage();
		String en_language = Locale.ENGLISH.getLanguage();
		String fileName = "emotion_en.plist";
		try {
			InputStream in = context.getResources().getAssets().open(fileName);// EN
			xml_parse(in, ENGLISH);// first we get standrander,
		} catch (IOException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}

		// if (!localLanguage.equalsIgnoreCase(en_language)) {
		try {
			InputStream in = context.getResources().getAssets()
					.open("emotion.plist");// CN
			xml_parse(in, CN);// first we get standrander,
		} catch (IOException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}
		// } else {
		// emotion_CN_Map = emotionMap;// just same in EN environment.
		// emotionsFromSender = emotions;
		// }

	}

	public static HashMap<String, String> getEmotionMap(Context context) {
		if (emotionMap == null)
			initEmotionMap(context);
		return emotionMap;
	}

	static int currentDpi = DisplayMetrics.DENSITY_HIGH;

	public static Bitmap getEmotionBitmapByResId(int resid) {
		Bitmap bitmap = BitmapFactory.decodeResource(
				app_context.getResources(), resid);
		if (currentDpi >= DisplayMetrics.DENSITY_HIGH) {
			if (bitmap!=null&&!bitmap.isRecycled()) {
				Bitmap mBitmap = Bitmap.createScaledBitmap(bitmap, 68, 68, true);
				bitmap.recycle();
				bitmap=null;
				return mBitmap;
			}

		}

		return bitmap;
	}

//	public static Bitmap getEmotionBitmap(int ind, int size) {
//		String key = emotions.get(ind);
//		if (key != null) {
//			Bitmap bitmap = getEmotionBitmap(key);
//			Bitmap mBitmap = bitmap;
//			if (bitmap != null && bitmap.getWidth() != size) {
//				emotionCache.remove(key);
//				bitmap = getEmotionBitmap(key);
//				if (bitmap!=null&&!bitmap.isRecycled()) {
//					mBitmap = Bitmap.createScaledBitmap(bitmap, size, size, true);
//					bitmap.recycle();
//					bitmap=null;
//				}else {
//					emotionCache.remove(key);
//				}
//
//				emotionCache.put(key, new SoftReference<Bitmap>(mBitmap));
//			}
//			return mBitmap;
//		}
//		return null;
//	}



//	public static Bitmap getEmotionBitmap(String key) {
//		Bitmap bitmap = null;
//		if (emotionCache.containsKey(key)) {
//			SoftReference<Bitmap> softReference = emotionCache.get(key);
//			bitmap = softReference.get();
//			if (bitmap != null) {
//				return bitmap;
//			} else {
//				emotionCache.remove(key);
//			}
//		}
//		String filename = emotionMap.get(key);// +".png";
//		if (TextUtils.isEmpty(filename)) {
//			filename = emotion_CN_Map.get(key);// +".png";
//			if (TextUtils.isEmpty(filename)) {
//				return null;
//			}
//		}
//
//		int resId = app_context.getResources().getIdentifier(filename,
//				"drawable", "com.ultralinked.messageplus");
//		if (resId == 0) {
//			String packNameString =app_context.getPackageName();
//			Log.i("ImEmotion", "app_null"+packNameString);
//			return null;
//		}
//		bitmap = BitmapFactory
//				.decodeResource(app_context.getResources(), resId);
//		emotionCache.put(key, new SoftReference<Bitmap>(bitmap));
//		return bitmap;
//	}

	public static int getEmotionResId(int ind) {
		String key = emotions.get(ind);
		if (key != null) {
			return getEmotionResId(key);
		}
		return 0;
	}



	public static int getEmotionResId(String key) {
		Integer ResId = emotionResids.get(key);
		if ((null != ResId) && (ResId > 0))
			return ResId;

		String filename = emotionMap.get(key);
		if (TextUtils.isEmpty(filename)) {
			return 0;
		}
		int resId = app_context.getResources().getIdentifier(filename,
				"drawable", app_context.getPackageName());
		if (resId == 0) {
			return 0;
		}
		emotionResids.put(key, resId);
		return resId;
	}

	public static boolean _dealEmotionExsit(CharSequence emotionChar) {
		String value = emotionMap.get(emotionChar);
		if (TextUtils.isEmpty(value)) {
			value = emotion_CN_Map.get(emotionChar);
			if (TextUtils.isEmpty(value)) {
				return false;
			}
		}
		return !TextUtils.isEmpty(value);

	}

	public static SpannableString _dealEmotion(CharSequence emotionChar,
			int size, Context context) {
		SpannableString emotion = new SpannableString(emotionChar);
		String value = emotionMap.get(emotionChar);
		if (TextUtils.isEmpty(value)) {
			value = emotion_CN_Map.get(emotionChar);
			if (TextUtils.isEmpty(value)) {
				return emotion;
			}
		}

//		Bitmap bitmap = getEmotionBitmap(emotionChar.toString());
//		Bitmap mBitmap = bitmap;
//		if (bitmap != null && bitmap.getWidth() != size) {
//			emotionCache.remove(emotionChar.toString());
//			bitmap = getEmotionBitmap(emotionChar.toString());
//			if (bitmap!=null&&!bitmap.isRecycled()) {
//				mBitmap = Bitmap.createScaledBitmap(bitmap, size, size, true);
//				bitmap.recycle();
//				bitmap=null;
//			}else {
//				emotionCache.remove(emotionChar.toString());
//			}
//
//			emotionCache.put(emotionChar.toString(), new SoftReference<Bitmap>(
//					mBitmap));
//		}
//		emotion.setSpan(new StickerImageSpan(context, mBitmap), 0,
//				emotionChar.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		Drawable eDrawable =getDrawable(getEmotionResId(emotionChar.toString()), size);
		if (eDrawable!=null) {
			emotion.setSpan(new StickerImageSpan(eDrawable), 0,
					emotionChar.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		}

		return emotion;
	}


	  public static Drawable getDrawable( int mResourceId,int size) {

	            try {
	                 Drawable mDrawable = app_context.getResources().getDrawable(mResourceId);
	                 //add drawable cache.
	                 mDrawable.setBounds(0, 0, size, size);
	                return mDrawable;
	            } catch (Exception e) {
	                // swallow
	            }
	        return null;

	    }

	private static synchronized void _dealExpression(Context context,
			SpannableString spannableString, Pattern patten, int start, int size,int alignTextFlag)
			throws Exception {
		Matcher matcher = patten.matcher(spannableString);
		while (matcher.find()) {
			String key = matcher.group();
			String value = emotionMap.get(key);
			if (TextUtils.isEmpty(value)) {
				value = emotion_CN_Map.get(key);
				if (TextUtils.isEmpty(value)) {
					continue;
				}
			}

//			Bitmap bitmap = getEmotionBitmap(key);
//			Bitmap mBitmap = bitmap;
//			if (bitmap != null && bitmap.getWidth() != size) {
//
//				emotionCache.remove(key);
//				bitmap = getEmotionBitmap(key);
//				if (bitmap!=null&&!bitmap.isRecycled()) {
//					mBitmap = Bitmap.createScaledBitmap(bitmap, size, size, true);
//					bitmap.recycle();
//					bitmap=null;
//				}else {
//					emotionCache.remove(key);
//				}
//
//				emotionCache.put(key, new SoftReference<Bitmap>(mBitmap));
//			}



//			spannableString.setSpan(new StickerImageSpan(context, mBitmap,alignTextFlag),
//					matcher.start(), matcher.end(),
//					Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			Drawable eDrawable =getDrawable(getEmotionResId(key), size);

			if (eDrawable!=null) {
				spannableString.setSpan(new StickerImageSpan(eDrawable),matcher.start(), matcher.end(),
						Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			}

		}

	}

	public static SpannableString genSpanString(String emotiontext, int fontSize) {

		return genSpanString(emotiontext, fontSize, ImageSpan.ALIGN_BOTTOM);//default
	}


	public static SpannableString genSpanString(String emotiontext, int fontSize,int alignTextFlag) {
		if (emotiontext == null){
			SpannableString spannableString = new SpannableString("");
			return  spannableString;
		}
		// emotiontext = getEmotionContent(emotiontext);
		SpannableString spannableString = new SpannableString(emotiontext);

		// 閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷峰紡閿熸枻鎷烽敓鏂ゆ嫹閿熻鍑ゆ嫹閿熸枻鎷烽敓瑙掑嚖鎷烽敓鍙唻鎷烽敓浠嬶紝閿熺晫锛�閿熸彮鐚存嫹[閿熸枻鎷烽敓鏂ゆ嫹]閿熸枻鎷�
		String zhengze = "\\[[^\\[^\\]]{1,15}\\]";
		// 閫氶敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熺粸鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹涓�敓鏂ゆ嫹pattern
		Pattern sinaPatten = Pattern.compile(zhengze, Pattern.CASE_INSENSITIVE);
		try {
			_dealExpression(app_context, spannableString, sinaPatten, 0,
					fontSize,alignTextFlag);
		} catch (Exception e) {
			if ( e.getMessage()!=null) {
				Log.e("dealExpression", e.getMessage());
			}

		}
		return spannableString;
	}


	public static CharSequence getEmotionDesc(int index) {
		// TODO Auto-generated method stub
		if (index >= emotions.size()) {
			return "";
		}
		String locale = Locale.getDefault().getLanguage();
		String en_language = Locale.ENGLISH.getLanguage();
		if (en_language.equalsIgnoreCase(locale)) {
			return emotions.get(index);
		} else {
			return emotionsFromSender.get(index);
		}

	}

	public static int getEmotionNum() {
		// TODO Auto-generated method stub
		return emotions.size();
	}




}
