package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.List;

/**
 * Created by ultralinked on 2016/7/6 0006.
 * <p>
 * for input country code
 */
public class EditViewPlus extends FrameLayout {
    TextView textView;
    EditText editText;
    Context context;

    public EditViewPlus(Context context) {
        super(context);
        this.context = context;
        View view = LayoutInflater.from(context).inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.edit_view_plus, this);
        textView = (TextView) view.findViewById(R.id.edit_plus_tv);
        editText = (EditText) view.findViewById(R.id.edit_plus_et);
        initView();
    }

    public EditViewPlus(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        View view = LayoutInflater.from(context).inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.edit_view_plus, this);
        textView = (TextView) view.findViewById(R.id.edit_plus_tv);
        editText = (EditText) view.findViewById(R.id.edit_plus_et);
        initView();
    }

    private void initView() {
        setCountryCode(SPUtil.getCode());
        editText.setSingleLine();
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN)
            editText.setBackground(null);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0) {
                    textView.setEnabled(true);
                } else if (!Character.isDigit(s.charAt(0))) {
                    textView.setEnabled(false);
                } else {
                    textView.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    /**
     * 设置默认显示
     *
     * @param hint
     * @return
     */
    public EditText setHint(String hint) {
        editText.setHint(hint);
        return editText;
    }

    /**
     * 设置国家码文本
     *
     * @param code
     * @return
     */
    public TextView setCountryCode(String code) {
        if (TextUtils.isEmpty(code)){
            return  textView;
        }
        if (!code.startsWith("+")){
            code = "+"+code;
            Log.i("editViewPlus","countryCode is :"+code);
        }
        CharSequence displayCode = textView.getText();
        if (!TextUtils.isEmpty(displayCode) && code.equals(displayCode.toString())){
            Log.i("editViewPlus","countryCode is not changed:"+code);
            return textView;
        }

        textView.setText(code);
        List<CountryInfo> countryInfos = CountryCodeStorageHelper.getInstance().getCountryCodeStorage(context).getAllCountryInfo();

        if (countryInfos != null) {
            try {
                for (CountryInfo countryInfo : countryInfos
                        ) {
                    if (countryInfo.getCountryCode().equals(code)) {
                        Log.i("editViewPlus","find the countryCode is :"+code);
                        int drawableId = getContext().getResources().getIdentifier("flag_" + countryInfo.getShortName(), "raw", context.getPackageName());

                        final Drawable drawable = getResources().getDrawable(drawableId);
                        int iconSize = getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_20_0_dp);
                        drawable.setBounds(0, 0, iconSize, iconSize); //设置边界
                        textView.setCompoundDrawables(null, drawable, null, null);//画在右边
                        break;
                    }

                }
            } catch (Exception e) {
                Log.e("CountryCodePicker", "Failure to get drawable id."+ android.util.Log.getStackTraceString(e));
            }

        }


        return textView;
    }

    /**
     * 获取国家码文本
     *
     * @return 没有 + 的国家码
     */
    public String getCountryCode() {
        String code = textView.getText().toString();
        if (!TextUtils.isEmpty(code) && code.startsWith("+")) {
            code = code.substring(1);
        }
        if (!textView.isEnabled()) {
            code = "";
        }
        return code;
    }

    public void setText(String code, String mobile) {
        setCountryCode(code);
        editText.setText(mobile);
        try {
            editText.setSelection(mobile.length());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置mobile
     *
     * @param mobile
     * @return
     */
    public EditText setMobile(String mobile) {
        editText.setText(mobile);
        try {
            editText.setSelection(mobile.length());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return editText;
    }


    /**
     * 获取输入文本
     *
     * @return
     */
    public String getText() {
        return editText.getText().toString();
    }

    /**
     * 获取所有文本
     *
     * @return
     */
    public String getTextAll() {
        return textView.isEnabled() ? getCountryCode() + getText() : getText();
    }

    /**
     * code listener set
     */
    public void setCodeListener(OnClickListener listener) {
        if (listener != null) {
            textView.setOnClickListener(listener);
        }
    }

}
