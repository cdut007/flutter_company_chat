package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by Created by ultralinked.
 */
public class FromContactAdapter extends MyBaseAdapter<PeopleEntity> {

     protected String TAG = "FromContactAdapter";

    private final Context mcontext;

    String CountryCode;

    public FromContactAdapter(Context context, OnFriendClickListener requestFriendListener) {
        super(context, R.layout.item_newfriend,new ArrayList<PeopleEntity>());
        mcontext = context;
        this.requestFriendListener = requestFriendListener;
         CountryCode = SPUtil.getCode();
    }

    public void setData(List<PeopleEntity> raw) {
         updateList(raw);
    }

    OnFriendClickListener requestFriendListener;

    public interface OnFriendClickListener extends  RequestFriendListener{
        void onItemClickListener(PeopleEntity entity);
    }


    HashMap<String,PeopleEntity> alreadyFriendMap = new HashMap<>();

    public void setAlreadyFriendMap(HashMap<String, PeopleEntity> alreadyFriendMap) {
        this.alreadyFriendMap = alreadyFriendMap;
        Log.i(TAG,"set FriendMap info:"+alreadyFriendMap.size());
        notifyDataSetChanged();
    }

    public HashMap<String, PeopleEntity> getAlreadyFriendMap() {
        return alreadyFriendMap;
    }

    @Override
    public void setHolder(MyHolder holder, PeopleEntity peopleEntity) {


        ImageView img_avar =  holder.getView(R.id.img_photo);
        TextView txt_name =  holder.getView( R.id.txt_name);
        TextView txt_msg =  holder.getView( R.id.txt_msg);

        final TextView txt_add = holder.getView(R.id.txt_add);


        ImageUtils.loadCircleImage(mcontext,img_avar, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));


        txt_name.setText(PeopleEntityQuery.getDisplayName(peopleEntity));
        txt_msg.setText(peopleEntity.mobile);
        String matchPhone = PhoneNumberUtils.normalizeMatchNumber(CountryCode, peopleEntity.mobile);
        if ("accepted".equals(peopleEntity.status) || alreadyFriendMap.get(matchPhone)!=null){
            txt_add.setTextColor(mcontext.getResources().getColor(
                    R.color.black1_color));
            txt_add.setBackgroundResource(R.drawable.corners_bg_f5f5f5);
            txt_add.setText(mcontext.getString(R.string.already_added));

            if (!TextUtils.isEmpty(peopleEntity.invite_message)){
                txt_msg.setText(peopleEntity.invite_message);
            }
            txt_msg.setText("+"+peopleEntity.mobile);//already friend.

        }else if("new".equals(peopleEntity.status)){
            txt_add.setTextColor(mcontext.getResources().getColor(
                    R.color.black1_color));
            txt_add.setBackgroundResource(R.drawable.corners_bg_f5f5f5);
            txt_add.setText(mcontext.getString(R.string.verfiy_pending));

        }else if("rejected".equals(peopleEntity.status)){
            txt_add.setTextColor(mcontext.getResources().getColor(
                    R.color.black1_color));
            txt_add.setBackgroundResource(R.drawable.corners_bg_f5f5f5);
            txt_add.setText(mcontext.getString(R.string.reject_status));
        }else if ("invite".equals(peopleEntity.status)){
            txt_add.setTextColor(mcontext.getResources().getColor(
                    R.color.white));
            txt_add.setBackgroundResource(R.drawable.button_invite_selector);
            txt_add.setText(mcontext.getString(R.string.add_contact_button_invite));
        }else {

            //normal,add
            if ("add".equals(peopleEntity.status)){
                txt_msg.setText("+"+peopleEntity.mobile);
                txt_add.setText(mcontext.getString(R.string.add_contact_button_add));
                txt_add.setBackgroundResource(R.drawable.button_selector);
            }else{
                txt_add.setText(mcontext.getString(R.string.add_contact_button_invite));
                txt_add.setBackgroundResource(R.drawable.button_invite_selector);
            }


            txt_add.setTextColor(mcontext.getResources().getColor(
                    R.color.white));


        }

        txt_add.setTag(peopleEntity);

        txt_add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PeopleEntity entity = (PeopleEntity) v.getTag();
                if("accepted".equals(entity.status)|| alreadyFriendMap.get(entity.mobile)!=null)
                {
                    return;
                }
                requestFriendListener.callFriendRequest(entity.status,entity);

            }
        });


        holder.tag = peopleEntity;

        holder.getContentView().setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MyHolder myHolder = (MyHolder) v.getTag();
                PeopleEntity entity = (PeopleEntity) myHolder.tag;

                requestFriendListener.onItemClickListener(entity);


            }
        });



    }


}
