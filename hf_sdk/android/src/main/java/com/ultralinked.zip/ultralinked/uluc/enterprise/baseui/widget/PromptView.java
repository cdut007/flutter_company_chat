package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewStub;
import android.widget.RelativeLayout;

import com.holdingfuture.flutterapp.hfsdk.R;


public class PromptView extends RelativeLayout implements View.OnClickListener{

    private final int CONTENT = 0;
    private final int LOADING = 1;
    private final int EMPTY = 2;
    private final int ERROR = 3;
    private int mCurrentState = CONTENT;

    private View mLoading, mEmpty, mError;
    public View mContent;

    public PromptView(Context context) {
        this(context, null);
    }

    public PromptView(Context context, AttributeSet attrs) {
        super(context, attrs);
        View.inflate(context, R.layout.view_prompt,this);
    }

    public void showLoading(){
        mCurrentState = LOADING;
        switchState();
    }

    public void showEmpty(){
        mCurrentState = EMPTY;
        switchState();
    }

    public void showError(){
        mCurrentState = ERROR;
        switchState();
    }

    public void showContent(){
        mCurrentState = CONTENT;
        switchState();
    }

    private void switchState(){
        switch (mCurrentState){
            case CONTENT:
                setVisibility(GONE);
                mContent.setVisibility(VISIBLE);
                break;
            case LOADING:
                if(getVisibility()==GONE){
                    setVisibility(VISIBLE);
                }
                hideEmpty();
                hideError();
                hideContent();
                initLoading();
                break;
            case EMPTY:
                if(getVisibility()==GONE){
                    setVisibility(VISIBLE);
                }
                hideLoading();
                hideError();
                hideContent();
                initEmpty();
                break;
            case ERROR:
                if(getVisibility()==GONE){
                    setVisibility(VISIBLE);
                }
                hideLoading();
                hideEmpty();
                hideContent();
                initError();
                break;
        }
    }

    public void setContent(View content){
        mContent = content;
    }

    public void initLoading(){
        if(mLoading == null){
            mLoading = ((ViewStub)findViewById(R.id.loading)).inflate();
            mLoading.findViewById(R.id.btn_loading).setOnClickListener(this);
        }else{
            mLoading.setVisibility(VISIBLE);
        }
    }

    public void initEmpty(){
        if(mEmpty == null){
            mEmpty = ((ViewStub)findViewById(R.id.empty)).inflate();
            mEmpty.findViewById(R.id.btn_empty).setOnClickListener(this);
        }else{
            mEmpty.setVisibility(VISIBLE);
        }
    }

    public void initError(){
        if(mError == null){
            mError = ((ViewStub)findViewById(R.id.error)).inflate();
            mError.findViewById(R.id.btn_error).setOnClickListener(this);
        }else{
            mError.setVisibility(VISIBLE);
        }
    }

    public void hideLoading(){
        if(mLoading!=null){
            mLoading.setVisibility(GONE);
        }
    }

    public void hideEmpty(){
        if(mEmpty!=null){
            mEmpty.setVisibility(GONE);
        }
    }

    public void hideError(){
        if(mError!=null){
            mError.setVisibility(GONE);
        }
    }

    public void hideContent(){
        if(mContent!=null){
            mContent.setVisibility(GONE);
        }
    }

    @Override
    public void onClick(View v) {
        showContent();
    }
}
