package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.View;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactLocalBook;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactMannual;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.RxBus;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class AcceptNewFriendActicity extends AddNewFriendActicity {

    @Override
    public void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        if (btnInvite == null){
            return;//maybe finished.
        }

        if (mDetailEntity!=null){
          if ("rejected".equals(mDetailEntity.status)){
              btnInvite.setText(R.string.add_contact_button_invite);
              btnInvite.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      if (mDetailEntity!=null){
                          RequestFriendManager.getInstance().inviteFriend(AcceptNewFriendActicity.this,mDetailEntity);
                      }

                  }
              });
          } else{
              btnInvite.setText(R.string.accept_btn);
              btnInvite.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      if (mDetailEntity!=null){
                          RequestFriendManager.getInstance().acceptFriend(AcceptNewFriendActicity.this,mDetailEntity);
                      }

                  }
              });
          }
        }else{
            Log.i(TAG,"get the detail Entity error the mDetail is null");
        }

    }

}
