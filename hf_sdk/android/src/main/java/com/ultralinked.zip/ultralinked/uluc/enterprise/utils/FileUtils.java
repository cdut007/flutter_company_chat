package com.ultralinked.uluc.enterprise.utils;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.Constants;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.ScanVideoActivity;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.Message;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Created by Chenlu on 2016/6/30 0030.
 */
public class FileUtils {

    private static final String TAG = "FileUtils";
    /**
     * 拷贝文件到指定目录
     * @param src
     * @param dst
     * @throws IOException
     */
    public static void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dst);

        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }

    /**
     * 将字符串写入到文件中
     * @param fileName
     * @param content
     */
    public static void writeFileSdcard(String fileName, String content) {
        try {
            FileOutputStream fout = new FileOutputStream(fileName);
            byte[] bytes = content.getBytes();
            fout.write(bytes);
            fout.flush();
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文件最大限制（单位：字节）
     * @param context
     * @return
     */
    public static long getMaxFileSendLimitedSize(Context context) {
        return Constants.MAX_FILE_SEND_LIMITED_SIZE;
    }

    /**
     * 检查发送的文件是否是允许的类型
     * @param activity
     * @param sendFilePath
     * @return
     */
    public static boolean checkSendfileFormartIsAllow(final BaseActivity activity, String sendFilePath) {

        if (!MediaFile.isSupportFileType(sendFilePath)) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    activity.showToast(com.holdingfuture.flutterapp.hfsdk.R.string.chat_file_format_limit_info);
                }
            });
            return false;
        }
        return true;
    }

    /**
     *
     * @param activity
     * @param fileSize
     * @param showToast
     * @return
     */
    private static boolean checkSendFileSizeIsOk(final BaseActivity activity, long fileSize,boolean showToast) {
        // check file size
        final long maxImageSize = getMaxFileSendLimitedSize(activity);
        Log.i(TAG, "file size====" + (fileSize / (double) (1024 * 1024))
                + ("maxfile===" + (maxImageSize / (double) (1024 * 1024))));
        if (maxImageSize <= fileSize) {
            if (showToast) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String str = activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.chat_file_max_limit_info) + " " + (maxImageSize / (double) (1024 * 1024))
                                + activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.file_unit_m);
                        activity.showToast(str);

                    }
                });
            }
            return false;
        }else if (0 == fileSize) {
            if (showToast) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        activity.showToast(com.holdingfuture.flutterapp.hfsdk.R.string.chat_file_min_limit_info);
                    }
                });
            }
            return false;
        }
        return true;
    }

    /**
     * 检查发送的文件大小是否符合要求
     * @param activity
     * @param sendingFile
     * @param showToast   true：如果不符合要求，弹出toast提示
     * @return
     */
    public static boolean checkSendFileSizeIsOk(BaseActivity activity,
                                                File sendingFile,boolean showToast) {
        // check file size
        return checkSendFileSizeIsOk(activity, sendingFile.length(),showToast);
    }

    /**
     * 检查发送的文件大小是否合适，如果选择的的视频类文件且大于视频文件大小限制，则先压缩
     * @param activity
     * @param sendingFile
     * @return
     */
    public static boolean checkSendileSizeIsOk(BaseActivity activity,
                                                File sendingFile) {
        // check file size
        //if file is video type and mp4  size around 20M~40M,we go video compress first.
        if (checkSendVideoFileSize(activity,sendingFile)) {

            Intent intent = new Intent(activity, ScanVideoActivity.class);
            intent.setAction(ScanVideoActivity.VIDEO_SCAN);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.putExtra("filePath", sendingFile.getAbsolutePath());
            intent.putExtra("fileName", sendingFile.getName());
            intent.putExtra("extraType", "compress_video");
            activity.startActivityForResult(intent, ChatModule.REQUEST_CODE_FOR_SCAN_VIDEO);

            return false;
        }
        return checkSendFileSizeIsOk(activity, sendingFile, true);
    }

    /**file is video type and mp4  size around 20M~40M,we go video compress first.
     * @param activity
     * @param sendingFile
     * @return
     */
    private static boolean checkSendVideoFileSize(BaseActivity activity,
                                                  File sendingFile) {
        if (true) {
            return false;
        }
        MediaFile.MediaFileType type = MediaFile.getFileType(sendingFile.getAbsolutePath());
        if(null != type) {
            //currently only consider the MP4
            if (type.fileType == MediaFile.FILE_TYPE_MP4) {
                //round 20M ~ 50M
                if (sendingFile.length() >= 20*1024*1024 && sendingFile.length() <= 50*1024*1024) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 显示文件选择器
     * @param instance
     * @param requestCode
     */
    public static void showFileChooser(BaseActivity instance, int requestCode) {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

        intent.setType("video/*;image/*");

        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {

            instance.startActivityForResult(
                    Intent.createChooser(intent,
                            instance.getString(com.holdingfuture.flutterapp.hfsdk.R.string.choose_file_title)),
                    requestCode);

        } catch (android.content.ActivityNotFoundException ex) {
            // Potentially direct the user to the Market with a Dialog
            if(instance!=null)
                instance.showDialog(instance.getString(com.holdingfuture.flutterapp.hfsdk.R.string.install_file_explorer));
        }
    }

    /**
     * 获取时间作为文件的名字
     * @return
     */
    public static String getFileNameByDate() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
        return dateFormat.format(date);
    }

    /**
     * 获取时间作为视频文件的名字
     * @return
     */
    public static String getVideoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'VIDEO'_yyyy-MM-dd-HHmmss");
        return dateFormat.format(date) + ".mp4";
    }
    /**
     * 获取时间作为图片文件的名字
     * @return
     */
    public static String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'IMG'_yyyy-MM-dd-HHmmss");
        return dateFormat.format(date) + ".jpg";
    }

    /**
     * 获取时间作为语音文件的名字
     * @return
     */
    public static String getVoiceFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'VOICE'_yyyy-MM-dd-HHmmss");
        return dateFormat.format(date) + ".amr";
    }
    /**
     * Get a file path from a Uri. This will get the the path for Storage Access
     * Framework Documents, as well as the _data field for the MediaStore and
     * other file-based ContentProviders.
     *
     * @param context
     *            The context.
     * @param uri
     *            The Uri to query.
     * @author paulburke
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= 19;// 4.4

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/"
                            + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"),
                        Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] { split[1] };

                return getDataColumn(context, contentUri, selection,
                        selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context
     *            The context.
     * @param uri
     *            The Uri to query.
     * @param selection
     *            (Optional) Filter used in the query.
     * @param selectionArgs
     *            (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri,
                                       String selection, String[] selectionArgs) {

        Cursor cursor = null;
        final String column = MediaStore.MediaColumns.DATA;
        final String[] projection = { column };

        try {
            cursor = context.getContentResolver().query(uri, projection,
                    selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);

                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    /**
     * @param uri
     *            The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri
                .getAuthority());
    }

    /**
     * @param uri
     *            The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri
                .getAuthority());
    }

    /**
     * @param uri
     *            The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri
                .getAuthority());
    }

    // get file absolute path.
    public static String Uri2Filename(Application application, Uri uriName) {
        Log.i("fileURI", "uriName=" + uriName);
        return getPath(application, uriName);
    }


    /**
     * 获取不带扩展名的文件名
     * @param filename
     * @return
     */
    public static String getFileNameNoEx(String filename) {
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length()))) {
                return filename.substring(0, dot);
            }
        }
        return filename;
    }

    /**
     * 获取文件的扩展名
     * Return the extension portion of the file's name .
     *
     * @see #getExtension
     */
    public static String getExtension(File f) {
        return (f != null) ? getExtension(f.getName()) : "";
    }

    public static String getExtension(String filename) {
        return getExtension(filename, "");
    }

    public static String getExtension(String filename, String defExt) {
        if ((filename != null) && (filename.length() > 0)) {
            int i = filename.lastIndexOf('.');

            if ((i > -1) && (i < (filename.length() - 1))) {
                return filename.substring(i + 1);
            }
        }
        return defExt;
    }

    /**
     * 坚持SD卡是否可用
     * @return
     */
    public static boolean getSdcardAviable() {

        Boolean isSDPresent = android.os.Environment.getExternalStorageState()
                .equals(android.os.Environment.MEDIA_MOUNTED);

        return isSDPresent;
    }

    /**
     * 去掉文件的扩展名
     * @param filename
     * @return
     */
    public static String trimExtension(String filename) {
        if ((filename != null) && (filename.length() > 0)) {
            int i = filename.lastIndexOf('.');
            if ((i > -1) && (i < (filename.length()))) {
                return filename.substring(0, i);
            }
        }
        return filename;
    }



    private static boolean IsMediaFileMsg(Context mContext,Message msg) {
        if (msg.getType() == Message.MESSAGE_TYPE_FILE) {
            String filePath = ((FileMessage) msg).getFilePath();
            if (TextUtils.isEmpty(filePath)) {
                return false;
            }
            boolean isRevOk =!msg.isSender() && msg.getStatus() == Message.STATUS_OK;
            boolean isMediaFileRevOk =isRevOk;//&&(MediaFile.isImageFileType(filePath)||MediaFile.isVideoFileType(filePath));
            if (isMediaFileRevOk) {
                scanMediaFileToGallery(mContext, filePath);
            }
            return isMediaFileRevOk;
        } else {
            return false;
        }
    }


    /**
     * 打开文件
     * @param mContext
     * @param runnable
     * @param msg
     * @return
     */
    public static boolean openFileMsg(final BaseActivity mContext, Runnable runnable, final Message msg) {
        int msgType = msg.getType();
        if (msg.getType() == Message.MESSAGE_TYPE_IMAGE || msg.getType() == Message.MESSAGE_TYPE_VIDEO) {

            boolean RevOk = !msg.isSender() && msg.getStatus() == Message.STATUS_OK;
            if (RevOk) {
                if (msgType == Message.MESSAGE_TYPE_IMAGE) {
                    mContext.runOnUiThread(runnable);
                }
                scanMediaFileToGallery(mContext, ((FileMessage) msg).getFilePath());
            }
            return RevOk;
        } else {
            IsMediaFileMsg(mContext, msg);
            return false;
        }
    }

    /**
     * 打开文件
     * @param context
     * @param path
     */
    public static void scanMediaFileToGallery(Context context, String path) {
        File file = new File(path);
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri);
        context.sendBroadcast(intent);
    }

    public static boolean checkSendfileSizeIsOk(File sendingFile) {
        final long maxImageSize = getMaxFileSendLimitedSize(App.getInstance());
        long fileSize = sendingFile.length();
        Log.i(TAG, "file size====" + (fileSize / (double) (1024 * 1024))
                + ("maxfile===" + (maxImageSize / (double) (1024 * 1024))));
        return !(maxImageSize <= fileSize || fileSize == 0);
    }

    public interface DownloadFileEndListener {
        void DownloadedFile(File file);
    }

    public static void saveNetworkFile(final BaseActivity activity,
                                       final Uri uri, final DownloadFileEndListener downloadFileEndListener) {
        Log.i("saveNetworkFile", "uriName  =" + uri);

        String type = activity.getContentResolver().getType(uri);
        Log.i(TAG, "saveNetworkFile mime type==" + type);
        // java.net.URLConnection.guessContentTypeFromStream(is)
        final String extension = MimeTypeMap.getSingleton()
                .getExtensionFromMimeType(type);
        Log.i(TAG, "saveNetworkFile  extension==" + extension);

        new Thread(new Runnable() {
            @Override
            public void run() {

                Cursor returnCursor = activity.getContentResolver().query(uri,
                        null, null, null, null);

                String extensionString = "";
                if (extension != null) {
                    extensionString = "." + extension;
                }

                String filePathString = ChatModule.sendingFileDir
                        + extension.toUpperCase() + "_" + getFileNameByDate()
                        + "" + extensionString;

                if (returnCursor != null && returnCursor.moveToFirst()) {
                    int nameIndex = returnCursor
                            .getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int sizeIndex = returnCursor
                            .getColumnIndex(OpenableColumns.SIZE);

                    Log.i("saveNetworkFile", "  nameIndex="
                            + nameIndex+";sizeIndex="+sizeIndex);

                    if (nameIndex > -1) {

                        String fileName = returnCursor.getString(nameIndex);
                        Log.i("saveNetworkFile", "uriName  name="
                                + fileName);
                        filePathString = ChatModule.sendingFileDir + fileName;
                    }

                    if (sizeIndex > -1) {
                        long fileSize = returnCursor.getLong(sizeIndex);
                        Log.i("saveNetworkFile", "uriName  size="
                                + fileSize);
                        if (!checkSendFileSizeIsOk(activity, fileSize,true)) {
                            returnCursor.close();
                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    activity.closeDialog();
                                }
                            });
                            return;
                        }
                    }
                    returnCursor.close();
                }
                Log.i("saveNetworkFile", "  filePathString="
                        + filePathString);

                InputStream is = null;
                try {
                    activity.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            activity.showDialog(activity.getString(R.string.downloading),true);
                        }
                    });

                    is = activity.getContentResolver().openInputStream(uri);

                    BufferedInputStream bufferedInputStream = new BufferedInputStream(
                            is);
                    final  File fileFromNet = new File(filePathString);
                    FileOutputStream fout = new FileOutputStream(fileFromNet);
                    int read = 0;
                    byte[] bytes = new byte[1024];
                    while ((read = bufferedInputStream.read(bytes)) != -1) {
                        fout.write(bytes, 0, read);
                    }
                    fout.flush();
                    fout.close();
                    bufferedInputStream.close();
                    Log.i("saveNetworkFile", "  bufferedInputStream close");
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            activity.closeDialog();
                            downloadFileEndListener.DownloadedFile(fileFromNet);
                        }
                    });

                } catch (FileNotFoundException e) {
                    Log.i("saveNetworkFile", "  \n1 java.io.FileNotFoundException: Connect to /59.24.3.173:443 timed out or " +
                            "\n 2 https://docs.google.com refused"+"\n 3 java.io.FileNotFoundException: No peer certificate");
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            activity.closeDialog();
                        }
                    });
                    e.printStackTrace();
                }catch (IOException e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }

            }
        }).start();
    }

    /**
     * 下载网路图片
     * @param activity
     * @param url
     * @param file
     * @param endRunnable
     */
    public static void saveNetworkPicture(final BaseActivity activity,
                                          final String url, final File file, final Runnable endRunnable) {
        activity.showDialog(activity.getString(R.string.downloading),true);
        Log.i("saveNetworkPicture", "uriName=" + url);
        new Thread(new Runnable() {
            @Override
            public void run() {
                InputStream is = null;
                try {

                    is = activity.getContentResolver().openInputStream(
                            Uri.parse(url));

                    BufferedInputStream bufferedInputStream = new BufferedInputStream(
                            is);
                    Bitmap bitmap = BitmapFactory
                            .decodeStream(bufferedInputStream);
                    if(bitmap!=null){
                        saveBitmap2TempFile(file, bitmap);
                    }else{
                        Log.i(TAG, "BitmapFactory.decodeStream(is) return null. rul:"+url);
                    }
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            activity.closeDialog();
                            endRunnable.run();
                        }
                    });

                } catch (FileNotFoundException e) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            activity.closeDialog();
                        }
                    });
                    e.printStackTrace();
                }

            }
        }).start();
    }

    /**
     * 保持Bitmap到文件
     * @param file
     * @param bitmap
     */
    private static void saveBitmap2TempFile(File file, Bitmap bitmap) {
        if(bitmap==null){
            return;
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70 /* ignored for PNG */, bos);
        byte[] bitmapdata = bos.toByteArray();

        // write the bytes in file
        FileOutputStream fos = null;
        try {

            fos = new FileOutputStream(file);

            fos.write(bitmapdata);
            fos.flush();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            try {
                fos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

    /**
     * 检查文件是否存在
     * @param fileName
     * @return
     */
    public static boolean isFileExist(String fileName) {
        if (TextUtils.isEmpty(fileName)) {
            return false;
        }
        File file = new File(fileName);
        return file.exists();

    }

    /**
     * 创建文件目录
     * @param dir
     */
    public static void createFileDir(String dir) {
        File file = new File(dir);
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    /**
     * 创建.nomedia
     * @param dir
     */
    public static void createFileDirNoMedia(String dir) {
        File file = new File(dir);
        if (!file.exists()) {
            file.mkdirs();
        }
        File targetFile=new File(dir+".nomedia");

        if(!targetFile.exists()){
            try {
                File parent=targetFile.getParentFile();
                if (parent!=null&&!parent.exists()) {
                    parent.mkdirs();
                }
                targetFile.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

    /**
     * 获取SD的根目录
     * @return
     */
    public static String getSDCardRoot()
    {
        String SDCardRoot = null;
        SDCardRoot = (new StringBuilder()).append(Environment.getExternalStorageDirectory().getAbsolutePath()).append(File.separator).toString();
        return SDCardRoot;
    }





    public final static String FILE_EXTENSION_SEPARATOR = ".";
    public static final double KB = 1024.0;
    public static final double MB = KB * KB;
    public static final double GB = KB * KB * KB;

    private FileUtils() {
        throw new AssertionError();
    }

    /**
     * read file
     *
     * @param filePath
     * @param charsetName The name of a supported {@link java.nio.charset.Charset </code>charset<code>}
     * @return if file not exist, return null, else return content of file
     * @throws RuntimeException if an error occurs while operator BufferedReader
     */
    public static StringBuilder readFile(String filePath, String charsetName) {
        File file = new File(filePath);
        StringBuilder fileContent = new StringBuilder("");
        if (file == null || !file.isFile()) {
            return null;
        }

        BufferedReader reader = null;
        try {
            InputStreamReader is = new InputStreamReader(new FileInputStream(file), charsetName);
            reader = new BufferedReader(is);
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (!fileContent.toString().equals("")) {
                    fileContent.append("\r\n");
                }
                fileContent.append(line);
            }
            reader.close();
            return fileContent;
        } catch (IOException e) {
            throw new RuntimeException("IOException occurred. ", e);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new RuntimeException("IOException occurred. ", e);
                }
            }
        }
    }

    /**
     * write file
     *
     * @param filePath
     * @param content
     * @param append is append, if true, write to the end of file, else clear content of file and write into it
     * @return return false if content is empty, true otherwise
     * @throws RuntimeException if an error occurs while operator FileWriter
     */
    public static boolean writeFile(String filePath, String content, boolean append) {
        if (TextUtils.isEmpty(content)) {
            return false;
        }

        FileWriter fileWriter = null;
        try {
            makeDirs(filePath);
            fileWriter = new FileWriter(filePath, append);
            fileWriter.write(content);
            fileWriter.close();
            return true;
        } catch (IOException e) {
            throw new RuntimeException("IOException occurred. ", e);
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (IOException e) {
                    throw new RuntimeException("IOException occurred. ", e);
                }
            }
        }
    }

    /**
     * write file
     *
     * @param filePath
     * @param contentList
     * @param append is append, if true, write to the end of file, else clear content of file and write into it
     * @return return false if contentList is empty, true otherwise
     * @throws RuntimeException if an error occurs while operator FileWriter
     */
    public static boolean writeFile(String filePath, List<String> contentList, boolean append) {
        if (contentList == null || contentList.size() == 0) {
            return false;
        }

        FileWriter fileWriter = null;
        try {
            makeDirs(filePath);
            fileWriter = new FileWriter(filePath, append);
            int i = 0;
            for (String line : contentList) {
                if (i++ > 0) {
                    fileWriter.write("\r\n");
                }
                fileWriter.write(line);
            }
            fileWriter.close();
            return true;
        } catch (IOException e) {
            throw new RuntimeException("IOException occurred. ", e);
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (IOException e) {
                    throw new RuntimeException("IOException occurred. ", e);
                }
            }
        }
    }

    /**
     * write file, the string will be written to the begin of the file
     *
     * @param filePath
     * @param content
     * @return
     */
    public static boolean writeFile(String filePath, String content) {
        return writeFile(filePath, content, false);
    }

    /**
     * write file, the string list will be written to the begin of the file
     *
     * @param filePath
     * @param contentList
     * @return
     */
    public static boolean writeFile(String filePath, List<String> contentList) {
        return writeFile(filePath, contentList, false);
    }

    /**
     * write file, the bytes will be written to the begin of the file
     *
     * @param filePath
     * @param stream
     * @return
     * @see {@link #writeFile(String, InputStream, boolean)}
     */
    public static boolean writeFile(String filePath, InputStream stream) {
        return writeFile(filePath, stream, false);
    }

    /**
     * write file
     *
     * @param filePath the file to be opened for writing.
     * @param stream the input stream
     * @param append if <code>true</code>, then bytes will be written to the end of the file rather than the beginning
     * @return return true
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean writeFile(String filePath, InputStream stream, boolean append) {
        return writeFile(filePath != null ? new File(filePath) : null, stream, append);
    }

    /**
     * write file, the bytes will be written to the begin of the file
     *
     * @param file
     * @param stream
     * @return
     * @see {@link #writeFile(File, InputStream, boolean)}
     */
    public static boolean writeFile(File file, InputStream stream) {
        return writeFile(file, stream, false);
    }

    /**
     * write file
     *
     * @param file the file to be opened for writing.
     * @param stream the input stream
     * @param append if <code>true</code>, then bytes will be written to the end of the file rather than the beginning
     * @return return true
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean writeFile(File file, InputStream stream, boolean append) {
        OutputStream o = null;
        try {
            makeDirs(file.getAbsolutePath());
            o = new FileOutputStream(file, append);
            byte data[] = new byte[1024];
            int length = -1;
            while ((length = stream.read(data)) != -1) {
                o.write(data, 0, length);
            }
            o.flush();
            return true;
        } catch (FileNotFoundException e) {
            throw new RuntimeException("FileNotFoundException occurred. ", e);
        } catch (IOException e) {
            throw new RuntimeException("IOException occurred. ", e);
        } finally {
            if (o != null) {
                try {
                    o.close();
                    stream.close();
                } catch (IOException e) {
                    throw new RuntimeException("IOException occurred. ", e);
                }
            }
        }
    }

    /**
     * move file
     *
     * @param sourceFilePath
     * @param destFilePath
     */
    public static void moveFile(String sourceFilePath, String destFilePath) {
        if (TextUtils.isEmpty(sourceFilePath) || TextUtils.isEmpty(destFilePath)) {
            throw new RuntimeException("Both sourceFilePath and destFilePath cannot be null.");
        }
        moveFile(new File(sourceFilePath), new File(destFilePath));
    }

    /**
     * move file
     *
     * @param srcFile
     * @param destFile
     */
    public static void moveFile(File srcFile, File destFile) {
        boolean rename = srcFile.renameTo(destFile);
        if (!rename) {
            copyFile(srcFile.getAbsolutePath(), destFile.getAbsolutePath());
            deleteFile(srcFile.getAbsolutePath());
        }
    }

    /**
     * copy file
     *
     * @param sourceFilePath
     * @param destFilePath
     * @return
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean copyFile(String sourceFilePath, String destFilePath) {
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(sourceFilePath);
        } catch (FileNotFoundException e) {
            throw new RuntimeException("FileNotFoundException occurred. ", e);
        }
        return writeFile(destFilePath, inputStream);
    }

    /**
     * read file to string list, a element of list is a line
     *
     * @param filePath
     * @param charsetName The name of a supported {@link java.nio.charset.Charset </code>charset<code>}
     * @return if file not exist, return null, else return content of file
     * @throws RuntimeException if an error occurs while operator BufferedReader
     */
    public static List<String> readFileToList(String filePath, String charsetName) {
        File file = new File(filePath);
        List<String> fileContent = new ArrayList<String>();
        if (file == null || !file.isFile()) {
            return null;
        }

        BufferedReader reader = null;
        try {
            InputStreamReader is = new InputStreamReader(new FileInputStream(file), charsetName);
            reader = new BufferedReader(is);
            String line = null;
            while ((line = reader.readLine()) != null) {
                fileContent.add(line);
            }
            reader.close();
            return fileContent;
        } catch (IOException e) {
            throw new RuntimeException("IOException occurred. ", e);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new RuntimeException("IOException occurred. ", e);
                }
            }
        }
    }

    /**
     * get file name from path, not include suffix
     *
     * <pre>
     *      getFileNameWithoutExtension(null)               =   null
     *      getFileNameWithoutExtension("")                 =   ""
     *      getFileNameWithoutExtension("   ")              =   "   "
     *      getFileNameWithoutExtension("abc")              =   "abc"
     *      getFileNameWithoutExtension("a.mp3")            =   "a"
     *      getFileNameWithoutExtension("a.b.rmvb")         =   "a.b"
     *      getFileNameWithoutExtension("c:\\")              =   ""
     *      getFileNameWithoutExtension("c:\\a")             =   "a"
     *      getFileNameWithoutExtension("c:\\a.b")           =   "a"
     *      getFileNameWithoutExtension("c:a.txt\\a")        =   "a"
     *      getFileNameWithoutExtension("/home/admin")      =   "admin"
     *      getFileNameWithoutExtension("/home/admin/a.txt/b.mp3")  =   "b"
     * </pre>
     *
     * @param filePath
     * @return file name from path, not include suffix
     * @see
     */
    public static String getFileNameWithoutExtension(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (filePosi == -1) {
            return (extenPosi == -1 ? filePath : filePath.substring(0, extenPosi));
        }
        if (extenPosi == -1) {
            return filePath.substring(filePosi + 1);
        }
        return (filePosi < extenPosi ? filePath.substring(filePosi + 1, extenPosi) : filePath.substring(filePosi + 1));
    }

    /**
     * get file name from path, include suffix
     *
     * <pre>
     *      getFileName(null)               =   null
     *      getFileName("")                 =   ""
     *      getFileName("   ")              =   "   "
     *      getFileName("a.mp3")            =   "a.mp3"
     *      getFileName("a.b.rmvb")         =   "a.b.rmvb"
     *      getFileName("abc")              =   "abc"
     *      getFileName("c:\\")              =   ""
     *      getFileName("c:\\a")             =   "a"
     *      getFileName("c:\\a.b")           =   "a.b"
     *      getFileName("c:a.txt\\a")        =   "a"
     *      getFileName("/home/admin")      =   "admin"
     *      getFileName("/home/admin/a.txt/b.mp3")  =   "b.mp3"
     * </pre>
     *
     * @param filePath
     * @return file name from path, include suffix
     */
    public static String getFileName(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? filePath : filePath.substring(filePosi + 1);
    }

    /**
     * get folder name from path
     *
     * <pre>
     *      getFolderName(null)               =   null
     *      getFolderName("")                 =   ""
     *      getFolderName("   ")              =   ""
     *      getFolderName("a.mp3")            =   ""
     *      getFolderName("a.b.rmvb")         =   ""
     *      getFolderName("abc")              =   ""
     *      getFolderName("c:\\")              =   "c:"
     *      getFolderName("c:\\a")             =   "c:"
     *      getFolderName("c:\\a.b")           =   "c:"
     *      getFolderName("c:a.txt\\a")        =   "c:a.txt"
     *      getFolderName("c:a\\b\\c\\d.txt")    =   "c:a\\b\\c"
     *      getFolderName("/home/admin")      =   "/home"
     *      getFolderName("/home/admin/a.txt/b.mp3")  =   "/home/admin/a.txt"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFolderName(String filePath) {

        if (TextUtils.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? "" : filePath.substring(0, filePosi);
    }

    public static void playVideo(Context context, String filePath) {

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        MimeTypeMap myMime = MimeTypeMap.getSingleton();
        String extension = MimeTypeMap.getFileExtensionFromUrl(filePath);
        if (TextUtils.isEmpty(extension)) {
            extension = FileUtils
                    .getExtension(filePath);
        }
        String mimeType = myMime.getMimeTypeFromExtension(extension);
        if (mimeType == null) {
            mimeType = "video/*";
            Log.i(TAG, "unkonw mimetype");
        }
        intent.setDataAndType(Uri.fromFile(new File(filePath)), mimeType);
        context.startActivity(intent);
    }

    /**
     * get suffix of file from path
     *
     * <pre>
     *      getFileExtension(null)               =   ""
     *      getFileExtension("")                 =   ""
     *      getFileExtension("   ")              =   "   "
     *      getFileExtension("a.mp3")            =   "mp3"
     *      getFileExtension("a.b.rmvb")         =   "rmvb"
     *      getFileExtension("abc")              =   ""
     *      getFileExtension("c:\\")              =   ""
     *      getFileExtension("c:\\a")             =   ""
     *      getFileExtension("c:\\a.b")           =   "b"
     *      getFileExtension("c:a.txt\\a")        =   ""
     *      getFileExtension("/home/admin")      =   ""
     *      getFileExtension("/home/admin/a.txt/b")  =   ""
     *      getFileExtension("/home/admin/a.txt/b.mp3")  =   "mp3"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFileExtension(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (extenPosi == -1) {
            return "";
        }
        return (filePosi >= extenPosi) ? "" : filePath.substring(extenPosi + 1);
    }

    /**
     * Creates the directory named by the trailing filename of this file, including the complete directory path required
     * to create this directory. <br/>
     * <br/>
     * <ul>
     * <strong>Attentions:</strong>
     * <li>makeDirs("C:\\Users\\Trinea") can only create users folder</li>
     * <li>makeFolder("C:\\Users\\Trinea\\") can create Trinea folder</li>
     * </ul>
     *
     * @param filePath
     * @return true if the necessary directories have been created or the target directory already exists, false one of
     *         the directories can not be created.
     *         <ul>
     *         <li>if {@link FileUtils#getFolderName(String)} return null, return false</li>
     *         <li>if target directory already exists, return true</li>
     *         <li>return {@link File# makeFolder}</li>
     *         </ul>
     */
    public static boolean makeDirs(String filePath) {
        String folderName = getFolderName(filePath);
        if (TextUtils.isEmpty(folderName)) {
            return false;
        }

        File folder = new File(folderName);
        return (folder.exists() && folder.isDirectory()) || folder.mkdirs();
    }

    /**
     * @param filePath
     * @return
     * @see #makeDirs(String)
     */
    public static boolean makeFolders(String filePath) {
        return makeDirs(filePath);
    }

    public static boolean makeFolders(File filePath) {
        return makeDirs(filePath.getAbsolutePath());
    }



    /**
     * Indicates if this file represents a directory on the underlying file system.
     *
     * @param directoryPath
     * @return
     */
    public static boolean isFolderExist(String directoryPath) {
        if (TextUtils.isEmpty(directoryPath)) {
            return false;
        }

        File dire = new File(directoryPath);
        return (dire.exists() && dire.isDirectory());
    }

    /**
     * delete file or directory
     * <ul>
     * <li>if path is null or empty, return true</li>
     * <li>if path not exist, return true</li>
     * <li>if path exist, delete recursion. return true</li>
     * <ul>
     *
     * @param path
     * @return
     */
    public static boolean deleteFile(String path) {
        if (TextUtils.isEmpty(path)) {
            return true;
        }

        File file = new File(path);
        if (!file.exists()) {
            return true;
        }
        if (file.isFile()) {
            return file.delete();
        }
        if (!file.isDirectory()) {
            return false;
        }
        for (File f : file.listFiles()) {
            if (f.isFile()) {
                f.delete();
            } else if (f.isDirectory()) {
                deleteFile(f.getAbsolutePath());
            }
        }
        return file.delete();
    }

    public static boolean deleteFile(File path) {
        if ( path == null ) {
            return false;
        }
        return deleteFile(path.getAbsolutePath());
    }

    /**
     * get file size
     * <ul>
     * <li>if path is null or empty, return -1</li>
     * <li>if path exist and it is a file, return file size, else return -1</li>
     * <ul>
     *
     * @param path
     * @return returns the length of this file in bytes. returns -1 if the file does not exist.
     */
    public static long getFileSize(String path) {
        if (TextUtils.isEmpty(path)) {
            return -1;
        }

        File file = new File(path);
        return (file.exists() && file.isFile() ? file.length() : -1);
    }

    public static String getUrlFileName(String url) {
        if (!TextUtils.isEmpty(url)) {
            // 通过 ‘？’ 和 ‘/’ 判断文件名
            int index = url.lastIndexOf('?');
            String filename;
            if (index > 1) {
                filename = url.substring(url.lastIndexOf('/') + 1, index);
            } else {
                filename = url.substring(url.lastIndexOf('/') + 1);
            }
            return filename;
        }

        return "";
    }

    public static String getUrlFileBaseName(String url) {
        if (!TextUtils.isEmpty(url)) {
            String filename = getUrlFileName(url);
            int dotIndex = filename.lastIndexOf('.');
            String filenameWithoutExtension;
            if (dotIndex == -1) {
                filenameWithoutExtension = filename.substring(0);
            } else {
                filenameWithoutExtension = filename.substring(0, dotIndex);
            }
            return filenameWithoutExtension;
        }

        return "";
    }

    public static String getUrlFileExtension(String url) {
        if (!TextUtils.isEmpty(url)) {
            String filename = getUrlFileName(url);
            int i = filename.lastIndexOf('.');
            if (i > 0 && i < filename.length() - 1) {
                return filename.substring(i + 1).toLowerCase();
            }
        }
        return "";
    }

    public static String getFileBaseName(String filename) {
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length()))) {
                return filename.substring(0, dot);
            }
        }
        return filename;
    }

    public static String showFileSize(long size) {
        String fileSize;
        if (size < KB) {
            fileSize = size + "B";
        } else if (size < MB) {
            fileSize = String.format("%.1f", size / KB) + "KB";
        } else if (size < GB) {
            fileSize = String.format("%.1f", size / MB) + "MB";
        } else {
            fileSize = String.format("%.1f", size / GB) + "GB";
        }

        return fileSize;
    }

    /**
     * 如果不存在就创建
     * @param path
     * @return
     */
    public static boolean createIfNoExists(String path) {
        File file = new File(path);
        boolean mk = false;
        if (!file.exists()) {
            mk = file.mkdirs();
        }
        return mk;
    }

    /**
     * 获取指定文件夹
     *
     * @throws Exception
     */
    public static long getFileSizes(File f) throws Exception {
        long size = 0;
        File flist[] = f.listFiles();
        for (int i = 0; i < flist.length; i++) {
            if (flist[i].isDirectory()) {
                size = size + getFileSizes(flist[i]);
            } else {
                size = size + getFileSize(flist[i]);
            }
        }
        return size;
    }

    /**
     * 获取指定文件大小
     *
     * @throws Exception
     */
    private static long getFileSize(File file) throws Exception {
        long size = 0;
        if (file.exists()) {
            FileInputStream fis = null;
            fis = new FileInputStream(file);
            size = fis.available();
        } else {
            file.createNewFile();
            Log.i(TAG,"文件不存在");
        }
        return size;
    }

    /**
     * 转换文件大小
     */
    public static String generateFileSize(long size) {
        String fileSize;
        if (size < KB) {
            fileSize = size + "B";
        } else if (size < MB) {
            fileSize = String.format("%.1f", size / KB) + "KB";
        } else if (size < GB) {
            fileSize = String.format("%.1f", size / MB) + "MB";
        } else {
            fileSize = String.format("%.1f", size / GB) + "GB";
        }

        return fileSize;
    }

    public static String generateNetworkSpeed(long size, long time) {
        String fileSize;
        if (size < KB) {
            fileSize = size + "B";
        } else if (size < MB) {
            fileSize = String.format("%.1f", size / KB) + "KB";
        } else if (size < GB) {
            fileSize = String.format("%.1f", size / MB) + "MB";
        } else {
            fileSize = String.format("%.1f", size / GB) + "GB";
        }

        return fileSize;
    }

}
