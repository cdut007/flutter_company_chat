package com.ultralinked.uluc.enterprise.call;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactLocalBook;

/**
 * Created by lly on 2016/9/23.
 */

public class LocalContactActivity extends BaseActivity implements FragmentAddContactLocalBook.OnContactsInteractionListener{
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_add_new_contact_acticity;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.container,new FragmentAddContactLocalBook());
        ft.commit();
    }

    @Override
    public void onContactSelected(String name, String phone) {
        Intent intent = getIntent();
        intent.putExtra("number",phone);
        setResult(RESULT_OK,intent);
        finish();
    }

    @Override
    public void onSelectionCleared() {

    }
}
