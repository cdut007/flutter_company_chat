package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.GroupChatImActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.more.SettingPersonalActivity;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.utils.FileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import cn.bingoogolapple.qrcode.zxing.QRCodeEncoder;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;

public class GroupQRCodeActivity extends BaseActivity implements View.OnClickListener{

    private ImageView leftBack,displayQRCode;
    private  String chatId;
    private  int chatType,chatFlag;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_group_chat_qrcode;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        chatId = getIntent().getStringExtra("conversation_id");
        super.onCreate(savedInstanceState);
        chatType = getIntent().getIntExtra("convType",-1);
        chatFlag = getIntent().getIntExtra("flag",-1);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack=bind(R.id.left_back);
        displayQRCode=bind(R.id.encode_qr_code);


        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.title_group_qr_code);
        initListener(this, leftBack, displayQRCode);
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSONObject object = new JSONObject();
                try {
                    object.put("group",chatId);
                    GroupConversation conversation = GroupConversation.getConversationByGroupId(chatId);
                    if (conversation!=null){
                        object.put("groupName",conversation.getGroupTopic());
                    }

                    Bitmap logo = BitmapFactory.decodeResource(getResources(),R.mipmap.logo);
                    final  Bitmap bitmap = QRCodeEncoder.syncEncodeQRCode(object.toString(), ScreenUtils.dp2px(GroupQRCodeActivity.this,256), Color.BLACK,logo);
                    if (bitmap == null){
                        Log.i(TAG,"the qr bitmap is null:"+displayQRCode.getWidth());
                        return;
                    }
                    if (getActivity() == null ||isFinishing()){
                        return;
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            displayQRCode.setImageBitmap(bitmap);
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }).start();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.encode_qr_code:

                break;


            default:
        }
    }




}
