package com.ultralinked.uluc.enterprise.baseui;


import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.jude.swipbackhelper.SwipeListener;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.widget.PromptView;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import java.lang.reflect.Field;

//import com.squareup.leakcanary.RefWatcher;

/**
 * Created by ultralinked on 2016/6/8 0008.
 * Android development framework
 */
public abstract class BaseActivity extends RxAppCompatActivity implements IDelegate {

    private PromptView mPrompt;
    private int mResId = 0;


    protected String TAG;

    private SparseArray<View> mViews = new SparseArray<>();
    private View rootView = null;

    protected boolean resumed;

    /**
     * @return root 设置root视图ID =xml layout id
     */
    public abstract int getRootLayoutId();

    /**
     * @param id
     * @param <T>
     * @return 通过id，获取到控件对象
     */
    public <T extends View> T bind(int id) {
        return (T) bindView(id);
    }

    /**
     * @param id
     * @param <T>
     * @return 绑定视图对象并返回
     */
    private <T extends View> T bindView(int id) {
        T view = (T) mViews.get(id);
        if (view == null) {
            view = (T) this.findViewById(id);
            if (view instanceof ImageView) {
                ImageUtils.buttonEffect((ImageView) view);
            }
            mViews.put(id, view);

        }
        return view;
    }


    @Override
    public void initListener(View.OnClickListener listener, int... ids) {
        if (ids == null) {
            return;
        }
        for (int id : ids) {
            bind(id).setOnClickListener(listener);
        }
    }

    @Override
    public void initListener(View.OnClickListener listener, View... views) {
        if (views == null) {
            return;
        }
        for (View view : views) {
            view.setOnClickListener(listener);
        }
    }

    @Override
    public void initOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener listener, CompoundButton... compoundButtons) {
        if (compoundButtons == null) {
            return;
        }
        for (CompoundButton btn : compoundButtons) {
            btn.setOnCheckedChangeListener(listener);
        }

    }

    public View getRootView() {
        return rootView;
    }


    /**
     * 返回当前的Activity
     *
     * @param <T>
     * @return
     */
    public <T extends Activity> T getActivity() {
        return (T) rootView.getContext();
    }

    @Override
    public void create(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(getRootLayoutId(), container, false);
            Log.i(TAG, " create rootView success");
        }
    }

    protected boolean swipeUI = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (swipeUI) {
            SwipeBackHelper.onCreate(this);
        }

//        SwipeBackHelper.getCurrentPage(this)//get current instance
//                .setSwipeBackEnable(true)//on-off
//                .setSwipeEdge(200)//set the touch area。200 mean only the left 200px of screen can touch to begin swipe.
//                .setSwipeEdgePercent(0.2f)//0.2 mean left 20% of screen can touch to begin swipe.
//                .setSwipeSensitivity(0.5f)//sensitiveness of the gesture。0:slow  1:sensitive
//                .setScrimColor(Color.BLUE)//color of Scrim below the activity
//                .setClosePercent(0.8f)//close activity when swipe over this
//                .setSwipeRelateEnable(false)//if should move together with the following Activity
//                .setSwipeRelateOffset(500)//the Offset of following Activity when setSwipeRelateEnable(true)
//                .setDisallowInterceptTouchEvent(true)//your view can hand the events first.default false;
//                .addListener(new SwipeListener() {
//
//                    @Override
//                    public void onScroll(float percent, int px) {
//                    }
//
//                    @Override
//                    public void onEdgeTouch() {
//                    }
//
//                    @Override
//                    public void onScrollToClose() {
//                    }
//                });

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setTheme(R.style.pageTheme);
        TAG = getLocalClassName();
        create(getLayoutInflater(), null, savedInstanceState);
        setContentView(rootView);

//
//        RefWatcher refWatcher = App.getInstance().getRefWatcher();
//        if(refWatcher!=null)
//            refWatcher.watch(this);


        setTopBar();
        initView(savedInstanceState);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if (swipeUI) {
            SwipeBackHelper.onPostCreate(this);
        }

    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        App.getInstance().checkIsNeedUnlock();

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG);

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        Log.i(TAG);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG);
    }


    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        Log.i(TAG);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (swipeUI) {
            SwipeBackHelper.onDestroy(this);
        }
        closeDialog();
    }

    /**
     * 显示一个提示信息
     *
     * @param msg
     */
    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示一个提示信息
     *
     * @param strId 显示信息在XML中ID
     */
    public void showToast(int strId) {
        Toast.makeText(this, strId, Toast.LENGTH_SHORT).show();
    }


    /**
     * 启动Activity 不带参数
     *
     * @param className
     */
    public void lunchActivity(Class<?> className) {
        Intent intent = new Intent(this, className);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.left_in, R.anim.left_out);
    }

    /**
     * 启动Activity 不带参数
     *
     * @param intent
     */
    public void lunchActivityWithIntent(Intent intent) {

        startActivity(intent);
        overridePendingTransition(R.anim.left_in, R.anim.left_out);
    }

    /**
     * 启动Activity 带参数
     *
     * @param className
     */
    public void lunchActivity(Class<?> className, Bundle bundle) {
        Intent intent = new Intent(this, className);
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
        overridePendingTransition(R.anim.left_in, R.anim.left_out);
        finish();
    }

    /**
     * 启动一个Activity 并等待返回
     *
     * @param className
     * @param requestCode
     * @param bundle
     */
    protected void lunchActivityForResult(Class<?> className, int requestCode, Bundle bundle) {
        Intent intent = new Intent(this, className);
        if (null != bundle) {
            intent.putExtras(bundle);
            overridePendingTransition(bundle.getInt("animIn", R.anim.left_in), bundle.getInt("animOut", R.anim.left_out));
        }
        startActivityForResult(intent, requestCode);
    }

    /**
     * 设置状态栏
     */
    protected void setTopBar() {
    }

    public void goneView(@Nullable View v) {
        v.setVisibility(View.GONE);
    }

    public void visibleView(@Nullable View v) {
        v.setVisibility(View.VISIBLE);
    }

    public void invisibleView(@Nullable View v) {
        v.setVisibility(View.INVISIBLE);
    }

    public static Fragment getFragmentByTag(BaseActivity activity, Bundle bundle, Class<?> className) {
        BaseFragment mFragment;
        FragmentManager fm = activity.getSupportFragmentManager();
        mFragment = (BaseFragment) fm.findFragmentByTag(className.getName());
        if (mFragment == null) {
            mFragment = (BaseFragment) Fragment.instantiate(activity, className.getName(), bundle);

        }
        return mFragment;
    }


    /**
     * 修复输入法引起的内存泄漏
     */
    public static void fixInputMethodManagerLeak(Context destContext) {
        if (destContext == null) {
            return;
        }

        InputMethodManager imm = (InputMethodManager) destContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) {
            return;
        }

        String[] arr = new String[]{"mCurRootView", "mServedView", "mNextServedView"};
        Field f = null;
        Object obj_get = null;
        for (int i = 0; i < arr.length; i++) {
            String param = arr[i];
            try {
                f = imm.getClass().getDeclaredField(param);
                if (f.isAccessible() == false) {
                    f.setAccessible(true);
                } // author: sodino mail:sodino@qq.com
                obj_get = f.get(imm);
                if (obj_get != null && obj_get instanceof View) {
                    View v_get = (View) obj_get;
                    if (v_get.getContext() == destContext) { // 被InputMethodManager持有引用的context是想要目标销毁的
                        f.set(imm, null); // 置空，破坏掉path to gc节点
                    } else {
                        // 不是想要目标销毁的，即为又进了另一层界面了，不要处理，避免影响原逻辑,也就不用继续for循环了
//                        if (QLog.isColorLevel()) {
//                            QLog.d(ReflecterHelper.class.getSimpleName(), QLog.CLR, "fixInputMethodManagerLeak break, context is not suitable, get_context=" + v_get.getContext()+" dest_context=" + destContext);
//                        }
                        break;
                    }
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    private ProgressDialog mProgressDialog;

    public void showDialog(String title, boolean isCancel) {
        closeDialog();
        mProgressDialog = new ProgressDialog(this);

        mProgressDialog.setCancelable(isCancel);
        mProgressDialog.setMessage(title);

        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

        mProgressDialog.show();

    }

    public void showDialog(String title) {
        showDialog(title, false);
    }

    public void closeDialog() {

        if (mProgressDialog != null && mProgressDialog.isShowing()) {

            mProgressDialog.dismiss();

            mProgressDialog = null;

        }
    }


    public boolean checkPermission(String permissionName, int requestCode) {
        PackageManager pm = getPackageManager();
        String packageName = getPackageName();

        int checkPm = PackageManager.PERMISSION_DENIED;
        switch (permissionName) {
            case "location":
                checkPm = pm.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, packageName);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    //申请  ACCESS_FINE_LOCATION 权限
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                            requestCode);
                }
                break;
            case "voice":
                checkPm = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE,},
                            requestCode);
                }
                break;
            case "video": {
                checkPm = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.CAMERA)) {

                        // Show an explanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.
                        showToast(R.string.permissions_video_record_denied_tips);
                        Log.i(TAG, "we should explain why we need this permission!");
                    } else {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                                requestCode);
                    }

                } else {
                    Log.i(TAG, "video has the PERMISSION_GRANTED" + checkPm);
                }


            }

            break;

            case "file":
                checkPm = pm.checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, packageName);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                            requestCode);
                }
                break;
            case "camera":
                checkPm = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);

                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                            requestCode);
                }
                break;
            case "contact":
                checkPm = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS},
                            requestCode);
                }
                break;
            case "write_contact":
                checkPm = pm.checkPermission(Manifest.permission.WRITE_CONTACTS, packageName);
                if (checkPm != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_CONTACTS},
                            requestCode);
                }
                break;
        }
        return PackageManager.PERMISSION_GRANTED == checkPm;
    }

    /*PromptView start*/
    private void initPromptView() {
        mPrompt = new PromptView(this);
        if (mResId == 0) {
            ViewGroup.LayoutParams lp = rootView.getLayoutParams();
            mPrompt = new PromptView(this);
            mPrompt.setContent(rootView);
            addContentView(mPrompt, lp);
        } else {
            View view = rootView.findViewById(mResId);
            mPrompt.setContent(view);
            ViewGroup.LayoutParams lp = view.getLayoutParams();
            ((ViewGroup) rootView).addView(mPrompt, lp);
        }
    }

    public void showLoading() {
        if (mPrompt == null) {
            initPromptView();
        }
        mPrompt.showLoading();
    }

    public void showEmpty() {
        if (mPrompt == null) {
            initPromptView();
        }
        mPrompt.showEmpty();
    }

    public void showError() {
        if (mPrompt == null) {
            initPromptView();
        }
        mPrompt.showError();
    }

    public void showContent() {
        if (mPrompt == null) {
            initPromptView();
        }
        mPrompt.showContent();
    }

    public void setReplaceId(int resId) {
        this.mResId = resId;
    }
    /*PromptView end*/

}
