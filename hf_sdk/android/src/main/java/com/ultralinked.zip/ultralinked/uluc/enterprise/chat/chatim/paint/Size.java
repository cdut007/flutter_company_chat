package com.ultralinked.uluc.enterprise.chat.chatim.paint;

/**
 * Size
 * AndroidDrawingView <com.vilyever.androiddrawingview>
 * Created by vilyever on 2015/9/21.
 * Feature:
 */
public class Size {
    public int width;
    public int height;

    /* #Constructors */
    public Size(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /* #Overrides */

    /* #Accessors */

    /* #Delegates */

    /* #Private Methods */

    /* #Public Methods */

    /* #Classes */

    /* #Interfaces */

    /* #Annotations @interface */

    /* #Enums */
}
