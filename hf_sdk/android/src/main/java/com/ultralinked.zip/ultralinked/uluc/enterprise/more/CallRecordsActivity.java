package com.ultralinked.uluc.enterprise.more;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.more.model.CallBillingModel;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.TimeUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2017/1/16.
 */
public class CallRecordsActivity extends BaseActivity implements View.OnClickListener {

    SparseArray<Map<String, Integer>> mapList;
    SparseArray<List<CallBillingModel>> dataList;
    List<String> times;

    RelativeLayout mRelativeClick;
    TextView mTextSelected;
    ImageView mImageUpDown;
    RecyclerView mRecyclerView;
    BillAdapter billAdapter;
    PopupWindow mPopWindow;
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_call_billings;
    }

    @Override
    protected void setTopBar() {
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.call_records);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        mRelativeClick = bind(R.id.relative_click);
        mTextSelected = bind(R.id.txt_selected_item);
        mImageUpDown = bind(R.id.img_up_down);
        mRecyclerView = bind(R.id.recycler_call_billing);

        mRelativeClick.setOnClickListener(this);
        mapList = new SparseArray<>(3);
        times = new ArrayList<>(3);
        Map<String, Integer> map;
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        for (int i = 0; i < 3; i++) {
            map = new HashMap<>(2);
            int tempMonth = month - i;
            if ((tempMonth) > 0) {
                map.put("month", tempMonth);
                map.put("year", year);
                times.add(year + " - " + tempMonth);
            } else {
                map.put("month", tempMonth + 12);
                map.put("year", year - 1);
                times.add((year - 1) + " - " + (tempMonth + 12));
            }
            mapList.put(i, map);
        }
        mTextSelected.setText(times.get(0));
        queryCallRecords(0);
    }

    private void queryCallRecords(final int position) {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().queryCallRecords(mapList.get(position))
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryCallRecords completed");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        closeDialog();
                        Log.e(TAG + "queryCallbilling onError: ", HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String response = "";
                        try {
                            response = responseBody.string();
                        } catch (IOException e) {
                            Log.e(TAG + "queryCallRecords: ", android.util.Log.getStackTraceString(e));
                        }
                        if (!TextUtils.isEmpty(response)) {
                            Log.i("queryCallingBilling: ",response);
                            JSONObject object = null;
                            try {
                                object = new JSONObject(response);
                            } catch (JSONException e) {
                                Log.e(TAG + "queryCallRecords: ", android.util.Log.getStackTraceString(e));
                            }
                            if (object != null) {
                                if (object.optInt("code") == 200) {
                                    try {
                                        List<CallBillingModel> list = new Gson().fromJson(object.optString("objects"), new TypeToken<List<CallBillingModel>>() {
                                        }.getType());
                                        if (dataList == null) {
                                            dataList = new SparseArray<>(3);
                                        }
                                        dataList.put(position, list);
                                        if (billAdapter == null) {
                                            mRecyclerView.setLayoutManager(new LinearLayoutManager(CallRecordsActivity.this));
                                            mRecyclerView.addItemDecoration(new DividerLinearDecoration(CallRecordsActivity.this, LinearLayoutManager.VERTICAL, R.dimen.px_5_0_dp));
                                            billAdapter = new BillAdapter(CallRecordsActivity.this, list);
                                            mRecyclerView.setAdapter(billAdapter);
                                        } else {
                                            billAdapter.updateData(list);
                                        }
                                    } catch (Exception ex) {
                                        Log.e(TAG + "queryCallRecords: ", android.util.Log.getStackTraceString(ex));
                                    }
                                }
                            }
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.relative_click:
                showMonthPop();
                break;
        }
    }

    void showMonthPop(){
        mImageUpDown.setImageResource(R.mipmap.up);
        if(mPopWindow == null){
            RecyclerView recyclerView = new RecyclerView(this);
            recyclerView.setBackground(getResources().getDrawable(R.drawable.shape_solic_1a8eaf_bottom_radius_6));
            recyclerView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.addItemDecoration(new DividerLinearDecoration(this,LinearLayoutManager.VERTICAL,R.drawable.divider_white_line,R.dimen.px_10_0_dp,R.dimen.px_10_0_dp));
            final MonthAdapter adapter = new MonthAdapter(this,times);
            adapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(View itemView, int position) {
                    mTextSelected.setText(times.get(position));
                    if (dataList != null) {
                        List<CallBillingModel> list = dataList.get(position);
                        if (list != null) {
                            billAdapter.updateData(list);
                        } else {
                            queryCallRecords(position);
                        }
                    }else {
                        queryCallRecords(position);
                    }
                    mPopWindow.dismiss();
                }
            });
            recyclerView.setAdapter(adapter);
            mPopWindow = new PopupWindow(recyclerView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,true);
            mPopWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mPopWindow.setAnimationStyle(R.style.PopupAnimationStyle);
            mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    mImageUpDown.setImageResource(R.mipmap.down);
                }
            });
        }
        mPopWindow.showAsDropDown(mRelativeClick);
    }

    class MonthAdapter extends BaseRecyclerAdapter<String,RecyclerViewHolder>{

        public MonthAdapter(Context ctx, List<String> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext,itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_text_view;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, String itemData) {
            holder.getTextView(R.id.txt_month).setText(itemData);
        }
    }

    class BillAdapter extends BaseRecyclerAdapter<CallBillingModel, RecyclerViewHolder> {

        public BillAdapter(Context ctx, List<CallBillingModel> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_call_billing;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, CallBillingModel itemData) {
            holder.getTextView(R.id.txt_transaction_time).setText(itemData.getSystem_startTime());
            holder.getTextView(R.id.txt_destination_number).setText(String.format(getString(R.string.call_number),PhoneNumberUtils.formatMobile(itemData.getDestination_number())));
            holder.getTextView(R.id.txt_call_time).setText(String.format(getString(R.string.call_duration), TimeUtil.formatSecondTime(itemData.getOrigin_duration())));
            holder.getTextView(R.id.txt_call_fee).setText(String.format(getString(R.string.call_consumption),itemData.getCharged_amount()));
            if (position == getData().size() - 1) {
                holder.getView(R.id.view_time_line).setVisibility(View.GONE);
            } else {
                holder.getView(R.id.view_time_line).setVisibility(View.VISIBLE);
            }
        }
    }
}
