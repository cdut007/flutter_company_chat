package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.ultralinked.uluc.enterprise.utils.SPUtil;

/**
 * Created by ultralinked on 16/7/20.
 */
public class CompanySelector {

    public static final String CHOOSED_COMPANY = "choosedCompany";
    public static final String CHOOSED_COMPANY_ID = "choosedCompany_id";
    private static CompanySelector companySelector;

    private final Context context;

    private final SharedPreferences pref;

    private CompanySelector(Context applicationContext) {
        context = applicationContext;
        pref = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static CompanySelector getInstance(Context context) {

        if (companySelector == null) {
            companySelector = new CompanySelector(context.getApplicationContext());
        }
        return companySelector;
    }

    public String getCompanyName() {

        String companyName = pref.getString(CHOOSED_COMPANY + SPUtil.getUserID(), "");
//        if ("Com3".equalsIgnoreCase(companyName)){
//            companyName = "SHP";// later will be removed.
//        }
        return companyName;
    }

    public String getCompanyID() {

        return pref.getString(CHOOSED_COMPANY_ID + SPUtil.getUserID(), "");
    }

    public boolean setChoosedCompany(String company, String companyId) {
        SharedPreferences.Editor edt = pref.edit();
        edt.putString(CHOOSED_COMPANY + SPUtil.getUserID(), company);
        edt.putString(CHOOSED_COMPANY_ID + SPUtil.getUserID(), companyId);
        return edt.commit();
    }

    public boolean clearCompanyData(){
        if(SPUtil.getUserID()==null){
            return false;
        }
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(CHOOSED_COMPANY + SPUtil.getUserID());
        editor.remove(CHOOSED_COMPANY_ID + SPUtil.getUserID());
        return editor.commit();
    }
}
