package com.ultralinked.uluc.enterprise.utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.MainThread;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.NotificationCompat;
import android.text.TextUtils;
import android.view.View;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.call.IncallActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.GroupChatImActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.service.PlayMusicService;
import com.ultralinked.voip.api.BitmapUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.SubscribeMessage;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by Administrator on 2016/8/19 0019.
 */
public class MsgNotificationUtils {


    private static final String TAG = "MsgNotificationUtils";
    public static void sendNotification(final Message msg) {

        try{


            Observable.create(new Observable.OnSubscribe<Conversation>() {


                @Override
                public void call(Subscriber<? super Conversation> subscriber  ) {
                    try {

                        int conversationId = msg.getConversationId();
                        Conversation conversation = null;
                        if (conversationId != -1){
                            conversation = MessagingApi.getConversationById(conversationId);
                        }else{
                            //invilad id
                            if (msg.getSender()!=null){
                                if (msg.getChatType() == Message.CHAT_TYPE_GROUP){
                                    GroupConversation groupConversation = GroupConversation.getConversationByGroupId(msg.getSender());
                                    if (groupConversation == null){
                                        subscriber.onNext(null);
                                        return;
                                    }
                                    conversation = groupConversation;
                                }else{
                                    conversation = MessagingApi.getConversation(msg.getSender());
                                }
                            }else{
                                Log.i(TAG,"not find the sender id , maybe incoming call");
                            }
                        }


                        if (conversation == null){
                            subscriber.onNext(null);
                            return;
                        }

                          if (conversation.isMute()){
                              Log.i(TAG,"conversation is mute ~~ id:"+conversation.getContactNumber());
                              conversation.setConversationId(-1);
                              subscriber.onNext(conversation);
                              return;
                          }


                        if (conversation.isGroup()){

                        }else{

                            PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(conversation.getContactNumber());
                            String name = null;
                            if (peopleEntity != null) {
                                name =PeopleEntityQuery.getDisplayName(peopleEntity);

                            }
                            if (TextUtils.isEmpty(name)) {
                                name = msg.getPeerInfo().nickName;
                            }

                            if(TextUtils.isEmpty(name)){
                                name = msg.getPeerInfo().userName;
                            }
                            Message.PeerInfo peerInfo = conversation.peerInfo;
                            if (peerInfo == null){
                                peerInfo = new Message.PeerInfo();
                            }
                            peerInfo.nickName = name;
                            peerInfo.icon_url = peopleEntity.icon_url;
                            conversation.peerInfo= peerInfo;
                        }

                        subscriber.onNext(conversation);
                    }catch (Exception e){
                        e.printStackTrace();
                        subscriber.onNext(null);
                    }



                }

            })
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<Conversation>() {
                        @Override
                        public void call(Conversation conversation) {

                            if (conversation == null) {
                                Log.i(TAG, "conversation is null,maybe from group push:");
                                Intent intent = new Intent(App.getInstance(), MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                PendingIntent pendingintent = PendingIntent.getActivity(App.getInstance(), 0,
                                        intent, PendingIntent.FLAG_CANCEL_CURRENT);
                                NotificationCompat.Builder builder = new NotificationCompat.Builder(App.getInstance());
                                builder.setContentTitle(App.getInstance().getString(R.string.app_name))
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                                        .setDefaults(NotificationCompat.DEFAULT_ALL)
                                        .setVibrate(new long[]{0, 100, 300})
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setAutoCancel(true)
                                        .setContentIntent(pendingintent)
                                        .setContentText(msg.getBody())
                                        .setSmallIcon(com.holdingfuture.flutterapp.hfsdk.R.mipmap.logo)
                                        .setTicker(App.getInstance().getString(R.string.incoming_new_message));

                                //发出状态栏通知
                                NotificationManager nm = (NotificationManager)App.getInstance().getSystemService(Context.NOTIFICATION_SERVICE);
                                nm.notify(0x11, builder.build());
                                return;
                            }


                            if (conversation.getConversationId() == -1){
                                //maybe open mute function.
                                 Log.i(TAG,"conversation is mute ~~");
                                return;
                            }


                            int unReadCount = conversation.getUnReadMsgCount();
                            String msgbody = MessageUtils.getMsgBody("",conversation);

                            String name=null;
                            String identify = null;
                            int iconResId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.logo;
                            int chatType = msg.getChatType();
                            if (chatType == Message.CHAT_TYPE_GROUP) {
                                name = ((GroupConversation) conversation).getGroupTopic();
                                identify = ((GroupConversation) conversation).getGroupID();

                            } else {
                                name = conversation.peerInfo.nickName;//reset the name.
                                identify = conversation.getContactNumber();
                            }


                            final String title = new StringBuffer(name).append("(").append(unReadCount).append(" ").append(App.getInstance().getString(R.string.new_message_count)).append(")").toString();
                            final String content = msgbody;
                            final String className = (msg.getChatType() == Message.CHAT_TYPE_GROUP) ? GroupChatImActivity.class.getName() : SingleChatImActivity.class.getName();
                            final Bundle data = new Bundle();
                            if (msg.getChatType() == Message.CHAT_TYPE_GROUP) {
                                data.putString(Constants.GROUPKD_KEY, identify);
                                data.putInt(Constants.CHAT_TYPE_KEY, Conversation.GROUP_CHAT);
                                data.putInt(Constants.CHAT_FLAG, conversation.conversationFlag);
                            } else {
                                data.putString(Constants.PHONE_NUMBER_KEY,identify);
                                data.putInt(Constants.CHAT_TYPE_KEY, Conversation.SINGLE_CHAT);
                                data.putInt(Constants.CHAT_FLAG,conversation.conversationFlag);
                            }
                            final String sticker = App.getInstance().getString(R.string.incoming_encrypty_new_message,name);
                            final int notifId = msg.getConversationId();
                            final int finalIconResId = iconResId;

                            if (msg.getChatType() == Message.CHAT_TYPE_GROUP) {
                                Log.i(TAG,"send group chat notification.");
                                Bitmap largeBitmap = BitmapFactory.decodeResource(App.getInstance().getResources(), com.holdingfuture.flutterapp.hfsdk.R.mipmap.avatar_group1);
                                NotificationUtil.notification(App.getInstance(), notifId, className, data, finalIconResId, largeBitmap, sticker, title, content);
                            } else {
                                Log.i(TAG,"send single chat notification.");
                                String url =conversation.peerInfo.icon_url;
                                if (!TextUtils.isEmpty(url)) {

                                    Glide.with(App.getInstance()).load(url).asBitmap().error(ImageUtils.getDefaultContactImageResource(identify)).transform(new GlideCircleTransform(App.getInstance())).into(new SimpleTarget<Bitmap>() {
                                        @Override
                                        public void onStart() {
                                            super.onStart();
                                        }

                                        @Override
                                        public void onLoadStarted(Drawable placeholder) {
                                            super.onLoadStarted(placeholder);
                                        }

                                        @Override
                                        public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                                            Log.i(TAG," onResourceReady~~");
                                            NotificationUtil.notification(App.getInstance(), notifId, className, data, finalIconResId, resource, sticker, title, content);
                                        }

                                        @Override
                                        public void onLoadFailed(Exception e, Drawable errorDrawable) {
                                            super.onLoadFailed(e, errorDrawable);
                                            if (e!=null){

                                                Log.i(TAG," onLoadFailed~~"+ android.util.Log.getStackTraceString(e));
                                            }else{
                                                Log.i(TAG," onLoadFailed~~");
                                            }
                                            NotificationUtil.notification(App.getInstance(), notifId, className, data, finalIconResId, BitmapUtils.drawableToBitmap(errorDrawable), sticker, title, content);
                                        }

                                        @Override
                                        public void onStop() {
                                            super.onStop();

                                        }
                                    });



                                } else {
                                    Log.i(TAG,"send notificication use default header.");
                                    Bitmap largeBitmap = BitmapFactory.decodeResource(App.getInstance().getResources(), ImageUtils.getDefaultContactImageResource(conversation.getContactNumber()));
                                    NotificationUtil.notification(App.getInstance(), notifId, className, data, finalIconResId, largeBitmap, sticker, title, content);
                                }
                            }

                        }

                    });

        }catch (Exception e){
            e.printStackTrace();
        }




    }


    public  static  void setNotificationCountOnXiaomi(Notification notification , int mCount){
        try {

            Field field = notification.getClass().getDeclaredField("extraNotification");

            Object extraNotification = field.get(notification);

            Method method = extraNotification.getClass().getDeclaredMethod("setMessageCount", int.class);

            method.invoke(extraNotification, mCount);

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public static void cancelNotificatonByConversaton(Conversation conversation) {
        if (conversation == null || conversation.getConversationId() == -1) {
            return;
        }

        NotificationUtil.cancelNotification(conversation.getConversationId());
    }
}
