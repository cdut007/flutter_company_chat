package com.ultralinked.uluc.enterprise.contacts;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Created by ultralinked.
 */
public class FriendAdapter extends MyBaseAdapter<PeopleEntity> implements SectionIndexer {

     protected String TAG = "FriendAdapter";

    private final Context mcontext;


    public FriendAdapter(Context context) {
        super(context, R.layout.item_contact,new ArrayList<PeopleEntity>());
        mcontext = context;
    }

    public FriendAdapter(Context context,int layoutId) {
        super(context, layoutId,new ArrayList<PeopleEntity>());
        mcontext = context;
    }

    public void setData(List<PeopleEntity> raw) {
         updateList(raw);
    }



    @Override
    public void setHolder(MyHolder holder, PeopleEntity peopleEntity) {


        ImageView ivAvatar =  holder.getView(R.id.contactitem_avatar_iv);
        TextView tvCatalog =  holder.getView(R.id.contactitem_catalog);
        TextView tvNick = holder.getView(R.id.contactitem_nick);



        char catalog = peopleEntity.getLetter();

        tvCatalog.setText(String.valueOf(catalog));

        if (holder.getPosition() == 0) {
            tvCatalog.setVisibility(View.VISIBLE);
        } else {
            int index = holder.getPosition() - 1;
            if (index <getList().size() && index >= 0){
                PeopleEntity NextUser = getList().get(index);
                char lastCatalog = NextUser.getLetter();

                if (catalog == lastCatalog) {
                    tvCatalog.setVisibility(View.GONE);
                } else {
                    tvCatalog.setVisibility(View.VISIBLE);
                }
            }else{
                tvCatalog.setVisibility(View.GONE);
            }

        }

        ImageUtils.loadCircleImage(mcontext,ivAvatar, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));


        tvNick.setText(PeopleEntityQuery.getDisplayName(peopleEntity));
    }

    @Override
    public Object[] getSections() {
        return null;
    }

    @Override
    public int getPositionForSection(int section) {
        for (int i = 0; i < getList().size(); i++) {
            PeopleEntity user = getList().get(i);
            Character letter = user.getLetter();

            char firstChar = letter;
            if (firstChar == section) {
                return i;
            }
        }
        return 0;
    }


    @Override
    public int getSectionForPosition(int position) {
        return 0;
    }
}
