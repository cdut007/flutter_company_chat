package com.ultralinked.uluc.enterprise.moments.bean;

import java.util.List;

/**
 * Created by ultralinked on 16/9/29.
 */

public class FeedUserLineItem extends User{


    public final static String TYPE_URL = "1";
    public final static String TYPE_IMG = "image";
    public final static String TYPE_VIDEO = "3";
    public final static String TYPE_GAME = "4";
    public final static String TYPE_TEXT= "text";


    public String type;
    public String location;

    public List<String> photos;

    public FeedUserLineItem(){
        super();
    }
    public FeedUserLineItem(String id, String name, String headUrl) {
        super(id, name, headUrl);
    }
}
