package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.trello.rxlifecycle.components.support.RxAppCompatActivity;
import com.ultralinked.contact.util.ToastUtil;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.call.IncallActivity;
import com.ultralinked.uluc.enterprise.call.VideoCallActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.TextMessage;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import tyrantgit.explosionfield.ExplosionField;

/**
 * Created by ultralinked on 2016/8/1 0001.
 */
public class BurningFragment extends DialogFragment implements View.OnClickListener {
    String TAG = "BurningFragment";
    public  View root;
    Dialog dialog;
    String content;
    private RxAppCompatActivity activity;

    private Message msg;


    public static BurningFragment getInstance(Message msg) {
        BurningFragment burningFragment = new BurningFragment();
        Bundle bundle = new Bundle();
        bundle.putString("content", ((TextMessage)msg).getText());
        bundle.putSerializable("message",msg);
        burningFragment.setArguments(bundle);
        return burningFragment;
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         content = getArguments().getString("content");
         msg = (Message) getArguments().getSerializable("msg");
        Log.i(TAG, TAG);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = (RxAppCompatActivity) activity;
        Log.i(TAG, TAG);
    }




    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try{
                    ExplosionField field = ExplosionField.attach2Window(activity);
                    field.explode(root);
                    dismiss();
                }catch (Exception e){

                }
            }
        },5000);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Log.i(TAG);
        this.dialog = new Dialog(getActivity(), R.style.CustomDatePickerDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        root = LayoutInflater.from(getActivity()).inflate(R.layout.chat_im_burning_detail, null);
        dialog.setContentView(root);
        dialog.setCanceledOnTouchOutside(true);
        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.CENTER;
        float scale = Float.valueOf(getActivity().getResources().getString(R.string.dialog_width_scale));
        int width = (int) (ScreenUtils.getScreenWidth(getActivity())* scale);
        int height = (int) (ScreenUtils.getScreenHeight(getActivity())* 0.6);
        wlp.width = width;
        wlp.height = height;
        window.setAttributes(wlp);


        return dialog;
    }


    @Override
    public void onClick(View v) {
        Log.i(TAG, "click ");
        switch (v.getId()) {
            case R.id.cancel_btn:
                dismiss();
                break;

        }
    }



    public void dismiss() {
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    public View getBurningViewByMsg(Message msg) {
        if (this.msg!=null && this.msg.equals(msg)){

            return root;
        }
        return null;
    }
}
