package com.ultralinked.uluc.enterprise.chat.chatim;

import android.os.Bundle;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.call.PercentFrameLayout;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.ConfigApi;

import java.io.File;
		import java.io.IOException;
		import java.util.ArrayList;
		import java.util.Collections;
		import java.util.Comparator;

		import android.app.Activity;
		import android.content.Context;
		import android.content.Intent;
		import android.content.pm.PackageManager;
		import android.graphics.Bitmap;
		import android.hardware.Camera;
		import android.hardware.Camera.Size;
		import android.media.CamcorderProfile;
		import android.media.MediaRecorder;
		import android.media.MediaRecorder.OnInfoListener;
		import android.media.ThumbnailUtils;
		import android.os.Bundle;
		import android.os.CountDownTimer;
		import android.provider.MediaStore.Images;
		import android.text.TextUtils;
		import android.view.SurfaceHolder;
		import android.view.SurfaceView;
		import android.view.View;
		import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
		import android.widget.TextView;

import org.webrtc.EglBase;
import org.webrtc.RendererCommon;

/*
 * http://demos-of-android-rui.googlecode.com/svn/branches/RuiDemos/src/com/google/rui/demos/camera/demos/CameraDemosActivity.java
 * https://github.com/commonsguy/cw-advandroid/blob/master/Camera/Preview/src/com/commonsware/android/camera/PreviewDemo.java
 */
/**
 * This class is defined as the video recording activity,it to setting  width and height of the video recording,
 * to choice of mobile phone camera and video recording quality.
 * After that a timer is defined  to describe the video size in this class.
 * @version 22 April 2015
 */

public class VideoRecoderActivity extends BaseActivity implements
		SurfaceHolder.Callback {
	private static final String TAG = "VideoRecoderActivity";
	public static final String VIDEO_FILE_KEY = "com.ultralinked.ui.VideoRecoder.FileKey";
	private int MaxDuration = 10 * 1000;
	private Intent resultIntent;
	private String recordFilePath;
	private boolean inRecording = false;
	private ImageView mBtnRecord;
	private View mBtnSend;
	private TextView mBtnBack;
	private View mBtnSwitchCamera;
	private boolean hasSecondCamra = false;
	private boolean mUseSecondCamra = false;
	private Size pic_size = null;

	private SurfaceView mSurfaceView;
	private View videoPrevView;
	private SurfaceHolder mSurfaceHolder;
	private Camera mCamera = null;
	private MediaRecorder mMediaRecorder = null;
	private PercentFrameLayout percentFrameLayout;

	private int prev_width = 240;
	private int prev_height = 320;

	private TextView timer;

	@Override
	public int getRootLayoutId() {
		return R.layout.video_recorder;
	}

	@Override
	public void initView(Bundle savedInstanceState) {

	}

	@Override
	public void onCreate(Bundle savedInstanceState) {


		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);

		init();

	}

	public static boolean checkCameraHardware(Context context) {
		// this device has a camera
// no camera on this device
		return context.getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_CAMERA);
	}

	private void showBeginStartRecordLayout() {
		// videoBar.setProgress(0);
		timer.setVisibility(View.GONE);
		mBtnSwitchCamera.setVisibility(hasSecondCamra ? View.VISIBLE
				: View.GONE);
		videoPrevView.setVisibility(View.GONE);
		mBtnRecord
				.setImageResource(R.drawable.video_record_btn_start_record_state);
		StartView.setVisibility(View.GONE);
		stopView.setVisibility(View.VISIBLE);
		mBtnBack.setVisibility(View.VISIBLE);

	}

	private void showStartRecordLayout() {
		timer.setVisibility(View.VISIBLE);
		videoPrevView.setVisibility(View.GONE);
		mBtnBack.setVisibility(View.GONE);
		mBtnSwitchCamera.setVisibility(View.GONE);
		mBtnRecord
				.setImageResource(R.drawable.video_record_btn_stop_record_state);
		StartView.setVisibility(View.GONE);
		stopView.setVisibility(View.VISIBLE);

	}

	private void showStopRecordLayout() {
		mBtnSwitchCamera.setVisibility(View.GONE);
		timer.setVisibility(View.VISIBLE);
		mBtnBack.setVisibility(View.VISIBLE);
		StartView.setVisibility(View.VISIBLE);
		stopView.setVisibility(View.GONE);
	}

	View StartView, stopView, retake;

	// ProgressBar videoBar;
	private void init() {
		resultIntent = getIntent();
		ButtonClickListenerImpl impl = new ButtonClickListenerImpl();
		videoPrevView = findViewById(R.id.video_prew_container);
		preView = (ImageView) videoPrevView.findViewById(R.id.video_prew_image);
		stopView = findViewById(R.id.message_videorecord_record_start_layout);
		StartView = findViewById(R.id.message_videorecord_record_stop_layout);
		// videoBar = (ProgressBar) findViewById(R.id.video_seekbar);

		mBtnRecord = (ImageView) initViewWithClickListener(this,
				R.id.message_videorecord_btn_record, impl);
		mBtnSend = initViewWithClickListener(this,
				R.id.message_videorecord_btn_send, impl);
		retake = initViewWithClickListener(this, R.id.retake_btn,
				impl);
		mBtnBack = (TextView)initViewWithClickListener(this,
				R.id.message_videorecord_btn_back, impl);
		mBtnSwitchCamera = initViewWithClickListener(this,
				R.id.message_videorecord_btn_switchcamera, impl);
		timer = (TextView) findViewById(R.id.timer);
		if (Camera.getNumberOfCameras() > 1)
			hasSecondCamra = true;
		if (!hasSecondCamra)
			mBtnSwitchCamera.setVisibility(View.GONE);

		mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView);
		percentFrameLayout = (PercentFrameLayout) findViewById(R.id.preview_container);

		mSurfaceHolder = mSurfaceView.getHolder();
		videoPrevView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				FileUtils.playVideo(VideoRecoderActivity.this, recordFilePath);
			}
		});

		mSurfaceHolder.addCallback(this);
		mSurfaceHolder.setKeepScreenOn(true);
		mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		// setTextStyle();

		showBeginStartRecordLayout();
	}

	View initViewWithClickListener(Activity actv, int resid,
								   OnClickListener listener) {
		View btn = actv.findViewById(resid);
		btn.setOnClickListener(listener);
		return btn;
	}

	private Camera.Size getBestPreviewSize(int width, int height,
										   Camera.Parameters parameters) {
		Camera.Size result = null;
		Log.d(TAG, "getSupportedPreviewSizes: start");
		for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
			Log.d(TAG, "getSupportedPreviewSizes: " + size.width + "x"
					+ size.height);
			if (result == null)
				result = size;
			if (size.width <= width && size.height <= height) {
				int resultArea = result.width * result.height;
				int newArea = size.width * size.height;
				if (newArea > resultArea) {
					result = size;
				}
			}
		}
		Log.d(TAG, "getSupportedPreviewSizes: end");
		return (result);
	}

	ArrayList<ScreenSize> screenList = new ArrayList<ScreenSize>();
	ScreenSize mScreenSize;

	class ScreenSize {
		public ScreenSize(int height, int width) {
			this.height = height;
			this.width = width;
		}

		int height;
		int width;
	}

	private Camera.Size getMinpreviewSize(Camera.Parameters parameters) {
		// 根据前后摄像头取，前摄像头取倒数第二，后摄像头取倒数第三
		screenList.clear();
		Camera.Size result = null;
		Log.d(TAG, "getSupportedPreviewSizes: start");

		for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
			Log.i(TAG, "getSupportedPreviewSizes: " + size.width + "x"
					+ size.height);
			if (result == null)
				result = size;
			screenList.add(new ScreenSize(size.height, size.width));
		}

		Collections.sort(screenList, new ComparatorHeight());
		mScreenSize = screenList.get(1);
		result.height = mScreenSize.height;
		if (result.height > 350) {
			mScreenSize = screenList.get(0);
			result.height = mScreenSize.height;
		}

		result.width = mScreenSize.width;
		return (result);
	}

	public static class ComparatorHeight implements Comparator<ScreenSize> {

		@Override
		public int compare(ScreenSize lhs, ScreenSize rhs) {
			// TODO Auto-generated method stub
			int height1 = lhs.height;
			int height2 = rhs.height;

			return height1 - height2;
		}

	}


	@Override
	protected void onDestroy() {
		super.onDestroy();



	}

	private void initPreview(boolean usefrontcamera, int width, int height) {
		if (!checkCameraHardware(this.getApplicationContext()))
			return;
		if ((width > 0) && (height > 0)) {
			prev_width = width;
			prev_height = height;
		}
		freePreview();
		if (hasSecondCamra && mUseSecondCamra) {
			// hard coded assuming 1 is the front facing camera
			try {
				mCamera = Camera.open(1);
			} catch (Exception e) {
				Log.d(TAG, "open camera1 error");
				e.printStackTrace();
				try {
					mCamera = Camera.open();
				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}
		} else {
			try {
				mCamera = Camera.open();
			} catch (Exception e) {
				Log.d(TAG, "open camera error");
				e.printStackTrace();
				return;
			}
		}
		if (mCamera == null) {
			// still no camera.
			finish();
			showToast(R.string.chat_camera_unavaliable);
			return;
		}

		try {

			// Camera setup is based on the API Camera Preview demo
			Camera.Parameters parameters = mCamera.getParameters();
			parameters.set("orientation", "portrait");
			parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
			// List<Size> pre_sizes = parameters.getSupportedPreviewSizes();
			// List<Size> pic_sizes = parameters.getSupportedPictureSizes();
			Size cameraSize = getMinpreviewSize(parameters);//
			// Size cameraSize = getBestPreviewSize(prev_width,
			// prev_height,parameters);
			// parameters.setPictureSize(pic_size.width, pic_size.height);
			prev_width = cameraSize.width;
			prev_height = cameraSize.height;
			Log.i(TAG, "w==" + prev_width + ";h=" + prev_height);
			if (prev_height == 0 || prev_width == 0) {
				prev_height = 320;
				prev_width = 240;
			}else{

			}

			if (width > 0) {
				//parameters.setPreviewSize(width, height); // use default.
				//mSurfaceHolder.setFixedSize(width, height);
				setSurfaceViewSize(width,height);
			} else {
				//parameters.setPreviewSize(prev_width, prev_height);
				//mSurfaceHolder.setFixedSize(prev_width, prev_height);
				setSurfaceViewSize(prev_width,prev_height);
			}

			try {
				int preWidth = parameters.getPreferredPreviewSizeForVideo().width;
				int preHeight = parameters.getPreferredPreviewSizeForVideo().height;
				Log.i(TAG,"witdhRatio preHeight="+preHeight+";preWidth="+preWidth);
				int witdhRatio = 100 ;//(int) (100 *(Math.min(preWidth,preHeight) * 1.0f/Math.max(preWidth,preHeight)*1.0f));
				int heightRatio = (int) (100 *(Math.max(preWidth,preHeight) * 1.0f/Math.min(preWidth,preHeight)*1.0f));
				percentFrameLayout.setPosition(0,0,witdhRatio,heightRatio);
			}catch (Exception e){
				e.printStackTrace();
				Log.i(TAG,"witdhRatio info error:"+ android.util.Log.getStackTraceString(e));
			}

			mCamera.setParameters(parameters);
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "setParameters error");
		}
		try {

			mCamera.setPreviewDisplay(mSurfaceHolder);
			mCamera.setDisplayOrientation(90);
			mCamera.startPreview();


		} catch (Exception e) {
			e.printStackTrace();
			finish();
			Log.d(TAG, "open camera error RuntimeException");
			showToast(R.string.chat_camera_unavaliable);
			return;
		}


	}

	private void setSurfaceViewSize(int width, int height) {

//		ViewGroup.LayoutParams layoutParams = (ViewGroup.LayoutParams) mSurfaceView.getLayoutParams();
//		float scale = width*1.0f/height*1.0f;
//		layoutParams.width = (int) (layoutParams.height * scale);
//
//		mSurfaceView.setLayoutParams(layoutParams);
	}

	private void freePreview() {
		if (mCamera != null) {
			// try {
			// mCamera.setPreviewDisplay(null);
			// } catch (IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}

	}

	private void initMediaRecorder() {
		// next codes is right for 2.3 and 4.0
		if (mCamera == null) {
//			Toast.makeText(this, getString(R.string.chat_camera_unavaliable),
//					Toast.LENGTH_LONG).show();
			showToast(R.string.chat_camera_unavaliable);
			return;
		}
		mMediaRecorder = new MediaRecorder();
		// camera.stopPreview();
		// ----Unlock the camera for the recorder to use. THis is required.

		// must set it.
		Camera.Parameters parameters = mCamera.getParameters();
		//parameters.setPreviewSize(prev_width, prev_height);
		//mSurfaceHolder.setFixedSize(prev_width, prev_height);
		setSurfaceViewSize(prev_width,prev_height);
		mCamera.setParameters(parameters);

		mCamera.unlock();
		mMediaRecorder.setCamera(mCamera);

		// Media recorder setup is based on Listing 9-6, Hashimi et all 2010
		// values based on best practices and good quality,
		// tested via upload to YouTube and played in QuickTime on Mac Snow
		// Leopard

		mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);

		mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

		// ������ƵԴ
		//mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);

		mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_480P));
//
//		// �����ļ������ʽ
//		mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
//
//		// ������Ƶ���뷽ʽ
//		mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
//
//		// ������Ƶ���뷽ʽ
//		mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);

		// ������Ƶ�ߺͿ�,ע���ĵ���˵��:

		// Must be called after setVideoSource().

		// Call this after setOutFormat() but before prepare().

		// ����¼�Ƶ���Ƶ֡��,ע���ĵ���˵��:

		// Must be called after setVideoSource().

		// Call this after setOutFormat() but before prepare().

		// ����Ԥ������
		// 在这里我提高了帧频率，然后就清晰了
		// 设置视频输出的格式和编码
//		CamcorderProfile mProfile =null;
//		try {
//			mProfile = CamcorderProfile
//					.get(CamcorderProfile.QUALITY_480P);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Log.i(TAG, "error record video =="+e.getLocalizedMessage());
//		}
//
//		if (mProfile!=null) {
//			if (mProfile.videoBitRate > 2 * 1024 * 1024)
//				mMediaRecorder.setVideoEncodingBitRate(2 * 1024 * 1024);
//			else {
//				mMediaRecorder.setVideoEncodingBitRate(mProfile.videoBitRate);
//			}
//			mMediaRecorder.setVideoFrameRate(mProfile.videoFrameRate);
//		}else {
//
//		}




		mMediaRecorder.setPreviewDisplay(mSurfaceHolder.getSurface());


		String appName = ConfigApi.appName;
		recordFilePath =  com.ultralinked.voip.api.utils.FileUtils.getSDPath() + File.separator + appName + File.separator ;
		recordFilePath += "Video_Capture"+File.separator ;
		if (!FileUtils.isFileExist(recordFilePath)) {
			com.ultralinked.voip.api.utils.FileUtils.createFileDir(recordFilePath);
		}
		recordFilePath += System.currentTimeMillis() + ".mp4";
		mMediaRecorder.setOutputFile(recordFilePath);

		// 设置录制的视频帧率。必须放在设置编码和格式的后面，否则报错
		//mMediaRecorder.setVideoSize(prev_width, prev_height);

		// mMediaRecorder.setVideoFrameRate(15);
		// ������Ƶ��������ʱ��
		mMediaRecorder.setMaxDuration(MaxDuration);// set max record during.
		if (mUseSecondCamra) {// front camera
			mMediaRecorder.setOrientationHint(270);
		} else {
			mMediaRecorder.setOrientationHint(90);
		}

		// ΪMediaRecorder���ü���
		mMediaRecorder.setOnInfoListener(new OnInfoListener() {

			public void onInfo(MediaRecorder mr, int what, int extra) {

				if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {

//					Toast.makeText(VideoRecoderActivity.this,
//							getString(R.string.timeout), Toast.LENGTH_SHORT)
//							.show();
					showToast(getString(R.string.timeout));
					mBtnRecord.performClick();
					// if (mMediaRecorder != null) {
					// mMediaRecorder.stop();
					//
					// mMediaRecorder.release();
					//
					// mMediaRecorder = null;
					//
					// freePreview();
					// //set data for return.
					// resultIntent.putExtra(VIDEO_FILE_KEY, recordFilePath);
					// VideoRecoderActivity.this.setResult(Activity.RESULT_OK,
					// resultIntent);
					// VideoRecoderActivity.this.finish();
					// }
				}
			}
		});

	}

	private void releaseMediaRecorder() {
	try{
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
        if (mCamera != null)
            mCamera.lock();
    }catch (Exception e){
        e.printStackTrace();
    }
	}

	private CountDownTimer countDownTimer;

	private class ButtonClickListenerImpl implements OnClickListener {

		public void onClick(View v) {

			switch (v.getId()) {
				case R.id.message_videorecord_btn_record: {
					if (inRecording) {
						boolean retake = false;
						try { // http://stackoverflow.com/questions/16221866/mediarecorder-failed-when-i-stop-the-recording
							// http://developer.android.com/reference/android/media/MediaRecorder.html#stop()
							mMediaRecorder.stop();
							// if save error, can not send video out
							mBtnSend.setVisibility(View.VISIBLE);
							setVideoPrew();
							videoPrevView.setVisibility(View.VISIBLE);
						} catch (Exception e) {
							e.printStackTrace();
							deleteTempFile();
							if (isLessThanOneSec(timer.getText())) {
								retake = true;
							}
							// mBtnSend.setVisibility(View.INVISIBLE);
							Log.d(TAG, "mMediaRecorder.stop too fast will err");
						}
						releaseMediaRecorder();
						inRecording = false;
						if (countDownTimer != null) {
							countDownTimer.cancel();
							countDownTimer = null;

						}
						if (retake || isLessThanOneSec(timer.getText())) {
							showBeginStartRecordLayout();
							showToast(getString(R.string.chat_recording_video_less_one_sec));
						} else {
							showStopRecordLayout();
						}
					} else {
						releaseMediaRecorder();
						initMediaRecorder();
						if (mMediaRecorder == null) {
							releaseMediaRecorder();
							inRecording = false;
							Log.i(TAG, "media Recorder is null");
							return;
						}
						try {
							mMediaRecorder.prepare();
						} catch (IllegalStateException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							Log.i(TAG, "media Recorder is IllegalStateException");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							Log.i(TAG, "media Recorder is IOException");
						}

						try {
							mMediaRecorder.start();
						} catch (Exception e) {
							e.printStackTrace();
							int index = 0;
							if (mScreenSize != null) {
								index = screenList.indexOf(mScreenSize);
							}

							Log.i(TAG, "next index====" + index + ";size="
									+ screenList.size() + ";height=" + prev_height);
							if (index > -1 && index < screenList.size() - 1) {
								mScreenSize = screenList.get(index + 1);
								prev_height = mScreenSize.height;
								prev_width = mScreenSize.width;
								mBtnRecord.performClick();
								return;
							}

							releaseMediaRecorder();
							inRecording = false;
//						Toast.makeText(VideoRecoderActivity.this,
//								getString(R.string.recording_error),
//								Toast.LENGTH_SHORT).show();
							Log.i(TAG, "recording_error  please check");
							return;
						}

						showStartRecordLayout();
						inRecording = true;
						countDownTimer = new CountDownTimer(MaxDuration, 500) {
							public void onTick(long millisUntilFinished) {
								int value = (int) ((MaxDuration - millisUntilFinished) / 1000);
								int progress = (int) ((float) value * 100 * 1000 / MaxDuration);
								Log.i(TAG, "current progress=" + progress);

								// videoBar.setProgress(progress);
								timer.setText(makeTimeString(value));
								// timer.setText("seconds remaining: " +
								// millisUntilFinished / 1000);
							}

							public void onFinish() {
								Log.i(TAG, "end count down timer~~~");
								timer.setText(makeTimeString(MaxDuration / 1000));
								// timer.setText("seconds remaining: 0");
							}

						}.start();

					}
					break;
				}
				case R.id.message_videorecord_btn_send: {
					if (isLessThanOneSec(timer.getText())) {
						showToast(getString(R.string.chat_recording_video_less_one_sec));
						return;
					}
					releaseMediaRecorder();
					freePreview();
					// set data for return.
					resultIntent.putExtra(VIDEO_FILE_KEY, recordFilePath);
					VideoRecoderActivity.this.setResult(Activity.RESULT_OK,
							resultIntent);
					VideoRecoderActivity.this.finish();
					break;
				}

				case R.id.retake_btn: {
					showBeginStartRecordLayout();
					break;
				}
				case R.id.message_videorecord_btn_back: {
					releaseMediaRecorder();
					freePreview();
					deleteTempFile();
					resultIntent.putExtra(VIDEO_FILE_KEY, recordFilePath);
					VideoRecoderActivity.this.setResult(Activity.RESULT_CANCELED,
							resultIntent);
					VideoRecoderActivity.this.finish();
					break;
				}
				case R.id.message_videorecord_btn_switchcamera: {
					v.setEnabled(false);
					if (!inRecording) {
						mUseSecondCamra = !mUseSecondCamra;
						initPreview(mUseSecondCamra, 0, 0);
					}
					v.setEnabled(true);
					break;

				}
			}
		}
	}

	private boolean isLessThanOneSec(CharSequence time) {
		// TODO Auto-generated method stub
		if (TextUtils.isEmpty(time)) {
			return false;
		}
		return time.toString().equals("00:00:00");
	}

	private String makeTimeString(long secs) {

		long minute = secs / 60;
		long sec = (secs) % 60;
		String secString = sec < 10 ? "0" + sec : sec + "";
		String minString = minute < 10 ? "0" + minute : minute + "";
		String hour = "00";
		return hour + ":" + minString + ":" + secString;

	}

	// SurfaceHolder.Callback�ӿ�
	@Override
	public void onBackPressed() {
		releaseMediaRecorder();
		freePreview();
		super.onBackPressed();

	}

	public void deleteTempFile() {
		// TODO Auto-generated method stub
		if (!TextUtils.isEmpty(recordFilePath)) {
			File videoFile = new File(recordFilePath);
			FileUtils.deleteFile(videoFile);
		}
	}

	ImageView preView;

	public void setVideoPrew() {
		Bitmap orignal = ThumbnailUtils.createVideoThumbnail(recordFilePath,
				Images.Thumbnails.MINI_KIND);
		Bitmap bm = null;
		if (mSurfaceView.getWidth() != 0) {
			bm = ThumbnailUtils.extractThumbnail(orignal,
					mSurfaceView.getWidth(), mSurfaceView.getHeight());
		} else {
			bm = orignal;
		}

		if (bm == null) {
			Log.i(TAG, "recordFilePath==" + recordFilePath);
		}

		preView.setImageBitmap(bm);
		videoPrevView.setVisibility(View.VISIBLE);

	}

	public void surfaceCreated(SurfaceHolder holder) {

		System.out.println("SurfaceView---->Created");
		try {
			if (mCamera == null) return;
			mCamera.setPreviewDisplay(holder);
			mCamera.startPreview();
		} catch (IOException e) {
			android.util.Log.d(TAG, "Error setting camera preview: " + e.getMessage());
		}
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		if (inRecording) {
			releaseMediaRecorder();
			inRecording = false;
			if (countDownTimer != null) {
				countDownTimer.cancel();
				countDownTimer = null;
			}
			showBeginStartRecordLayout();
		}
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
							   int height) {
		System.out.println(height + "SurfaceView---->Changed" + width);


		initPreview(mUseSecondCamra, 0, 0);
	}

	public void surfaceDestroyed(SurfaceHolder holder) {

		System.out.println("SurfaceView---->Destroyed");
		releaseMediaRecorder();
		try {
            if (mCamera != null) {
                mCamera.stopPreview();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

	public void setMaxDuration(int duration) {
		this.MaxDuration = duration;
	}
}
