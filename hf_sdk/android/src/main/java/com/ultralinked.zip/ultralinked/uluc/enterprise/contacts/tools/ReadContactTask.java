package com.ultralinked.uluc.enterprise.contacts.tools;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ultralinked on 16/7/15.
 */
public class ReadContactTask{

    private static final String EXIST_USER = "(a." + PersonnelContract.PersonnelColumn.DELETE_DATE + " is NULL OR  a."
            + PersonnelContract.PersonnelColumn.DELETE_DATE + " ='' OR  a."
            + PersonnelContract.PersonnelColumn.DELETE_DATE + " ='None' " +
            ") ";
    private static String mSelection;
    private final int ID;

    public ReadContactTask(final Activity context, int ID) {

        mContext = context;

        this.ID = ID;
        mLoader = new LoaderManager.LoaderCallbacks<Cursor>() {

            @Override
            public Loader<Cursor> onCreateLoader(int id, Bundle args) {
                Log.i(TAG, "onCreateLoader");
                //read the join talble of personnel and relation
                return new CursorLoader(context, PersonnelContract.CONTENT_URI.buildUpon().appendPath("company").build(), null,
                        mSelection /* selection */,
                        null /* selectionArgs */,
                        PersonnelContract.PersonnelColumn.PINYIN /* sortOrder */);
            }

            @Override
            public void onLoadFinished(Loader<Cursor> loader,final Cursor data) {

                Log.i(TAG, "onLoadFinished " + loader.getId());
                if (data == null){
                    Log.i(TAG, "onLoadFinished but cursor is null");
                }else{
                    Log.i(TAG, "onLoadFinished the cursor count is :"+data.getCount());
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            readContact(data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();


            }


            @Override
            public void onLoaderReset(Loader<Cursor> loader) {

                Log.i(TAG, "onLoaderReset" + loader.getId());
            }
        };
    }

    String companyId;

    public void restCompany(String companyId) {

        this.companyId = companyId;
        reset();
    }

    String searchWord;

    public void resetLoader(String searchWord) {

        this.searchWord = searchWord;
        reset();
    }

    private void reset() {
        //reset the sql ,do not remove.
        Log.i(TAG, "resetLoader " + searchWord+";companyId=="+companyId+";get the database name:"+ DbSQLHelper.DATABASE_NAME);

        if (!TextUtils.isEmpty(searchWord)){

            searchWord = searchWord.trim();
            searchWord = searchWord.replaceAll("\'", "");//fix bug
        }
        Log.i(TAG, "searchWord " + searchWord);
        if (TextUtils.isEmpty(searchWord)) {

            mSelection = EXIST_USER;

        } else {
            searchWord = " '%" + searchWord + "%'";
            mSelection = EXIST_USER + " AND (a." + PersonnelContract.PersonnelColumn.SUBUSER_ID + " LIKE " + searchWord
                    + " OR a." + PersonnelContract.PersonnelColumn.EMAIL + " LIKE " + searchWord
                    + " OR a." + PersonnelContract.PersonnelColumn.MOBILE + " LIKE " + searchWord
                    + " OR a." + PersonnelContract.PersonnelColumn.NICKNAME + " LIKE " + searchWord
                    + " OR a." + PersonnelContract.PersonnelColumn.REMARKNAME + " LIKE " + searchWord
                    + ")";
        }

        if (!TextUtils.isEmpty(companyId)) {
            mSelection = mSelection + " AND (b." + RelationContract.RelationColumn.COMPANY_ID + " = " + companyId + ") ";
        }


        if (mContext instanceof FragmentActivity) {
            Log.i(TAG, "resetLoader restartLoader");
            ((FragmentActivity) mContext).getSupportLoaderManager().restartLoader(ID, null, mLoader);
        }
    }

    public interface onContactReadFinishListener {
        void setAdapter(List<PeopleEntity> friend,char[]alphaLetters);
      //  void setAdapter(List<PeopleEntity> internal, List<PeopleEntity> external);

    }


    public static final String TAG = "ReadContactTask";

    LoaderManager.LoaderCallbacks<Cursor> mLoader;

    private HashMap<String, PeopleEntity> mMap_Internal = new HashMap<>();
    private HashMap<String, PeopleEntity> mMap_External = new HashMap<>();


    private List<PeopleEntity> mDatas_Internal = new ArrayList<>();
    private List<PeopleEntity> mDatas_External = new ArrayList<>();

    private Activity mContext;
    private onContactReadFinishListener mListener;

    public void registerListener(onContactReadFinishListener listener) {

        mListener = listener;
    }

    public void unregisterListener(Context context) {

        mContext = null;
        mListener = null;
    }

    public LoaderManager.LoaderCallbacks<Cursor> getLoader() {

        return mLoader;
    }

    /**
     * read personnel info into list of people entity
     *
     * @param cursor
     */
    private void readContact(Cursor cursor) {


        mMap_Internal.clear();
        mMap_External.clear();

        if (cursor == null || cursor.getCount() == 0) {
            Log.i(TAG, " readContact null ");

            mDatas_Internal = new ArrayList<>(mMap_Internal.values());
            mDatas_External = new ArrayList<>(mMap_External.values());

            if (mListener != null&&!mContext.isFinishing()) {
                mContext.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mListener!=null)
                        mListener.setAdapter(new ArrayList<PeopleEntity>(),new char[]{});
                    }
                });
            }

            return;
        }


        cursor.moveToFirst();

        do {


            PeopleEntity peopleEntity  = DbSQLHelper.readPeopleBaseColumns(cursor);

            peopleEntity.deparment_type = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_TYPE));
            peopleEntity.deparment_id = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPART_ID));

            peopleEntity.companyid = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.COMPANY_ID));
            peopleEntity.deparment_name = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_NAME));
            peopleEntity.companyName = cursor.getString(cursor.getColumnIndex(RelationContract.RelationColumn.COMPANY_NAME));


            if ("Internal".equalsIgnoreCase(peopleEntity.deparment_type)) {

                if (!mMap_Internal.containsKey(peopleEntity.subuser_id)) {

                    mMap_Internal.put(peopleEntity.subuser_id, peopleEntity);
                }

            } else {

                if (!mMap_External.containsKey(peopleEntity.subuser_id)) {

                    mMap_External.put(peopleEntity.subuser_id, peopleEntity);
                }
            }

        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

        mDatas_Internal = new ArrayList<>(mMap_Internal.values());
        mDatas_External = new ArrayList<>(mMap_External.values());
        sort(mDatas_Internal);
      //  sort(mDatas_External);

        final char[] alphaLetters = ReadFriendContactTask.getAlphaLetters(mDatas_Internal);
        if (mListener != null&&!mContext.isFinishing()) {
            mContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    List<PeopleEntity> peopleEntities = new ArrayList<PeopleEntity>(mDatas_Internal);
                    if (mListener!=null)
                    mListener.setAdapter(peopleEntities,alphaLetters);
                }
            });
        }
    }

    private void sort(List<PeopleEntity> data) {
        try{
            Collections.sort(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
