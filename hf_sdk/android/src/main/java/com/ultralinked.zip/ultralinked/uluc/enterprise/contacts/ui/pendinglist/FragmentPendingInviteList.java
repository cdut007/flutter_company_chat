package com.ultralinked.uluc.enterprise.contacts.ui.pendinglist;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.RawPerson;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.LocalBookAdapter;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


/**
 * Created by ultralinked on 16/7/19.
 */

public class FragmentPendingInviteList extends BaseFragment {

    // Identifier for the permission request
    private static final int READ_CONTACTS_PERMISSIONS_REQUEST = 0x121;
    private static final int LOADERID = 0x128;
    private static final String TAG = "FragmentPendingInvite";
    private ListView mListView;
    private PendingInviteAdapter mAdapter;
    private boolean mIsSearchResultView;
    private String mSearchTerm;
    private EditText mEditText;
    private OnContactsInteractionListener mOnContactSelectedListener;

    @Override
    public void initView(Bundle savedInstanceState) {

    }




    /**
     * This interface must be implemented by any activity that loads this fragment. When an
     * interaction occurs, such as touching an item from the ListView, these callbacks will
     * be invoked to communicate the event back to the activity.
     */
    public interface OnContactsInteractionListener {
        /**
         * Called when a contact is selected from the ListView.
         */
        void onContactSelected(PeopleEntity peopleEntity);

        /**
         * Called when the ListView selection is cleared like when
         * a contact search is taking place or is finishing.
         */
        void onSelectionCleared();

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            // Assign callback listener which the holding activity must implement. This is used
            // so that when a contact item is interacted with (selected by the user) the holding
            // activity will be notified and can take further action such as populating the contact
            // detail pane (if in multi-pane layout) or starting a new activity with the contact
            // details (single pane layout).
            mOnContactSelectedListener = (OnContactsInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnContactsInteractionListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pending_invite_list, container, false);

        initTitleBar(view);

        mListView = (ListView) view.findViewById(R.id.pendingInviteList);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                mOnContactSelectedListener.onContactSelected(mAdapter.getItem(position));
            }
        });

        mEditText = (EditText) view.findViewById(R.id.search_edittext);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                setSearchQuery(s.toString());
            }
        });

        mEditText.clearFocus();
        mListView.requestFocus();
        return view;
    }

    @Override
    public int getRootLayoutId() {
        return 0;
    }

    private void initTitleBar(View view) {

        ImageView left_back = (ImageView) view.findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });


        TextView titleCenter = (TextView) view.findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.organization_pending_invite));


        TextView titleRight = (TextView) view.findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }

   public static List<PeopleEntity> mInviteList = new ArrayList<>();
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        //getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        mAdapter = new PendingInviteAdapter(getContext(),R.layout.pending_list_item,mInviteList);
        mListView.setAdapter(mAdapter);
        getPendingList();

    }


    public   void getPendingList() {



        ApiManager.getInstance().getPendingList()
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"getPendingListComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "get pending invite  error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                List<PeopleEntity> pendingList = gson.fromJson(result, sToken);
                                if (pendingList!=null){
                                    mInviteList = pendingList;
                                    mAdapter.updateList(pendingList);
                                }


                            }


                        } catch (JsonSyntaxException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        }
                        catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }
                        catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "get pending invite userInfo:  " + rs);
                    }         //请求成功

                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    public void setSearchQuery(String query) {
        if (TextUtils.isEmpty(query)) {
            mIsSearchResultView = false;
        } else {
            mSearchTerm = query;
            mIsSearchResultView = true;
        }

    }

}
