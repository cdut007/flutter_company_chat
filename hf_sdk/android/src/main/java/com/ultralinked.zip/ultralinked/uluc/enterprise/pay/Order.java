package com.ultralinked.uluc.enterprise.pay;

//import javax.annotation.Generated;
import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Order implements Serializable{

	@SerializedName("order_id")
	@Expose
	private String order_id;
	@SerializedName("order_title")
	@Expose
	private String order_title;
	@SerializedName("order_body")
	@Expose
	private String order_body;
	@SerializedName("order_state")
	@Expose
	private String order_state;
	@SerializedName("order_amount")
	@Expose
	private String order_amount;
	@SerializedName("order_no")
	@Expose
	private String order_no;
	@SerializedName("order_content")
	@Expose
	private String order_content;
	@SerializedName("create_time")
	@Expose
	private String create_time;


}
