package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.Constants;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.MessagingApi;

import com.ultralinked.uluc.enterprise.baseui.widget.SwitchView;

/**
 * Created by Administrator on 2016/7/27 0027.
 */
public abstract class BaseChatDetailsFragment extends BaseFragment implements View.OnClickListener,CompoundButton.OnCheckedChangeListener {

    private static final int REQUEST_CHANGE_SKIN = 2;
    protected Conversation mConversation;
    protected TextView titleCenter;
    protected TextView titleRight;
    protected ImageView titleLeft;
    protected View stickOnTop;
    protected View muteNotifications;
    protected TextView clearChatHistory;
    protected BaseActivity activity;

    protected  View changeChatSkin;

    @Override
    public void initView(Bundle savedInstanceState) {
        titleLeft = bind(R.id.left_back);
        titleRight = bind(R.id.titleRight);
        titleCenter = bind(R.id.titleCenter);
        titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.chat_details);
        goneView(titleRight);

        stickOnTop = bind(R.id.stick_on_top);
        muteNotifications = bind(R.id.mute_notifications);
        clearChatHistory = bind(R.id.clear_chat_history);

        changeChatSkin = bind(R.id.change_chat_skin);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  super.onCreateView(inflater, container, savedInstanceState);
        initConversation(getArguments());
        if (mConversation == null) {
            Log.i(TAG, "conversation is null, conversationID:" + getArguments().getInt("conversation_id"));
            return view;
        }


        initSwitchStatus();

        return view;
    }

    protected  void initConversation(Bundle data){
        mConversation = MessagingApi.getConversationById(data.getInt("conversation_id"));
        if (mConversation == null) {
            mConversation = MessagingApi.getConversation(data.getString("user_id"));
            Log.i(TAG,"mConversation  is ~~~~~"+mConversation);
        }

    }


    @Override
    public void onResume() {
        super.onResume();


    }

    /**
     * 初始化开关状态
     */
    private void initSwitchStatus() {
        Log.i(TAG, " isTopUP:" + mConversation.isTopUp + "  isMute:" + mConversation.isMute());
        SwitchView stick = (SwitchView) stickOnTop;
        SwitchView mute = (SwitchView) muteNotifications;

        stick.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));
        mute.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));

//        stickOnTop.setChecked(mConversation.isTopUp);
//        muteNotifications.setChecked(mConversation.isMute());

        initListener(this, titleLeft, clearChatHistory,changeChatSkin);
//        initOnCheckedChangeListener(this);

        if (mConversation.isTopUp){
            stick.toggleSwitch(true);
        }else{
            stick.toggleSwitch(false);
        }


        if (mConversation.isMute()){
            mute.toggleSwitch(true);
        }else{
            mute.toggleSwitch(false);
        }

        //切换开关
        //开关切换事件
        mute.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                mConversation.setMute(true);
                Log.i(TAG, "set is mute on notifications:" );
                view.toggleSwitch(true);
            }

            @Override
            public void toggleToOff(SwitchView view) {
                mConversation.setMute(false);
                Log.i(TAG, "set is mute off notifications:");
                view.toggleSwitch(false);
            }
        });


        stick.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                mConversation.topUp(true);
                view.toggleSwitch(true);
                Log.i(TAG, "set is stick on notifications:");
            }

            @Override
            public void toggleToOff(SwitchView view) {
                mConversation.topUp(false);
                view.toggleSwitch(false);
                Log.i(TAG, "set is stick off notifications:");
            }
        });



    }

    @Override
    public void onAttach(Activity activity) {
        this.activity = (BaseActivity) activity;
        super.onAttach(activity);

    }

    protected void initData(Bundle data) {

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                activity.finish();
                break;
            case R.id.change_chat_skin:
                if (mConversation == null){
                    return;
                }
                Intent intent = new Intent(activity,ChangeChatSkinActivity.class);
                if (mConversation.isGroup()){
                    intent.putExtra("conversation_id",((GroupConversation)mConversation).getGroupID());

                }else{
                    intent.putExtra("conversation_id",mConversation.getContactNumber());
                }
                intent.putExtra("convType",mConversation.isGroup()?Conversation.GROUP_CHAT:Conversation.SINGLE_CHAT);
                intent.putExtra("flag",mConversation.conversationFlag);

               startActivityForResult(intent,REQUEST_CHANGE_SKIN);
                break;
            case R.id.clear_chat_history:
                if (mConversation == null){
                    return;
                }
                DialogManager.showOKCancelDialog(activity, "", mContext.getString(R.string.delete_all_message), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mConversation.deleteAllMessages();
                        Intent data = new Intent();
                        data.putExtra("clear_all_history", true);
                        activity.setResult(Activity.RESULT_OK, data);
                    }
                },null);
                break;
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK){
            if (requestCode == REQUEST_CHANGE_SKIN){
              getActivity().finish();
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.mute_notifications:
                mConversation.setMute(isChecked);
                Log.i(TAG, "set is mute notifications:" + isChecked);
                break;

            case R.id.stick_on_top:
                mConversation.topUp(isChecked);
                Log.i(TAG, "set is stick to top:" + isChecked);
                break;
        }
    }
}
