package com.ultralinked.uluc.enterprise.contacts.contract;

/**
 * Created by ultralinked on 16/7/11.
 */

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by ultralinked on 16/6/30.
 */
public interface PersonnelContract extends BaseContract {

    String TABLE_NAME = "personnel";

    String PATH_PERSONNEL = "personnel";

    Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_PERSONNEL).build();

    // DIR 代表 返回的Cursor中包含0或多条记录
    String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_PERSONNEL;

    //ITEM 代表 返回的Cursor中为特定ID的一条记录
    String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_PERSONNEL;

    interface PersonnelColumn extends BasePeopleColumns {
        // Column with the foreign key into the company table.
    }

}
