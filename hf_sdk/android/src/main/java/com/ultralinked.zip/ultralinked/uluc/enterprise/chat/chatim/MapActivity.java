package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.telephony.TelephonyManager;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.utils.Log;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public class MapActivity extends BaseFragmentActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (!App.getInstance().baiduSDkInited){
            App.getInstance().initBaiduSDK();
        }

        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
    }




    @Override
    public void initView(Bundle savedInstanceState) {

        Bundle bundle = getIntent().getExtras();

        if (App.checkPlayServices(this)) {
            Log.i(TAG, "support google services");

            if (App.getInstance().inChina()){
                Log.i(TAG, "in china , use baidu instead.");
                setFragment(BaiduMapPreviewFragment.class, bundle);
            }else{
                setFragment(MapPreviewFragment.class, bundle);
            }

        } else {

            Log.i(TAG, "not support google services , use baidu instead.");
            setFragment(BaiduMapPreviewFragment.class, bundle);
        }

    }



    public static void launchActivityForResult(BaseFragment fragment, Activity activity, int requestCode) {
        Intent i = new Intent(activity, MapActivity.class);
        fragment.startActivityForResult(i,requestCode);

    }
    public static void launchActivityForResult(Activity activity, int requestCode) {
        Intent i = new Intent(activity, MapActivity.class);
        activity.startActivityForResult(i,requestCode);

    }

    public static void launchActivityForResult(Activity activity, int requestCode, Location location) {
        Intent i = new Intent(activity, MapActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("location",location);
        i.putExtras(bundle);
        activity.startActivityForResult(i,requestCode);

    }

}
