package com.ultralinked.uluc.enterprise;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.widget.Toolbar;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonSyntaxException;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AcceptNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.bingoogolapple.qrcode.core.QRCodeView;
import cn.bingoogolapple.qrcode.zxing.ZXingView;
import okhttp3.ResponseBody;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by Administrator on 2016/5/31.
 */
public class QrScanActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks, QRCodeView.Delegate, View.OnClickListener {

    private static final int REQUEST_CODE_QRCODE_PERMISSIONS = 1;

    private static final String TAG = "QrScanActivity";
    public static final String QR_CONTENT = "qrcontent";
    public static final int REQUEST_CODE_QRCODE_LOGIN = 0x33;
    private QRCodeView mQRCodeView;

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {

    }





    @AfterPermissionGranted(REQUEST_CODE_QRCODE_PERMISSIONS)
    private void requestCodeQrcodePermissions() {
//        String[] perms = {Manifest.permission.CAMERA, Manifest.permission.FLASHLIGHT};
//        if (!EasyPermissions.hasPermissions(this, perms)) {
//            EasyPermissions.requestPermissions(this, "扫描二维码需要打开相机和散光灯的权限", REQUEST_CODE_QRCODE_PERMISSIONS, perms);
//        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }


    @Override
    public void onScanQRCodeSuccess(String result) {
        Log.i(TAG, "result:" + result);
       // Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
        vibrate();
        mQRCodeView.stopSpot();
       if (result!=null && result.startsWith(SPUtil.getQRCODE_url())){
           parseRequest(result);
       }else{
           //other type  detail later.
            if (result!=null && result.contains("http")){
                try{
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(result)));
                }catch (Exception e){
                    e.printStackTrace();
                }
            }else{
               showToast(result);
            }
//            Intent mintent = new Intent(this, QrScanResponseActivity.class);
//            mintent.putExtra(QR_CONTENT, result);
//            startActivityForResult(mintent, REQUEST_CODE_QRCODE_LOGIN);
        }

    }
//https://uc.ultralinked.com/qr/5808951f85d5db371b42d559
    private void parseRequest(String url) {

        ApiManager.getInstance().parseQrCodeUrl(url,new HashMap<String, String>())
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        android.util.Log.i(TAG,"parseVcardQRCodeUrlComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "parseVcardQRCodeUrl  error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                JSONObject result = object.optJSONObject("result");
                                String type = result.optString("type");

                                if ("vcard".equals(type)){
                                    PeopleEntity peopleEntity = GsonUtil.fromJson(result.optJSONObject("user_info").toString(), PeopleEntity.class);
                                    Intent intent = new Intent(QrScanActivity.this, AddNewFriendActicity.class);
                                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY,peopleEntity);
                                    startActivity(intent);
                                    finish();
                               }


                            }else{
                                showToast(object.optString("description"));
                            }


                        }
                        catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "parseVcardQRCodeUrl:  " + rs);
                    }         //请求成功

                });

    }

    @Override
    public void onScanQRCodeOpenCameraError() {
        Log.e(TAG, "打开相机出错");
        showToast(R.string.chat_camera_unavaliable);
        finish();
    }


    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(200);
    }



    @Override
    public int getRootLayoutId() {
        return R.layout.activity_qr_scan;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
        mQRCodeView = (ZXingView) findViewById(R.id.zxingview);
        mQRCodeView.setDelegate(this);
        TCAgent.onPageStart(getActivity(),"扫二维码");

    }

    @Override
    protected void onStart() {
        super.onStart();
        requestCodeQrcodePermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
       try {
           mQRCodeView.startCamera();
           mQRCodeView.startSpotAndShowRect();
       }catch (Exception e){
           e.printStackTrace();
           finish();
       }
    }

    @Override
    protected void onStop() {
        try {
            mQRCodeView.stopSpotAndHiddenRect();
            mQRCodeView.stopCamera();
        }catch (Exception e){
            e.printStackTrace();
        }

        super.onStop();
    }

    @Override
    protected void onDestroy() {
        try {
            mQRCodeView.onDestroy();
            mQRCodeView = null;
        }catch (Exception e){
            e.printStackTrace();
        }
        TCAgent.onPageEnd(getActivity(),"扫二维码");
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            setResult(RESULT_OK, data);
            Log.i(TAG, "data==" + data.getStringExtra("qr_rep_data"));
            finish();
        }
    }

    private ImageView leftBack;
    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack=bind(R.id.left_back);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.title_scan_barcode);
        initListener(this, leftBack);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;
        }
    }
}
