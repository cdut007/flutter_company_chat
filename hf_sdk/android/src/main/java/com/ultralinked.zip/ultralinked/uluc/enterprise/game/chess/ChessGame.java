/*
XQWLMIDlet.java - Source Code for XiangQi Wizard Light, Part III

XiangQi Wizard Light - a Chinese Chess Program for Java ME
Designed by Morning Yellow, Version: 1.42, Last Modified: May 2010
Copyright (C) 2004-2010 www.xqbase.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
package com.ultralinked.uluc.enterprise.game.chess;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.content.IntentCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.google.gson.JsonObject;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.game.util.Util;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONException;
import org.json.JSONObject;

import rx.Subscription;
import rx.functions.Action1;

public class ChessGame extends Activity {


    static final String[] SOUND_NAME = {"click", "illegal", "move", "move2",
            "capture", "capture2", "check", "check2", "win", "draw", "loss",};

    static final int RS_DATA_LEN = 512;
    private static final String USER_ID = "userId";
    private static final String ACCEPT_SIDE = "accepted_side";

    /**
     * 0: Status, 0 = Startup Form, 1 = Red To Move, 2 = Black To Move<br>
     * 16: Player, 0 = Red, 1 = Black (Flipped), 2 = Both<br>
     * 17: Handicap, 0 = None, 1 = 1 Knight, 2 = 2 Knights, 3 = 9 Pieces<br>
     * 18: Level, 0 = Beginner, 1 = Amateur, 2 = Expert<br>
     * 19: Sound Level, 0 = Mute, 5 = Max<br>
     * 20: Music Level, 0 = Mute, 5 = Max<br>
     * 256-511: Squares
     */
    byte[] rsData = new byte[RS_DATA_LEN];
    int moveMode, handicap, level, sound, music;

    private ChessView mChessView;

    private Subscription rxPlayDataSubscription;

    private String TAG = "ChessGame";

    private String gameUser;
    private PeopleEntity peopleEntity;

    private Conversation conversation;

    GameModel gameModel = new GameModel();

    private  boolean acceptSide;

    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gameUser = getIntent().getStringExtra(USER_ID);
        acceptSide = getIntent().getBooleanExtra(ACCEPT_SIDE,false);
        setContentView(R.layout.activity_chess_game);
         FrameLayout chessBorad= (FrameLayout) findViewById(R.id.chess_view);
        moveMode = ChessView.COMPUTER_BLACK;
        if (acceptSide){
            moveMode = ChessView.COMPUTER_RED;
        }
        mChessView = new ChessView(this,moveMode);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        chessBorad.addView(mChessView,layoutParams);

        peopleEntity = PeopleEntityQuery.getInstance().getByID(gameUser);
        if (peopleEntity == null){
            finish();
            return;
        }
        ImageView head = (ImageView) findViewById(R.id.user_head);
        ImageUtils.loadCircleImage(this, head, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));
        ImageView myHead = (ImageView) findViewById(R.id.my_head);
        UserInfo userInfo = SPUtil.getUserInfo();
        if (userInfo != null) {
            ImageUtils.loadCircleImage(this, myHead, userInfo.getIcon_url(), ImageUtils.getDefaultContactImageResource(SPUtil.getUserID()));

        } else {
            ImageUtils.loadCircleImage(this, myHead, ImageUtils.getDefaultContactImageResource(SPUtil.getUserID()));

        }

        Position.readBookData(this);
        startApp();

        mChessView.setMoveChessListener(new ChessView.MoveChessListener() {
            @Override
            public void chessMove(String fen , int moveTo) {

                if (conversation == null) {
                    conversation = MessagingApi.getConversation(gameUser);

                }
                JSONObject playData = new JSONObject();
                try {
                    playData.put("fen",fen);
                    playData.put("moveTo",moveTo);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                conversation.sendCustomBroadcast(GameModel.TYPE_CHESS,gameModel.play(playData));

            }
        });

        rxPlayDataSubscription = RxBus.getDefault().toObservable(GameModel.class)
                .subscribe(new Action1<GameModel>() {
                               @Override
                               public void call(GameModel gameModel) {

                                   if (gameUser != null && gameUser.equals(gameModel.getGameUser())) {
                                       //for update.
                                       JSONObject playData = gameModel.getPlayData();
                                       String fen = playData.optString("fen");
                                       int moveTo = playData.optInt("moveTo");
                                       Log.i(TAG, "update the gameModel~~~~"+fen+";moveTo="+moveTo);
                                       mChessView.makeResponseMove(fen,moveTo);

                                   }
                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG, "update the subscribe error:" + android.util.Log.getStackTraceString(throwable));
                            }
                        });

    }


    private boolean started = false;

    public void startApp() {
        if (started) {
            return;
        }
        started = true;
        for (int i = 0; i < RS_DATA_LEN; i++) {
            rsData[i] = 0;
        }
        rsData[19] = 3;
        rsData[20] = 2;


        handicap = Util.MIN_MAX(0, rsData[17], 3);
        level = Util.MIN_MAX(0, rsData[18], 2);
        sound = Util.MIN_MAX(0, rsData[19], 5);
        music = Util.MIN_MAX(0, rsData[20], 5);

        if (!SPUtil.isAssistant(gameUser)) {
            //moveMode = ChessView.RESP_HUMAN_SINGLE;
            if (acceptSide){
                rsData[0] = 2;
            }else{
                rsData[0] = 1;
            }
        }else{
            moveMode = Util.MIN_MAX(0, rsData[16], 2);
            mChessView.setComputer(true);
        }

        mChessView.load(rsData, handicap, moveMode, level);

    }

    @Override
    protected void onDestroy() {

        if (rxPlayDataSubscription != null && !rxPlayDataSubscription.isUnsubscribed()) {
            rxPlayDataSubscription.unsubscribe();
        }

        destroyApp(true);
        super.onDestroy();
        //game maybe cause not memory.
        if (isTaskRoot()){
            // go to main
            Intent mIntent = new Intent(this, MainActivity.class);
            mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(mIntent);
        }
    }

    public void destroyApp(boolean unc) {
        rsData[16] = (byte) moveMode;
        rsData[17] = (byte) handicap;
        rsData[18] = (byte) level;
        rsData[19] = (byte) sound;
        rsData[20] = (byte) music;

        started = false;
    }

    public static void lunch(String gameUser,boolean acceptSide) {
        Intent i = new Intent(App.getInstance(), ChessGame.class);
        i.putExtra(ChessGame.USER_ID, gameUser);
        i.putExtra(ChessGame.ACCEPT_SIDE,acceptSide);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        App.getInstance().startActivity(i);

    }
}
