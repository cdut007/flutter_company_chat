package com.ultralinked.uluc.enterprise.baseui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.ultralinked.uluc.enterprise.baseui.widget.PromptView;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.trello.rxlifecycle.components.support.RxFragment;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.voip.api.Conversation;

import rx.Subscription;
import rx.functions.Action1;

/**
 * Created by ultralinked on 2016/6/8 0008.
 */
public abstract class BaseFragment extends RxFragment implements IDelegate {



    public void onHidden(boolean isHidden){

    }


    protected boolean isActivityDestryed() {

        return  getActivity() == null || getActivity().isFinishing();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

    }

    private PromptView mPrompt;
    private int mResId = 0;
    private ViewGroup mParent;


    protected String TAG;
    protected SparseArray<View> mViews = new SparseArray<>();
    protected View rootView = null;
    protected Activity mContext;



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        Log.i("onCreate");
    }



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (rootView!=null){

            return rootView;
        }

        mParent = container;
        restoreStateFromArguments(savedInstanceState,true);
        create(inflater,container,savedInstanceState);
        TAG=this.getClass().getSimpleName();
        initView(savedInstanceState);
        Log.i("onCreateView");
        return rootView;
    }


    protected  void settingConfigHasChanged(){

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.i("onViewCreated");

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        // Save State Here
        saveStateToArguments(getArguments());


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = (Activity) context;
        Log.i("onAttach");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i("onPause");

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i("onResume");

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mContext = null;
        Log.i("onDestroy");

    }


    /**
     * 启动Activity 不带参数
     *
     * @param className
     */
    protected void lunchActivity(Class<?> className) {
        startActivity(new Intent(getActivity(), className));
    }

    /**
     * 启动Activity 带参数
     *
     * @param className
     */
    protected void lunchActivity(Class<?> className, Bundle bundle) {
        Intent intent = new Intent(getActivity(), className);
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    /**
     * 显示一个提示信息
     *
     * @param msg
     */
    protected void showToast(String msg) {
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示一个提示信息
     *
     * @param strId 显示信息在XML中ID
     */
    protected void showToast(int strId) {
        if(getActivity()!=null)
         Toast.makeText(getActivity(), strId, Toast.LENGTH_SHORT).show();
    }

    /**
     * @param id
     * @param <T>
     * @return 通过id，获取到控件对象
     */
    public <T extends View> T bind(int id) {
        return (T) bindView(id);
    }

    /**
     * @param id
     * @param <T>
     * @return 绑定视图对象并返回
     */
    private <T extends View> T bindView(int id) {
        T view = (T) mViews.get(id);
        if (view == null) {
            view = (T) getRootView().findViewById(id);
            if (view instanceof ImageView){
                ImageUtils.buttonEffect((ImageView) view);
            }
            mViews.put(id, view);
        }
        return view;
    }

    @Override
    public void create(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView=inflater.inflate(getRootLayoutId(), container, false);
            Log.i(TAG, " create fragment rootView success");
        }
    }

    @Override
    public void initListener(View.OnClickListener listener, int... ids) {
        if (ids == null) {
            return;
        }
        for (int id : ids) {
            bind(id).setOnClickListener(listener);
        }
    }
    @Override
    public void initListener(View.OnClickListener listener,View... views) {
        if (views == null) {
            return;
        }
        for (View view : views) {
            view.setOnClickListener(listener);
        }
    }
    @Override
    public void initOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener listener,CompoundButton... compoundButtons) {
        if (compoundButtons == null) {
            return;
        }
        for (CompoundButton btn : compoundButtons) {
            btn.setOnCheckedChangeListener(listener);
        }

    }


    /**
     * @return root 设置root视图ID =xml layout id
     */
    public abstract int getRootLayoutId();

    public void goneView(@Nullable View v) {
      v.setVisibility(View.GONE);
    }
    public void visibleView(@Nullable View v) {
        v.setVisibility(View.VISIBLE);
    }
    public void invisibleView(@Nullable View v) {
        v.setVisibility(View.INVISIBLE);
    }






    Bundle savedState;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Restore State Here
        if (!restoreStateFromArguments(savedInstanceState,false)) {
            // First Time, Initialize something here
            onFirstTimeLaunched();
        }
    }

    protected void onFirstTimeLaunched() {

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save State Here
        saveStateToArguments(outState);
    }


    ////////////////////
    // Don't Touch !!
    ////////////////////

    private void saveStateToArguments(Bundle outState) {
        if (outState == null){
            return;
        }

        if (getView() != null)
            savedState = saveState();
        if (savedState != null) {
            Log.i(TAG,"savedState.......");
            outState.putBundle("internalSavedViewState_fragment_"+getTag(), savedState);
        }
    }

    ////////////////////
    // Don't Touch !!
    ////////////////////

    private boolean restoreStateFromArguments(Bundle savedInstanceState,boolean checkRestore) {
        Bundle b = savedInstanceState;
        if (b == null){
            b = getArguments();
        }
        if (b == null){
            Log.i(TAG,"restore.....but arguments is null..");
            return false;
        }
        Log.i(TAG,"restore.......");

        savedState = b.getBundle("internalSavedViewState_fragment_"+getTag());
        if (savedState != null) {
            if (checkRestore){
                restoreState();
            }
            return true;
        }
        return false;
    }

    /////////////////////////////////
    // Restore Instance State Here
    /////////////////////////////////

    private void restoreState() {
        if (savedState != null) {
            // For Example
            //tv1.setText(savedState.getString(text));
            onRestoreState(savedState);
        }
    }

    protected void onRestoreState(Bundle savedInstanceState) {

    }

    //////////////////////////////
    // Save Instance State Here
    //////////////////////////////

    private Bundle saveState() {
        Bundle state = new Bundle();
        // For Example
        //state.putString(text, tv1.getText().toString());
        onSaveState(state);
        return state;
    }

    protected void onSaveState(Bundle outState) {

    }

    protected   View getRootView(){

        if (rootView == null){
            rootView = getView();
        }

        return rootView;
    }

    /*PromptView start*/
    private void initPromptView(){
        mPrompt = new PromptView(mContext);
        if(mResId==0) {
            ViewGroup.LayoutParams lp = getRootView().getLayoutParams();
            mPrompt = new PromptView(mContext);
            mPrompt.setContent(getRootView());
            mParent.addView(mPrompt,lp);
        }else{
            View view =bind(mResId);
            mPrompt.setContent(view);
            ViewGroup.LayoutParams lp = view.getLayoutParams();
            ((ViewGroup)getRootView()).addView(mPrompt,lp);
        }
    }

    public void showLoading() {
        if(mPrompt==null){
            initPromptView();
        }
        mPrompt.showLoading();
    }

    public void showEmpty() {
        if(mPrompt==null){
            initPromptView();
        }
        mPrompt.showEmpty();
    }

    public void showError() {
        if(mPrompt==null){
            initPromptView();
        }
        mPrompt.showError();
    }

    public void showContent() {
        if(mPrompt==null){
            initPromptView();
        }
        mPrompt.showContent();
    }

    public void setReplaceId(int resId){
        this.mResId = resId;
    }
    /*PromptView end*/

}
