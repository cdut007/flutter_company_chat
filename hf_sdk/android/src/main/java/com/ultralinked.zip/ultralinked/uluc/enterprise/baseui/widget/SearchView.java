package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.Log;

/**
 * Created by Administrator on 2016/8/19 0019.
 */
public class SearchView extends EditText {

    private float searchSize;
    private float textSize;
    private int textColor;
    private Drawable mDrawable;
    private Paint paint;

    public SearchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        InitResource(context, attrs);
        InitPaint();
        initListener();
    }

    private void initListener() {
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                requestFocusFromTouch();
                InputMethodManager imm = (InputMethodManager)getContext(). getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
                setCursorVisible(true);
                return false;
            }
        });


        setOnFinishComposingListener(new OnFinishComposingListener() {
            @Override
            public void finishComposing() {
                Log.i("searchEdit","finish input.....");
                if (TextUtils.isEmpty(getText())){
                    InputMethodManager imm = (InputMethodManager)getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    boolean isOpen=imm.isActive();//isOpen若返回true
                    if (!isOpen){
                        setCursorVisible(false);
                    }

                }
            }
        });




        setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus) {
// 此处为得到焦点时的处理内容
                } else {
// 此处为失去焦点时的处理内容
                    if (TextUtils.isEmpty(getText())){
                            setCursorVisible(false);
                    }
                }
            }
        });
    }



    private void InitResource(Context context, AttributeSet attrs) {
        TypedArray mTypedArray = context.obtainStyledAttributes(attrs, R.styleable.searchedit);
        float density = context.getResources().getDisplayMetrics().density;
        searchSize = mTypedArray.getDimension(R.styleable.searchedit_imagewidth, context.getResources().getDimensionPixelSize(R.dimen.px_14_0_dp));
        textColor = context.getResources().getColor(R.color.color_d4d4d7);//mTypedArray.getColor(R.styleable.searchedit_textColor, context.getResources().getColor(R.color.color_525a65));
        textSize = mTypedArray.getDimension(R.styleable.searchedit_textSize, context.getResources().getDimensionPixelSize(R.dimen.px_14_sp));
        mTypedArray.recycle();
    }

    private void InitPaint() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(textColor);
        paint.setTextSize(textSize);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        DrawSearchIcon(canvas);
    }

    private void DrawSearchIcon(Canvas canvas) {
        if (this.getText().toString().length() == 0) {
            float textWidth = paint.measureText(getResources().getString(R.string.search));
            float textHeight = getFontLeading(paint);

            float dx = (getWidth() - searchSize - textWidth - 8) / 2;
            float dy = (getHeight() - searchSize) / 2;

            canvas.save();
            canvas.translate(getScrollX() + dx, getScrollY() + dy);
            if (mDrawable != null) {
                mDrawable.draw(canvas);
            }
            canvas.drawText(getResources().getString(R.string.search), getScrollX() + searchSize + 8, getScrollY() + (getHeight() - (getHeight() - textHeight) / 2) - paint.getFontMetrics().bottom - dy, paint);
            canvas.restore();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mDrawable == null) {
            try {
                mDrawable = getContext().getResources().getDrawable(R.mipmap.search_icon);
                mDrawable.setBounds(0, 0, (int) searchSize, (int) searchSize);
            } catch (Exception e) {

            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (mDrawable != null) {
            mDrawable.setCallback(null);
            mDrawable = null;
        }
        super.onDetachedFromWindow();
    }

    public float getFontLeading(Paint paint) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        return fm.bottom - fm.top;
    }



    private OnFinishComposingListener mFinishComposingListener;
    private void setOnFinishComposingListener(OnFinishComposingListener listener){
        this.mFinishComposingListener =listener;
    }
    @Override
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        return new MyInputConnection(super.onCreateInputConnection(outAttrs), false);
    }
    public class MyInputConnection extends InputConnectionWrapper {
        public MyInputConnection(InputConnection target, boolean mutable) {
            super(target, mutable);
        }
        @Override
        public boolean finishComposingText() {
            boolean finishComposing = super.finishComposingText();
            if(mFinishComposingListener != null){
                mFinishComposingListener.finishComposing();
            }

            return finishComposing;
        }
    }
    public interface OnFinishComposingListener{
        void finishComposing();
    }

}
