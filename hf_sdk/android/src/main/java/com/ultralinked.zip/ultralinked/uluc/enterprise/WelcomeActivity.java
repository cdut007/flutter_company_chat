package com.ultralinked.uluc.enterprise;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.trello.rxlifecycle.components.support.RxFragmentActivity;
import com.ultralinked.uluc.enterprise.chat.viewpagerindicator.IconPageIndicator;
import com.ultralinked.uluc.enterprise.chat.viewpagerindicator.IconPagerAdapter;
import com.ultralinked.uluc.enterprise.login.GuideActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.io.File;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.functions.Action1;

public class WelcomeActivity extends RxFragmentActivity {

    ViewPager viewPager;

    private IconPageIndicator iconPageIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.welcome);
        initView();

//        if (isRootSystem()){
//            Toast.makeText(this,"Your device is not allowed to use.",Toast.LENGTH_LONG).show();
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    System.exit(0);
//                }
//            },1000);
//        }
    }


    private final static int kSystemRootStateUnknow = -1;
    private final static int kSystemRootStateDisable = 0;
    private final static int kSystemRootStateEnable = 1;
    private static int systemRootState = kSystemRootStateUnknow;

    public static boolean isRootSystem() {
        if (systemRootState == kSystemRootStateEnable) {
            return true;
        } else if (systemRootState == kSystemRootStateDisable) {
            return false;
        }
        File f = null;
        final String kSuSearchPaths[] = {"/system/bin/", "/system/xbin/",
                "/system/sbin/", "/sbin/", "/vendor/bin/"};
        try {
            for (int i = 0; i < kSuSearchPaths.length; i++) {
                f = new File(kSuSearchPaths[i] + "su");
                if (f != null && f.exists()) {
                    systemRootState = kSystemRootStateEnable;
                    return true;
                }
            }
        } catch (Exception e) {
        }
        systemRootState = kSystemRootStateDisable;
        return false;
    }

    SparseArray<Fragment> fragments;

    public void initView() {

        viewPager = (ViewPager) findViewById(R.id.convenientBanner);

        fragments = new SparseArray<>();


        iconPageIndicator = (IconPageIndicator) findViewById(R.id.guide_show_pagerTab);

        if (!GuideViewHelper.checkHasThisGuideLabel("guide_first_install")) {

            GuideFragment guideFragment = new GuideFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("index", 0);
            guideFragment.setArguments(bundle);
            fragments.put(0, guideFragment);

            guideFragment = new GuideFragment();
            bundle = new Bundle();
            bundle.putInt("index", 1);
            guideFragment.setArguments(bundle);
            fragments.put(1, guideFragment);

            guideFragment = new GuideFragment();
            bundle = new Bundle();
            bundle.putInt("index", 2);
            guideFragment.setArguments(bundle);
            fragments.put(2, guideFragment);

            viewPager.setAdapter(new FragmentPageAdapter(getSupportFragmentManager(), fragments));



            viewPager.setOffscreenPageLimit(3);
            viewPager.setCurrentItem(0);
            iconPageIndicator.setViewPager(viewPager);
            iconPageIndicator.setCurrentItem(0);


        } else {
            findViewById(R.id.fmAd).setVisibility(View.GONE);
            go2lunch(true);
        }


    }

    private void go2lunch(boolean delay) {
        long time = App.getInstance().initTime;
        Log.i("WelcomeActivity", " app start time ==" + time);
        int delayTime = 500;
        if (!delay) {
            delayTime = 0;
        }
        Observable.just(SPUtil.contains("userID"))
                .compose(this.<Boolean>bindToLifecycle())
                .delay(delayTime, TimeUnit.MILLISECONDS).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean aBoolean) {
                if (aBoolean) {
                    Intent intent = new Intent(WelcomeActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(WelcomeActivity.this, GuideActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                }
                overridePendingTransition(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out);
                finish();
            }
        });
    }


    public static class FragmentPageAdapter extends FragmentPagerAdapter implements
            IconPagerAdapter {
        SparseArray<Fragment> fragments;

        public FragmentPageAdapter(FragmentManager fm, SparseArray<Fragment> fragments) {
            super(fm);
            this.fragments = fragments;
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }


        @Override
        public int getIconResId(int index) {
            return R.drawable.dot_state_guide;
        }

    }

    public static final class GuideFragment extends Fragment {


        int index;
        TextView desc;
        ImageView guideImage;


        @Nullable
        @Override
        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            super.onCreateView(inflater, container, savedInstanceState);
            index = getArguments().getInt("index");
            View view = inflater.inflate(R.layout.welcome_guide, null);
            desc = (TextView) view.findViewById(R.id.txt_tv);
            guideImage = (ImageView) view.findViewById(R.id.image);
            if (index == 0) {
                desc.setText(R.string.welcome_1);
            } else if (index == 1) {

//                ImageUtils.loadImageByString(getActivity(), guideImage,"android.resource://"+ App.getInstance().getPackageName()+"/drawable/"+R.drawable.e_2,R.mipmap.no_pic, R.mipmap.no_pic);
                desc.setText(R.string.welcome_2);
            } else {
              //  guideImage.setImageResource(R.drawable.e_3);
//                ImageUtils.loadImageByString(getActivity(), guideImage,"android.resource://"+ App.getInstance().getPackageName()+"/drawable/"+R.drawable.e_3,R.mipmap.no_pic, R.mipmap.no_pic);

                //last
            }

//            view.findViewById(R.id.pass).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    GuideViewHelper.addUserGuide("guide_first_install");
//                    ((WelcomeActivity) getActivity()).go2lunch(false);
//                }
//            });

            if (index == 2) {
                desc.setVisibility(View.GONE);
                view.findViewById(R.id.txt_start).setVisibility(View.VISIBLE);
                view.findViewById(R.id.txt_start).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GuideViewHelper.addUserGuide("guide_first_install");
                        ((WelcomeActivity) getActivity()).go2lunch(false);
                    }
                });
            }
            return view;
        }
    }


}
