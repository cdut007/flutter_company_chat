package com.ultralinked.uluc.enterprise.call;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatBottomMenuPagerAdapter;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.TimeUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2017/1/24.
 */

public class CallLogDetailActivity extends BaseActivity implements View.OnClickListener {

    RecyclerView mRecyclerView;
    CallLogAdapter adapter;
    TextView mTxtMobile, mTxtMessage, mTxtCall;
    ImageView mImgHead;
    List<SparseArray<String>> logs;
    CallLog log;
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_call_log_detail;
    }

    @Override
    protected void setTopBar() {
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.call_details);
        bind(R.id.left_back).setOnClickListener(this);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        mRecyclerView = bind(R.id.recycler_call_log_detail);
        mTxtMobile = bind(R.id.txt_mobile);
        mTxtMessage = bind(R.id.txt_message);
        mTxtCall = bind(R.id.txt_call);
        mImgHead = bind(R.id.img_head);
        ImageUtils.buttonEffect(mTxtMessage);
        ImageUtils.buttonEffect(mTxtCall);
        mTxtMessage.setOnClickListener(this);
        mTxtCall.setOnClickListener(this);

        Intent intent = getIntent();
        log = intent.getParcelableExtra("call_log");
        ImageUtils.loadCircleImage(this, mImgHead, log.getIcon_url(), R.mipmap.default_head);
        String mobile = log.getMobile();
        if (!TextUtils.isEmpty(mobile)) {
            mTxtMobile.setText(PhoneNumberUtils.formatMobile(mobile));
            initializeDate();
//            queryCallLogsByMobile(mobile);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.txt_message:
                if(log!=null) {
                    PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().queryFriendByMobileSql(log.getMobile());
                    if (PeopleEntityQuery.hasFoundPeople(peopleEntity)){
                        Conversation conversation = MessagingApi.getConversation(peopleEntity.subuser_id);
                        if (conversation == null) {
                            Log.i(TAG, "userid:" + peopleEntity.subuser_id);
                            return;
                        }

                        SingleChatImActivity.launchToSingleChatIm(CallLogDetailActivity.this, peopleEntity.subuser_id, conversation.conversationFlag);
                    }else{
                        //maybe need invite.
                    }
                }

                break;
            case R.id.txt_call:
                if(log!=null) {
                    CallDialog callDialog = CallDialog.getInstance(log.getMobile(), "", "");
                    // callDialog.show(getActivity().getFragmentManager(), "call_dialog");
                    callDialog.makeCall(getActivity(), log.getMobile(), null, null, null, ChatBottomMenuPagerAdapter.IP2_PHONE_CALL);
                    callDialog.setCallStartListener(new CallDialog.OnCallStartListener() {
                        @Override
                        public void go2Call() {
//                            clearCallNumber = true;
                        }
                    });
                }
                break;
        }
    }

    private void initializeDate(){
        logs = new ArrayList<>(1);
        SparseArray<String> array = new SparseArray<>(2);
        array.put(0,log.getEnd_time());
        array.put(1,log.getDuration());
        logs.add(array);
        if (logs != null) {
            if(adapter == null){
                mRecyclerView.setLayoutManager(new LinearLayoutManager(CallLogDetailActivity.this));
                mRecyclerView.addItemDecoration(new DividerLinearDecoration(CallLogDetailActivity.this, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_10_0_dp, R.dimen.px_10_0_dp));
                adapter = new CallLogAdapter(CallLogDetailActivity.this, logs);
                mRecyclerView.setAdapter(adapter);
            }else{
                adapter.notifyDataSetChanged();
            }
        }
    }

    private void queryCallLogsByMobile(final String mobile) {

        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                Cursor cursor = null;
                try {
                    String sql = "select call_endtime,call_duration from call_log where call_from = ?";
                    SQLiteDatabase database = SqliteUtils.getInstance(CallLogDetailActivity.this).getDb();
                    cursor = database.rawQuery(sql, new String[]{mobile});
                    if (cursor.moveToFirst()) {
                        logs = new ArrayList<>(cursor.getCount());
                        do {
                            SparseArray<String> array = new SparseArray<>(2);
                            array.put(0, cursor.getString(0));
                            array.put(1, cursor.getString(1));
                            logs.add(array);
                        } while (cursor.moveToNext());
                    }
                    subscriber.onNext("");
                } catch (Exception ex) {
                    Log.e(TAG, android.util.Log.getStackTraceString(ex));
                } finally {
                    if (cursor != null)
                        cursor.close();
                }
            }
        })
                .compose(this.<String>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG + "query call_log error: ", HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(String s) {
                        if (logs != null) {
                            if(adapter == null){
                                mRecyclerView.setLayoutManager(new LinearLayoutManager(CallLogDetailActivity.this));
                                mRecyclerView.addItemDecoration(new DividerLinearDecoration(CallLogDetailActivity.this, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_10_0_dp, R.dimen.px_10_0_dp));
                                adapter = new CallLogAdapter(CallLogDetailActivity.this, logs);
                                mRecyclerView.setAdapter(adapter);
                            }else{
                                adapter.notifyDataSetChanged();
                            }
                        }
                    }
                });
    }

    class CallLogAdapter extends BaseRecyclerAdapter<SparseArray<String>, RecyclerViewHolder> {

        public CallLogAdapter(Context ctx, List<SparseArray<String>> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_call_log_detail;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, SparseArray<String> itemData) {
            holder.getTextView(R.id.txt_end_time).setText(TimeUtil.formatMillisecond(Long.parseLong(itemData.get(0))));
            String duration = itemData.get(1);
            if(duration.contains(":")){
                holder.getTextView(R.id.txt_duration).setText(duration);
            }else{
                holder.getTextView(R.id.txt_duration).setText("00:00");
            }
        }
    }
}
