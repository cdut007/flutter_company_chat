package com.ultralinked.uluc.enterprise.login;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import com.google.android.gms.common.GoogleApiAvailability;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.UpgrdeInfo;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.bean.DeviceInfo;
import com.ultralinked.uluc.enterprise.login.bean.UserConfigs;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.google.gson.Gson;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MLoginApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/6/8 0008.
 */

public class LoginPresenter implements LoginModelFab {

    private static String TAG = "LoginPresenter";
    private LoginView loginViewFab;
    private LoginModel model;

    public LoginPresenter(LoginView loginViewFab, Context context) {
        this.loginViewFab = loginViewFab;
        model = new LoginModelImp(this, context);
    }


    public void otpCreateCompany(String mobile, String company, String otp) {
        loginViewFab.showDialog();
        model.otpCreateCompany(mobile, company, otp);
    }


    public void otpRegistCompany(String mobile, String company, String email, String username, String otp) {
        loginViewFab.showDialog();
        model.otpRegistCompany(mobile, company, email, username, otp);
    }

    public void otpRegist(String mobile, String username, String otp) {
        loginViewFab.showDialog();
        model.otpRegist(mobile, username, otp);
    }


    public void login(String username, String password) {
        loginViewFab.showDialog();
        model.login(username, password);
    }

    public void refreshTokenConfig() {
        model.refreshTokenConfig();
    }

    public void otpRequest(String mobile, String action, String type) {
        // loginViewFab.showDialog();
        model.otpRequest(mobile, action, type);
    }

    public void otpLogin(String mobile, String otp) {
        loginViewFab.showDialog();
        model.otpLogin(mobile, otp);
    }

    public boolean onlyRefreshSettings;

    @Override
    public void error(String e) {
        if (TextUtils.isEmpty(e)) {
            e = App.getInstance().getString(R.string.login_error);
        }
        if (onlyRefreshSettings) {
            if (e != null && e.contains("401")) {
                //invilad token , go 2 login page.
                App.getInstance().goToLoginActivity(true);
            }
            Log.i(TAG, "refresh config error:" + onlyRefreshSettings);
        }

        loginViewFab.loginError(e);
        loginViewFab.hideDialog();
    }

    @Override
    public void success(ResponseBody responseBody) {
        String body;
        try {
            body = responseBody.string();

            JSONObject object = new JSONObject(body);

            if (body.contains("access_token")) {
                //将配置保存到DefaultSharedPreferences
                Gson gson = new Gson();
                if (onlyRefreshSettings) {
                    UserConfigs userConfigs = gson.fromJson(body, UserConfigs.class);
                    SPUtil.refreshSettingConfigs2DefaultSharedPreferences(userConfigs.getSettings());
                } else {
                    UserConfigs userConfigs = gson.fromJson(body, UserConfigs.class);
                    SPUtil.saveUserConfigs2DefaultSharedPreferences(userConfigs);
                }

                loginViewFab.hideDialog();
                loginViewFab.loginSuccess();
            } else {

                if (200 == object.optInt("code")) {
                    loginViewFab.hideDialog();
                    loginViewFab.loginSuccess();
                } else {
                    if (onlyRefreshSettings) {
                        if (401 == object.optInt("code")) {
                            //invilad token , go 2 login page.
                            App.getInstance().goToLoginActivity(true);
                        }

                    }

                    loginViewFab.loginError(object.optString("description"));
                    loginViewFab.hideDialog();
                }

            }


        } catch (Exception e) {
            body = "";
            loginViewFab.loginError(android.util.Log.getStackTraceString(e));
            loginViewFab.hideDialog();
        }

        Log.i(TAG, body);

    }


    public static void deleteAllFiles() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                delete(new File("/data/data/" + App.getInstance().getPackageName()), App.getInstance());
            }
        }).start();
    }

    // 递归删除文件及文件夹
    private static void delete(File file, Context context) {
        if (file.isFile()) {
            deleteFile(file, context);
            return;
        }

        if (file.isDirectory()) {
            File[] childFiles = file.listFiles();
            if (childFiles == null || childFiles.length == 0) {
                deleteFile(file, context);
                return;
            }

            for (int i = 0; i < childFiles.length; i++) {
                delete(childFiles[i], context);
            }
            // deleteFile(file);
        }
    }

    public static void deleteFile(File file, Context context) {
        String fileName = file.getName();
        if (fileName.equals(".nomedia")) {
            return;
        }
        file.delete();
        String filePath = file.getAbsolutePath();
        // if
        // (MediaFile.isImageFileType(filePath)||MediaFile.isVideoFileType(filePath))
        // {
        //
        // }
        //FileUtils.scanMediaFileToGallery(context, filePath);
    }

    public static void logout(Context context) {
        SPUtil.clear();
        LoginApi.logout();
        MLoginApi.logout();
        Intent intent = new Intent(context, GuideActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        if (context instanceof BaseActivity) {
            BaseActivity activity = (BaseActivity) context;
            activity.lunchActivityWithIntent(intent);
            activity.finish();
        } else {
            context.startActivity(intent);
        }
    }


    public static void checkLoginStatus() {
        //first quick login.
        MLoginApi.checkLoginStatus();

        checkDeviceStatus(new OnDetectDeviceStatusCallback() {
            @Override
            public void onDeviceStatus(int status) {
                if (status == DeviceInfo.NORMAL) {

                    Log.i(TAG, "rgLogin checkLoginStatus~~~");
                } else {
                    Log.i(TAG, "rgLogin checkLoginStatus  but the status is~~~" + status);
                }
            }
        });

    }

    public static void reLogin() {

        checkDeviceStatus(new OnDetectDeviceStatusCallback() {
            @Override
            public void onDeviceStatus(int status) {
                if (status == DeviceInfo.NORMAL) {
                    MLoginApi.reLogin();
                    Log.i(TAG, "rgLogin normal~~~");
                } else {
                    Log.i(TAG, "rgLogin  but the device status is~~~" + status);
                }
            }
        });
    }

    public static void checkDeviceStatus() {

        checkDeviceStatus(new OnDetectDeviceStatusCallback() {
            @Override
            public void onDeviceStatus(int status) {

            }
        });
    }

    public static void checkDeviceStatus(final OnDetectDeviceStatusCallback detectDeviceStatusCallback) {


        DeviceInfo deviceInfo = null;
        try {
            deviceInfo = DeviceInfo.getInfos();
        } catch (JSONException e) {

            Log.i(TAG, "get current devices info error:" + android.util.Log.getStackTraceString(e));
        }
        if (deviceInfo == null) {
            Log.i(TAG, "get current devices info error");
            detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);
            return;
        }
        ApiManager.getInstance().getCurrentDeviceStatus(deviceInfo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getCurrentDeviceStatusCompleted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        //   detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);
                        Log.e(TAG, "getCurrentDeviceStatus error:" + HttpErrorException.handErrorMessage(e));

                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String body = "";
                        try {
                            body = responseBody.string();
                            JSONObject object = new JSONObject(body);
                            int code = object.optInt("code");
                            if (200 == code) {
                                //
                                // MainActivity.instance
//
                                JSONObject app_version = object.optJSONObject("app_version");
                                if (app_version != null) {
                                    JSONObject android = app_version.optJSONObject("android");
                                    if (android != null) {
                                        final int version = android.optInt("version");
                                        final boolean force_upgrade = android.optBoolean("force_upgrade");
                                        if (displayInfoTimer != null) {
                                            displayInfoTimer.cancel();
                                            displayInfoTimer = null;
                                        }
                                        displayInfoTimer = new Timer();
                                        displayInfoTimer.schedule(new TimerTask() {
                                            @Override
                                            public void run() {
                                                if (MainActivity.instance != null) {
                                                    MainActivity.instance.runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            parseUpgradeInfo(version, force_upgrade);
                                                        }
                                                    });
                                                }

                                            }
                                        }, 1000);
                                    }
                                }
                                List<DeviceInfo> deviceInfoList = new ArrayList<DeviceInfo>();
                                Gson gson = new Gson();
                                deviceInfoList = gson.fromJson(object.optString("result"),
                                        new TypeToken<List<DeviceInfo>>() {
                                        }.getType());
                                if (deviceInfoList.size() > 0) {
                                    detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.DESTROYED);
                                    Toast.makeText(App.getInstance(), R.string.remote_destrcut_tips, Toast.LENGTH_LONG).show();
                                    LoginPresenter.logout(App.getInstance());
                                    LoginPresenter.deleteAllFiles();
                                } else {
                                    //     detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);
                                }
                            } else {
                                //    detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);
                                Log.i(TAG, "getCurrentDeviceStatus error:" + "errorcode:" + code + "\n" + object.optString("description"));
                            }
                        } catch (Exception e) {
                            //   detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);
                            Log.i(TAG, "parse info error:" + android.util.Log.getStackTraceString(e));

                        }
                        Log.i(TAG, "getCurrentDeviceStatus==" + body);
                    }

                });

        //for normal login quickly. 并发登录,后面考虑要不要去掉,如果去掉,则上面网络normal打开。
        detectDeviceStatusCallback.onDeviceStatus(DeviceInfo.NORMAL);

    }

    static Timer displayInfoTimer;
    static Dialog upgradeDialog;

    private static void parseUpgradeInfo(int version, boolean force_upgrade) {
        Log.e("version and upgrade: ", version + " " + force_upgrade);
        if (upgradeDialog != null && upgradeDialog.isShowing()) {
            return;
        }
        try {
            if (version > 0 && MainActivity.instance != null) {
                if (UpgrdeInfo.getVersionCode(MainActivity.instance) < version) {
                    if (force_upgrade) {
                        upgradeDialog = DialogManager.showOKDialog(MainActivity.instance, MainActivity.instance.getString(R.string.bugly_has_new_ver), MainActivity.instance.getString(R.string.please_upgrade), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                upgradeDialog = null;
                                if (hasGoogleService(MainActivity.instance)) {
                                    MainActivity.instance.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.ultralinked.uluc.enterprise")));
                                } else {
                                    MainActivity.instance.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://sj.qq.com/myapp/detail.htm?apkName=com.ultralinked.uluc.enterprise")));
                                }
                            }
                        });
                    } else {
                        upgradeDialog = DialogManager.showOKCancelDialog(MainActivity.instance, MainActivity.instance.getString(R.string.bugly_has_new_ver), MainActivity.instance.getString(R.string.please_upgrade), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                upgradeDialog = null;
                                if (hasGoogleService(MainActivity.instance)) {
                                    MainActivity.instance.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.ultralinked.uluc.enterprise")));
                                } else {
                                    MainActivity.instance.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://sj.qq.com/myapp/detail.htm?apkName=com.ultralinked.uluc.enterprise")));
                                }
                            }
                        }, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                upgradeDialog = null;
                            }
                        });
                    }
                }
            }
        } catch (Exception ex) {
            Log.e("LoginPresenter parseUpgradeInfo: ", android.util.Log.getStackTraceString(ex));
        }

    }

    public static boolean hasGoogleService(Context context) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(context);
        if (resultCode != 0) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                android.util.Log.i("LoginApi", "This device do not have the google play service.");
            } else {
                android.util.Log.i("LoginApi", "This device is not supported.");
            }
            return false;
        } else {
            android.util.Log.i("LoginApi", "This device is support google play service.");
            return true;
        }
    }


    public interface OnDetectDeviceStatusCallback {
        void onDeviceStatus(int status);
    }
}
