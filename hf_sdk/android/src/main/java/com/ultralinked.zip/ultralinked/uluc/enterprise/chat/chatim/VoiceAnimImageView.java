package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.content.LocalBroadcastManager;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.VoiceMessage;

public class VoiceAnimImageView extends ImageView
{
    private  Context context;
    private AlphaAnimation alphaAnimation;
    private AnimationDrawable receive;
    private AnimationDrawable send;
    private boolean isSender;

    public VoiceAnimImageView(Context context)
    {
        super(context);
        this.context = context;
        init();
    }

    public VoiceAnimImageView(Context context, AttributeSet attributeSet)
    {
        super(context, attributeSet);
        this.context = context;
        init();
    }

    public VoiceAnimImageView(Context context, AttributeSet attributeSet, int defStyleAttr)
    {
        super(context, attributeSet, defStyleAttr);
        this.context = context;
        init();
    }

    private void init()
    {
        this.alphaAnimation = new AlphaAnimation(0.1F, 1.0F);
        this.alphaAnimation.setDuration(1000L);
        this.alphaAnimation.setRepeatCount(-1);//forever
        this.alphaAnimation.setRepeatMode(Animation.REVERSE);
        this.send = new AnimationDrawable();
        Drawable localDrawable1 = getResources().getDrawable(R.mipmap.chatto_voice_playing_f_1);
        localDrawable1.setBounds(0, 0, localDrawable1.getIntrinsicWidth(), localDrawable1.getIntrinsicHeight());
        this.send.addFrame(localDrawable1, 300);
        Drawable localDrawable2 = getResources().getDrawable(R.mipmap.chatto_voice_playing_f_2);
        localDrawable2.setBounds(0, 0, localDrawable2.getIntrinsicWidth(), localDrawable2.getIntrinsicHeight());
        this.send.addFrame(localDrawable2, 300);
        Drawable localDrawable3 = getResources().getDrawable(R.mipmap.chatto_voice_playing_f_3);
        localDrawable3.setBounds(0, 0, localDrawable3.getIntrinsicWidth(), localDrawable3.getIntrinsicHeight());
        this.send.addFrame(localDrawable3, 300);
        this.send.setOneShot(false);
        this.send.setVisible(true, true);

        this.receive = new AnimationDrawable();
        Drawable localDrawable4 = getResources().getDrawable(R.mipmap.chatfrom_voice_playing_f1);
        localDrawable4.setBounds(0, 0, localDrawable4.getIntrinsicWidth(), localDrawable4.getIntrinsicHeight());
        this.receive.addFrame(localDrawable4, 300);
        Drawable localDrawable5 = getResources().getDrawable(R.mipmap.chatfrom_voice_playing_f2);
        localDrawable5.setBounds(0, 0, localDrawable5.getIntrinsicWidth(), localDrawable5.getIntrinsicHeight());
        this.receive.addFrame(localDrawable5, 300);
        Drawable localDrawable6 = getResources().getDrawable(R.mipmap.chatfrom_voice_playing_f3);
        localDrawable6.setBounds(0, 0, localDrawable6.getIntrinsicWidth(), localDrawable6.getIntrinsicHeight());
        this.receive.addFrame(localDrawable6, 300);
        this.receive.setOneShot(false);
        this.receive.setVisible(true, true);
    }


    public final void stop()
    {
        if (isSender)
        {
            this.send.stop();

            setImageResource(R.mipmap.chatto_voice_playing_f_3);

        }else{
            this.receive.stop();
            setImageResource(R.mipmap.chatfrom_voice_playing_f3);
        }

        playingMsgId = -1;
        if ((this.alphaAnimation != null) && (this.alphaAnimation.isInitialized()))
        {
            if (alphaAnimation.hasStarted()){
                alphaAnimation.cancel();
            }


            setAnimation(null);
            alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    if (isSender)
                    {

                        setImageResource(R.mipmap.chatto_voice_playing_f_3);

                    }else{
                        setImageResource(R.mipmap.chatfrom_voice_playing_f3);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

        }


    }

    public final void setIsSender(boolean isSender)
    {
        this.isSender = isSender;

    }


    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        regiser = false;
        LocalBroadcastManager.getInstance(context).unregisterReceiver(playingBroadcastReceiver);

    }

    private  int playingMsgId = -1;
    boolean regiser;
    public final void start(int playingMsgId)
    {

        if (!regiser){
            regiser = true;
            IntentFilter playEndIntentFiler = new IntentFilter();
            playEndIntentFiler.addAction("com.uluc.message.EVENT_VOICE_PLAY");
            LocalBroadcastManager.getInstance(context).registerReceiver(playingBroadcastReceiver,playEndIntentFiler);
        }

        stop();

        this. playingMsgId = playingMsgId;


        if (isSender){

            setImageDrawable(send);
            this.send.start();

        }else {

            setImageDrawable(receive);
            this.receive.start();

        }

        setAnimation(this.alphaAnimation);
        this.alphaAnimation.startNow();



    }

    BroadcastReceiver playingBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            int status = intent.getIntExtra("status",-1);
            long msgId =  intent.getLongExtra("message_id",-1);
            checkStop(msgId,status);
        }
    };

    public void checkStop(long msgId, int playStatus) {
        if (playingMsgId != msgId && msgId!=-1 ){
            return;
        }
        if (playStatus != VoiceMessage.PLAY_STATUS_START) {
          stop();
        }
    }
}
