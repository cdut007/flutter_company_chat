package com.ultralinked.uluc.enterprise.contacts.contract;

/**
 * Created by ultralinked on 16/7/11.
 */

import android.content.ContentResolver;
import android.net.Uri;

/**
 * Created by ultralinked on 16/6/30.
 */
public interface LocalContactContract extends BaseContract {

    String TABLE_NAME = "local";

    String PATH_LOCAL = "local";

    Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_LOCAL).build();

    // DIR 代表 返回的Cursor中包含0或多条记录
    String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_LOCAL;

    //ITEM 代表 返回的Cursor中为特定ID的一条记录
    String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_LOCAL;

    interface LocalColumn extends BasePeopleColumns {
        // Column with the foreign key into the company table.

    }

}
