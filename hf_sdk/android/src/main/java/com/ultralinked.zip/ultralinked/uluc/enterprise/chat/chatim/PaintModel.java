package com.ultralinked.uluc.enterprise.chat.chatim;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by ultralinked on 16/10/7.
 */
public class PaintModel {
    public static final int REQUEST = 1;
    public static final int ACCEPT = 2;
    public static final int DRAW = 3;
    public static final int DISPLAY = 4;
    private int paintAction;

    JSONObject jsonObject = new JSONObject();
    JSONObject drawData;

    public PaintModel(){

    }

    public PaintModel(String pintInfo) {
        try {
            jsonObject = new JSONObject(pintInfo);
            String action = jsonObject.optString("action");
            if ("request".equals(action)){
                paintAction = REQUEST;
            }else if("accept".equals(action)){
                paintAction = ACCEPT;
            }else if("draw".equals(action)){
                paintAction = DRAW;
            }else if("display".equals(action)){
                paintAction = DISPLAY;
            }
             drawData = jsonObject.optJSONObject("drawData");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public  JSONObject getDrawData(){
        return  drawData;
    }

    public int getPaintAction() {

        return paintAction;
    }

    public JSONObject accept() {
        try {
            jsonObject.put("action","accept");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    public JSONObject display() {
        try {
            jsonObject.put("action","display");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }


    public JSONObject request() {
        try {
            jsonObject.put("action","request");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    public JSONObject paint(JSONObject paint) {
        try {
            jsonObject.put("action","draw");
            jsonObject.put("drawData",paint);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }
}
