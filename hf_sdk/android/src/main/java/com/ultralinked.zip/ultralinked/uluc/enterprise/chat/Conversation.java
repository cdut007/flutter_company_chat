package com.ultralinked.uluc.enterprise.chat;

/**
 * Created by ultralinked on 2016/7/4 0004.
 */
public class Conversation {

    private String name;
    private String latestMsg;
    private String photoUri;
    private String time;

    public String getName() {
        return name;
    }

    public Conversation setName(String name) {
        this.name = name;
        return this;
    }

    public String getLatestMsg() {
        return latestMsg;
    }

    public Conversation setLatestMsg(String latestMsg) {
        this.latestMsg = latestMsg;
        return this;

    }

    public String getPhotoUri() {
        return photoUri;
    }

    public Conversation setPhotoUri(String photoUri) {
        this.photoUri = photoUri;
        return this;

    }

    public String getTime() {
        return time;
    }

    public Conversation setTime(String time) {
        this.time = time;
        return this;

    }
}
