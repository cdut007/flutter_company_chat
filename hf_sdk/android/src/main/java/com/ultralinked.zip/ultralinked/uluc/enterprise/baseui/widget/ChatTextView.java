package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.utils.CommonLinkify;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

/**
 * Created by mac on 16/11/28.
 */

public class ChatTextView extends TextView {

    private Context mContext;

    private float textSize =0;

    public ChatTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setAutoLinkMask(Linkify.ALL);
        mContext = context;
        textSize = getTextSize();
        notifySizeChanged();
    }


    public void notifySizeChanged(){
        float standFontSize = textSize;
        float size = standFontSize
                / mContext.getResources().getDisplayMetrics().scaledDensity;
        setTextSize(size);
    }


    @Override
    public void setTextSize(float size) {

        float scaleSize = SPUtil.getFontScale(getContext());
        super.setTextSize(size * scaleSize);
    }


    @Override
    public void setText(CharSequence text, BufferType type) {
//
//
//        if (!(text instanceof SpannableStringBuilder)){
//
//            setMovementMethod(null);
//            super.setText(text, type);
//            return;
//        }
//
//        boolean hasLink = CommonLinkify.addLinks((SpannableStringBuilder)text, CommonLinkify.WEB_URLS
//                        | CommonLinkify.PHONE_NUMBERS | CommonLinkify.EMAIL_ADDRESSES,
//                new CommonLinkify.ClickUrlListener() {
//                    @Override
//                    public void onClick(String url, View v) {
//                        Log.i("click", " url==" + url);
//                        URLSpan rSpan = new URLSpan(url);
//                        rSpan.onClick(v);
////                        if (url.startsWith("tel:")) {
////
////                        } else {
////
////                            URLSpan rSpan = new URLSpan(url);
////                            rSpan.onClick(v);
////                                /*
////								 * Uri uri = Uri.parse(url); Context context =
////								 * textView.getContext(); Intent intent = new
////								 * Intent(Intent.ACTION_VIEW, uri);
////								 * intent.putExtra(Browser.EXTRA_APPLICATION_ID,
////								 * context.getPackageName());
////								 * context.startActivity(intent);
////								 */
////                            Log.i("linkweb", "link clicked");
////
////                        }
//                    }
//                });
//
//        if (!hasLink) {
//
//            setMovementMethod(null);
//        } else {
//
//            setMovementMethod(LinkClickMovementMethod.getInstance());
//
//        }

        super.setText(text, type);
    }
}
