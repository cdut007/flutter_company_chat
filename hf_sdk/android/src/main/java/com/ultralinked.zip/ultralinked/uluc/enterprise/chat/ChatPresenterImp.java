package com.ultralinked.uluc.enterprise.chat;

import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import java.util.ArrayList;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/7/4 0004.
 */
public class ChatPresenterImp {

    private ChatModelFab chatFab;

    public ChatPresenterImp(ChatModelFab chatModel) {
        chatFab = chatModel;
    }

    public void initChatData(final boolean isGroupChatsList, final boolean isPrivate) {


        Observable.create(new Observable.OnSubscribe<List<Conversation>>() {


            @Override
            public void call(Subscriber<? super List<Conversation>> subscriber) {
                if (isGroupChatsList) {

                    subscriber.onNext(MessagingApi.getAllConversationsByType(Conversation.GROUP_CHAT));

                } else {

                    List<Conversation> conversations = MessagingApi.getAllConversations();
                    if (conversations == null) {
                        conversations = new ArrayList<Conversation>();
                    }
                    List<Conversation> filterconversations = new ArrayList<>();
                    if (isPrivate) {
                        for (Conversation conversation : conversations) {
                            if (conversation.conversationFlag != Conversation.CONVERSATION_FLAG_PRIVATE) {
                                continue;
                            }
                            filterconversations.add(conversation);
                        }
                    } else {
                        for (Conversation conversation : conversations) {
                            if (conversation.conversationFlag == Conversation.CONVERSATION_FLAG_PRIVATE) {
                                continue;
                            }
                            filterconversations.add(conversation);
                        }
                    }

                    subscriber.onNext(filterconversations);
                    chatFab.updateUnreadCount(MessageUtils.getAllUnreadMessageCount(filterconversations));
                }


            }

        })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<List<Conversation>>() {
                    @Override
                    public void call(List<Conversation> conversations) {
                        chatFab.updateConversations(conversations);
                    }

                });


    }

}
