package com.ultralinked.uluc.enterprise.chat.chatim;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.R.integer;
import android.app.Activity;
import android.content.Context;

public class ImStickerMap {
	// We don't use namespaces
	private static HashMap<String, String> stickerHashMap = new HashMap<String, String>();
	private static HashMap<String, Integer> stickerNumHashMap = new HashMap<String, Integer>();
	private static ImStickerMap mStickerMap;

	public static String im_programmer_gif="im_programmer_gif_";

	public static String im_seals_gif="im_seals_gif_";

	Context context;
	public ImStickerMap(Context context) {
		// TODO Auto-generated constructor stub
	 this.context = context;
	}

	static{
		init();
	}


	public static ImStickerMap getInstance(Context context){
		if (mStickerMap == null) {
			synchronized (ImStickerMap.class) {
				mStickerMap = new ImStickerMap(context);
			}
		}
		return mStickerMap;
	}

	private  static void  init(){
		//for programmer
		for (int i = 0; i <8; i++) {
			String resName = getStickerResId(im_programmer_gif, i);
			stickerHashMap.put(resName, ""+i);
		}
		stickerNumHashMap.put(im_programmer_gif, 8);
		//for seals
		for (int i = 0; i <8; i++) {
			String resName =getStickerResId(im_seals_gif, i);
			stickerHashMap.put(resName, ""+i);
		}
		stickerNumHashMap.put(im_seals_gif, 8);
	}


//	public static final String STICKER_PERFX="[STICKER]:";



	public static boolean  isSticker(String resName){
		return stickerHashMap.containsKey(resName);
	}

//	public static boolean isStickerMessage(String stickerMessage) {
//		// TODO Auto-generated method stub
//		if (stickerMessage.startsWith(STICKER_PERFX)) {
//			if (ImStickerMap.isSticker(stickerMessage.substring(STICKER_PERFX.length()))) {
//				return true;
//			}
//
//		}
//		return false;
//	}
//
	public  String getStickerName(String msgContent) {
		//int start=STICKER_PERFX.length();
		// TODO Auto-generated method stub
		//return  msgContent.substring(start);
		return  msgContent;
	}

	public static String  getStickerResId(String stickerNameTag, int index) {

		return stickerNameTag+(index+1) + ".gif";
	}

	public  String getStickerDesc(String resDesc) {

		return resDesc;
	}

	public  int getStickerNum(String stickerNameTag) {
		return stickerNumHashMap.get(stickerNameTag);
	}







}
