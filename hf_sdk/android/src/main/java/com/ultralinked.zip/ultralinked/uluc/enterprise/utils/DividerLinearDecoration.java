package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by lly on 2016/12/7.
 */

public class DividerLinearDecoration extends RecyclerView.ItemDecoration {

    Drawable mDividerDrawable;
    int mDividerDimension = 0;
    int mOrientation = LinearLayoutManager.VERTICAL;
    int aMargin = 0;
    int bMargin = 0;
    boolean isNoFooterLine = true;

    public DividerLinearDecoration(Context context, int orientation, int dividerDimensionId) {
        this.mOrientation = orientation;
        this.mDividerDimension = context.getResources().getDimensionPixelSize(dividerDimensionId);
    }

    public DividerLinearDecoration(Context context, int orientation, int dividerDimensionId, boolean isNoFooterLine) {
        this.mOrientation = orientation;
        this.mDividerDimension = context.getResources().getDimensionPixelSize(dividerDimensionId);
        this.isNoFooterLine = isNoFooterLine;
    }

    public DividerLinearDecoration(Context context, int orientation, int dividerDrawableId, int marginLeftDimensionId, int marginRightDimensionId) {
        this.mOrientation = orientation;
        Resources resources = context.getResources();
        this.mDividerDrawable = resources.getDrawable(dividerDrawableId);
        this.aMargin = resources.getDimensionPixelSize(marginLeftDimensionId);
        this.bMargin = resources.getDimensionPixelSize(marginRightDimensionId);
    }

    public DividerLinearDecoration(Context context, int orientation, int dividerDrawableId, int marginLeftDimensionId, int marginRightDimensionId, boolean isNoFooterLine) {
        this.mOrientation = orientation;
        Resources resources = context.getResources();
        this.mDividerDrawable = resources.getDrawable(dividerDrawableId);
        this.aMargin = resources.getDimensionPixelSize(marginLeftDimensionId);
        this.bMargin = resources.getDimensionPixelSize(marginRightDimensionId);
        this.isNoFooterLine = isNoFooterLine;
    }

    @Override
    public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
        if (mDividerDrawable != null)
            if (mOrientation == LinearLayoutManager.VERTICAL) {
                drawVertical(c, parent);
            } else {
                drawHorizontal(c, parent);
            }
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        if(isLastRow(view,parent)&&isNoFooterLine){
            return;
        }
        if (mOrientation == LinearLayoutManager.VERTICAL) {
            if (mDividerDrawable != null) {
                outRect.set(0, 0, 0, mDividerDrawable.getIntrinsicHeight());
            } else {
                outRect.set(0, 0, 0, mDividerDimension);
            }
        } else {
            if (mDividerDrawable != null) {
                outRect.set(0, 0, mDividerDrawable.getIntrinsicWidth(), 0);
            } else {
                outRect.set(0, 0, mDividerDimension, 0);
            }
        }
    }

    private void drawVertical(Canvas c, RecyclerView parent) {
        final int left = parent.getPaddingLeft() + aMargin;
        final int right = parent.getWidth() - parent.getPaddingRight() - bMargin;

        final int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = parent.getChildAt(i);
            final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child
                    .getLayoutParams();
            final int top = child.getBottom() + params.bottomMargin;
            final int bottom = top + mDividerDrawable.getIntrinsicHeight();
            mDividerDrawable.setBounds(left, top, right, bottom);
            mDividerDrawable.draw(c);
        }
    }

    private void drawHorizontal(Canvas c, RecyclerView parent) {
        final int top = parent.getPaddingTop() + aMargin;
        final int bottom = parent.getHeight() - parent.getPaddingBottom() - bMargin;

        final int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = parent.getChildAt(i);
            final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child
                    .getLayoutParams();
            final int left = child.getRight() + params.rightMargin;
            final int right = left + mDividerDrawable.getIntrinsicHeight();
            mDividerDrawable.setBounds(left, top, right, bottom);
            mDividerDrawable.draw(c);
        }
    }

    //Judge if the view belongs to last row.
    private boolean isLastRow(View view ,RecyclerView parent){
        return (parent.getChildLayoutPosition(view)==parent.getAdapter().getItemCount()-1);
    }

}
