package com.ultralinked.uluc.enterprise.chat.bean;

import android.support.annotation.NonNull;

import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.voip.api.Message;

/**
 * Created by Chenlu on 2016/7/12 0012.
 */
public class MsgTime {
    private Message msg;
    private String day;
    private String time;

    public String getDay() {
        return day;
    }

    public String getTime() {
        return time;
    }

    public MsgTime(@NonNull  Message msg) {
        this.msg = msg;

        String globalMsgTime = msg.getGlobalMsgTime();
        if (globalMsgTime == null) {
            day = "";
            time = "";
           return;
        }
        this.day =  ChatModule.convertTimeForChatListItem(null, globalMsgTime);
        this.time = ChatModule.converTiemForMessage(globalMsgTime);
    }
    private MsgTime() {
        this.day = "";
        this.time = "";
    }
    public static MsgTime getEmptyInstance() {
        return new MsgTime();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MsgTime msgTime = (MsgTime) o;

        return msg.getGlobalMsgTime().equals(msgTime.msg.getGlobalMsgTime());

    }

    @Override
    public int hashCode() {
        return msg.hashCode();
    }
}
