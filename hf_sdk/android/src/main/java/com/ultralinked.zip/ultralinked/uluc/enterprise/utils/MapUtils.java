package com.ultralinked.uluc.enterprise.utils;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.CoordinateConverter;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.bean.DLocation;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.voip.api.LocationMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


public class MapUtils {

	private static final String TAG = "MapUtils";
	public static void goToMapsActivity(BaseActivity context, LocationMessage location) throws URISyntaxException {

		double latitude = location.getLatitude();
		double longitude = location.getLongitude();

		double newLatitude;
		double newLongitude;
		String title = location.getTitle();
		String subTitle = location.getSubTitle();
		String content = location.getLocationDesc();

		if (TextUtils.isEmpty(title)) {
			title = context.getString(R.string.share_location);
		}
		if (TextUtils.isEmpty(content)) {
			content = latitude + "," + longitude;
			subTitle = latitude + "," + longitude;
		}

		Log.i(TAG,"location info:"+location.toString()+"  title:"+title+"  subTitle:"+subTitle
		+"  content:"+content);

		String uri = "http://ditu.google.cn/maps?hl=zh&mrt=loc&q=latitude,longitude&mode=w";

		uri = uri.replace("latitude,longitude", new StringBuffer().append(latitude).append(",").append(longitude).toString());
		Log.i(TAG, uri);
		Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
		i.setPackage("com.google.android.apps.maps");
		if (i.resolveActivity(context.getPackageManager()) != null && !App.getInstance().inChina()) {
			context.startActivity(i);
			Log.i(TAG, "open location through local google map app.");
		} else  {

			Log.i(GPSUtils.TAG, "bd09_To_gps84 " + location.getLatitude() + "," + location.getLongitude() + "--->" + latitude + "," + longitude);
			String bdUri = "intent://map/marker?location=" +
					latitude +
					"," +
					longitude +
					"&coord_type=wgs84"+   // use wgs84
					"&title=" +
					title +
					"&content=" +
					content +
					"&src=thirdapp.marker.ultralinked.uluc#Intent;" +
					"scheme=bdapp;package=com.baidu.BaiduMap;end";
			i = Intent.getIntent(bdUri);
			if (i.resolveActivity(context.getPackageManager()) != null) {
				context.startActivity(i);
				Log.i(TAG, "open location through local baidu map app.");
			} else {

				// open through browser
				if (App.checkPlayServices(context)) {// support google play services
					String urlStr = "http://ditu.google.cn/maps?hl=zh&mrt=loc&q=" +
							latitude +
							"," +
							longitude +
							"&mode=w";
					Intent i2 = new Intent(Intent.ACTION_VIEW, Uri.parse(urlStr));
					context.startActivity(i2);
					Log.i(TAG, "open location through  google web map.");

				} else {
					/**
					 * http://api.map.baidu.com/marker?location=40.047669,116.313082&title=我的位置&content=百度奎科大厦&output=html&src=yourComponyName|yourAppName
					 * //调起百度PC或web地图，且在（lat:39.916979519873，lng:116.41004950566）坐标点上显示名称"我的位置"，内容"百度奎科大厦"的信息窗口。
					 */

					String urlStr = "http://api.map.baidu.com/marker?location=" +
							latitude +
							"," +
							longitude+
							"&coord_type=wgs84"+
							"&title=" +
							title +
							"&content=" +
							content +
							"&output=html"+
							"&src=ultralinked|uluc";
					Intent i3 = new Intent(Intent.ACTION_VIEW, Uri.parse(urlStr));
					context.startActivity(i3);
					Log.i(TAG, "open location through  baidu web map."+"  latitude:" + latitude + ",longitude" + longitude);

				}
			}
		}

	}

	public static LatLng convertGpsToBaidu(double latitude,double longitude){
		// 将GPS设备采集的原始GPS坐标转换成百度坐标
		CoordinateConverter converter  = new CoordinateConverter();
		converter.from(CoordinateConverter.CoordType.GPS);
		// sourceLatLng待转换坐标
		converter.coord(new LatLng(latitude, longitude));
		LatLng desLatLng = converter.convert();
		Log.i(TAG, "latitude,longitude:  " + latitude + "," + longitude + "-->" + desLatLng.latitude + "," + desLatLng.longitude);
		return desLatLng;
	}



	public interface CallBack{
		void succed(DLocation pointF);
		void failed(String reason);
	}
	public static void getGpsToMap(BaseActivity activity, DLocation pointF, final CallBack callBack) {

		String mcode = "mcode=72:CB:A3:EE:13:C4:39:24:E7:2B:81:6E:F1:D6:F9:D5:D0:47:74:09;com.ultralinked.uluc.enterprise";
		String url = new StringBuffer().append("http://api.map.baidu.com/geoconv/v1/?coords=")
				.append(pointF.longitude).append(",")
				.append(pointF.latitude).append("&").append(mcode)
				.append("&from=1&to=5&ak=FtGWsTC5zD2A3zX4fOzsrxztIyuAiINO").toString();

		Log.i(TAG, "url~~~~~~~~~~~~~:" + url);

		final double fx = pointF.longitude;
		final double fy = pointF.latitude;
		ApiManager.getInstance().getMapPoint(pointF.longitude + "," + pointF.latitude)
				.subscribeOn(Schedulers.io())
				.compose(activity.<ResponseBody>bindToLifecycle())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(new Subscriber<ResponseBody>() {
					@Override
					public void onCompleted() {
						Log.i(TAG,"getUserComplted");
					}
					@Override
					public void onError(Throwable e) {
						String errorMessage = HttpErrorException.handErrorMessage(e);
						callBack.failed("getGpsToMap error :" + errorMessage.toString());
					}
					@Override
					public void onNext(ResponseBody responseBody) {
						try {
							String jsonString = responseBody.string();
							try {
								Log.i(TAG, "jsonString~~" + jsonString);
								JSONObject jsonObject = new JSONObject(jsonString);
								int status = jsonObject.getInt("status");
								double x = Float.valueOf(jsonObject.getJSONArray("result").getJSONObject(0).getString("x"));
								double y = Float.valueOf(jsonObject.getJSONArray("result").getJSONObject(0).getString("y"));


								if (status == 0) {
									x = 2*fx-x;
									y = 2*fy-y;
									callBack.succed(new DLocation(x,y));
								} else {
									Log.i(TAG, "failed, stauts:" + status);
									callBack.failed("stauts:"+status);
								}
							} catch (JSONException e) {
								e.printStackTrace();
								Log.i(TAG, " json error:" + e.getMessage());
								callBack.failed(" json error:" + e.getMessage());
							}
						} catch (IOException e) {
							e.printStackTrace();
							callBack.failed(" json error~~:" + e.getMessage());
						}
					}

				});
	}


	//100 is less
	static HashMap<String,String > usericonUrlMap = new  HashMap<String,String>();

	public  static  String getUserIconUrl(String userId){
		return  usericonUrlMap.get(userId);
	}
	public  static  void setUserIconUrl(String userId,String icon_url){
		usericonUrlMap.put(userId,icon_url);
	}

// 将google地图、soso地图、aliyun地图、mapabc地图和amap地图// 所用坐标转换成百度坐标
// CoordinateConverter converter  = new CoordinateConverter();
// converter.from(CoordType.COMMON);  // sourceLatLng待转换坐标
// converter.coord(sourceLatLng);
// LatLng desLatLng = converter.convert();

// 将GPS设备采集的原始GPS坐标转换成百度坐标
// CoordinateConverter converter  = new CoordinateConverter();
// converter.from(CoordType.GPS);
// sourceLatLng待转换坐标  converter.coord(sourceLatLng);
// LatLng desLatLng = converter.convert();
}
