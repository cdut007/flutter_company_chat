package com.ultralinked.uluc.enterprise.chat.chatim;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.bumptech.glide.GenericRequestBuilder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.ListPreloader;
import com.bumptech.glide.RequestManager;
import com.ultralinked.contact.util.ToastUtil;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.WrapContentLinearLayoutManager;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.ActionMenu;
import com.ultralinked.uluc.enterprise.baseui.widget.AudioRecordButton;
import com.ultralinked.uluc.enterprise.baseui.widget.MessageRecyclerView;
import com.ultralinked.uluc.enterprise.baseui.widget.MyEditText;
import com.ultralinked.uluc.enterprise.call.CallModel;
import com.ultralinked.uluc.enterprise.chat.bean.ComposMessage;
import com.ultralinked.uluc.enterprise.chat.bean.DLocation;
import com.ultralinked.uluc.enterprise.chat.chatdetails.GroupChatDetailsFragment;
import com.ultralinked.uluc.enterprise.chat.group.ChooseGroupMemberActivity;
import com.ultralinked.uluc.enterprise.chat.viewpagerindicator.IconPageIndicator;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.selectmember.SelectMemberActivity;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.GPSUtils;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MediaFile;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.MsgNotificationUtils;
import com.ultralinked.uluc.enterprise.utils.MyRecyclerItemAnimator;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.BroadcastApi;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.LocationMessage;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.TextMessage;
import com.ultralinked.voip.api.VoiceMessage;
import com.ultralinked.voip.api.VoipCallMessage;
import com.ultralinked.voip.api.utils.FileUtils;
import com.umeng.message.proguard.T;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import tyrantgit.explosionfield.ExplosionField;

/**
 * Created by Chenlu on 2016/7/6 0006.
 */
public abstract class BaseChatImFragment extends BaseFragment implements View.OnClickListener, BaseRecyclerAdapter.OnItemClickListener, BaseRecyclerAdapter.OnItemLongClickListener, SwipeRefreshLayout.OnRefreshListener, MsgViewHolder.OnMessageItemClickListener {

    protected static final String TAG = "BaseChatImFragment";
    private static final int REQUEST_CODE_GALLERY = 0x01;
    private static final int REQUEST_CODE_CAMERA = 0x02;
    private static final int REQUEST_CODE_FOR_CHOOSE_VIDEO = 0x03;
    private static final int REQUEST_CODE_CHOOSE_FILE = 0x04;
    private static final int REQUEST_FILE_PERMISSION_CODE = 0x10;
    private static final int REQUEST_VOICE_PERMISSION_CODE = 0x11;
    private static final int REQUEST_LOCATION_PERMISSION_CODE = 0x12;
    private static final int REQUEST_RECORD_VIDEO_PERMISSION_CODE = 0x15;

    private static final int REQUEST_CODE_FOR_LAST_LOCATION = 0x13;

    public static final int REQUEST_CODE_FOR_CHAT_DETAILS = 0x16;
    private static final int REQUEST_CODE_FOR_RECORD_VIDEO = 0x14;

    public static final String EVENT_MESSAGE_DELETED = "com.ultralinked.message.DELETE";


    protected boolean burningModule;
    protected BaseActivity activity;
    protected ImageView backBtn;
    protected ImageView headerImg;
    protected TextView title;
    protected TextView subtitle;
    protected ImageView saveContact;
    protected ImageView callPhone;
    protected ImageView chatDetails;
    protected ImageView burningView;


    protected boolean isAssistant;

    private MyRecyclerItemAnimator msgAnimator;
    protected MessageRecyclerView recyclerView;
    private WrapContentLinearLayoutManager layoutManager;

    protected Conversation mConversation;
    protected int chatType;
    protected boolean isPrivate;
    protected ArrayList<Message> msgList = new ArrayList<>();
    protected ChatImRecyclerAdapter adapter;
    private ImageView chatAttch, chatEmoji;
    private MyEditText inputEditText;
    private ViewGroup moreLayout, emotionLayout;
    private TextView send;

    protected ChatModule chatModule;
    private int MSG_STEP_COUNT = 20;
    private SwipeRefreshLayout refreshLayout;
    private ImageView voice;
    protected AudioRecordButton recordBtn;
    private LocationManager locationManager;
    private String provider;
    private ImageView deleteSelectedMsgs;
    private ImageView editBackBtn;
    private boolean useInternalVideoRecord = true;
    private View chat_bg;

    protected ChatBottomMenuPagerAdapter pageMenuAdapter;

    protected ChatEmotionPagerAdapter pageEmotionMenuAdapter;
    private ExplosionField mExplosionField;

    public ChatModule getChatModule() {
        return chatModule;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (BaseActivity) context;
        mExplosionField = ExplosionField.attach2Window(activity);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        IntentFilter playEndIntentFiler = new IntentFilter();
        playEndIntentFiler.addAction("com.uluc.message.EVENT_VOICE_PLAY");
        LocalBroadcastManager.getInstance(activity).registerReceiver(playingBroadcastReceiver, playEndIntentFiler);
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.chat_im_layout;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        backBtn = bind(R.id.left_back);
        editBackBtn = bind(R.id.left_back_edit);
        editBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isEdit = false;
                refreshTitleBar(isEdit);
                adapter.setCancelEdit();
            }
        });
        headerImg = bind(R.id.header_img);
        title = bind(R.id.title);
        subtitle = bind(R.id.subtitle);
        saveContact = bind(R.id.save_contact);
        burningView = bind(R.id.private_lock);
        callPhone = bind(R.id.call_phone);
        chatDetails = bind(R.id.chat_details);
        deleteSelectedMsgs = bind(R.id.delete_selected_msg);
        recyclerView = bind(R.id.recycler_view);
        chat_bg = bind(R.id.chat_bg);
        goneView(burningView);
        //fix not flash issue.
        try {

            ((DefaultItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
        } catch (Exception e) {
            e.printStackTrace();
        }

        inputEditText = bind(R.id.input_edit_text);
        chatAttch = bind(R.id.chat_attch);
        chatEmoji = bind(R.id.chat_emoji);
        send = bind(R.id.send);
        voice = bind(R.id.voice);
        moreLayout = bind(R.id.more_layout);
        emotionLayout = bind(R.id.emoji_layout);
        refreshLayout = bind(R.id.swipe_refresh_layout);
        refreshLayout.setOnRefreshListener(this);//设置刷新监听

        recordBtn = bind(R.id.audio_record_btn);//录音按钮
        recordBtn.setAudioRecordFinishListener(new AudioRecordButton.AudioRecordFinishListener() {
            @Override
            public Message.Options onPreSendVoice() {
                Message.Options options = getMsgOption();
                if (burningModule) {
                    options.messageFlag = Message.MESSAGE_FLAG_BURNING;
                }
                return options;
            }

            @Override
            public void onRecognizeResult(String content) {
                inputEditText.setText(content);
            }

            @Override
            public void onFinish(float second, boolean recognise, String filePath) {
                if (!recognise && !com.ultralinked.voip.api.utils.FileUtils.isFileExist(filePath)) {
                    activity.showToast(R.string.chat_recording_voice_failed);
                    return;
                }
            }
        });

        goneView(headerImg);
        goneView(recordBtn);
        goneView(moreLayout);
        goneView(send);
        visibleView(chatAttch);
        visibleView(chatEmoji);
        visibleView(inputEditText);
        bottomMenu = bind(R.id.chat_menu_show_viewPage);// init the bottom menu for chat .
        iconPageIndicator = bind(R.id.chat_menu_show_pagerTab);


        bottomEmojiMenu = bind(R.id.emotion_show_viewPage);// init the bottom menu for chat .
        iconEmojiPageIndicator = bind(R.id.emotion_show_pagerTab);


        inputEditText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hiddenAllChatMenus();
                inputEditText.requestFocusFromTouch();
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);

                return false;
            }
        });
        inputEditText.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return false;
            }
        });


        inputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.i(TAG, "beforeTextChanged :" + s.toString());
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.i(TAG, "onTextChanged :" + s.toString() + ";start=" + start + ";before=" + before + ";count=" + count);
                if (chatType == Conversation.GROUP_CHAT && count == 1) {
                    CharSequence newContent = s.subSequence(start, start + count);
                    if ("@".equals(newContent.toString())) {
                        if (fromDraft) {//from the draft set. ignore it.
                            fromDraft = false;
                            return;
                        }
                        Bundle bundle = new Bundle();
                        bundle.putStringArrayList("linkedMembers", getLinkedUsersArrayList(false, null));
                        bundle.putString("group_id", ((GroupConversation) mConversation).getGroupID());
                        ChooseGroupMemberActivity.startForResult(BaseChatImFragment.this, ChooseGroupMemberActivity.REQUEST_AT_MEMBERS, bundle);
                    }
                    //check remove userIds if delete @ someone.
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (mConversation == null) {
                    return;
                }
                if (!mConversation.isGroup()) {
                    chatModule.sendComposing();
                    try {
                        if (s.toString().startsWith(":loc")){
                            sendgetLocationInfo();
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
                Log.i(TAG, "afterTextChanged :" + s.toString());
                if (s.length() > 0) {
                    if (send.getVisibility() == View.GONE) {
                        visibleView(send);
                        goneView(chatAttch);
                        // goneView(chatEmoji);
                    }
                } else {
                    goneView(send);
                    visibleView(chatAttch);
                    visibleView(chatEmoji);
                }
            }
        });


        initListener(this, subtitle, voice, chatAttch, chatEmoji, send, deleteSelectedMsgs);

    }

    long lastCheckLocationTime;
    private void sendgetLocationInfo() {
        long checkTime = System.currentTimeMillis();

        if (checkTime - lastCheckLocationTime < 3000){

            return;
        }
        lastCheckLocationTime = checkTime;

        LocationModel locationModel = new LocationModel();
        mConversation.sendCustomBroadcast(LocationModel.TYPE_LOCATION,locationModel.request());

    }


    private ArrayList<String> getLinkedUsersArrayList(boolean checkFilter, String filerName) {
        ArrayList<String> userIds = new ArrayList<>();
        for (LinkUserId userId : linkUserIds
                ) {
            if (checkFilter) {
                if (filerName.contains(userId.linkName)) {
                    userIds.add(userId.id);
                }
            } else {
                userIds.add(userId.id);
            }

        }
        return userIds;
    }

    private boolean hiddenAllChatMenus() {

        if (chatAttch.isSelected()) {
            displayChatMenu(false);
            chatAttch.setSelected(false);
            return true;
        }

        if (chatEmoji.isSelected()) {
            chatEmoji.setSelected(false);
            displayEmotionMenu(false);
            return true;
        }
        return false;
    }


    @Override
    public void initListener(View.OnClickListener listener, View... views) {
        super.initListener(listener, views);

    }


    private IconPageIndicator iconPageIndicator;
    private ViewPager bottomMenu;


    private IconPageIndicator iconEmojiPageIndicator;
    private ViewPager bottomEmojiMenu;


    // init bottom menu of menu adapter
    private void initChatEmotionMenuAdapter() {
        pageEmotionMenuAdapter = new ChatEmotionPagerAdapter(mContext,
                chatType, new ChatEmotionPagerAdapter.OnChildItemSelectId() {

            public void onClick(int whichButton, int resourceType,
                                int page, String resDesc) {

//                if (isVoiceRecording) {
//                    return;
//                }

                if (ChatEmotionPagerAdapter.TYPE_STICKER == resourceType) {
                    ImStickerMap stickerMap = ImStickerMap.getInstance(mContext);
                    Message msg = chatModule.sendSticker(stickerMap
                            .getStickerDesc(resDesc), getMsgOption());
                    return;
                }

                Editable editable = inputEditText.getEditableText();
                // int maxLength = getCurrentChatIMTextMaxTextLen();

//                if (editable.length() >= maxLength) {
//                    showMaxInput();
//                    return;
//                }
                int start = inputEditText.getSelectionStart();
//                if (start >= maxLength) {
//                    showMaxInput();
//                    return;
//                }
                int pageCount = ChatBottomMenuPagerAdapter.pageCount - 1;
                CharSequence emotionChar = ImEmotionMap
                        .getEmotionDesc(page * (pageCount + 1)
                                + whichButton);
//                if (editable.length() + emotionChar.length() >= maxLength) {
//                    showMaxInput();
//                    return;
//                }
                int tsize = (int) inputEditText.getTextSize();
                tsize = (int) (1.4f * tsize);
                int size = tsize + (tsize % 2 == 0 ? 0 : 1);
                inputEditText.setEditEmotionSize(size);
                SpannableString emotion = ImEmotionMap._dealEmotion(
                        emotionChar, size,
                        mContext);// new
                // SpannableString(emotionChar);//
                editable.insert(start, emotion);
                inputEditText.setSelection(start + emotion.length());

            }
        }, null);


        bottomEmojiMenu.setAdapter(pageEmotionMenuAdapter);

    }

    // init bottom menu of menu adapter
    private void initChatMenuAdapter() {
        pageMenuAdapter = new ChatBottomMenuPagerAdapter(mContext,
                chatType, null, new ChatBottomMenuPagerAdapter.OnGroupItemSelected() {

            @Override
            public void onClick(int whichButton) {
                // menu selected
                chooseOptionMenu(whichButton);
            }
        }, CallModel.getCallModel());


        bottomMenu.setAdapter(pageMenuAdapter);
    }


    private void goForward(Message msg) {
        Bundle data = new Bundle();
        data.putSerializable("message", msg);
        SelectMemberActivity.startForResult(this, SelectMemberActivity.REQUEST_FORWARD_MESSAGE, data);
    }

    protected void chooseOptionMenu(int whichType) {
        switch (whichType) {
            case ChatBottomMenuPagerAdapter.IMAGE:
                goGallery();
                break;
            case ChatBottomMenuPagerAdapter.VIDEO:
                goCamera();
                break;
            case ChatBottomMenuPagerAdapter.VCARD:
//                showToast("contacts");
                SelectMemberActivity.startForResult(this, SelectMemberActivity.REQUEST_SEND_VCARD);

                break;
            case ChatBottomMenuPagerAdapter.FILE:
                sendFileMessage();

                break;
            case ChatBottomMenuPagerAdapter.LOCATION:
                sendLocationMessage();
                break;
            case ChatBottomMenuPagerAdapter.VIDEO_CALL:
                makeCall(whichType);
                break;
            case ChatBottomMenuPagerAdapter.VOICE_CALL:
                makeCall(whichType);
                break;
            case ChatBottomMenuPagerAdapter.CALLBACK_CALL:
                // makeCall(whichType);
                displayCall(whichType);
                break;


        }
    }

    protected void displayCall(int whichType) {
        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(mConversation.getContactNumber());
        if (peopleEntity == null) {
            Log.i(TAG, "can not find the people info.");
            return;
        }
        CallDialog callDialog = CallDialog.getInstance(peopleEntity.mobile, null, peopleEntity.icon_url);
        callDialog.show(getActivity().getFragmentManager(), "call_dialog");
    }

    protected void makeCall(int whichType) {
        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(mConversation.getContactNumber());
        if (peopleEntity == null) {
            Log.i(TAG, "can not find the people info.");
            return;
        }
        String displayName = PeopleEntityQuery.getDisplayName(peopleEntity);
        CallDialog callDialog = CallDialog.getInstance(peopleEntity.mobile, displayName, peopleEntity.icon_url);

        Log.i("callfromChat", "call mobile:===" + peopleEntity.mobile + ";call name=" + displayName);
        callDialog.makeCall(getActivity(), peopleEntity.mobile, displayName, peopleEntity.icon_url, peopleEntity.subuser_id, whichType);
    }


    private void displayEmotionMenu(boolean showEmojiMenu) {
        if (pageEmotionMenuAdapter == null) {
            initChatEmotionMenuAdapter();
        } else {

        }


        if (showEmojiMenu) {

            ViewGroup.LayoutParams params = emotionLayout.getLayoutParams();
            if (chatType == Conversation.GROUP_CHAT) {
                params.height = getResources().getDimensionPixelSize(
                        R.dimen.px_200_0_dp);
            } else {
                params.height = getResources().getDimensionPixelSize(
                        R.dimen.px_200_0_dp);
            }
            emotionLayout.setLayoutParams(params);
            visibleView(emotionLayout);
            pageEmotionMenuAdapter.switchTo(0);// only show static emotion
            disableRecordVoiceBtn();
        } else {
            goneView(emotionLayout);
        }

        bottomEmojiMenu.setAdapter(pageEmotionMenuAdapter);

        // chatMessageEditText.requestFocus();
        if (showEmojiMenu) {

            iconEmojiPageIndicator.setVisibility(View.VISIBLE);
            iconEmojiPageIndicator.setViewPager(bottomEmojiMenu);
            iconEmojiPageIndicator.setCurrentItem(0);
        } else {
            iconEmojiPageIndicator.setVisibility(View.GONE);
        }
    }


    private void displayChatMenu(boolean showMenu) {
        if (pageMenuAdapter == null) {
            initChatMenuAdapter();
        } else {
            /*
             * pageAdapter.loadMenuLayout(); bottomMenu.setAdapter(pageAdapter);
			 */
        }


        if (showMenu) {

            ViewGroup.LayoutParams params = moreLayout.getLayoutParams();
            if (chatType == Conversation.GROUP_CHAT) {
                params.height = getResources().getDimensionPixelSize(
                        R.dimen.px_200_0_dp);
            } else {
                params.height = getResources().getDimensionPixelSize(
                        R.dimen.px_200_0_dp);
            }
            moreLayout.setLayoutParams(params);
            visibleView(moreLayout);
            pageMenuAdapter.loadMenuLayout();
            disableRecordVoiceBtn();
        } else {
            goneView(moreLayout);
//            if (pageEmotionMenuAdapter == null){
//
//            }
            // pageEmotionMenuAdapter.switchTo(0);// only show emotion
        }

        bottomMenu.setAdapter(pageMenuAdapter);

        // chatMessageEditText.requestFocus();
//        if (!showMenu) {
//
//            iconPageIndicator.setVisibility(View.VISIBLE);
//            iconPageIndicator.setViewPager(bottomMenu);
//            iconPageIndicator.setCurrentItem(0);
//        } else {
//            iconPageIndicator.setVisibility(View.GONE);
//        }
    }


    protected boolean bottomMenuIsExpand() {
        return moreLayout.getVisibility() == View.VISIBLE;
    }


    /**
     * 判断收到的消息是否定刚刚发送出去的消息，如果是则滑动到最底部
     *
     * @param addMsg
     * @return
     */
    private boolean isCurrentSendingMsg(@NonNull Message addMsg) {
        if (addMsg.isSender()) {
            int status = addMsg.getStatus();
            if (status == Message.STATUS_IN_PROGRESS) {
                return true;
            }
        }
        return false;
    }

    /**
     * 将消息列表滑动到最底部
     */
    private void scrollToBottom(boolean isFast) {
        if (adapter == null) {
            return;
        }
        int index = adapter.getItemCount() - 1;
        if (index >= 0) {
            if (isFast) {
                recyclerView.scrollToPosition(index);
            } else {
                recyclerView.smoothScrollToPosition(index);
            }

        }
    }

    /**
     * 消息点击事件
     *
     * @param itemView
     * @param pos
     */
    @Override
    public void onItemClick(View itemView, int pos) {
        closeInputMethod();
//        if (isEdit) {
//            return;
//        }
//        Message msg = msgList.get(pos);
//        chatModule.handleMessageClick(itemView,msg);
//        Log.i(TAG, "msg body:" + msg.getBody().toString());

    }

    @Override
    public void onResend(Message msg) {
        Log.i(TAG, "resend msg :" + msg.toString());
        MessageUtils.resendMsg(msg);
    }

    BurningFragment burningFragment;

    @Override
    public void onClickMessage(View itemView, final Message msg) {
        if (isEdit) {
            return;
        }
        Log.i(TAG, "onClickMessage~ msg:" + msg.toString() + " ;msg.isSender()" + msg.isSender());

        if (msg.getType() == Message.MESSAGE_TYPE_VOIP) {
            VoipCallMessage callMessage = (VoipCallMessage) msg;
            if (callMessage.callType == CallSession.TYPE_VIDEO) {
                makeCall(ChatBottomMenuPagerAdapter.VIDEO_CALL);
            } else {
                makeCall(ChatBottomMenuPagerAdapter.VOICE_CALL);
            }

        }
        chatModule.handleMessageClick(itemView, msg);


        if (msg.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
            boolean isBurning = false, isSender = msg.isSender();
            int msgType = msg.getType();


//            if ((msg instanceof  FileMessage) && com.ultralinked.uluc.enterprise.utils.FileUtils.isFileExist(((FileMessage)msg).getFilePath())){
//                if (!isSender)
//                isBurning = true;
//            }
//
//            if (Message.MESSAGE_TYPE_TEXT == msgType){
//
//                //ToastUtil.showToast(getContext(),((TextMessage)msg).getText(), Toast.LENGTH_LONG);
//                burningFragment = BurningFragment.getInstance(msg);
//
//                burningFragment.show(activity.getFragmentManager(),"burningFragment_dialog");
//
//
//            }
//
//            if (isBurning&&msg.getStatus()!= Message.STATUS_BURNING){
//                if (msg!=null){
//                    msg.burning_fire();
//                }
//
//            }

        }
    }


    @Override
    public void onMessageLongClick(View itemView, Message msg) {
        handleItemLongClick(itemView, msg);

    }


    @Override
    public void onLongClickUserHead(View itemView, Message msg) {

        String userId = msg.getSender();

        addAtLinkUser(userId);

    }

    private void addAtLinkUser(String userId) {

        Editable editable = inputEditText.getEditableText();
        int start = inputEditText.getSelectionStart();
        PeopleEntity entity = PeopleEntityQuery.getInstance().getByID(userId);

        if (entity != null) {

            CharSequence userName = ChatModule.formatLinkName(PeopleEntityQuery.getDisplayName(entity));
            LinkUserId linkUserId = new LinkUserId();
            linkUserId.id = userId;
            linkUserId.linkName = userName.toString();
            if (!linkUserIds.contains(linkUserId)) {
                linkUserIds.add(linkUserId);
            }

            editable.insert(start, userName);
            inputEditText.setSelection(start + userName.length());
        } else {
            Log.i(TAG, "the userId can not find the name:" + userId);
        }
    }

    @Override
    public void onClickUserHead(View itemView, Message msg) {
        String userId = msg.getSender();
        PeopleEntity entity = PeopleEntityQuery.getInstance().getByID(userId);

        if (entity != null) {
            DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
        }
    }

    private boolean isEdit;

    private void handleItemLongClick(View itemView, final Message msg) {
        if (isEdit) {
            return;
        }
        View contentView = itemView.findViewById(R.id.content);
        int pos = -1;
        if (contentView == null) {

            contentView = itemView;

            if (msg.getType() == Message.MESSAGE_TYPE_TEXT) {
                pos = Gravity.CENTER;
            }
        }

        int msgType = msg.getType();
        if (msgType == Message.MESSAGE_TYPE_TIPS ||
                msgType == Message.MESSAGE_TYPE_PUSH ||
                msgType == Message.MESSAGE_TYPE_UNKNOWN ||
                msgType == Message.MESSAGE_TYPE_EVENT ||
                msgType == Message.MESSAGE_TYPE_SYSTEM
                ) {
            return;
        }


        ActionMenu.build(activity, contentView, pos).addActions(ChatModule.createOptions(mContext, msg, mConversation)).setListener(new ActionMenu.ActionMenuListener() {
            @Override
            public void onAction(String action, int which) {
                if (action.equals(ChatModule.COPY)) {
                    if (msg instanceof TextMessage) {
                        chatModule.copyMsg(((TextMessage) msg).getText());
                    } else {
                        Log.i(TAG, "try to copy message but the type not text. msg type is :" + msg.getType());
                    }

                } else if (action.equals(ChatModule.FORWARD)) {
                    if (msg instanceof FileMessage) {
                        if (!FileUtils.isFileExist(((FileMessage) msg).getFilePath())) {
                            Log.i(TAG, "no need show file not exsit.");
                            return;
                        }
                    }
                    goForward(msg);
                } else if (action.equals(ChatModule.RESEND)) {
                    String chatId = mConversation.getContactNumber();
                    if (chatType == Conversation.GROUP_CHAT) {
                        chatId = ((GroupConversation) mConversation).getGroupID();
                    }
                    MessagingApi.forwordMsg(msg, chatId, chatType);
                } else if (action.equals(ChatModule.SHARE)) {
                    ShareUtils.shareMessage(getActivity(), msg);

                } else if (action.equals(ChatModule.DELETE)) {
                    updateMessageDelete(msgList.lastIndexOf(msg));
                } else if (action.equals(ChatModule.MORE)) {
                    isEdit = true;
                    refreshTitleBar(isEdit);
                    adapter.showCheckBoxForEdit();
                } else if (action.equals(ChatModule.TTS)) {
                    Intent mIntent = new Intent(getActivity(), TTSActivity.class);
                    mIntent.putExtra("text", ((TextMessage) msg).getText());
                    startActivity(mIntent);
                }

            }
        }).show();
//        DialogManager.showItemsDialog(activity, "", new String[]{activity.getString(R.string.delete), activity.getString(R.string.edit)}, itemView, new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Log.i(TAG, " position:" + position + "  conten:" + parent.getAdapter().getItem(position));
//
//                switch (position) {
//                    case 0:
//                        updateMessageDelete(msgList.lastIndexOf(msg));
//                        break;
//                    case 1:
//                        isEdit = true;
//                        refreshTitleBar(isEdit);
//                        adapter.showCheckBoxForEdit();
//                        break;
//                }
//
//
//            }
//        });


    }

    private void refreshTitleBar(boolean isEdit) {
        bind(R.id.edit_title_bar).setVisibility(isEdit ? View.VISIBLE : View.GONE);
        bind(R.id.chat_im_title_bar).setVisibility(isEdit ? View.GONE : View.VISIBLE);
        ArrayList<Message> deleteMsgs = adapter.getSelectedDeleteMsgs();
        if (deleteMsgs != null && deleteMsgs.size() > 0) {
            deleteMsgs.clear();
        }
    }

    @Override
    public void onItemLongClick(View itemView, int pos) {

        handleItemLongClick(itemView, msgList.get(pos));

    }

    /**
     * 消息下拉刷新回调
     */
    @Override
    public void onRefresh() {
        Log.i(TAG, "current is refreshing");
        refreshLayout.setRefreshing(true);
        Observable.create(new Observable.OnSubscribe<List<Message>>() {

            @Override
            public void call(Subscriber<? super List<Message>> subscriber) {

                int msgKeyId = msgList.isEmpty() ? -1 : msgList.get(0).getKeyId();
                String body = msgList.isEmpty() ? "" : msgList.get(0).getBody();

                List<Message> newList = mConversation.getMessageListWithFront(msgKeyId, MSG_STEP_COUNT);
                Log.i(TAG, "msgKeyId:" + msgKeyId + " msg body:" + body + " MSG_STEP_COUNT: " + MSG_STEP_COUNT + " getMsg count:" + newList.size() + " mConversation.getMsgCount(): " + mConversation.getMsgCount());
                //maybe repeat
                if (newList != null && newList.size() > 0 && newList.size() < 50) {
                    Iterator<Message> iterator = newList.iterator();
                    while (iterator.hasNext()) {
                        Message next = iterator.next();
                        MessageUtils.read(next, false);
                        boolean flag = msgList.contains(next);
                        if (flag) {
                            newList.remove(next);
                            Log.i(TAG, "remove the repeat msg." + next.toString());
                        }

                    }
                }


                subscriber.onNext(newList);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<List<Message>>() {
            @Override
            public void onCompleted() {
                Log.i(TAG, "refreshing completed.");
                refreshLayout.setRefreshing(false);
            }

            @Override
            public void onError(Throwable e) {
                Log.i(TAG, "refresh get more msg failed. " + e.toString());
                refreshLayout.setRefreshing(false);
            }

            @Override
            public void onNext(List<Message> messages) {
                updateAddMoreMessages(messages, true);
            }
        });


    }


    /**
     * 加载更多历史消息（用于上拉加载或下拉加载更多）
     *
     * @param addMsgs
     * @param isAddTop true:加到顶部，false：加到底部
     */
    private void updateAddMoreMessages(List<Message> addMsgs, boolean isAddTop) {

        if (addMsgs == null || addMsgs.isEmpty()) {
            return;
        }
        int index;
        if (isAddTop) {
            index = addMsgs.size();
            msgList.addAll(0, addMsgs);
            adapter.notifyDataSetChanged();
            layoutManager.scrollToPositionWithOffset(index - 1, 0);
            Log.i(TAG, "add messages to top. add count:" + addMsgs.size() + " scrollToPosition:" + index + " msg:" + msgList.get(index).getBody());
        } else {
            index = msgList.size();
            msgList.addAll(addMsgs);
            adapter.notifyDataSetChanged();
            Log.i(TAG, "add messages to bottom. add count:" + addMsgs.size() + " scrollToPosition:" + index + " msg:" + msgList.get(index).getBody());
        }


    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBundle(Constants.DATA_KEY, getArguments());

    }

    boolean fromDraft = false;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        Bundle bundle = null;
        if (savedInstanceState != null) {
            bundle = savedInstanceState.getBundle(Constants.DATA_KEY);
            Log.i(TAG, "get bundle from savedInstanceState, the bundle is:" + bundle);
        } else {
            bundle = getArguments();
        }
        if (bundle == null) {
            Log.e(TAG, "bundle is null");
            return view;
        }

        chatType = bundle.getInt(Constants.CHAT_TYPE_KEY);
        isPrivate = bundle.getInt(Constants.CHAT_FLAG, Conversation.CONVERSATION_FLAG_NONE) == Conversation.CONVERSATION_FLAG_PRIVATE;
        String chatIdentity = "";
        if (chatType == Conversation.SINGLE_CHAT) {
            chatIdentity = bundle.getString(Constants.PHONE_NUMBER_KEY);
            mConversation = MessagingApi.getConversation(chatIdentity);
        } else {
            chatIdentity = bundle.getString(Constants.GROUPKD_KEY);
            mConversation = GroupConversation.getConversationByGroupId(chatIdentity);
        }

        if (mConversation == null) {// 在子类中finish
            Log.i(TAG, "mConversation is null. chatIdentity:" + chatIdentity + " chatType:" + chatType);
            return view;

        }
        Log.i(TAG, "conversation id:~~~~" + mConversation.getConversationId() + " isgroup:" + mConversation.isGroup() + "  conversation:" + mConversation.toString());

        chatModule = new ChatModule(mConversation, activity);

        registerObservers();
        loadChatSkin();

        layoutManager = new WrapContentLinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        //       layoutManager.setStackFromEnd(true);
//        layoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(layoutManager);

        try {
            recyclerView.setItemAnimator(msgAnimator = new MyRecyclerItemAnimator());
        } catch (Exception e) {
            e.printStackTrace();
        }

        adapter = new ChatImRecyclerAdapter(activity, msgList, mConversation.isGroup());
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(this);// 改用setOnMessageResendClickListener
        adapter.setOnItemLongClickListener(this);//设置消息的长按监听
        adapter.setOnMessageResendClickListener(this);


        String draft = mConversation.getDraft();
        if (!TextUtils.isEmpty(draft)) {
            int tsize = (int) inputEditText.getTextSize();
            tsize = (int) (1.4f * tsize);
            int size = tsize + (tsize % 2 == 0 ? 0 : 1);
            SpannableString content = ImEmotionMap.genSpanString(draft, size);
            fromDraft = true;
            inputEditText.setText(content);
            inputEditText.setSelection(content.length());
        }

        initData();

        //check is need cancel notification about this chat
        MsgNotificationUtils.cancelNotificatonByConversaton(mConversation);

        return view;
    }

    private Subscription rxSkinChangeSubscription;

    private void registerObservers() {
        rxSkinChangeSubscription = RxBus.getDefault().toObservable(String.class)
                .subscribe(new Action1<String>() {
                               @Override
                               public void call(String info) {
                                   Log.i(TAG, "update the skin~~~~" + info);
                                   loadChatSkin();

                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG, "update the subscribe error:" + android.util.Log.getStackTraceString(throwable));
                            }
                        });
    }

    private void loadChatSkin() {

        String skinfilePath = ChatModule.getChatBackgroudTheme(mConversation);
        if (FileUtils.isFileExist(skinfilePath)) {
            ImageUtils.loadImageByString(getActivity(), (ImageView) chat_bg, skinfilePath, -1);
        } else {
            ((ImageView) chat_bg).setImageDrawable(null);
            ((ImageView) chat_bg).setImageBitmap(null);
        }

    }

    protected void initData() {
        if (mConversation.getMsgCount() > 0) {

            Observable.create(new Observable.OnSubscribe<List<Message>>() {

                @Override
                public void call(Subscriber<? super List<Message>> subscriber) {

                    List<Message> messages = mConversation.getPrevMessageList(-1, MSG_STEP_COUNT);
                    Log.i(TAG, "init msg . MSG_STEP_COUNT:" + MSG_STEP_COUNT + " getmsg size:" + messages.size());
                    if (messages.isEmpty()) {
                        //no messages found.
                        Message message = MessageUtils.insertSecurityTips(mConversation);
                        if (message != null) {
                            messages.add(message);
                        }

                    }
                    subscriber.onNext(messages);


                    if (mConversation.getUnReadMsgCount() > 0) {
                        mConversation.read();//将所有消息置为已读
                        Log.i(TAG, " read all message. conversationId: " + mConversation.toString());
                    }
                    for (Message itemData : messages) {
                        Log.i(TAG, "msgKeyID:" + itemData.getKeyId() + "  body:" + itemData.getBody());
                        MessageUtils.read(itemData, false);
//                        Log.i(TAG, "is sender :" + itemData.isSender() + " msgKeyId:" + itemData.getKeyId() + " sendName:" + itemData.getSenderName() + " receiverName:" + itemData.getReceiver() + " body:" + itemData.getBody());
                    }


                }
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<List<Message>>() {
                @Override
                public void call(List<Message> messages) {
                    msgList.addAll(messages);
                    adapter.notifyDataSetChanged();
                    scrollToBottom(true);
                }
            });

        } else {

            //no messages found.
            Message message = MessageUtils.insertSecurityTips(mConversation);
            if (message != null) {
                msgList.add(message);
                adapter.notifyDataSetChanged();
            }


        }

    }

    @Override
    public void onResume() {
        super.onResume();
        lifeStatus = Status.onResume;
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        if (mConversation != null) {
            App.getInstance().setCurrentChatId(mConversation.getConversationId());
        }

        visibleView(subtitle);
        if (!MLoginApi.isLogin() && !MLoginApi.isConnecting) {
            subtitle.setVisibility(View.VISIBLE);
            boolean networkStatus = NetUtil.isNetworkAvailable(getActivity());
            if (!networkStatus) {
                subtitle.setText(R.string.no_network);
            } else {
                LoginPresenter.checkLoginStatus();
                subtitle.setVisibility(View.GONE);
            }
            Log.i(TAG, "MLoginApi status: Disconnected");
        } else {
            subtitle.setVisibility(View.GONE);
            //subtitle.setText("Connected");
            Log.i(TAG, "MLoginApi status: Connected");
        }
        IntentFilter playEndIntentFiler = new IntentFilter();
        playEndIntentFiler.addAction("com.uluc.message.EVENT_VOICE_PLAY");
        LocalBroadcastManager.getInstance(activity).registerReceiver(playingBroadcastReceiver, playEndIntentFiler);


        //mark reset
        readUnreadMsg();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        lifeStatus = Status.onDestory;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (rxSkinChangeSubscription != null && !rxSkinChangeSubscription.isUnsubscribed()) {
            rxSkinChangeSubscription.unsubscribe();
        }

        saveDraft();
        closeInputMethod();
        if (pageMenuAdapter != null) {
            pageMenuAdapter.releaseResource();
        }

        if (pageEmotionMenuAdapter != null) {
            pageEmotionMenuAdapter.releaseResource();
        }

        LocalBroadcastManager.getInstance(activity).unregisterReceiver(playingBroadcastReceiver);

    }

    private void saveDraft() {
        String draft = inputEditText.getText().toString();
        if (mConversation != null) {
            if (TextUtils.isEmpty(draft)) {
                if (!TextUtils.isEmpty(mConversation.getDraft())) {
                    mConversation.removeDraft();
                    RxBus.getDefault().post(mConversation);
                    Log.i(TAG, "remove draft");
                }


            } else if (!TextUtils.isEmpty(draft)) {
                mConversation.saveDraft(draft);
                RxBus.getDefault().post(mConversation);
                Log.i(TAG, "save draft:" + draft);
            }
        }
    }

    /**
     * 返回键的监听，事件由BaseChatImActivity传递过来
     */
    public void onBackPressed() {
        if (isEdit) {
            isEdit = false;
            refreshTitleBar(isEdit);
            adapter.setCancelEdit();

        } else {
            if (getActivity().isTaskRoot()) {
                // go to main
                Intent mIntent = new Intent(getActivity(), MainActivity.class);
                mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(mIntent);
                if (getActivity() != null) {
                    getActivity().finish();
                }
            } else {
                if (getActivity() != null) {
                    getActivity().finish();
                }
            }

        }

    }

    /**
     * 初始化会话对象
     *
     * @param mIntent
     */
    protected void initConversation(Intent mIntent, Conversation mConversation) {

    }

    /**
     * 共同的广播，交给子类调用
     */
    protected void registerBroadCastReceiver() {
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(deleteMessageReceiver, new IntentFilter(EVENT_MESSAGE_DELETED));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MLoginStatusChangedReceiver, new IntentFilter(MLoginApi.EVENT_LOGIN_STATUS_CHANGE));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MsgStatusChangedReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_STATUS_CHANGED));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MsgIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_INCOMING));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(FileTransferProgressReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_PROGRESS_CHANGED));//消息发送进度广播
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(composingReceiver, new IntentFilter(MessagingApi.EVENT_COMPOSING));


    }

    protected void unregisterBroadCastReceiver() {
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(deleteMessageReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MLoginStatusChangedReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MsgStatusChangedReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MsgIncomingReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(FileTransferProgressReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(composingReceiver);

    }

    /**
     * 检查收到的消息是否属于当前会话
     *
     * @param msg
     * @return
     */
    protected boolean isCurrentConversationMsg(Message msg) {
        if (chatModule == null) {
            Log.i(TAG, " current chatModule is null. mConversation:" + mConversation);
            return false;
        }
        return chatModule.checkIsCurrentConversationMsg(msg);
    }

    protected boolean isCurrentConversationMsg(String chatIdentity) {
        if (chatModule == null) {
            Log.i(TAG, " current chatModule is null. mConversation:" + mConversation);
            return false;
        }
        return chatModule.checkIsCurrentConversationMsg(chatIdentity);
    }

    public enum Status {
        onResume, onPause, onStop, onDestory
    }

    @Override
    public void onPause() {
        super.onPause();
        lifeStatus = Status.onPause;
    }



    public Status lifeStatus = Status.onResume;// default

    private BroadcastReceiver MLoginStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                int loginStatus = intent.getIntExtra(MLoginApi.PARAM_LOGIN_STATUS, -1);
                Log.i(TAG, "MLoginStatusChangedReceiver~~ status:" + loginStatus);
                subtitle.setVisibility(View.GONE);
                switch (loginStatus) {
                    case MLoginApi.STATUS_CONNECTING:
                        subtitle.setVisibility(View.VISIBLE);
                        subtitle.setText("Connecting");
                        break;
                    case MLoginApi.STATUS_DISCONNECTED:
                        subtitle.setVisibility(View.VISIBLE);
                        boolean networkStatus = NetUtil.isNetworkAvailable(getActivity());
                        if (!networkStatus) {
                            subtitle.setText("You are disconnected");
                        } else {
                            subtitle.setVisibility(View.GONE);
                        }

                        break;
                    case MLoginApi.STATUS_RECONNECT:
                        //subtitle.setText("reconnect");
                        break;
                    case MLoginApi.STATUS_REGISTER_ACCOUNT_ERROR:
                        subtitle.setText("register_account_error");
                        break;
                    case MLoginApi.STATUS_REGISTER_OK:
                        subtitle.setText("");
                        break;
                    case MLoginApi.STATUS_SERVER_FORCE_LOGOUT:
                        subtitle.setVisibility(View.VISIBLE);
                        subtitle.setText("server_force_logout");
                        break;
                    case MLoginApi.STATUS_USER_LOGOUT:
                        subtitle.setVisibility(View.VISIBLE);
                        subtitle.setText("");
                        break;
                    default:
                        subtitle.setText("unknown status");

                }
            }
        }
    };

    private BroadcastReceiver composingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean isComposing = intent.getBooleanExtra(MessagingApi.PARAM_COMPOSING_STATUS, false);
            String formTo = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            int chatType = intent.getIntExtra(MessagingApi.PARAM_CHAT_TYPE, -1);
            String chatId = intent.getStringExtra(MessagingApi.PARAM_CHAT_ID);
            Log.i(TAG, "composingReceiver~~ isComposing:" + isComposing + " fromTo:" + formTo + " chatTYpe:" + (chatType == Message.CHAT_TYPE_GROUP ? "group" : "single") + " chatId:" + chatId);


            if (isCurrentConversationMsg(formTo)) {
                Log.i(TAG, " receiver composing~~ iscomposing:" + isComposing);
                ComposMessage composMsg = new ComposMessage();
                composMsg.setComposing(isComposing);
                composMsg.setSender(formTo);
                if (isComposing) {

                    if (!msgList.contains(composMsg)) {
                        updateReceiveNewMessage(composMsg);
                        Log.i(TAG, "add composing msg.");
                    } else {
                        Log.i(TAG, "current has add composing msg.");
                    }
                } else {
                    if (msgList.contains(composMsg)) {
                        boolean removed = msgList.remove(composMsg);
                        if (removed) {
                            adapter.notifyDataSetChanged();
                            Log.i(TAG, "remove composing msg succeed.");
                        } else {
                            Log.i(TAG, "remove composing msg failed.");
                        }

                    } else {
                        Log.i(TAG, "composing msg not exists.");
                    }
                }

            } else {
                Log.i(TAG, "not is current conversation.");
            }
        }
    };

    private BroadcastReceiver MsgIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

                if (msg == null) {
                    Log.i(TAG, "incoming msg is null ");
                    return;
                }
                Log.i(TAG, "MsgIncomingReceiver~~ msgKeyId:" + msg.getKeyId() + " status:" + ChatModule.convertMsgStatus2String(msg) + " msg:" + msg.toString());
                boolean flag = isCurrentConversationMsg(msg);
                if (flag) {
                    Log.i(TAG, "new msgStatus: " + msg.getStatus());
                    if (lifeStatus == Status.onResume){
                        handleReceiveNewMessage(msg);
                    }else {
                        addUnreadMsgToList(msg);
                    }

                } else {
                    Log.i(TAG, "not is belong to current Conversation.");
                    if (isResumed()) {
                        //fix issue
                    }
                }

            }

        }
    };

    List<Message> unreadMsgList = new ArrayList<>();
    private void addUnreadMsgToList(Message message){
        Log.i(TAG, "addUnreadMsgToList new msg: " + message.getKeyId());
        unreadMsgList.add(message);
    }

    public  void readUnreadMsg(){
        if (!unreadMsgList.isEmpty()){

            for (Message msg:unreadMsgList
                 ) {
                handleReceiveNewMessage(msg);
            }
            unreadMsgList.clear();
            //mConversation.read();
        }
    }


    private BroadcastReceiver deleteMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);
                if (msg == null) {
                    Log.i(TAG, "status change msg is null ");
                    return;
                }
                boolean flag = isCurrentConversationMsg(msg);
                if (flag) {
                    Log.i(TAG, "delete msgKeyId:" + msg.getKeyId() + "  msgStatus: " + msg.getStatus() + "  " + ChatModule.convertMsgStatus2String(msg));

                    int index = msgList.indexOf(msg);
                    try {
                        msgList.remove(msg);//do not use the remove.
                        if (index >= 0) {
                            adapter.notifyItemRemoved(index);
                        } else {
                            adapter.notifyDataSetChanged();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                } else {

                }

            }

        }
    };


    private BroadcastReceiver MsgStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("MsgStatusChangedReceiver", ((Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE)).getReceiver());
            Log.e("MsgStatusChangedReceiver", ((Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE)).getSender());
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);
                if (msg == null) {
                    Log.i(TAG, "status change msg is null ");
                    return;
                }
                boolean flag = isCurrentConversationMsg(msg);
                if (flag) {
                    Log.i(TAG, "msgKeyId:" + msg.getKeyId() + "  msgStatus: " + msg.getStatus() + "  " + ChatModule.convertMsgStatus2String(msg));
                    handleMsgStatusChange(msg);

                } else {

                }

            }

        }
    };

    private BroadcastReceiver FileTransferProgressReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);
                if (msg == null) {
                    Log.i(TAG, "the file message is null.");
                    return;
                }
                if (!(msg instanceof FileMessage)) {
                    Log.i(TAG, " not is File message.");
                    return;
                }
                FileMessage fMsg = (FileMessage) msg;


                boolean flag = isCurrentConversationMsg(msg);
                if (flag) {
                    handleFileMsgProgressChange(fMsg);

                } else {
                    Log.i(TAG, "not is belong to current Conversation.");
                }

            }

        }
    };

    private void handleReceiveNewMessage(final Message newMsg) {
        Observable.create(new Observable.OnSubscribe<Message>() {
            @Override
            public void call(Subscriber<? super Message> subscriber) {
                if (!newMsg.isSender()) {
                    MessageUtils.read(newMsg, false);
                }
                if (!chatModule.checkMsgHasAdded(newMsg, msgList)) {
                    subscriber.onNext(newMsg);
                } else {
                    Log.i(TAG, "the msg has added to msgList. msgKeyId:" + newMsg.getKeyId());
                }

            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Message>() {
            @Override
            public void call(Message msg) {
                Log.i(TAG, "add received msg. msgKeyId:" + msg.getKeyId());
                updateReceiveNewMessage(msg);

            }
        });
    }

    private void handleMsgStatusChange(Message newMsg) {

        int index = msgList.lastIndexOf(newMsg);
        if (index != -1) {
            updateMessageStatusChange(newMsg, index);
        } else {
            adapter.notifyDataSetChanged();
            Log.i(TAG, "not fond message in msgList. msgKeyId:" + newMsg.getKeyId());
        }


    }

    /**
     * 处理文件类消息传输进度的变更
     *
     * @param fMsg
     */
    private void handleFileMsgProgressChange(final FileMessage fMsg) {
        Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> subscriber) {
                int curSize = fMsg.getFileCurSize();
                int totalSize = fMsg.getTotalFileSize();
                int present = fMsg.getTotalFileSize() == 0 ? 0 : (int) (1f * curSize / totalSize * 100);
                Log.i(TAG, "FileTransferProgressReceiver~~ msgKeyId:" + fMsg.getKeyId() + "  curSize:" + curSize + "totalSize:" + totalSize + " present:" + present + "%" + "  status:" + ChatModule.convertMsgStatus2String(fMsg));

                int index = msgList.lastIndexOf(fMsg);
                if (index != -1) {
                    subscriber.onNext(index);
                } else {
                    Log.i(TAG, "not fond message in msgList. msgKeyId:" + fMsg.getKeyId());
                }


            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Integer>() {
            @Override
            public void call(Integer index) {
                updateMessageStatusChange(fMsg, index);
            }
        });
    }

    /**
     * 更新新收到的消息到界面
     *
     * @param msg
     */
    private void updateReceiveNewMessage(Message msg) {
        if (msgList.contains(msg)) {
            Log.i(TAG, "the msg has added, msg:" + msg.toString());
            return;
        }
        boolean isCurrentStopBottom = true;
        int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();
        isCurrentStopBottom = lastVisibleItemPosition == msgList.size() - 1;

        if (msgList.size() > 0 && msgList.get(msgList.size() - 1) instanceof ComposMessage) {

            msgList.remove(msgList.size() - 1);
//            adapter.notifyItemRemoved(msgList.size() - 1);
            adapter.notifyDataSetChanged();
        }

        msgList.add(msg);
        int insertIndex = msgList.lastIndexOf(msg);
        if (insertIndex != -1) {

            adapter.notifyItemInserted(insertIndex);
            Log.i(TAG, "~~~~~~~~~ isCurrentStopBottom:" + isCurrentStopBottom + " isCurrentSendingMsg(msg)" + isCurrentSendingMsg(msg));
            if (isCurrentStopBottom || msg.isSender()) {
                scrollToBottom(true);

            }
        } else {
            adapter.notifyDataSetChanged();
            Log.i(TAG, "insert Msg failed.");
        }
    }


    /**
     * 跟新状态变化的消息
     *
     * @param msg
     */
    private void updateMessageStatusChange(final Message msg, final int index) {
        if (msg.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {


            if (msg.getStatus() == Message.STATUS_READ && !MessageUtils.hasStartBurning(msg)) {//no burning_fire begin.
                //do burning_fire first.
                MessageUtils.burning(msg);
                return;

            }

            boolean burning = MessageUtils.checkBruningEnd(msg, true);

            if (burning) {
                if (index < 0) {
                    return;
                }
                try {
                    RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForAdapterPosition(index);
                    if (viewHolder != null && viewHolder instanceof MsgViewHolder) {
                        MsgViewHolder burningMsgViewHolder = (MsgViewHolder) viewHolder;
                        mExplosionField.explode(burningMsgViewHolder.bruningView);

                    }

                    msgList.remove(index);//do not use the remove.
                    adapter.notifyItemRemoved(index);

                } catch (Exception e) {
                    Log.i(TAG, "maybe index of range:" + android.util.Log.getStackTraceString(e));
                }

            } else {

                try {
                    msgList.set(index, msg);
                    adapter.notifyItemChanged(index);

                } catch (Exception e) {
                    Log.i(TAG, "maybe index of range:" + android.util.Log.getStackTraceString(e));
                }
            }


        } else {
            try {

                if (!msgAnimator.isAddRunning) {
                    msgList.set(index, msg);
                    adapter.notifyItemChanged(index);
                } else {
                    Log.i(TAG, "is Running animate , just wait.");
                    msgAnimator.isRunning(new RecyclerView.ItemAnimator.ItemAnimatorFinishedListener() {
                        @Override
                        public void onAnimationsFinished() {
                            Log.i(TAG, "is Running animate end , msgAnimator.isAddRunning=" + msgAnimator.isAddRunning);
                            if (!msgAnimator.isAddRunning) {
                                msgList.set(index, msg);
                                adapter.notifyItemChanged(index);
                            }
                        }
                    });

                }

            } catch (Exception e) {
                Log.i(TAG, "maybe index of range:" + android.util.Log.getStackTraceString(e));
            }

        }
//        adapter.notifyDataSetChanged();// 更新时整个布局会闪速、移动
        Log.i(TAG, "notifyItemChanged  status change:" + ChatModule.convertMsgStatus2String(msg) + "  msgKeyId:" + msg.getKeyId() + " msg:" + msg.toString());
    }

    private void updateMessageDelete(int index) {
        if (index < 0) {
            return;
        }
        updateMessageDelete(new int[]{index});
    }

    /**
     * 消息删除更新
     *
     * @param indexs
     */
    private void updateMessageDelete(int[] indexs) {
        if (indexs == null || indexs.length == 0) {
            return;
        }
        int[] keyIds = new int[indexs.length];
        for (int i = 0; i < indexs.length; i++) {
            keyIds[i] = msgList.get(indexs[i]).getKeyId();
        }
        for (int i = 0; i < indexs.length; i++) {
            msgList.remove(indexs[i]);
            adapter.notifyItemRemoved(indexs[i]);
            Log.i(TAG, "notify remove msg:" + indexs[i]);

            mConversation.deleteMessage(keyIds[i]);
        }
//        mConversation.deleteMutipleMessage(keyIds);
    }

    private void openInputMethod() {
//        inputEditText.requestFocus();
//        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
//        boolean flag =  imm.showSoftInput(inputEditText,InputMethodManager.SHOW_FORCED);
//
//        Log.i(TAG,"open input method. isSucced:");

//        displayChatMenu(false);
//        chatAttch.setSelected(false);
//        chatEmoji.setSelected(false);
        inputEditText.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(inputEditText, InputMethodManager.SHOW_IMPLICIT);
                inputEditText.requestFocus();
                inputEditText.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_DOWN, 0, 0, 0));

            }
        }, 100);


    }

    private void closeInputMethod() {

        // hide input method and emotion mothod
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        // switch input status
        if (inputMethodManager.isActive()) {
            try {
                inputMethodManager.hideSoftInputFromWindow(activity
                                .getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            } catch (Exception e) {
                inputMethodManager.toggleSoftInput(
                        InputMethodManager.SHOW_IMPLICIT,
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }

    }

    private boolean isInputMethodOpened() {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        Log.i(TAG, "input method. isActive:" + imm.isActive());
        return imm.isActive();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.subtitle:
                if (!MLoginApi.isLogin() && !MLoginApi.isConnecting) {
                    LoginPresenter.reLogin();
                    subtitle.setText(R.string._chat_loading);
                    Log.i(TAG, "click to reLogin.");
                }

                break;

            case R.id.delete_selected_msg:
                Log.i(TAG, "deleted selected msgs");
                ArrayList<Message> deleteMsgs = adapter.getSelectedDeleteMsgs();

                int msgKeyIds[] = new int[deleteMsgs.size()];
                for (int i = 0; i < deleteMsgs.size(); i++) {
                    msgKeyIds[i] = deleteMsgs.get(i).getKeyId();

                }
                if (msgKeyIds.length > 0) {
                    mConversation.deleteMutipleMessage(msgKeyIds);
                }

                boolean flag = msgList.removeAll(deleteMsgs);
                Log.i(TAG, "delete msg is succeed:" + flag);

                isEdit = false;
                refreshTitleBar(isEdit);
                adapter.setCancelEdit();


                break;
            case R.id.voice:
                boolean voiceGranted = activity.checkPermission("voice", -1);
                if (voiceGranted) {

                    recordVoice();

                } else {
                    Log.i(TAG, "has no voice permission:");
                }

                break;

            case R.id.send://send text message
                sendTextMessage();

                break;

            case R.id.chat_attch:
                chatAttch.setSelected(!chatAttch.isSelected());
                if (chatEmoji.isSelected()) {
                    try {
                        Animation lastAnimation = emotionLayout.getAnimation();
                        if (lastAnimation != null) {
                            lastAnimation.cancel();
                        }
                        emotionLayout.clearAnimation();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                displayChatMenu(chatAttch.isSelected());
                chatEmoji.setSelected(false);
                visibleView(chatEmoji);
                displayEmotionMenu(false);
                if (chatAttch.isSelected()) {
                    voice.setImageResource(R.drawable.voice_bg_selector);
                    closeInputMethod();
                    Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.up_tran);
                    animation.setDuration(180);
                    moreLayout.startAnimation(animation);
                } else {
                    openInputMethod();
                }

                break;
            case R.id.chat_emoji:
                chatEmoji.setSelected(!chatEmoji.isSelected());
                if (chatEmoji.isSelected()) {
                    try {
                        Animation lastAnimation = moreLayout.getAnimation();
                        if (lastAnimation != null) {
                            lastAnimation.cancel();
                        }
                        moreLayout.clearAnimation();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                displayEmotionMenu(chatEmoji.isSelected());
                chatAttch.setSelected(false);
                displayChatMenu(false);
                if (chatEmoji.isSelected()) {
                    voice.setImageResource(R.drawable.voice_bg_selector);
                    closeInputMethod();
                    Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.up_tran);
                    animation.setDuration(180);
                    emotionLayout.startAnimation(animation);
                } else {
                    openInputMethod();
                }
                break;

            case R.id.left_back:
                if (getActivity().isTaskRoot()) {
                    // go to main
                    Intent mIntent = new Intent(getActivity(), MainActivity.class);
                    mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(mIntent);

                } else {

                }
                getActivity().finish();

                break;

        }
    }

    private void sendFileMessage() {
        boolean granted = activity.checkPermission("file", REQUEST_FILE_PERMISSION_CODE);
        if (granted) {
            selectFileAndSend();
        } else {
            Log.i(TAG, "has no permission:" + Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
    }

    private void sendLocationMessage() {
        boolean locationGranted = activity.checkPermission("location", REQUEST_LOCATION_PERMISSION_CODE);
        if (locationGranted) {
            MapActivity.launchActivityForResult(activity, REQUEST_CODE_FOR_LAST_LOCATION);
//            getCurrentLocation();

        } else {
            Log.i(TAG, "has no permission:" + Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void recordVoice() {
        voice.setSelected(!voice.isSelected());
        Log.i(TAG, "recoverbtn status:" + voice.isSelected() + " inputMethod isOpened:" + isInputMethodOpened());
        if (voice.isSelected()) {
            inputEditText.clearFocus();
            goneView(chatEmoji);
            goneView(inputEditText);
            visibleView(recordBtn);
            chatAttch.setSelected(false);
            chatEmoji.setSelected(false);
            voice.setImageResource(R.drawable.selector_chat_keybord);
        } else {
            visibleView(chatEmoji);
            disableRecordVoiceBtn();
            chatAttch.setSelected(false);
            chatEmoji.setSelected(false);
            voice.setImageResource(R.drawable.voice_bg_selector);
            openInputMethod();
            //showkeypad.
        }
        displayChatMenu(false);
        displayEmotionMenu(false);
    }

    private void disableRecordVoiceBtn() {
        goneView(recordBtn);
        visibleView(inputEditText);
        voice.setSelected(false);
    }


    private boolean test = false;

    /**
     * 点击发送按钮发送文本消息
     */
    ArrayList<LinkUserId> linkUserIds = new ArrayList<>();

    private void sendTextMessage() {
//        closeInputMethod();
        if (test) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (int i = 0; i < 200; i++) {
                        try {
                            Thread.sleep(500);
                            Message sendMsg = chatModule.sendText("test send message ,current index is " + i, null);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }
            }).start();
            return;
        }

        final String sendText = inputEditText.getText().toString();
        inputEditText.setText("");

        if (!TextUtils.isEmpty(sendText)) {
            Log.i(TAG, "send text msg:" + sendText);
            Message.Options options = getMsgOption();//create new optin.

            if (burningModule) {
                options.messageFlag = Message.MESSAGE_FLAG_BURNING;
            }

            ArrayList<String> linkIds = getLinkedUsersArrayList(true, sendText);
            if (linkIds.size() > 0) {

                //check remove userIds if delete @ someone.
                options.linkUserIds = linkIds;

            }
            Message sendMsg = null;
            if (isAssistant) {
                sendMsg = chatModule.sendTextByAsistant(sendText, options);
            } else {
                sendMsg = chatModule.sendText(sendText, options);
            }
            linkUserIds.clear();
            if (sendMsg == null) {
                Log.i(TAG, "the send text msg is null, is login:" + MLoginApi.isLogin());
            } else {
                Log.d(TAG, "sendMsg: " + sendMsg.toString());
            }
        } else {
            showToast(activity.getString(R.string.input_empty_msg_tips));
        }
    }

    private void sendImage(String path) {
        Message.Options options = getMsgOption();
        if (burningModule) {
            options.messageFlag = Message.MESSAGE_FLAG_BURNING;
        }
        mConversation.sendImage(path, options);
    }

    private void showLocation(Location location) {
        Log.i(TAG, "current location,  Latitude:" + location.getLatitude() + " Longitude:" + location.getLongitude());
        HashMap<String, String> map = new HashMap<>();
        map.put("longitude", location.getLongitude() + "");
        map.put("latitude", location.getLatitude() + "");
        chatModule.sendLocation(map, getMsgOption());

        activity.startActivity(new Intent(activity, MapActivity.class));
    }

    /**
     * 选择文件并发送
     */
    private void selectFileAndSend() {
        String mimeType = "*/*";
        String selectTile = "Select file";
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(mimeType);
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // special intent for Samsung file manager
        Intent samsungIntent = new Intent("com.sec.android.app.myfiles.PICK_DATA");
        samsungIntent.putExtra("CONTENT_TYPE", mimeType);

        Intent chooserIntent;
        if (activity.getPackageManager().resolveActivity(samsungIntent, 0) != null) {
            chooserIntent = Intent.createChooser(samsungIntent, selectTile);
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{intent});
        } else {
            chooserIntent = Intent.createChooser(intent, selectTile);
        }

        if (chooserIntent != null) {
            try {
                startActivityForResult(chooserIntent, REQUEST_CODE_CHOOSE_FILE);
            } catch (android.content.ActivityNotFoundException ex) {
                ex.printStackTrace();
                Log.i(TAG, "select file not found support ");
            }
        }

    }


    private void goCamera() {

        DialogManager.showItemsDialog(activity, "", new String[]{mContext.getString(R.string.recording_video), mContext.getString(R.string.choose_video)}, null, new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {

                    recordVideo();


                } else {
                    chooseVideo();
                }

            }
        });


    }

    private void chooseVideo() {
        Intent intent = new Intent();
        intent.setType("video/*");
        //选择视频 （mp4 3gp 是android支持的视频格式）
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        startActivityForResult(intent, REQUEST_CODE_FOR_CHOOSE_VIDEO);
    }

    /**
     * 录制视频
     */
    private void recordVideo() {

        if (useInternalVideoRecord) {

            boolean granted = activity.checkPermission("video", -1);
            if (granted) {
                Intent getVideoIntent = new Intent(activity, VideoRecoderActivity.class);
                activity.startActivityForResult(getVideoIntent, REQUEST_CODE_FOR_RECORD_VIDEO);
            } else {
                Log.i(TAG, "has no permission:" + Manifest.permission.CAMERA);
            }

            return;
        }
        Intent intent = new Intent();
        intent.setAction(MediaStore.ACTION_VIDEO_CAPTURE);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
        intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, 1024 * 1024 * 20);
        startActivityForResult(intent, REQUEST_CODE_FOR_RECORD_VIDEO);

    }

    private void goGallery() {

        boolean granted = activity.checkPermission("file", REQUEST_FILE_PERMISSION_CODE);
        if (granted) {
            GalleryFinal.openGalleryMuti(REQUEST_CODE_GALLERY, 10, mOnHandlerResultCallback);
        } else {
            Log.i(TAG, "has no permission:" + Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }


    }

    /**
     * 请求权限的回调
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean isGrant = true;
        showToast("requestCode: " + requestCode + "");
        Log.i(TAG, "onRequestPermissionsResult~~ requestCode:" + requestCode);
        for (int i = 0; i < permissions.length; i++) {
            Log.i(TAG, "permission: " + i + "  " + permissions[i] + " isGrant:" + grantResults[i]);
        }
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                isGrant = false;
                break;
            }
        }
        if (requestCode == REQUEST_FILE_PERMISSION_CODE) {
            if (isGrant) {
                GalleryFinal.openGalleryMuti(REQUEST_CODE_GALLERY, 10, mOnHandlerResultCallback);
            } else {
                Log.i(TAG, "file permission is denied.");
            }

        } else if (requestCode == REQUEST_LOCATION_PERMISSION_CODE) {
            if (isGrant) {
                MapActivity.launchActivityForResult(activity, REQUEST_CODE_FOR_LAST_LOCATION);
            } else {
                Log.i(TAG, "location permission is denied.");
            }

        } else if (requestCode == REQUEST_VOICE_PERMISSION_CODE) {
            if (isGrant) {
                recordVoice();
            } else {
                Log.i(TAG, "voice permission is denied.");
            }
        } else if (requestCode == REQUEST_RECORD_VIDEO_PERMISSION_CODE) {
            if (isGrant) {
                //  recordVideo();
            } else {
                Log.i(TAG, "record video permission is denied.");
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null || resultCode != Activity.RESULT_OK) {
            Log.i(TAG, "resultCode:" + resultCode + " requestCode:" + requestCode + " data:" + data);
            return;
        }
        Log.i(TAG, "resultCode:" + resultCode + " requestCode:" + requestCode + " data:" + data);


        if (requestCode == REQUEST_CODE_FOR_LAST_LOCATION) {
            String locationType = data.getStringExtra("location_type");
            if (locationType == null) {
                Log.e(TAG, "Unknow location type.");
                return;
            }
            if (locationType.equals("google")) {
                Location location = data.getParcelableExtra("lastLocation");
                if (location == null) {
                    Log.e(TAG, "location is null...");
                    return;
                }
                location.getAccuracy();
                location.getProvider();
                location.getExtras();

                HashMap<String, String> map = new HashMap<>();
                map.put("longitude", location.getLongitude() + "");
                map.put("latitude", location.getLatitude() + "");
                map.put(LocationMessage.LATITUDE, location.getLatitude() + "");
                map.put(LocationMessage.LONGITUDE, location.getLongitude() + "");
                Bundle bundle = location.getExtras();
                if (bundle != null) {
                    map.put(LocationMessage.TITLE, bundle.getString(LocationMessage.TITLE));
                    map.put(LocationMessage.SUBTITLE, bundle.getString(LocationMessage.SUBTITLE));
                }

                chatModule.sendLocation(map, getMsgOption());


            } else {//baidu
                final BDLocation bdLocation = data.getParcelableExtra("lastLocation");
                if (bdLocation == null) {
                    Log.e(TAG, "bdLocation is nll...");
                    return;
                }
                final DLocation dLocation = new DLocation(bdLocation.getLongitude(), bdLocation.getLatitude());
                Log.i(TAG, "~~~~bdLocation.getLongitude():" + bdLocation.getLongitude() + " bdLocation.getLatitude()" + bdLocation.getLatitude());

                double[] doubles = GPSUtils.bd09_To_gps84(bdLocation.getLatitude(), bdLocation.getLongitude());

                double latitude = doubles[0];
                double longitude = doubles[1];
                String title = TextUtils.isEmpty(bdLocation.getBuildingName()) ? activity.getString(R.string.share_location) : bdLocation.getBuildingName();
                String subTitle = TextUtils.isEmpty(bdLocation.getAddrStr()) ? activity.getString(R.string.unknow_adress) : bdLocation.getAddrStr();


                HashMap<String, String> map = new HashMap<>();
                map.put(LocationMessage.LATITUDE, latitude + "");
                map.put(LocationMessage.LONGITUDE, longitude + "");
                map.put(LocationMessage.TITLE, title);
                map.put(LocationMessage.SUBTITLE, subTitle);
                chatModule.sendLocation(map, getMsgOption());
//                Log.i(GPSUtils.TAG, "bd09_To_gps84 "+bdLocation.getLatitude() + "," + bdLocation.getLongitude() + "-->" + doubles[0] + "," + doubles[1]);
//                MapUtils.getGpsToMap(activity, dLocation, new MapUtils.CallBack() {
//                    @Override
//                    public void succed(DLocation pointF) {
//                        HashMap<String, String> map = new HashMap<>();
//                        map.put("longitude", pointF.longitude + "");//经度
//                        map.put("latitude", pointF.latitude + "");//纬度
//                        map.put("title", TextUtils.isEmpty(bdLocation.getBuildingName()) ? activity.getString(R.string.share_location) : bdLocation.getBuildingName());
//                        map.put("subTitle", bdLocation.getAddrStr());
//                        Log.i(TAG, "send location:" + dLocation.longitude + "," + dLocation.latitude + "--->" + pointF.longitude + "," + pointF.latitude + " title:" + title + " subtitle:" + subtitle);
//                        chatModule.sendLocation(map);
//
//                    }
//
//                    @Override
//                    public void failed(String reason) {
//                        showToast("convert baidu locaton to gps location  failed ");
//                    }
//                });

            }

        } else if (requestCode == REQUEST_CODE_FOR_CHOOSE_VIDEO) {
            Uri uri = data.getData();
            String filePath = FileUtils.getPath(getActivity(), uri);
            boolean isFileExist = FileUtils.isFileExist(filePath);
            if (isFileExist) {
                if (MediaFile.isImageFileType(filePath)) {
                    chatModule.sendImage(filePath, getMsgOption());
                } else if (MediaFile.isVideoFileType(filePath)) {
                    chatModule.sendVideo(filePath, getMsgOption());
                }

            } else {
                Log.i(TAG, "the selected video not exists.");
            }

        } else if (requestCode == REQUEST_CODE_FOR_RECORD_VIDEO) {
            String filePath = null;
            if (useInternalVideoRecord) {
                filePath = data
                        .getStringExtra(VideoRecoderActivity.VIDEO_FILE_KEY);
                Log.i(TAG, "Record file name:" + filePath);
            } else {
                Uri uri = data.getData();
                Log.i(TAG, "recoverd video succeed. rui:" + uri.toString());
                filePath = FileUtils.getPath(getActivity(), uri);
            }

            boolean isFileExist = FileUtils.isFileExist(filePath);
            if (isFileExist) {
                chatModule.sendVideo(filePath, getMsgOption());
            } else {
                Log.i(TAG, "the selected video not exists.");
            }


        } else if (requestCode == REQUEST_CODE_CHOOSE_FILE) {

            Uri uri = data.getData();
            String filePath = FileUtils.getPath(getActivity(), uri);
            boolean isFileExist = FileUtils.isFileExist(filePath);
            if (isFileExist) {
                chatModule.sendFile(filePath, getMsgOption());
            } else {
                Log.i(TAG, "the selected file not exists.");
            }
        } else if (requestCode == SelectMemberActivity.REQUEST_SEND_VCARD) {
            String[] urls = data.getStringArrayExtra(SelectMemberActivity.SEND_VCARD);
            if (urls != null && urls.length > 0) {
                chatModule.sendVCard(urls, getMsgOption());
                Log.i(TAG, "send cCard. count:" + urls.length);
            } else {
                Log.i(TAG, " cCard urls is valid");
            }
        } else if (requestCode == SelectMemberActivity.REQUEST_FORWARD_MESSAGE) {

        } else if (requestCode == ChooseGroupMemberActivity.REQUEST_AT_MEMBERS) {
            ArrayList<String> members = data.getStringArrayListExtra("select_members");
            if (members != null && members.size() > 0) {
                int start = inputEditText.getSelectionStart();

                Editable editable = inputEditText.getEditableText();
                editable.delete(start - 1, start);
                for (String member : members
                        ) {
                    addAtLinkUser(member);
                }
            }

        }


    }

    @Override
    public void onStop() {
        super.onStop();
        lifeStatus = Status.onStop;
        if (mConversation != null) {
            App.getInstance().setCurrentChatId(-1);
        }
        VoiceMessage.stopCurrentVoice();

    }

    /**
     * 图片选择器的回调
     */
    private GalleryFinal.OnHanlderResultCallback mOnHandlerResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int requestCode, List<PhotoInfo> resultList) {
            if (resultList == null) {
                Log.i(TAG, " requestCode:" + requestCode + " resultList is null.");
                return;
            }
            if (requestCode == REQUEST_CODE_GALLERY || requestCode == REQUEST_CODE_CAMERA) {
                for (PhotoInfo photoInfo : resultList) {
                    String filePath = photoInfo.getPhotoPath();
                    if (FileUtils.isFileExist(filePath)) {
//                        chatModule.sendImage(filePath, getMsgOption());
                        sendImage(filePath);
                    } else {
                        Log.i(TAG, "the photo file is not exist.. filePath:" + filePath);
                    }
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            showToast(errorMsg);
            Log.i(TAG, " requestCode:" + requestCode + " errorMsg:" + errorMsg);
        }
    };

    public void onNewIntent(Bundle data) {

        loadChatSkin();

        if (data != null) {
            //to do something.
        }

        //group has many issues  can't handle it.
        if (mConversation != null && !mConversation.isGroup()) {
            isAssistant = SPUtil.isAssistant(mConversation.getContactNumber());

            if (isAssistant) {
                recordBtn.setUseRecognize(true);
                AsistantService.getInstance().initSpeech();
            } else {
                recordBtn.setUseRecognize(false);
            }
        }


    }


    public void getCurrentLocation() {

        locationManager = (LocationManager) activity.getSystemService(Context.LOCATION_SERVICE);
        List<String> locationList = locationManager.getProviders(true);
        Log.i(TAG, "locationList size:" + locationList.size());
        for (String str : locationList) {
            Log.i(TAG, "provider: " + str);
        }
        if (locationList.contains(LocationManager.GPS_PROVIDER)) {
            provider = LocationManager.GPS_PROVIDER;
        } else if (locationList.contains(LocationManager.NETWORK_PROVIDER)) {
            provider = LocationManager.NETWORK_PROVIDER;
        } else if (locationList.contains(LocationManager.PASSIVE_PROVIDER)) {
            provider = LocationManager.PASSIVE_PROVIDER;
        } else {
            Log.i(TAG, "没有可用的定位服务");
            return;
        }


        Log.i(TAG, "current provider:" + provider);
        Location location = locationManager.getLastKnownLocation(provider);
        if (location == null) {
            Log.i(TAG, "get location from gps is null, change to network provider.");
            location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }
        if (location != null) {
//            showLocation(location);
            Log.i(TAG, "get location from network " + location.toString());
            MapActivity.launchActivityForResult(activity, REQUEST_CODE_FOR_LAST_LOCATION, location);
        } else {
            Log.i(TAG, " get location from nwtwork is null.~`requestLocationUpdates");
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 1, gpsLocationListener);
        }
    }


    LocationListener gpsLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            Log.i(TAG, "onLocationChanged~~ location:" + location.toString());

            if (isVisible()) {
//                LatLng latLng = MapUtils.convertGpsToBaidu(location.getLatitude(), location.getLongitude());
//                BigDecimal bLatitude = new BigDecimal(latLng.latitude);
//                location.setLatitude( bLatitude.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue());
//
//                BigDecimal bLongitude = new BigDecimal(latLng.longitude);
//                location.setLongitude(bLongitude.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue());

//                location.setLatitude(latLng.latitude);
//                location.setLongitude(latLng.longitude);
                Log.i(TAG, "latitude,longitude-->" + location.getLatitude() + "," + location.getLongitude());

                locationManager.removeUpdates(gpsLocationListener);
                MapActivity.launchActivityForResult(activity, REQUEST_CODE_FOR_LAST_LOCATION, location);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            Log.i(TAG, "onStatusChanged~~ provider" + provider);
        }

        @Override
        public void onProviderEnabled(String provider) {
            Log.i(TAG, "onProviderEnabled~~ provider" + provider);
        }

        @Override
        public void onProviderDisabled(String provider) {
            Log.i(TAG, "onProviderDisabled~~ provider" + provider);
        }

    };

    public abstract Message.Options getMsgOption();

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return hiddenAllChatMenus();// no need further handler this event.
        }
        return false;
    }

    BroadcastReceiver playingBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            int status = intent.getIntExtra("status", -1);
            long msgId = intent.getLongExtra("message_id", -1);
            Log.e(TAG, "playingBroadcastReceiver msgId:" + msgId + "");
            if (status == VoiceMessage.PLAY_STATUS_STOP || status == VoiceMessage.PLAY_STATUS_COMPLETION) {
//                MessageUtils.read(MessagingApi.getMessageById((int) msgId,false),true);
                for (Message msg : msgList) {
                    if (msg.getKeyId() == msgId) {
                        MessageUtils.read(msg, true);
                    }
                }
            }
        }
    };
}
