package com.ultralinked.uluc.enterprise.contacts;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;

import java.util.ArrayList;

/**
 * Created by ultralinked on 16/7/19.
 */
public class LocalContactsAdapter extends MyBaseAdapter<PeopleEntity>  implements SectionIndexer{



    private static final String TAG = "LocalContactsAdapter";


    public LocalContactsAdapter(Context context) {

        super(context,R.layout.localcontact_list_item,new ArrayList<PeopleEntity>());

    }




    @Override
    public void setHolder(MyHolder holder, PeopleEntity localContact) {



        ImageView ivAvatar =  holder.getView(R.id.contactitem_avatar_iv);
        TextView tvCatalog =  holder.getView(R.id.contactitem_catalog);
        TextView tvNick = holder.getView(R.id.contactitem_nick);
        TextView phone = holder.getView(R.id.phone);
        ImageView sealChat =  holder.getView(R.id.seal_chat_icon);



        char catalog = localContact.getLetter();

        tvCatalog.setText(String.valueOf(catalog));
        if (holder.getPosition() == 0) {
            tvCatalog.setVisibility(View.VISIBLE);
        } else {
            int index = holder.getPosition() - 1;
            if (index <getList().size() && index >= 0){
                PeopleEntity NextUser = getList().get(index);
                char lastCatalog = NextUser.getLetter();

                if (catalog == lastCatalog) {
                    tvCatalog.setVisibility(View.GONE);
                } else {
                    tvCatalog.setVisibility(View.VISIBLE);
                }
            }else{
                tvCatalog.setVisibility(View.GONE);
            }

        }

        ImageUtils.loadCircleImage(getContext(),ivAvatar, localContact.icon_url, ImageUtils.getDefaultContactImageResource(localContact.mobile));


        if (TextUtils.isEmpty(localContact.subuser_id)){
            tvNick.setText(localContact.name);
            phone.setText(localContact.mobile);
            sealChat.setVisibility(View.GONE);
        }else{
            tvNick.setText(PeopleEntityQuery.getDisplayName(localContact));
            phone.setText(PhoneNumberUtils.formatMobile(localContact.mobile));
            sealChat.setVisibility(View.VISIBLE);
        }
    }



    @Override
    public Object[] getSections() {
        return null;
    }

    @Override
    public int getPositionForSection(int section) {
        for (int i = 0; i < getList().size(); i++) {
            PeopleEntity user = getList().get(i);
            Character letter = user.getLetter();

            char firstChar = letter;
            if (firstChar == section) {
                return i;
            }
        }
        return 0;
    }


    @Override
    public int getSectionForPosition(int position) {
        return 0;
    }

}
