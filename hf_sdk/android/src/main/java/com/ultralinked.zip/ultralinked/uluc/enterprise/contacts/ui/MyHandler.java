package com.ultralinked.uluc.enterprise.contacts.ui;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;

import java.lang.ref.WeakReference;

/**
 * Created by ultralinked on 16/7/29.
 */


public class MyHandler extends Handler {

    private MyHandlerListener mlistener;


    public interface MyHandlerListener {

        void handleMessage(Message msg);
    }

    public WeakReference reference;

    public <T extends AppCompatActivity> MyHandler(T activity) {
        reference = new WeakReference(activity);
    }

    @Override
    public void handleMessage(Message msg) {

        if (mlistener != null) {
            mlistener.handleMessage(msg);
        }

    }

    public void setListener(MyHandlerListener listener) {
        mlistener = listener;
    }

}

