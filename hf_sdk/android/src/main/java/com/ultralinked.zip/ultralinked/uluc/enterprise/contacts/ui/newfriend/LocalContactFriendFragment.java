package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.baseui.widget.ULListView;
import com.ultralinked.uluc.enterprise.chat.group.GroupChatListActivity;
import com.ultralinked.uluc.enterprise.contacts.FragmentFriend;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.LocalContactContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.RawMatchsFriendPerson;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Conversation;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class LocalContactFriendFragment extends BaseFragment implements View.OnClickListener, LoaderManager.LoaderCallbacks<Cursor>, FromContactAdapter.OnFriendClickListener, ReadFriendContactTask.onContactReadFinishListener {


    private String mSearchWord;
    // Identifier for the permission request
    private static final int READ_CONTACTS_PERMISSIONS_REQUEST = 0x666;
    private static final int LOADERID = 0x999;

    private static final int FRIEND_LOADERID = 0x24;


    private ULListView mContactsListView;

    private static final String TAG = "LocalContactFriendFragment";

    private FromContactAdapter contactsAdapter;

    private ContentObserver contactChangeObserver, localContactChangeObserver, friendContactChangeObserver;

    private List<PeopleEntity> registerPeopleEntitys = new ArrayList<>();
    private List<PeopleEntity> localContacts = new ArrayList<>();

    private char[] alphaLetters = new char[]{}, regiserAlphaLetters = new char[]{};

    @Override
    public int getRootLayoutId() {
        return R.layout.mobile_contacts_friend_layout;
    }


    //  TextView secretBtn;

    EditText mSearch_edittext;

    BaseActivity baseActivity;
    private Subscription rxSubscription;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        baseActivity = (BaseActivity) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RequestFriendManager.loadLastMatchCache();

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSIONS_REQUEST);
        } else {
            getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        }
    }


    @Override
    public void initView(Bundle savedInstanceState) {

        initTopbar();
        mContactsListView = bind(R.id.friend_list_view);

        goneView(bind(R.id.sideBar));

        initListView();

        initListener(this, R.id.searchParent);


        mSearch_edittext = bind(R.id.search_edittext);
        mSearch_edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {


                if (TextUtils.isEmpty(s)) {
                    mSearchWord = "";
                } else {
                    mSearchWord = s.toString();
                }
                reloadData();

                //todo:expand the list

            }
        });


    }

    private void initTopbar() {
        ImageView left_back = bind(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseActivity.finish();
            }
        });

        TextView titleCenter = bind(R.id.titleCenter);
        titleCenter.setText(getString(R.string.mobile_contacts));
        goneView(bind(R.id.titleRight));
    }

    public void reloadData() {

        getActivity().getSupportLoaderManager().restartLoader(LOADERID, null, this);
    }


    private SideBar indexBar;
    private TextView contactheaderCatalog;

    private int mCurrentPosition = -1;

    int mSuspensionHeight;


    private void initListView() {
        indexBar = bind(R.id.sideBar);
        contactheaderCatalog = bind(R.id.contactheader_catalog);

        indexBar.setListView(mContactsListView, true);


        contactsAdapter = new FromContactAdapter(getActivity(), this);
        mContactsListView.setAdapter(contactsAdapter);

        mContactsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PeopleEntity entity = (PeopleEntity) parent.getItemAtPosition(position);

                if (!TextUtils.isEmpty(entity.subuser_id)) {//our register user
                    DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
                } else {
                    //go to normal detail page , maybe need reload when query succ.
                    //invite
                    Intent intent = new Intent(mContext, AddNewFriendActicity.class);
                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, entity);
                    intent.putExtra(AddNewFriendActicity.KEY_QUERY_DETAIL_ENTITY, true);
                    mContext.startActivity(intent);
                }


            }
        });


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        rxSubscription = RxBus.getDefault().toObservable(PeopleEntity.class)
                .subscribe(new Action1<PeopleEntity>() {
                               @Override
                               public void call(PeopleEntity peopleEntity) {
                                   Log.i(TAG, "update the peopleEntity~~~~");
                                   if (peopleEntity != null && peopleEntity.is_friend) {

                                       if (contactsAdapter!=null){
                                           final HashMap<String, PeopleEntity> alreadyFriendMap = contactsAdapter.getAlreadyFriendMap();
                                           alreadyFriendMap.put(peopleEntity.mobile, peopleEntity);
                                           getActivity().runOnUiThread(new Runnable() {
                                               @Override
                                               public void run() {
                                                   contactsAdapter.setAlreadyFriendMap(alreadyFriendMap);
                                               }
                                           });
                                       }

                                   }


                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG, "update the subscribe error:" + android.util.Log.getStackTraceString(throwable));
                            }
                        });
        return root;
    }

    private ReadFriendContactTask mReadContactTask;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        mReadContactTask = new ReadFriendContactTask(getActivity(), FRIEND_LOADERID);
        mReadContactTask.registerListener(this);
        getActivity().getSupportLoaderManager().initLoader(FRIEND_LOADERID, null, mReadContactTask.getLoader());


        Uri friendUri = FriendContract.CONTENT_URI;
        friendContactChangeObserver = new FriendContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(friendUri, true, friendContactChangeObserver);

        //for friend end ..

        Uri uri = LocalContactContract.CONTENT_URI;
        contactChangeObserver = new ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri, true, contactChangeObserver);

        try {
            localContactChangeObserver = new LocalContactChangeObserver(new Handler());
            getActivity().getContentResolver().registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, localContactChangeObserver);
        } catch (Exception e) {
            e.printStackTrace();//maybe not has permission
        }

    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
    }

    @Override
    public void onItemClickListener(PeopleEntity entity) {
        if ("accepted".equals(entity.status)) {
            Log.i(TAG, "entity.subuser_id===" + entity.subuser_id);
            String id = entity.subuser_id;
            PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(id);
            if (peopleEntity != null) {

                DetailPersonActivity.gotoDetailPersonActivity(baseActivity, peopleEntity);
            }
            return;
        }
        Intent intent = new Intent(baseActivity, AddNewFriendActicity.class);
        intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, entity);
        intent.putExtra(AddNewFriendActicity.KEY_QUERY_DETAIL_ENTITY, true);
        baseActivity.startActivity(intent);
    }


    public void queryContact(final PeopleEntity peopleEntity) {

        String CountryCode = SPUtil.getCode();
        String matchPhone = PhoneNumberUtils.normalizeMatchNumber(CountryCode, peopleEntity.mobile);
        Log.e(TAG, "Query matchPhone " + matchPhone);

        ApiManager.getInstance().queryUser(matchPhone)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "QueryFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        Log.e(TAG, "Query error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                RawMatchsFriendPerson rawFriendPerson = GsonUtil.fromJson(rs, RawMatchsFriendPerson.class);
                                if (rawFriendPerson != null && rawFriendPerson.matchs != null) {
                                    if (rawFriendPerson.matchs.size() >= 1) {

                                        PeopleEntity entity = rawFriendPerson.matchs.get(0);
                                        // go to detail or add friend page.
                                        if (entity.is_friend) {
                                            DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
                                        } else {
                                            RequestFriendManager.getInstance().inviteFriend((BaseActivity) getActivity(), entity, new FromContactAdapter.OnFriendClickListener() {
                                                @Override
                                                public void onItemClickListener(PeopleEntity entity) {

                                                }

                                                @Override
                                                public void callFriendRequest(String action, PeopleEntity peopleEntity) {

                                                }

                                                @Override
                                                public void onFriendStatusChanged(PeopleEntity peopleEntity) {
                                                    contactsAdapter.updateItem(peopleEntity);
                                                }
                                            });

//                                            Intent intent = new Intent(getActivity(), AddNewFriendActicity.class);
//                                            intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, entity);
//                                            startActivity(intent);
                                        }
                                    }

                                } else {
                                    //not found. just share.
                                }

                            } else if (202 == object.optInt("code")) {
                                String shareInfo = object.optString("description");
                                //showToast(R.string.add_contact_invite_success);
                                String mobile = peopleEntity.mobile;
                                Log.i(TAG, "invite mobile info:" + mobile);

                                ShareUtils.tellFriend(getContext(), shareInfo, mobile);
                            } else {
                                showToast(R.string.add_contact_invite_failed);

                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
                        }

                        Log.i(TAG, "Query  " + rs);
                    }

                });

    }


    private void updateFriendHashMap(List<PeopleEntity> friends) {
        if (contactsAdapter != null && friends != null && friends.size() > 0) {
            final HashMap<String, PeopleEntity> alreadyFriendMap = new HashMap<>();
            for (PeopleEntity friend : friends
                    ) {
                friend.is_friend = true;
                alreadyFriendMap.put(friend.mobile, friend);
            }
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    contactsAdapter.setAlreadyFriendMap(alreadyFriendMap);
                }
            });
        }
    }

    @Override
    public void callFriendRequest(String action, PeopleEntity peopleEntity) {
        RequestFriendManager requestFriendManager = RequestFriendManager.getInstance();
        if ("invite".equals(action)) {
            queryContact(peopleEntity);
            //do invite.
            return;
        }

        requestFriendManager.inviteFriend(baseActivity, peopleEntity, new FromContactAdapter.OnFriendClickListener() {
            @Override
            public void onItemClickListener(PeopleEntity entity) {

            }

            @Override
            public void callFriendRequest(String action, PeopleEntity peopleEntity) {

            }

            @Override
            public void onFriendStatusChanged(PeopleEntity peopleEntity) {
                contactsAdapter.updateItem(peopleEntity);
            }
        });
    }

    @Override
    public void onFriendStatusChanged(PeopleEntity peopleEntity) {
        contactsAdapter.updateItem(peopleEntity);
    }

    //for friend.
    @Override
    public void setAdapter(List<PeopleEntity> friend, char[] alphaLetters) {
        updateFriendHashMap(friend);
    }


    private class LocalContactChangeObserver extends ContentObserver {
        public LocalContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "LocalContactChangeObserver hasChanged..");
        }
    }


    private class FriendContactChangeObserver extends ContentObserver {
        public FriendContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "friend contact hasChanged..");
            getActivity().getSupportLoaderManager().restartLoader(FRIEND_LOADERID, null, LocalContactFriendFragment.this);
        }
    }

    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "contact hasChanged..");
            reloadData();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_CONTACTS_PERMISSIONS_REQUEST) {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST ");
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
            } else {
                Toast.makeText(getContext().getApplicationContext(), "Read Contacts permission denied", Toast.LENGTH_SHORT).show();
                getActivity().finish();
            }
        } else {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST no");
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        Uri contentUri;
        if (TextUtils.isEmpty(mSearchWord)) {
            // Since there's no search string, use the content URI that searches the entire
            // Contacts table
            contentUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        } else {
            // Since there's a search string, use the special content Uri that searches the
            // Contacts table. The URI consists of a base Uri and the search string.
            contentUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(mSearchWord));
        }


        return new CursorLoader(getContext(), contentUri,
                null, ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + " > 0", null, "sort_key");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, final Cursor data) {
        //
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    readContact(data);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }


    void changeTab() {

        indexBar.resetLetters(alphaLetters);
        contactsAdapter.updateList(localContacts);
        contactsAdapter.notifyDataSetChanged();

    }


    private void readContact(Cursor cursor) throws Exception {
        if (cursor == null || getActivity().isFinishing()) {
            if (cursor == null) {
                Log.i(TAG, "contact cursor is null maybe no permission");
            }
            return;
        }

        Log.i(TAG, "contact cursor maybe has permission ");


        if (cursor.getCount() == 0) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //clear
                    registerPeopleEntitys.clear();
                    localContacts.clear();
                    alphaLetters = new char[]{};
                    regiserAlphaLetters = new char[]{};
                    changeTab();
                }
            });

            return;
        }
        Log.i(TAG, "contact cursor move to frist");
        cursor.moveToFirst();
        final List<PeopleEntity> data = new ArrayList<>();
        final List<PeopleEntity> dataRegisers = new ArrayList<>();
        List<String> userMoblies = new ArrayList<>();

        String CountryCode = SPUtil.getCode();
        do {

            String photoThubnailUri = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI));

            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            if (TextUtils.isEmpty(phone)) {
                Log.i(TAG, "phone number is empty ,user contact name:" + name);
                continue;
            }
            PeopleEntity localContact = new PeopleEntity();
            localContact.name = name;
            localContact.nickname = name;
            localContact.mobile = phone;

            String matchPhone = PhoneNumberUtils.normalizeMatchNumber(CountryCode, phone);

            PeopleEntity matchPhoneEntity = RequestFriendManager.registerAccount.get(matchPhone);
            if (PeopleEntityQuery.hasFoundPeople(matchPhoneEntity)) {
                localContact = matchPhoneEntity;
                localContact.name = name;
                localContact.nickname = name;
                if (matchPhoneEntity.is_friend) {
                    localContact.status = "accepted";
                } else {
                    localContact.status = "add";
                }
                dataRegisers.add(localContact);
                userMoblies.add(matchPhone);//must query the nest status.
            } else {
                localContact.status = "invite";
                localContact.icon_url = photoThubnailUri;
                userMoblies.add(matchPhone);
            }

            localContact.setLetter(localContact.name);
            data.add(localContact);


        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

        try {
            Collections.sort(data);
            Collections.sort(dataRegisers);
        } catch (Exception e) {
            e.printStackTrace();
        }

        final char[] alphaLettersTemp = ReadFriendContactTask.getAlphaLetters(data);
        final char[] registerAlphaLettersTemp = ReadFriendContactTask.getAlphaLetters(dataRegisers);
        if (!getActivity().isFinishing()) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    localContacts = new ArrayList<PeopleEntity>(data);
                    registerPeopleEntitys = new ArrayList<PeopleEntity>(dataRegisers);
                    alphaLetters = alphaLettersTemp;
                    regiserAlphaLetters = registerAlphaLettersTemp;
                    changeTab();

                }
            });
        }


        if (!resetFlag) {
            Log.i(TAG, "check userList from server");

            checkContactsFromServer(userMoblies);

        } else {
            resetFlag = false;
            Log.i(TAG, "no need to check userList from server=="+userMoblies.size());

        }


    }

    boolean resetFlag = false;

    private void checkContactsFromServer(final List<String> userMoblies) {
        Log.i(TAG, "checkContactsFromServer start--"+userMoblies.size());

        RequestFriendManager.getInstance().queryPeoplesByMoblieWithStatus(userMoblies, new QueryFriendListener() {
            @Override
            public void onResultFriendList(List<PeopleEntity> entities) {
                //in threads

                if (entities != null && !entities.isEmpty()) {
                    if (!getActivity().isFinishing()) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                resetFlag = true;
                                reloadData();
                            }
                        });
                    }
                    //save to contact local table later.
                }
            }

            @Override
            public void onQueryFailed(List<String> requestUserIds) {
                //sub thread.
            }
        });
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        //clear
        contactsAdapter.updateList(new ArrayList<PeopleEntity>());
        contactsAdapter.notifyDataSetChanged();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (rxSubscription != null && !rxSubscription.isUnsubscribed()) {
            rxSubscription.unsubscribe();
        }

        getActivity().getSupportLoaderManager().destroyLoader(LOADERID);
        if (contactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }

        if (localContactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(localContactChangeObserver);
        }

        if (friendContactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(friendContactChangeObserver);
        }

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {


            case R.id.searchParent:
                mSearch_edittext.requestFocus();
                KeyBoardUtils.openKeybord(mSearch_edittext, getActivity());
                break;
        }

    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.i(TAG, " onResume ");


    }


}
