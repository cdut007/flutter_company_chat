package com.ultralinked.uluc.enterprise.contacts;


import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.contract.StrangerContract;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import rx.Subscription;
import rx.functions.Action1;

public class FragmentContacts extends BaseFragment implements View.OnClickListener {


    private static final String TAG = "FragmentContacts";
    private boolean mIsShowingPersonal = true;

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.contacts_layout;
    }


    TextView personalTab;
    TextView companyTab;

    ImageView backBtn;

    MainActivity mainActivity;
    Subscription mCompanySubscription;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mainActivity = (MainActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TCAgent.onPageStart(getActivity(),"手机联系人");
    }

    private static final int PERSONAL = 0, COMPANY = 1, CONTACTS = 2;


    int getPersonalModel() {
        if (SPUtil.getFindContactsSetting()) {

            return CONTACTS;
        }
        return PERSONAL;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        backBtn = bind(R.id.left_back);
        companyTab = bind(R.id.company_contacts);
        personalTab = bind(R.id.personal_contacts);

        goneView(backBtn);

        selectPersonalOrCompany(getPersonalModel(), true);//默认选择personal

        changeStateByCompany();
        initListener(this, companyTab, personalTab);

        if (mCompanySubscription == null) {
            mCompanySubscription = RxBus.getDefault().toObservable(String.class)
                    .subscribe(new Action1<String>() {
                        @Override
                        public void call(String s) {
                            Log.i(TAG, "change info:" + s);
                            if ("change company state".equals(s)) {
                                changeStateByCompany();
                            } else if ("change contacts model".equals(s)) {
                                changeModel = true;
                            }
                        }
                    }, new Action1<Throwable>() {
                        @Override
                        public void call(Throwable throwable) {
                            Log.e(TAG, "change company state error!");
                        }
                    });
        }
    }

    private  boolean changeModel;




    @Override
    protected void onRestoreState(Bundle savedInstanceState) {
        super.onRestoreState(savedInstanceState);
    }

    private void changeContactsModel() {
        selectPersonalOrCompany(getPersonalModel(), true);
    }

    private void changeStateByCompany() {
        if (!SPUtil.getUserHasCompany()) {
            bind(R.id.title_bar_company).setVisibility(View.GONE);
            bind(R.id.txt_no_company).setVisibility(View.VISIBLE);
        } else {
            bind(R.id.title_bar_company).setVisibility(View.VISIBLE);
            bind(R.id.txt_no_company).setVisibility(View.GONE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
        //show last time

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        TCAgent.onPageEnd(getActivity(),"手机联系人");

    }

    @Override
    public void onDestroy() {
        if (mCompanySubscription != null && mCompanySubscription.isUnsubscribed())
            mCompanySubscription.unsubscribe();
        super.onDestroy();
    }

    /**
     * public: 0
     * private:1
     *
     * @param item
     */
    int lastSelectedItem = -1;
    Bundle dataBundle = new Bundle();

    private void selectPersonalOrCompany(int item, boolean reset) {
        if (lastSelectedItem == item && !reset) {
            return;
        }

        mIsShowingPersonal = item != COMPANY;

        lastSelectedItem = item;
        bind(R.id.company_contacts_line).setSelected(item == COMPANY);
        bind(R.id.personal_contacts_line).setSelected(item != COMPANY);
        int white = getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.white);
        int white_tint = getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.white_tint);
        companyTab.setTextColor(item == COMPANY ? white : white_tint);
        personalTab.setTextColor(item != COMPANY ? white : white_tint);

        FragmentManager childFragmentManager = getChildFragmentManager();


        // Create new fragment and transaction
        Fragment newFragment, HiddenFragment, removeFragment = null;
        String tag;
        if (item == COMPANY) {
            tag = "company";
            newFragment = childFragmentManager.findFragmentByTag(tag);
            if (newFragment == null) {
                newFragment = new FragmentCompanyContacts();
                newFragment.setArguments(dataBundle);
                Log.i(TAG, "find the tag for company not exsit,create new one");
            }
            HiddenFragment = getFragmentByTag(SPUtil.getFindContactsSetting() ? "contacts" : "friend");

        } else if (item == PERSONAL) {
            if (reset) {
                removeFragment = getFragmentByTag("contacts");
            }
            tag = "friend";
            newFragment = childFragmentManager.findFragmentByTag(tag);
            if (newFragment == null) {
                newFragment = new FragmentFriend();
                newFragment.setArguments(dataBundle);
                Log.i(TAG, "find the tag for friend not exsit,create new one");
            }
            HiddenFragment = getFragmentByTag("company");
        } else {

            if (reset) {
                removeFragment = getFragmentByTag("friend");
            }

            tag = "contacts";
            newFragment = childFragmentManager.findFragmentByTag(tag);
            if (newFragment == null) {
                newFragment = new FragmentLocalContacts();
                newFragment.setArguments(dataBundle);
                Log.i(TAG, "find the tag for LocalContacts not exsit,create new one");
            }
            HiddenFragment = getFragmentByTag("company");
        }


        FragmentTransaction transaction = childFragmentManager.beginTransaction();


        // Replace whatever is in the fragment_container view with this fragment,

        // and add the transaction to the back stack

        //  transaction.replace(R.id.fragment_content, newFragment,tag);

        if (reset) {
            if (removeFragment != null) {
                if (removeFragment.isAdded()) {
                    Log.i(TAG, "remove last frament:" + removeFragment.getTag());
                    transaction.remove(removeFragment);
                } else {
                    Log.i(TAG, "remove last frament not added");
                }

            } else {
                Log.i(TAG, "remove last frament not found");
            }

            if (CONTACTS == item) {
                loadMatchRegisterAccount();
            } else if (PERSONAL == item) {
                //clear

            }

        }

        if (!newFragment.isAdded()) {
            transaction.add(R.id.fragment_content, newFragment, tag);
        }
        transaction.show(newFragment);
        if (HiddenFragment != null) {
            transaction.hide(HiddenFragment);
        }

        // Commit the transaction
        transaction.commit();



    }

    private void loadMatchRegisterAccount() {
        Log.i(TAG,"loadMatchRegisterAccount~~");
        new Thread(new Runnable() {
            @Override
            public void run() {

                PeopleEntityQuery.getInstance().getAllRegisterAccounts();
                final Fragment fragmentLocalContacts = getFragmentByTag("contacts");
                if (fragmentLocalContacts!=null){
                   getActivity().runOnUiThread(new Runnable() {
                       @Override
                       public void run() {
                           ((FragmentLocalContacts)fragmentLocalContacts).reloadData();
                       }
                   });
                }

            }
        }).start();


    }


    public void updateBadge() {
        Fragment fragmentCompanyContacts = getFragmentByTag("company");
        if (fragmentCompanyContacts != null) {
            ((FragmentCompanyContacts) fragmentCompanyContacts).updateBadge();
        }

    }

    private Fragment getFragmentByTag(String tag) {
        FragmentManager childFragmentManager = getChildFragmentManager();
        Fragment newFragment = childFragmentManager.findFragmentByTag(tag);
        if (newFragment != null && newFragment.isAdded() && !newFragment.isHidden()) {
            return newFragment;
        }
        return null;

    }

    private int sign = -1;

    private boolean priviteModelChecked;

    @Override
    public void onClick(View v) {


        switch (v.getId()) {

            case R.id.company_contacts:
                selectPersonalOrCompany(COMPANY, false);
                break;

            case R.id.personal_contacts:
                selectPersonalOrCompany(getPersonalModel(), false);
                break;

        }

    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

    }


    @Override
    public void onResume() {
        super.onResume();
        if (changeModel){
            changeModel = false;
            changeContactsModel();
        }

        Log.i(TAG, " onResume ");

    }


    public static String firstLetterToUpper(String str) {

        return str;
//        if (TextUtils.isEmpty(str)) {
//            return "";
//        }
//
//        if (TextUtils.isEmpty(str)) {
//            return "";
//        }
//
//        if (Character.isUpperCase(str.charAt(0))) {
//            return str;
//        }
//
//        char[] array = str.toCharArray();
//        array[0] -= 32;
//        return String.valueOf(array);
    }

    public boolean isPersonalModel() {
        return mIsShowingPersonal;
    }


}
