package com.ultralinked.uluc.enterprise.login;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.baseui.widget.OTPButton;
import com.ultralinked.uluc.enterprise.common.AutoGetCode;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.StringUtils;

import java.util.List;
import java.util.Locale;

import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by ultralinked on 2016/7/1 0001.
 */
public class SignupFragment extends BaseFragment implements View.OnClickListener, LoginView, EasyPermissions.PermissionCallbacks {

    EditText etName;
    EditViewPlus etMobile;
    OTPButton btRequestOTP;
    EditText etOTP;

    LoginPresenter presenter;

    private Button btSignup;
    private LoginActivity activity;
    private int requestCode = 1;


    private AutoGetCode autoGetCode;
    private Handler smsHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String otp = (String) msg.obj;
            String lastMobile = SPUtil.getLastMobile();
            if (lastMobile != null && etMobile.getText() != null && !lastMobile.equals(etMobile.getText().toString())) {
                Log.i(TAG, "user change the mobile , let user input otp by themself");
                return;
            }
            etOTP.setText(otp);
            //  showToast(mContext, getString(R.string.toast_otp_auto_fillin, otp), Style.ALERT);
            btSignup.performClick();
        }
    };
    private String currentType;

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (autoGetCode != null) {
            getActivity().getContentResolver().unregisterContentObserver(autoGetCode);
        }

        smsHandler.removeCallbacksAndMessages(null);


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (LoginActivity) context;
    }

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_signup;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        TextView mTnc = bind(R.id.txt_tnc);
        mTnc.setText(StringUtils.getDifferColorString(getString(R.string.tnc), new String[]{"Terms of Service", "Privacy Policy", "《安讯软件许可及服务协议》"}, activity.getResources().getColor(R.color.color_primary), true));
        mTnc.setOnClickListener(this);
        btSignup = bind(R.id.btSignup);
        etOTP = bind(R.id.etOTP);
        etMobile = bind(R.id.customEt);
        etMobile.setHint(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.hint_mobile));

        etName = bind(R.id.name);
        btRequestOTP = bind(R.id.btRequestOTP);

        TextView tvSignup = bind(R.id.tvSignup);
        tvSignup.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);

        SpannableStringBuilder sp = new SpannableStringBuilder(tvSignup.getText());

        try {
            sp.setSpan(new ForegroundColorSpan(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_primary)), 0, 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        } catch (IndexOutOfBoundsException ex) {
            sp.setSpan(new ForegroundColorSpan(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_primary)), 0, 2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        tvSignup.setText(sp);

        initListener(this, btSignup, etMobile, btRequestOTP, tvSignup);

        etMobile.setCountryCode(SPUtil.getCode());

        detectMobile();
    }

    private void detectMobile() {

        String[] perms = {Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS};
        if (EasyPermissions.hasPermissions(getActivity(), perms)) {
            autoGetCode = new AutoGetCode(mContext, smsHandler);//
            getActivity().getContentResolver().registerContentObserver(Uri.parse("content://sms/"), true, autoGetCode); //...
        } else {
            //...
            Log.i("signup", "no perimisson for read sms");
        }


        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        try {

            TelephonyManager mTelephonyMgr;
            mTelephonyMgr = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
            String number = mTelephonyMgr.getLine1Number();
            Log.i("signup", "get mobile number: " + number);

            Log.i("signup", "get mobile getSimSerialNumber: " + mTelephonyMgr.getSimSerialNumber());
            // phone must begin with '+'
            String currentLanguage = Locale.getDefault().getLanguage();
            if (!TextUtils.isEmpty(number)) {
                Phonenumber.PhoneNumber numberProto = phoneUtil.parse(number, currentLanguage);
                int countryCode = numberProto.getCountryCode();
                if (countryCode > -1) {
                    etMobile.setCountryCode("+" + countryCode);
                }
                number = numberProto.getNationalNumber() + "";
                etMobile.setMobile(number);
            }


        } catch (Exception e) {
            Log.i("signup", "NumberParseException was thrown: " + android.util.Log.getStackTraceString(e));
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        presenter = new LoginPresenter(this, activity);
        Log.i(TAG);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.customEt:
                Intent intent = new Intent(activity, CountryCodeChooseActivity.class);
                startActivityForResult(intent, CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
                break;
            case R.id.btRequestOTP:

                requestOTP(etMobile.getTextAll());
                break;
            case R.id.btSignup:
                initSignup(etMobile.getTextAll(), etOTP.getText().toString()
                        , etName.getText().toString());
                break;

            case R.id.tvSignup:
                activity.titleLeft.setVisibility(View.VISIBLE);
                activity.titleCenter.setText(R.string.sign_up_for_company);
                activity.getSupportFragmentManager()
                        .beginTransaction()
                        .setCustomAnimations(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out, com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out)
                        .replace(R.id.container, new SignupWithCompanyFragment(), "SignupWithCompanyFragment")
                        .commit();
                break;
            case R.id.txt_tnc:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.TERMS_URL)));
                break;
        }
    }

    private void requestOTP(final String mobile) {
        if (!NetUtil.isNetworkAvailable(activity)) {
            showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
            return;
        }
        if (!RegexValidateUtils.checkCellphone(mobile)) {
            showToast(com.holdingfuture.flutterapp.hfsdk.R.string.error_mobile);
            return;
        }

        btRequestOTP.click(new OTPButton.OnRequestTypeListener() {
            @Override
            public void clickType(String type) {
                currentType = type;
                presenter.otpRequest(mobile, "otp_regist", type);
            }
        });
        requestCode = 1;

    }

    private void initSignup(String mobile, String otp, String userName) {

        if (!NetUtil.isNetworkAvailable(activity)) {
            showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
            return;
        }


        if (TextUtils.isEmpty(userName) || TextUtils.isEmpty(userName.trim())) {

            showToast(R.string.error_username);
            try {
                bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }


        if (!RegexValidateUtils.checkCellphone(mobile)) {
            showToast(com.holdingfuture.flutterapp.hfsdk.R.string.error_mobile);
            try {
                bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }


        if (TextUtils.isEmpty(otp) || TextUtils.isEmpty(otp.trim())) {

            showToast(R.string.please_enter_otp);
            try {
                etOTP.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }


        requestCode = 2;
        presenter.otpRegist(mobile, userName, otp);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG, requestCode + "  " + resultCode);
        if (data != null)
            etMobile.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.i("signup", "onDestroyView");
    }

    @Override
    public void loginSuccess() {
        activity.hideDialog();
        if (requestCode == 1) {
            if ("voice".equals(currentType)) {
                showToast(activity.getString(R.string.voice_sms_code_has_sent_you));

            } else {
                showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).substring(0, activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).indexOf("%s")) + etMobile.getText());
            }
        } else {

            SPUtil.saveCode(etMobile.getCountryCode());
            SPUtil.saveMobile(etMobile.getText());
            SPUtil.saveLoginModel(SPUtil.LOGIN_BY_OTP, false);
            Log.i(TAG, "login success from the ui login page, we need to init the DB manager for contact or other things.");
            SqliteUtils.getInstance(activity);//init the db manager ,
            Bundle bundle = new Bundle();
            bundle.putBoolean("register", true);
            lunchActivity(MainActivity.class, bundle);
            activity.finish();
            // activity.titleCenter.setText(R.string.signin);
            // activity.replaceFg(new Login1Fragment(),"Login1Fragment");
        }

    }

    @Override
    public void loginError(String msg) {
        if (requestCode == 1) {
            btRequestOTP.cancelCountDown();
        } else {
            try {
                bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        activity.showToast(msg);
    }

    @Override
    public void showDialog() {
        activity.showDialog();
    }

    @Override
    public void hideDialog() {
        activity.hideDialog();
    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }


}
