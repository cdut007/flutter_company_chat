package com.ultralinked.uluc.enterprise.contacts.contract;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

/**
 * Created by ultralinked on 16/6/30.
 */

/**
 * a sqlite helper class, only used in SqliteUtils ,
 * coz we need pay attention to sychronize on multi thread, be careful
 */
public class DbSQLHelper extends SQLiteOpenHelper {

    //打Log时，通常会用的标记 实用
    private static final String LOG_TAG = "DbSQLHelper";

    //if you change the database schema , you must increment the database version
    private static final int DATABASE_VERSION = 10;
    private static final String CALL_LOG = "call_log";

    public static  String DATABASE_NAME = "ulucenterprise.db";

    public DbSQLHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }






    public static ContentValues assignValues(PeopleEntity item) {

        SPUtil.updateRegisterAccount(item);//cause memeroy

        ContentValues value = new ContentValues();
        value.put(BasePeopleColumns.SUBUSER_ID, "" + item.subuser_id);
        value.put(BasePeopleColumns.MOBILE, "" + item.mobile);
        value.put(BasePeopleColumns.ENABLE, "" + item.enable);

        if (TextUtils.isEmpty(item.name)){
            item.name = "";
        }

        value.put(BasePeopleColumns.NAME, "" + item.name);

        value.put(BasePeopleColumns.ACTIVE, "" + item.active);

        if (TextUtils.isEmpty(item.icon_url)){
            item.icon_url = "";
        }

        value.put(BasePeopleColumns.ICON, "" + item.icon_url);

        if (TextUtils.isEmpty(item.nickname)){
            item.nickname = "";
        }

        value.put(BasePeopleColumns.NICKNAME, "" + item.nickname);


        if (TextUtils.isEmpty(item.remarkname)){
            item.remarkname = "";
        }

        value.put(BasePeopleColumns.REMARKNAME, "" + item.remarkname);

        value.put(BasePeopleColumns.DOMAIN_ID, "" + item.domain_id);

        if (TextUtils.isEmpty(item.email)){
            item.email = "";
        }

        value.put(BasePeopleColumns.EMAIL, "" + item.email);

        if (TextUtils.isEmpty(item.gender)){
            item.gender = "1";//default.
        }

        value.put(BasePeopleColumns.SEX, "" + item.gender);


        value.put(BasePeopleColumns.PINYIN, "" + item.name);

        value.put(BasePeopleColumns.CREATE_DATE, "" + item.created_at);
        value.put(BasePeopleColumns.DELETE_DATE, "" + item.deleted_at);
        value.put(BasePeopleColumns.LAST_UPDATE, "" + item.updated_at);
        value.put(BasePeopleColumns.LAST_UPDATE_RELATION, "");
        return value;
    }





    public static PeopleEntity readPeopleBaseColumns(Cursor cursor) {
        PeopleEntity peopleEntity = new PeopleEntity();

        peopleEntity.subuser_id = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.SUBUSER_ID));
        peopleEntity.icon_url = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.ICON));
        peopleEntity.mobile = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.MOBILE));
        peopleEntity.email = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.EMAIL));
        peopleEntity.nickname = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.NICKNAME));
        peopleEntity.remarkname = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.REMARKNAME));
        peopleEntity.name = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.NAME));
        peopleEntity.gender = cursor.getString(cursor.getColumnIndex(BasePeopleColumns.SEX));

        peopleEntity.setLetter(PeopleEntityQuery.getDisplayName(peopleEntity));
        return peopleEntity;
    }

    public static String[] getPeopleColumns() {
        return new String[] {
                BasePeopleColumns.SUBUSER_ID,
                BasePeopleColumns.MOBILE,
                BasePeopleColumns.ENABLE,
                BasePeopleColumns.NAME,
                BasePeopleColumns.ACTIVE,
                BasePeopleColumns.SEX,
                BasePeopleColumns.ICON,
                BasePeopleColumns.NICKNAME,
                BasePeopleColumns.REMARKNAME,
                BasePeopleColumns.DOMAIN_ID,
                BasePeopleColumns.EMAIL,
                BasePeopleColumns.PINYIN,
                BasePeopleColumns.CREATE_DATE,
                BasePeopleColumns.DELETE_DATE,
                BasePeopleColumns.LAST_UPDATE,
                BasePeopleColumns.LAST_UPDATE_RELATION,
        };
    }


    public static String[] getPeopleWithCompanyColumns() {
        return new String[]{

                "a." + PersonnelContract.PersonnelColumn.SUBUSER_ID,
                "a." + PersonnelContract.PersonnelColumn.MOBILE,
                "a." + PersonnelContract.PersonnelColumn.ENABLE,
                "a." + PersonnelContract.PersonnelColumn.NAME,
                "a." + PersonnelContract.PersonnelColumn.ACTIVE,
                "a." + PersonnelContract.PersonnelColumn.ICON,
                "a." + PersonnelContract.PersonnelColumn.SEX,
                "a." + PersonnelContract.PersonnelColumn.NICKNAME,
                "a." + PersonnelContract.PersonnelColumn.REMARKNAME,
                "a." + PersonnelContract.PersonnelColumn.DOMAIN_ID,
                "a." + PersonnelContract.PersonnelColumn.EMAIL,
                "a." + PersonnelContract.PersonnelColumn.PINYIN,

                "a." + PersonnelContract.PersonnelColumn.CREATE_DATE,
                "a." + PersonnelContract.PersonnelColumn.DELETE_DATE,
                "a." + PersonnelContract.PersonnelColumn.LAST_UPDATE,
                "a." + PersonnelContract.PersonnelColumn.LAST_UPDATE_RELATION,

                "b." + RelationContract.RelationColumn.DEPART_ID,
                "b." + RelationContract.RelationColumn.DEPARTMENT_TYPE,
                "b." + RelationContract.RelationColumn.DEPARTMENT_NAME,
                "b." + RelationContract.RelationColumn.COMPANY_NAME,
                "b." + RelationContract.RelationColumn.COMPANY_ID
        };
    }



    private  static  final String TABLE_COLUMNS=" ( " +
            BasePeopleColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT ," +
            BasePeopleColumns.SUBUSER_ID + " TEXT UNIQUE NOT NULL , " +
            BasePeopleColumns.MOBILE + " TEXT , " +
            BasePeopleColumns.ENABLE + " TEXT ," +
            BasePeopleColumns.ACTIVE + " TEXT , " +
            BasePeopleColumns.NAME + " TEXT , " +

            BasePeopleColumns.SEX + " TEXT , " +
          //  BasePeopleColumns.AGE + " INTEGER , " +

            BasePeopleColumns.ICON + " TEXT, " +
            BasePeopleColumns.NICKNAME + " TEXT, " +
            BasePeopleColumns.REMARKNAME + " TEXT, " +
            BasePeopleColumns.PINYIN + " TEXT COLLATE NOCASE, " +
            BasePeopleColumns.DOMAIN_ID + " TEXT, " +
            BasePeopleColumns.EMAIL + " TEXT, " +
            BasePeopleColumns.CREATE_DATE + " TEXT, " +
            BasePeopleColumns.DELETE_DATE + " TEXT, " +
            BasePeopleColumns.LAST_UPDATE + " TEXT, " +
            BasePeopleColumns.LAST_UPDATE_RELATION + " TEXT " +
            ");";




    //local
    private static final String SQL_CREATE_LOCAL_TABLE = "CREATE TABLE " +
            LocalContactContract.TABLE_NAME + TABLE_COLUMNS;

    //stranger
    private static final String SQL_CREATE_STRANGER_TABLE = "CREATE TABLE " +
            StrangerContract.TABLE_NAME + TABLE_COLUMNS;


    //friend
    private static final String SQL_CREATE_FRIEND_TABLE = "CREATE TABLE " +
            FriendContract.TABLE_NAME + TABLE_COLUMNS;


    //private
    private static final String SQL_CREATE_PRIVATE_TABLE = "CREATE TABLE " +
            PrivateContract.TABLE_NAME + TABLE_COLUMNS;

    //personnel
    private static final String SQL_CREATE_PERSONNEL_TABLE =  "CREATE TABLE " +
            PersonnelContract.TABLE_NAME + TABLE_COLUMNS;



    private static final String SQL_CREATE_RELATION_TABLE = "CREATE TABLE " +

            RelationContract.TABLE_NAME + " ( " +

            RelationContract.RelationColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +

            RelationContract.RelationColumn.DEPART_ID + " TEXT NOT NULL , " +

            RelationContract.RelationColumn.USER_ID + " TEXT NOT NULL , " +

            RelationContract.RelationColumn.DEPARTMENT_TYPE + " TEXT NOT NULL , " +

            RelationContract.RelationColumn.DEPARTMENT_NAME + " TEXT , " +

            RelationContract.RelationColumn.COMPANY_ID + " TEXT NOT NULL , " +

            RelationContract.RelationColumn.COMPANY_NAME + " TEXT  , " +

            // Set up the personnel id column as a foreign key to relation table.
            " FOREIGN KEY (" + RelationContract.RelationColumn.USER_ID + ") REFERENCES " +

            PersonnelContract.TABLE_NAME + "(" + PersonnelContract.PersonnelColumn.SUBUSER_ID + ") on delete cascade, " +

            " UNIQUE (" + RelationContract.RelationColumn.DEPART_ID + ", " + RelationContract.RelationColumn.USER_ID + ") ON CONFLICT REPLACE);";

    private static final String SQL_CREATE_CALLLOG_TABLE = "CREATE TABLE " + CALL_LOG + " ( " +
            "_id" + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "call_from" + " TEXT  , " +
            "call_name" + " TEXT  , " +
            "call_endtime" + " TEXT , " +
            "call_duration" + " TEXT  , " +
            "call_icon" + " TEXT ," +
            "call_type" + "  TEXT" + ");";

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(LOG_TAG, " onCreate = ");
        db.beginTransaction();
        try {
            db.execSQL(SQL_CREATE_PERSONNEL_TABLE);
            db.execSQL(SQL_CREATE_RELATION_TABLE);
            db.execSQL(SQL_CREATE_CALLLOG_TABLE);
            db.execSQL(SQL_CREATE_PRIVATE_TABLE);
            db.execSQL(SQL_CREATE_FRIEND_TABLE);
            db.execSQL(SQL_CREATE_STRANGER_TABLE);
            db.execSQL(SQL_CREATE_LOCAL_TABLE);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

        Log.i(LOG_TAG, " onUpgrade = ");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + CALL_LOG);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + PersonnelContract.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + RelationContract.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + PrivateContract.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + FriendContract.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + StrangerContract.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + LocalContactContract.TABLE_NAME);
        onCreate(sqLiteDatabase);


    }



}
