package com.ultralinked.uluc.enterprise.chat.chatim;

import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.mapapi.map.Text;
import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SynthesizerListener;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.utils.Log;

/**
 * Created by mac on 16/11/16.
 */

public class TTSActivity extends BaseActivity implements View.OnClickListener{
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_tts_info;
    }
    private ImageView leftBack;
    private  TextView textDisplay;
    String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AsistantService.getInstance().initSpeech();
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack=bind(R.id.left_back);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.tts);

        initListener(this, leftBack);
        textDisplay = bind(R.id.tts_text);

        // 初始化合成对象
        mTts = SpeechSynthesizer.createSynthesizer(this, mTtsInitListener);

        // 云端发音人名称列表
       // mCloudVoicersEntries = getResources().getStringArray(R.array.voicer_cloud_entries);
       // mCloudVoicersValue = getResources().getStringArray(R.array.voicer_cloud_values);



        text = getIntent().getStringExtra("text");
        if (TextUtils.isEmpty(text)){
            text = "no result";
        }
        textDisplay.setText(text);

        boolean sound = getIntent().getBooleanExtra("sound",true);

        if (sound){
            // 设置参数
            setParam();
            int code = mTts.startSpeaking(text, mTtsListener);
//			/**
//			 * 只保存音频不进行播放接口,调用此接口请注释startSpeaking接口
//			 * text:要合成的文本，uri:需要保存的音频全路径，listener:回调接口
//			*/
//			String path = Environment.getExternalStorageDirectory()+"/tts.pcm";
//			int code = mTts.synthesizeToUri(text, path, mTtsListener);

            if (code != ErrorCode.SUCCESS) {
                if(code == ErrorCode.ERROR_COMPONENT_NOT_INSTALLED){
                    //未安装则跳转到提示安装页面
                }else {
                    showTip("语音合成失败,错误码: " + code);
                }
            }
        }else{
            ((TextView)bind(R.id.titleCenter)).setText(R.string.detail);
        }

    }


    // 语音合成对象
    private SpeechSynthesizer mTts;

    // 默认发音人
    private String voicer = "xiaoyan";

    private String[] mCloudVoicersEntries;
    private String[] mCloudVoicersValue ;

    // 缓冲进度
    private int mPercentForBuffering = 0;
    // 播放进度
    private int mPercentForPlaying = 0;


    // 引擎类型
    private String mEngineType = SpeechConstant.TYPE_CLOUD;




    private int selectedNum = 0;
//    /**
//     * 发音人选择。
//     */
//    private void showPresonSelectDialog() {
//        switch (mRadioGroup.getCheckedRadioButtonId()) {
//            // 选择在线合成
//            case R.id.tts_radioCloud:
//                new AlertDialog.Builder(this).setTitle("在线合成发音人选项")
//                        .setSingleChoiceItems(mCloudVoicersEntries, // 单选框有几项,各是什么名字
//                                selectedNum, // 默认的选项
//                                new DialogInterface.OnClickListener() { // 点击单选框后的处理
//                                    public void onClick(DialogInterface dialog,
//                                                        int which) { // 点击了哪一项
//                                        voicer = mCloudVoicersValue[which];
//                                        if ("catherine".equals(voicer) || "henry".equals(voicer) || "vimary".equals(voicer)) {
//                                            ((EditText) findViewById(R.id.tts_text)).setText(R.string.text_tts_source_en);
//                                        }else {
//                                            ((EditText) findViewById(R.id.tts_text)).setText(R.string.text_tts_source);
//                                        }
//                                        selectedNum = which;
//                                        dialog.dismiss();
//                                    }
//                                }).show();
//                break;
//
//            default:
//                break;
//        }
//    }

    /**
     * 初始化监听。
     */
    private InitListener mTtsInitListener = new InitListener() {
        @Override
        public void onInit(int code) {
            Log.d(TAG, "InitListener init() code = " + code);
            if (code != ErrorCode.SUCCESS) {
                showTip("初始化失败,错误码："+code);
            } else {
                // 初始化成功，之后可以调用startSpeaking方法
                // 注：有的开发者在onCreate方法中创建完合成对象之后马上就调用startSpeaking进行合成，
                // 正确的做法是将onCreate中的startSpeaking调用移至这里
            }
        }
    };

    /**
     * 合成回调监听。
     */
    private SynthesizerListener mTtsListener = new SynthesizerListener() {

        @Override
        public void onSpeakBegin() {
            showTip("开始播放");
        }

        @Override
        public void onSpeakPaused() {
            showTip("暂停播放");
        }

        @Override
        public void onSpeakResumed() {
            showTip("继续播放");
        }

        @Override
        public void onBufferProgress(int percent, int beginPos, int endPos,
                                     String info) {
            // 合成进度
            mPercentForBuffering = percent;
            showTip(String.format("缓冲进度为%d%%，播放进度为%d%%",
                    mPercentForBuffering, mPercentForPlaying));
        }

        @Override
        public void onSpeakProgress(int percent, int beginPos, int endPos) {
            // 播放进度
            mPercentForPlaying = percent;
            showTip(String.format("play 缓冲进度为%d%%，播放进度为%d%%",
                    mPercentForBuffering, mPercentForPlaying));
        }

        @Override
        public void onCompleted(SpeechError error) {
            if (error == null) {
                finish();
                showTip("播放完成");
            } else if (error != null) {
                showTip(error.getPlainDescription(true));
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
            // 以下代码用于获取与云端的会话id，当业务出错时将会话id提供给技术支持人员，可用于查询会话日志，定位出错原因
            // 若使用本地能力，会话id为null
            //	if (SpeechEvent.EVENT_SESSION_ID == eventType) {
            //		String sid = obj.getString(SpeechEvent.KEY_EVENT_SESSION_ID);
            //		Log.d(TAG, "session id =" + sid);
            //	}
        }
    };

    private void showTip(final String str) {
        Log.i(TAG,"tts info:"+str);
    }

    /**
     * 参数设置
     * @param
     * @return
     */
    private void setParam(){
        // 清空参数
        mTts.setParameter(SpeechConstant.PARAMS, null);
        // 根据合成引擎设置相应参数
        if(mEngineType.equals(SpeechConstant.TYPE_CLOUD)) {
            mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
            // 设置在线合成发音人
            mTts.setParameter(SpeechConstant.VOICE_NAME, voicer);
            //设置合成语速
            mTts.setParameter(SpeechConstant.SPEED, "50");
            //设置合成音调
            mTts.setParameter(SpeechConstant.PITCH, "50");
            //设置合成音量
            mTts.setParameter(SpeechConstant.VOLUME,"50");
        }else {
            mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
            // 设置本地合成发音人 voicer为空，默认通过语记界面指定发音人。
            mTts.setParameter(SpeechConstant.VOICE_NAME, "");
            /**
             * TODO 本地合成不设置语速、音调、音量，默认使用语记设置
             * 开发者如需自定义参数，请参考在线合成参数设置
             */
        }
        //设置播放器音频流类型
        mTts.setParameter(SpeechConstant.STREAM_TYPE, "3");
        // 设置播放合成音频打断音乐播放，默认为true
        mTts.setParameter(SpeechConstant.KEY_REQUEST_FOCUS, "true");

        // 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
        // 注：AUDIO_FORMAT参数语记需要更新版本才能生效
        mTts.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
        mTts.setParameter(SpeechConstant.TTS_AUDIO_PATH, Environment.getExternalStorageDirectory()+"/msc/tts.wav");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mTts!=null){
            mTts.stopSpeaking();
            // 退出时释放连接
            mTts.destroy();
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;


            default:
        }
    }


}
