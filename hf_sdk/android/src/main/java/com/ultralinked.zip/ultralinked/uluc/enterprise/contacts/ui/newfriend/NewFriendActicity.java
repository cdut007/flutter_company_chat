package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.os.Bundle;

import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.secret.FragmentPrivate;

public class NewFriendActicity extends BaseFragmentActivity  {

    @Override
    public void initView(Bundle savedInstanceState) {
        Class<?> className = FragmentNewFriend.class;
        setFragment(className, new Bundle());

    }


}
