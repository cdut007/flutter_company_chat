package com.ultralinked.uluc.enterprise.baseui.widget;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.HashMap;

/**
 * Created by ultralinked on 2015/8/6.
 */
public class NumberKeyboard extends FrameLayout implements View.OnClickListener, View.OnLongClickListener {
    private ViewGroup mView;
    private int xmlId;
    private Integer currentTone = null;
    private HashMap mToneMap; // storage DTMF Tones
    private Activity context;
    private ToneGenerator mToneGenerator; // voice generator

    public NumberKeyboard(Activity context) {
        super(context);
        this.context=context;
        init(context);
    }
    public View getKeyPadView(){
        return mView;
    }

    public NumberKeyboard(Activity context, int xmlId) {
        super(context);
        this.xmlId = xmlId;
        this.context=context;
        init(context);
    }

    public NumberKeyboard(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context= (Activity) context;
        init(context);
    }

    public NumberKeyboard(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context= (Activity) context;
        init(context);
    }

    private void init(Context context) {
        if (xmlId != 0)
            mView = (ViewGroup) View.inflate(context, xmlId,this);
        else
            mView = (ViewGroup) View.inflate(context, R.layout.numpad, this);

        setOnClickListener(null);
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        mView.findViewById(R.id.Digit1).setOnClickListener(this);
        mView.findViewById(R.id.Digit2).setOnClickListener(this);
        mView.findViewById(R.id.Digit3).setOnClickListener(this);
        mView.findViewById(R.id.Digit4).setOnClickListener(this);
        mView.findViewById(R.id.Digit5).setOnClickListener(this);
        mView.findViewById(R.id.Digit6).setOnClickListener(this);
        mView.findViewById(R.id.Digit7).setOnClickListener(this);
        mView.findViewById(R.id.Digit8).setOnClickListener(this);
        mView.findViewById(R.id.Digit8).setOnLongClickListener(this);
        mView.findViewById(R.id.Digit9).setOnClickListener(this);
        mView.findViewById(R.id.Digit9).setOnLongClickListener(this);
        mView.findViewById(R.id.DigitStar).setOnClickListener(this);
        mView.findViewById(R.id.Digit00).setOnClickListener(this);
        mView.findViewById(R.id.Digit00).setOnLongClickListener(this);
        mView.findViewById(R.id.DigitHash).setOnClickListener(this);
        ImageUtils.buttonEffect((ImageView)mView.findViewById(R.id.bottomCenter));
        initTone();
    }


    @Override
    public void onClick(View v) {
        if (listener != null) {
            listener.onClick(v);
            if(v.getTag()!=null&&!v.getTag().toString().isEmpty()){
                context.setVolumeControlStream(AudioManager.STREAM_DTMF);
                playTone(v.getTag().toString());
                context.setVolumeControlStream(AudioManager.USE_DEFAULT_STREAM_TYPE);
                listener.onKeyDown(v.getTag().toString());
            }
        }
    }


    private OnKeyDownListener listener;

    public OnKeyDownListener getOnKeyDownListener() {
        return listener;
    }

    public void setOnKeyDownListener(OnKeyDownListener listener) {
        this.listener = listener;
    }

    @Override
    public boolean onLongClick(View v) {
        if (listener != null) {
            boolean pressDigitZero = false;
            if (v.getId() == R.id.Digit00) {
                listener.onKeyDown("+");
                pressDigitZero = true;
            }
            listener.onLongClick(v);
            if (pressDigitZero){
                return true;
            }

        }
        return false;
    }

    public boolean isShowing() {

        if (dialer == null){
            return true;
        }

        return dialer.getVisibility() == VISIBLE;
    }

    public void dismiss() {
        dismiss(true);
    }

    private  View dialer;

    public void dismiss(boolean animate) {

        if(dialer == null){
            return;
        }

        try {
            View view = (View) dialer.getParent();
            view.findViewById(R.id.call_log).setVisibility(VISIBLE);
        }catch (Exception e){
            e.printStackTrace();
        }

        Animation lastAnimation =  dialer.getAnimation();
        if (lastAnimation!=null && lastAnimation.hasStarted()){
            lastAnimation.setAnimationListener(null);
            lastAnimation.cancel();
            dialer.clearAnimation();
        }


        if (!animate){
            dialer.setVisibility(View.GONE);
            return;
        }



        Animation animation= AnimationUtils.loadAnimation(getContext(), R.anim.down_tran);

        dialer.startAnimation(animation);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation arg0) {}   //在动画开始时使用

            @Override
            public void onAnimationRepeat(Animation arg0) {}  //在动画重复时使用

            @Override
            public void onAnimationEnd(Animation arg0) {
                dialer.setVisibility(View.GONE);

            }
        });
    }


    public void show(View dialer) {
        show(true,dialer);
    }


    public void setDialer(View dialer) {
        this.dialer = dialer;
    }

    public void show(boolean animate, View dialer) {
        this.dialer = dialer;

        try {
            View view = (View) dialer.getParent();
            view.findViewById(R.id.call_log).setVisibility(GONE);
        }catch (Exception e){
            e.printStackTrace();
        }

        Animation lastAnimation =  dialer.getAnimation();
        if (lastAnimation!=null && lastAnimation.hasStarted()){
            lastAnimation.setAnimationListener(null);
            lastAnimation.cancel();
            dialer.clearAnimation();
        }


        if (!animate){
            dialer.setVisibility(View.VISIBLE);
            return;
        }



        Animation animation= AnimationUtils.loadAnimation(getContext(), R.anim.up_tran);

        dialer.startAnimation(animation);
        dialer.setVisibility(View.VISIBLE);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation arg0) {}   //在动画开始时使用

            @Override
            public void onAnimationRepeat(Animation arg0) {}  //在动画重复时使用

            @Override
            public void onAnimationEnd(Animation arg0) {

            }
        });

    }



    public interface OnKeyDownListener {
        void onKeyDown(String tag);

        void onLongClick(View v);

        void onClick(View v);
    }

    private void playTone(String tag) {
        Log.i(tag);

        currentTone = (Integer) mToneMap.get(tag);
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int ringerMode = audioManager.getRingerMode();
        if (ringerMode == AudioManager.RINGER_MODE_SILENT) {
            return;
        }
        synchronized ("tone") {
            if (mToneGenerator == null) {
                Log.w("playTone", "playTone: mToneGenerator == null, currentTone: "+ currentTone);
                return;
            }
            if (ringerMode == AudioManager.RINGER_MODE_VIBRATE) {
                this.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,
                        HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            } else {
                mToneGenerator.startTone(currentTone, 120); // start voice
            }
        }
    }

    private void initTone() {
        if (mToneMap == null) {
            mToneMap = new HashMap();
            mToneMap.put("1", ToneGenerator.TONE_DTMF_1);
            mToneMap.put("2", ToneGenerator.TONE_DTMF_2);
            mToneMap.put("3", ToneGenerator.TONE_DTMF_3);
            mToneMap.put("4", ToneGenerator.TONE_DTMF_4);
            mToneMap.put("5", ToneGenerator.TONE_DTMF_5);
            mToneMap.put("6", ToneGenerator.TONE_DTMF_6);
            mToneMap.put("7", ToneGenerator.TONE_DTMF_7);
            mToneMap.put("8", ToneGenerator.TONE_DTMF_8);
            mToneMap.put("9", ToneGenerator.TONE_DTMF_9);
            mToneMap.put("0", ToneGenerator.TONE_DTMF_0);
            mToneMap.put("#", ToneGenerator.TONE_DTMF_P);
            mToneMap.put("*", ToneGenerator.TONE_DTMF_S);
        }
        try {
            synchronized ("tone") {
                if ( mToneGenerator == null) {
                    mToneGenerator = new ToneGenerator(
                            AudioManager.STREAM_DTMF, 80); // set voice height
                }
            }
        } catch (Exception e) {
            Log.e("exception", e.getMessage());
            mToneGenerator = null;
        }
    }

}
