package com.ultralinked.uluc.enterprise.moments.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.moments.adapter.MomentCommentsAdapter;
import com.ultralinked.uluc.enterprise.moments.bean.NewMomentItem;
import com.ultralinked.uluc.enterprise.more.FragmentMore;
import com.ultralinked.uluc.enterprise.utils.Log;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mac on 17/1/24.
 */

public class MomentCommentsActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_moment_comment_list_dispaly;
    }

    ListView momentsCommentList;
    MomentCommentsAdapter commentsAdapter;

    @Override
    public void initView(Bundle savedInstanceState) {

        ImageView leftBack = bind(R.id.left_back);
        leftBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ((TextView) bind(R.id.titleCenter)).setText(getString(R.string.comments));


        TextView right = bind(R.id.titleRight);
        goneView(right);


        momentsCommentList = bind(R.id.displayMomentsCommentsList);
        commentsAdapter = new MomentCommentsAdapter(this);
        commentsAdapter.updateList(new ArrayList<NewMomentItem>(FragmentMore.newMommetsItems));
        momentsCommentList.setAdapter(commentsAdapter);

        deleteUneadMomentsFromServer();


    }


    void deleteUneadMomentsFromServer() {

        List<String> ids = new ArrayList<>();

        for (NewMomentItem momentItem : FragmentMore.newMommetsItems
                ) {
            if (!TextUtils.isEmpty(momentItem.moments_event_id)) {
                ids.add(momentItem.moments_event_id);
            }

        }
        ApiManager.getInstance().deleteUnreadMomentsItems(ids)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "deleteUneadMomentsFromServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                String result = object.optString("result");
                                FragmentMore.newMommetsItems.clear();

                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse deleteUneadMomentsFromServer error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "deleteUneadMomentsFromServer result:" + rs);
                    }
                });

    }

}
