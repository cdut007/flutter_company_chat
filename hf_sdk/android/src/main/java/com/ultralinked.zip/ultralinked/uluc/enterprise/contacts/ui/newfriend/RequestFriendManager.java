package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.RawMatchsFriendPerson;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailHelper;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Conversation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mac on 16/10/20.
 */

public class RequestFriendManager {

    public static final String TAG = "RequestFriendManager";

    private static RequestFriendManager requestFriendManager;

    public static RequestFriendManager getInstance() {
        if (requestFriendManager == null) {
            requestFriendManager = new RequestFriendManager();
        }
        return requestFriendManager;
    }


    public void removeFriend(final BaseActivity baseActivity, final PeopleEntity peopleEntity, final NewFriendAdapter.OnFriendClickListener friendClickListener) {
        String str1 = baseActivity.getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(baseActivity);
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();

        ApiManager.getInstance().deleteFriend(peopleEntity.subuser_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(baseActivity.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "deleteFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressDialog.cancel();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        baseActivity.showToast(eMsg + "");
                        Log.e(TAG, "delete friend error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        progressDialog.cancel();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {

                                if (friendClickListener != null) {
                                    friendClickListener.onFriendStatusChanged(peopleEntity);
                                }

                                baseActivity.showToast(R.string.remove_firend_success);
                                //notify the contact refresh.
                                RxBus.getDefault().post(new PeopleEntity());
                            } else {
                                baseActivity.showToast(R.string.remove_firend_failed);
                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "delete friend  " + rs);
                    }

                });

    }


    public void inviteFriend(BaseActivity baseActivity, PeopleEntity peopleEntity) {
        inviteFriend(baseActivity, peopleEntity, null);
    }


    public void inviteFriend(final BaseActivity baseActivity, final PeopleEntity peopleEntity, final FromContactAdapter.OnFriendClickListener friendClickListener) {


        if (SPUtil.getUserID().equals(peopleEntity.subuser_id)) {
            baseActivity.showToast(R.string.invite_self_warning);
            return;
        }

        String str1 = baseActivity.getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(baseActivity);
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();

        ApiManager.getInstance().inViteFriend(peopleEntity.subuser_id, peopleEntity.invite_message)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(baseActivity.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "InviteFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressDialog.cancel();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        baseActivity.showToast(eMsg + "");
                        Log.e(TAG, "invite error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        progressDialog.cancel();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                peopleEntity.status = "pending";
                                baseActivity.showToast(R.string.add_firend_invite_success);
                                if (friendClickListener != null) {
                                    friendClickListener.onFriendStatusChanged(peopleEntity);
                                }
                                //notify the contact refresh.
                                RxBus.getDefault().post(new PeopleEntity());
                            } else {
                                baseActivity.showToast(R.string.add_contact_invite_failed);
                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "invite  " + rs);
                    }

                });

    }


    public void acceptFriend(BaseActivity baseActivity, PeopleEntity peopleEntity) {
        acceptFriend(baseActivity, peopleEntity, null);
    }


    public void acceptFriend(final BaseActivity baseActivity, final PeopleEntity peopleEntity, final NewFriendAdapter.OnFriendClickListener friendClickListener) {
        String str1 = baseActivity.getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(baseActivity);
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();

        ApiManager.getInstance().acceptFriend(peopleEntity.invite_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(baseActivity.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "acceptFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressDialog.cancel();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        baseActivity.showToast(eMsg + "");
                        Log.e(TAG, "accept error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        progressDialog.cancel();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //save.

                                peopleEntity.status = "accepted";
                                if (MainActivity.instance != null) {
                                    MainActivity.instance.getFriend();
                                }
                                if (friendClickListener != null) {
                                    friendClickListener.onFriendStatusChanged(peopleEntity);
                                }
                                //go the friends page.

                                baseActivity.showToast(R.string.accept_firend_success);
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {

                                        DetailHelper.save_FRIEND_(peopleEntity);
                                        MessageUtils.insertFriendStartTips(peopleEntity.subuser_id);
                                        SingleChatImActivity.launchToSingleChatIm(baseActivity, peopleEntity.subuser_id, Conversation.CONVERSATION_FLAG_NONE);
                                        peopleEntity.is_friend = true;
                                        updatePersonAsFriend(peopleEntity);
                                    }
                                }).start();
                                //notify the contact refresh.
                                RxBus.getDefault().post(new PeopleEntity());
                            } else {
                                baseActivity.showToast(R.string.accept_firend_failed);
                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "accept  " + rs);
                    }

                });

    }


    public void rejectFriend(BaseActivity baseActivity, PeopleEntity peopleEntity) {
        rejectFriend(baseActivity, peopleEntity, null);
    }


    public void rejectFriend(final BaseActivity baseActivity, final PeopleEntity peopleEntity, final NewFriendAdapter.OnFriendClickListener friendClickListener) {
        String str1 = baseActivity.getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(baseActivity);
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();

        ApiManager.getInstance().rejectFriend(peopleEntity.invite_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(baseActivity.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "rejectFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressDialog.cancel();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        baseActivity.showToast(eMsg + "");
                        Log.e(TAG, "reject error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        progressDialog.cancel();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                peopleEntity.status = "pending";
                                if (friendClickListener != null) {
                                    friendClickListener.onFriendStatusChanged(peopleEntity);
                                }

                                baseActivity.showToast(R.string.reject_firend_invite_success);
                                //notify the contact refresh.
                                RxBus.getDefault().post(new PeopleEntity());
                            } else {
                                baseActivity.showToast(R.string.reject_firend_invite_failed);
                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "reject  " + rs);
                    }

                });

    }


    //phone below 8  complete match, >8  only match end
    public static HashMap<String, PeopleEntity> registerAccount = new HashMap<>();


    public static void loadLastMatchCache() {
        try {
            if (registerAccount.isEmpty()) {
                Type sToken = new TypeToken<List<PeopleEntity>>() {
                }.getType();
                Gson gson = new GsonBuilder().serializeNulls().create();
                ACache mCache = ACache.get(App.getInstance());
                String result = mCache.getAsString(SPUtil.getUserID() + "_matchLocalContactInfo");
                List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
                for (PeopleEntity entity : queryPeoples
                        ) {
                    updateRegisterAccount(entity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void deletePerson(PeopleEntity entity) {

        try {
            if (!registerAccount.isEmpty()) {
                registerAccount.remove(entity.mobile);
            }

            Type sToken = new TypeToken<List<PeopleEntity>>() {
            }.getType();
            Gson gson = new GsonBuilder().serializeNulls().create();
            ACache mCache = ACache.get(App.getInstance());
            String result = mCache.getAsString(SPUtil.getUserID() + "_matchLocalContactInfo");
            List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
            boolean found = false;
            for (PeopleEntity entityPerson : queryPeoples
                    ) {
                if (entityPerson.subuser_id.equals(entity.subuser_id)) {
                    queryPeoples.remove(entityPerson);
                    found = true;
                    break;
                }
            }

            if (found) {
                String updateResult = gson.toJson(queryPeoples);
                if (!queryPeoples.isEmpty()) {

                    mCache.put(SPUtil.getUserID() + "_matchLocalContactInfo", updateResult, 365 * ACache.TIME_DAY);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static void updatePersonAsFriend(PeopleEntity entity) {

        try {
            registerAccount.put(entity.mobile, entity);

            Type sToken = new TypeToken<List<PeopleEntity>>() {
            }.getType();
            Gson gson = new GsonBuilder().serializeNulls().create();
            ACache mCache = ACache.get(App.getInstance());
            String result = mCache.getAsString(SPUtil.getUserID() + "_matchLocalContactInfo");
            List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
            boolean found = false;
            for (int i = 0; i < queryPeoples.size(); i++) {
                PeopleEntity entityPerson = queryPeoples.get(i);
                if (entityPerson.subuser_id.equals(entity.subuser_id)) {
                    queryPeoples.set(i, entity);
                    found = true;
                    break;
                }
            }

            if (found) {
                String updateResult = gson.toJson(queryPeoples);
                if (!queryPeoples.isEmpty()) {

                    mCache.put(SPUtil.getUserID() + "_matchLocalContactInfo", updateResult, 365 * ACache.TIME_DAY);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static void updateRegisterAccount(PeopleEntity item) {
        String match = RegexValidateUtils.matchPhone(item.mobile);
        if (!TextUtils.isEmpty(match)) {
            registerAccount.put(match, item);
        }
    }

    public void queryPeoplesByMoblieWithStatus(final List<String> mobiles, final QueryFriendListener queryFriendListener) {
        ApiManager.getInstance().queryUsersByMoblieWithAction(mobiles)
                .subscribeOn(Schedulers.io())                   //子线程

                // 绑定生命周期
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryPeoplesByMoblieWithStatusComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        if (queryFriendListener != null) {
                            queryFriendListener.onQueryFailed(mobiles);
                        }
                        Log.e(TAG, "queryPeoplesByMoblieWithStatus error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {

                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                final List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
                                if (queryPeoples != null) {


//                                    List<PeopleEntity> strangers = new ArrayList<PeopleEntity>();
                                    for (PeopleEntity people : queryPeoples
                                            ) {
                                        updateRegisterAccount(people);
                                    }
                                    //save cache.
                                    if (!queryPeoples.isEmpty()) {
                                        ACache mCache = ACache.get(App.getInstance());
                                        mCache.put(SPUtil.getUserID() + "_matchLocalContactInfo", result, 365 * ACache.TIME_DAY);
                                    }
//
//                                    //save the data.
//                                    if (!strangers.isEmpty()) {
//                                        Save2MutliProvider.save_Stranger(strangers);
//                                        // Save2MutliProvider.save_local(infos);//always add
//                                    }

                                    if (queryFriendListener != null) {

                                        queryFriendListener.onResultFriendList(queryPeoples);
                                    }
                                }


                            } else {
                                if (queryFriendListener != null) {
                                    queryFriendListener.onQueryFailed(mobiles);
                                }

                            }

                        } catch (Exception e) {
                            Log.e(TAG, "Exception " + e.getMessage());
                        }

                        Log.i(TAG, "Query queryPeoplesByMoblieWithStatus members: " + rs);
                    }

                });
    }

    String lastCheckFriendInfo;

    public void queryPeoplesByMoblie(final List<String> mobiles, final QueryFriendListener queryFriendListener) {
        ApiManager.getInstance().queryUsersByMoblie(mobiles)
                .subscribeOn(Schedulers.io())                   //子线程

                // 绑定生命周期
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryPeoplesByMoblieComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        if (queryFriendListener != null) {
                            queryFriendListener.onQueryFailed(mobiles);
                        }
                        Log.e(TAG, "queryPeoplesByMoblie error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            if (rs!=null && rs.equals(lastCheckFriendInfo)){

                                if (queryFriendListener != null) {

                                    queryFriendListener.onResultFriendList(null);
                                }
                                Log.i(TAG, " queryFriendListener already refreshed..");

                                return;
                            }

                            lastCheckFriendInfo = rs;

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {

                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                final List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
                                if (queryPeoples != null) {

                                    List<PeopleEntity> strangers = new ArrayList<PeopleEntity>();
                                    for (PeopleEntity people : queryPeoples
                                            ) {
                                        if (people.is_friend) {
                                            DetailHelper.save_FRIEND_(people);
                                        } else {
                                            strangers.add(people);
                                        }
                                    }

                                    //save the data.
                                    if (!strangers.isEmpty()) {
                                        Save2MutliProvider.save_Stranger(strangers);
                                        // Save2MutliProvider.save_local(infos);//always add
                                    }

                                    if (queryFriendListener != null) {

                                        queryFriendListener.onResultFriendList(queryPeoples);
                                    }
                                }


                            } else {
                                if (queryFriendListener != null) {
                                    queryFriendListener.onQueryFailed(mobiles);
                                }

                            }

                        } catch (Exception e) {
                            Log.e(TAG, "Exception " + e.getMessage());
                        }

                        Log.i(TAG, "Query queryPeoplesByMoblie members: " + rs);
                    }

                });
    }


    public void queryPeople(final List<String> userIds, final QueryFriendListener queryFriendListener) {
        ApiManager.getInstance().queryUsers(userIds)
                .subscribeOn(Schedulers.io())                   //子线程

                // 绑定生命周期
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        android.util.Log.i(TAG, "queryPeopleComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        if (queryFriendListener != null) {
                            queryFriendListener.onQueryFailed(userIds);
                        }
                        Log.e(TAG, "queryPeople error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {

                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                final List<PeopleEntity> queryPeoples = gson.fromJson(result, sToken);
                                if (queryPeoples != null) {

                                    List<PeopleEntity> strangers = new ArrayList<PeopleEntity>();
                                    for (PeopleEntity people : queryPeoples
                                            ) {
                                        if (people.is_friend) {
                                            DetailHelper.save_FRIEND_(people);
                                        } else {
                                            strangers.add(people);
                                        }
                                    }

                                    //save the data.
                                    if (!strangers.isEmpty()) {
                                        Save2MutliProvider.save_Stranger(strangers);
                                    }

                                    if (queryFriendListener != null) {

                                        queryFriendListener.onResultFriendList(queryPeoples);
                                    }
                                }


                            } else {
                                if (queryFriendListener != null) {
                                    queryFriendListener.onQueryFailed(userIds);
                                }

                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "Query queryPeople members: " + rs);
                    }

                });
    }


}
