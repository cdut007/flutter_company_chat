package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.baseui.BaseActivity;

import java.util.Timer;
import java.util.TimerTask;


public class MyLocation {


    private static final int REQUEST_CODE_LOCATION = 0x90;
    private Timer timer1;
    private LocationManager lm;
    private LocationResult locationResult;
    boolean gps_enabled=false;
    boolean network_enabled=false;
    boolean isWifi=false;

    private BaseActivity mContext;

    public boolean getLocation(BaseActivity context, LocationResult result,boolean isLong)
    {
        //I use LocationResult callback class to pass location value from MyLocation to user code.

    	this.mContext = context;
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService( Context.CONNECTIVITY_SERVICE );

	    NetworkInfo wifiNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);


	    if (wifiNetInfo != null&&wifiNetInfo.isConnected())   //WIFI
	    {
	    	isWifi=true;
	    	Log.i("MyLocation", "isWifi : "+isWifi);

	    }else{

	    	Log.i("MyLocation", "isWifi : "+isWifi);

	    }

        locationResult=result;
        if(lm==null)
            lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if(lm==null){

        	return false;
        }

        //exceptions will be thrown if provider is not permitted.
        try{gps_enabled=lm.isProviderEnabled(LocationManager.GPS_PROVIDER);}catch(Exception ex){}
        try{network_enabled=lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);}catch(Exception ex){}

        //don't start listeners if no provider is enabled
        if(!gps_enabled && !network_enabled)
            return false;
        cancel();
        if(gps_enabled&&!isWifi){
            boolean grant = mContext.checkPermission("location", REQUEST_CODE_LOCATION);
            if (grant) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGps);
            }
        }else{

        	gps_enabled=false;

        }
        if(network_enabled)
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListenerNetwork);
        timer1=new Timer();
        timer1.schedule(new GetLastLocation(), isLong?10000:20000);
        return true;
    }

    LocationListener locationListenerGps = new LocationListener() {
        public void onLocationChanged(Location location) {
        	if(locationResult==null){
        		return;
        	}
        	if(timer1!=null){
             timer1.cancel();

        	}
            locationResult.gotLocation(location);
            boolean grant = mContext.checkPermission("location", REQUEST_CODE_LOCATION);
            if (grant) {

                lm.removeUpdates(this);
                lm.removeUpdates(locationListenerNetwork);
            }
        }
        public void onProviderDisabled(String provider) {}
        public void onProviderEnabled(String provider) {}
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    };

    LocationListener locationListenerNetwork = new LocationListener() {
        public void onLocationChanged(Location location) {
           	if(locationResult==null){
        		return;
        	}
         	if(timer1!=null){
                timer1.cancel();

           	}
            locationResult.gotLocation(location);
            boolean grant = mContext.checkPermission("location", REQUEST_CODE_LOCATION);
            if (grant) {
                lm.removeUpdates(this);
                lm.removeUpdates(locationListenerGps);
            }
        }
        public void onProviderDisabled(String provider) {}
        public void onProviderEnabled(String provider) {}
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    };


    public void cancel() {
        boolean grant = mContext.checkPermission("location", REQUEST_CODE_LOCATION);
        if (grant) {
            lm.removeUpdates(locationListenerGps);
            lm.removeUpdates(locationListenerNetwork);
        }


    	if (timer1!=null) {
    		timer1.cancel();
		}


	}

    class GetLastLocation extends TimerTask {
        @Override
        public void run() {
           	if(locationResult==null){
        		return;
        	}
            boolean grant = mContext.checkPermission("location", REQUEST_CODE_LOCATION);
            if (grant) {
                lm.removeUpdates(locationListenerGps);
                lm.removeUpdates(locationListenerNetwork);
            }


             Location net_loc=null, gps_loc=null;
             if(gps_enabled)
                 gps_loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
             if(network_enabled)
                 net_loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

             //if there are both values use the latest one
             if(gps_loc!=null && net_loc!=null){
                 if(gps_loc.getTime()>net_loc.getTime())
                     locationResult.gotLocation(gps_loc);
                 else
                     locationResult.gotLocation(net_loc);
                 return;
             }
             Log.i("location", "gps_loc="+(gps_loc==null));

             if(gps_loc!=null){
                 locationResult.gotLocation(gps_loc);
                 return;
             }
             if(net_loc!=null){
                 locationResult.gotLocation(net_loc);
                 return;
             }

             locationResult.gotLocation(null);

        }
    }

    public static abstract class LocationResult{
        public abstract void gotLocation(Location location);
    }

}
