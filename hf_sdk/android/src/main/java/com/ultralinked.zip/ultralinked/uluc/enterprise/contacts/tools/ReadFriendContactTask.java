package com.ultralinked.uluc.enterprise.contacts.tools;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.baseui.widget.LetterListView;
import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import retrofit2.http.Query;

/**
 * Created by james on 16/7/15.
 */
public class ReadFriendContactTask {


    protected static String mSelection;

    protected static  String[] QUERY_PROJECTION ;

    protected   int ID;
    public ReadFriendContactTask() {

    }
    public ReadFriendContactTask(final Activity context, int ID) {

        mContext = context;

        this.ID = ID;
        mSelection = null;
        QUERY_PROJECTION = null;
        mLoader = new LoaderManager.LoaderCallbacks<Cursor>() {

            @Override
            public Loader<Cursor> onCreateLoader(int id, Bundle args) {
                Log.i(TAG, "onCreateLoader");
                //read the join talble of personnel and relation
                return new CursorLoader(context, FriendContract.CONTENT_URI, QUERY_PROJECTION,
                        mSelection /* selection */,
                        null /* selectionArgs */,
                        FriendContract.FriendColumn.PINYIN /* sortOrder */);
            }

            @Override
            public void onLoadFinished(Loader<Cursor> loader, final Cursor data) {

                Log.i(TAG, "onLoadFinished " + loader.getId());
                if (data == null){
                    Log.i(TAG, "onLoadFinished but cursor is null");
                }else{
                    Log.i(TAG, "onLoadFinished the cursor count is :"+data.getCount());
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            readContact(data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }



            @Override
            public void onLoaderReset(Loader<Cursor> loader) {

                Log.i(TAG, "onLoaderReset" + loader.getId());
            }
        };
    }

    String companyId;



    String searchWord;

    public void resetLoader(String searchWord) {

        this.searchWord = searchWord;
        reset();
    }

    private void reset() {
        //reset the sql ,do not remove.
        Log.i(TAG, "resetLoader " + searchWord+";companyId=="+companyId+";get the database name:"+ DbSQLHelper.DATABASE_NAME);

        if (!TextUtils.isEmpty(searchWord)){

            searchWord = searchWord.trim();
            searchWord = searchWord.replaceAll("\'", "");//fix bug
        }
        Log.i(TAG, "searchWord " + searchWord);
        if (TextUtils.isEmpty(searchWord)) {

            mSelection = null;
            QUERY_PROJECTION = null;

        } else {

            searchWord = " '%" + searchWord + "%'";
            mSelection ="("+FriendContract.FriendColumn.EMAIL + " LIKE " + searchWord
                    + " OR "+ FriendContract.FriendColumn.MOBILE + " LIKE " + searchWord
                    + " OR "+ FriendContract.FriendColumn.NICKNAME + " LIKE " + searchWord
                    + " OR "+ FriendContract.FriendColumn.REMARKNAME + " LIKE " + searchWord
                    + ")";

            QUERY_PROJECTION =  DbSQLHelper.getPeopleColumns();


        }


        if (mContext instanceof FragmentActivity) {
            Log.i(TAG, "resetLoader restartLoader");
            ((FragmentActivity) mContext).getSupportLoaderManager().restartLoader(ID, null, mLoader);
        }
    }



    public interface onContactReadFinishListener {

        void setAdapter(List<PeopleEntity> friend,char[]alphaLetters);

    }


    public final String TAG = "ReadFriendContactTask";

    LoaderManager.LoaderCallbacks<Cursor> mLoader;


    private List<PeopleEntity> mDatas_Friend = new ArrayList<>();
    protected Activity mContext;
    private onContactReadFinishListener mListener;

    public void registerListener(onContactReadFinishListener listener) {

        mListener = listener;
    }

    public void unregisterListener(Context context) {

        mContext = null;
        mListener = null;
    }

    public LoaderManager.LoaderCallbacks<Cursor> getLoader() {

        return mLoader;
    }





    public static String getFirstSpell(PeopleEntity peopleEntity) {
        String lastCatalog ;
        if (TextUtils.isEmpty(PeopleEntityQuery.getDisplayName(peopleEntity)))
            lastCatalog = "#";
        else
        {
            lastCatalog = PeopleEntityQuery.getDisplayName(peopleEntity).substring(0, 1);
        }
        return lastCatalog.toUpperCase();
    }

    public static char[] getAlphaLetters(List<PeopleEntity> peopleEntities) {


        if (peopleEntities == null) {

            return new char[]{};

        }

        Set<Character> set = new HashSet<Character>();

        List<Character> newList = new ArrayList<Character>();

        for (Iterator<PeopleEntity> iter = peopleEntities.iterator(); iter.hasNext();) {

            PeopleEntity info = iter.next();
            Character letter = '#';
            if (!TextUtils.isEmpty(PeopleEntityQuery.getDisplayName(info))){
                letter = info.getLetter();

            }

            if (set.add(letter)) {

                newList.add(letter);

            }


        }

        Collections.sort(newList);


        if (!newList.isEmpty()){
            if (newList.get(0) == '#'){
                //put # to end.
                newList.remove(0);
                newList.add('#');
            }
        }


        char [] letters = new char[newList.size()];
        for (int i = 0; i < letters.length; i++) {
            letters[i] = newList.get(i);
        }

        return letters;
    }

    /**
     * read personnel info into list of people entity
     *
     * @param cursor
     */
    protected void readContact(Cursor cursor) throws  Exception{


        if (cursor == null ||  cursor.isClosed() || cursor.getCount() == 0) {
            Log.i(TAG, " readContact null ");

            mDatas_Friend = new ArrayList<>();//use notify bundle data refresh.
            if (mListener != null&&!mContext.isFinishing()) {
                mContext.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mListener!=null)
                        mListener.setAdapter(new ArrayList<PeopleEntity>(),new char[]{});
                    }
                });
            }


            return;
        }

        mDatas_Friend.clear();

        cursor.moveToFirst();

        do {
            PeopleEntity peopleEntity =  DbSQLHelper.readPeopleBaseColumns(cursor);
            mDatas_Friend.add(peopleEntity);


        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

        sort(mDatas_Friend);
       final char[] alphaLetters = getAlphaLetters(mDatas_Friend);
        if (mListener != null&&!mContext.isFinishing()) {
            mContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    List<PeopleEntity> peopleEntities = new ArrayList<PeopleEntity>(mDatas_Friend);
                    if (mListener!=null)
                    mListener.setAdapter(peopleEntities,alphaLetters);
                }
            });
        }

    }

    private void sort(List<PeopleEntity> data) {
        try{
            Collections.sort(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
