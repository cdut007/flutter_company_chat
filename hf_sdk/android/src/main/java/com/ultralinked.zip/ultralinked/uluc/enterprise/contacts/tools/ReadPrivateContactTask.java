package com.ultralinked.uluc.enterprise.contacts.tools;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import com.ultralinked.uluc.enterprise.utils.Log;



import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;



/**
 * Created by james on 16/7/15.
 */
public class ReadPrivateContactTask extends  ReadFriendContactTask{


    public final String TAG = "ReadPrivateContactTask";


    public ReadPrivateContactTask(final Activity context, int ID) {
          super();
        mContext = context;

        mSelection = null;
        QUERY_PROJECTION = null;
        this.ID = ID;
        mLoader = new LoaderManager.LoaderCallbacks<Cursor>() {

            @Override
            public Loader<Cursor> onCreateLoader(int id, Bundle args) {
                Log.i(TAG, "onCreateLoader");
                //read the join talble of personnel and relation
                return new CursorLoader(context, PrivateContract.CONTENT_URI, QUERY_PROJECTION,
                        mSelection /* selection */,
                        null /* selectionArgs */,
                        PrivateContract.PrivateColumn.PINYIN /* sortOrder */);
            }

            @Override
            public void onLoadFinished(Loader<Cursor> loader, final Cursor data) {

                Log.i(TAG, "onLoadFinished " + loader.getId());
                if (data == null){
                    Log.i(TAG, "onLoadFinished but cursor is null");
                }else{
                    Log.i(TAG, "onLoadFinished the cursor count is :"+data.getCount());
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            readContact(data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }



            @Override
            public void onLoaderReset(Loader<Cursor> loader) {

                Log.i(TAG, "onLoaderReset" + loader.getId());
            }
        };
    }


}
