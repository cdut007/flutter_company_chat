package com.ultralinked.uluc.enterprise.login;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

/**
 * Created by ultralinked on 2016/7/1 0001.
 */
public class Login1Fragment extends BaseFragment implements View.OnClickListener{

    private LoginPresenter loginPresenter;
    private EditText etPassword;
    private EditViewPlus etUsername;
    private LoginActivity activity;
    public String mobile,password;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (LoginActivity) context;
    }

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_login1;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        etUsername=bind(R.id.etUsername);
        etPassword=bind(R.id.etPassword);
        etUsername.setHint(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.hint_mobile));
        etUsername.setCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
            }
        });//设置国家码点击事件


        TextView btLogin = bind(R.id.btRequest);
        TextView tvOTP = bind(R.id.tvOTP);
        View tvSignup = bind(R.id.tvSignup);

        tvOTP.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//        tvSignup.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//
//        SpannableStringBuilder sp=new SpannableStringBuilder(tvSignup.getText());
//
//        try{
//            sp.setSpan(new ForegroundColorSpan(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_3b5998)),0,7, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//        }catch (IndexOutOfBoundsException ex){
//            sp.setSpan(new ForegroundColorSpan(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_3b5998)),0,2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//        }
//
//        tvSignup.setText(sp);

        initListener(this, btLogin, tvOTP, tvSignup);

        initData();
    }

    private void initData() {
        String lastMobile = SPUtil.getLastMobile();
        if (!TextUtils.isEmpty(lastMobile)){
            etUsername.setText(SPUtil.getLastCode(),lastMobile);
        }else{
            etUsername.setCountryCode(SPUtil.getCode());
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG,requestCode+"  "+resultCode);
        if(data!=null)
          etUsername.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loginPresenter=new LoginPresenter(loginView,activity);
        Log.i(TAG);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tvOTP:
                activity.titleLeft.setVisibility(View.VISIBLE);
                activity
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .setCustomAnimations(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out, com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out)
                        .replace(R.id.container,new Login2Fragment(),"Login2Fragment")
                        .commit();
                break;

            case R.id.tvSignup:
                activity.titleLeft.setVisibility(View.VISIBLE);
                activity.titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.sign_up);
                activity.getSupportFragmentManager()
                        .beginTransaction()
                        .setCustomAnimations(com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out, com.holdingfuture.flutterapp.hfsdk.R.anim.left_in, com.holdingfuture.flutterapp.hfsdk.R.anim.left_out)
                        .replace(R.id.container,new SignupFragment(),"SignupFragment")
                        .commit();
                break;

            case R.id.btRequest:
                mobile=etUsername.getTextAll();
                password=etPassword.getText().toString();

                if (!TextUtils.isEmpty(mobile)){
                    if (mobile.contains("321321321")){//product
                        ApiManager.setBaseUrl(false,null);
                        System.exit(0);

                    }else if(mobile.contains("123123123")){//stage
                        ApiManager.setBaseUrl(true,null);
                        System.exit(0);

                    }else if(mobile.contains("666666")){//uc
                        ApiManager.setDomain("uc");
                        System.exit(0);

                    }else if(mobile.contains("777777")){//stage
                        ApiManager.setDomain("stage");
                        System.exit(0);

                    }else if(mobile.contains("888888")){//dev
                        ApiManager.setDomain("dev");
                        System.exit(0);

                    }

                }

                if(!NetUtil.isNetworkAvailable(activity)){
                    showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
                    return;
                }

                if(!RegexValidateUtils.checkCellphone(mobile)){
                    showToast(com.holdingfuture.flutterapp.hfsdk.R.string.error_mobile);
                    try {
                        bind(R.id.btRequest).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    showToast(R.string.empty_password);
                    try {
                        bind(R.id.btRequest).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }


                loginPresenter.login(mobile,password);
                break;
        }
    }

    LoginView loginView=new LoginView() {
        @Override
        public void loginSuccess() {
            SPUtil.saveCode(etUsername.getCountryCode());
            SPUtil.saveMobile(etUsername.getText());
            SPUtil.saveLoginModel(SPUtil.LOGIN_BY_PSD);
            Log.i(TAG,"login success from the ui login page, we need to init the DB manager for contact or other things.");
            SqliteUtils.getInstance(getActivity());//init the db manager ,
            Bundle bundle = new Bundle();
            bundle.putBoolean("login",true);
            lunchActivity(MainActivity.class,bundle);
            activity.finish();
        }

        @Override
        public void loginError(String error) {
            Log.e(TAG,error);
            activity.showToast(error);
            try {
                bind(R.id.btRequest).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void showDialog() {
            activity.showDialog();
        }

        @Override
        public void hideDialog() {
            activity.hideDialog();
        }
    };
}
