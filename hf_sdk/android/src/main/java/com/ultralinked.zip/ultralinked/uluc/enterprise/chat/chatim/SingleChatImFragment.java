package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.GuideViewHelper;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.DrawingFragment;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.chat.chatdetails.ChatDetailsActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MapUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import java.util.ArrayList;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by Chenlu on 2016/7/6 0006.
 */
public class SingleChatImFragment extends BaseChatImFragment {


    @Override
    public void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);

        goneView(subtitle);//二级标题
        goneView(saveContact);

        goneView(callPhone);

        visibleView(chatDetails);
        visibleView(title);
        visibleView(burningView);

        initListener(this, backBtn, headerImg, callPhone, chatDetails);

        burningView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                burningModule = !burningModule;
                if (burningModule) {
                    burningView.setImageResource(R.mipmap.fire_click_icon);
                } else {
                    burningView.setImageResource(R.mipmap.fire_icon);
                }
            }

        });

        title.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PaintModel paintModel = new PaintModel();
                mConversation.sendPaintInfo(paintModel.request());
                showToast(R.string.request_wait_draw);
                return false;
            }
        });

        //checkuserGuide.
        //     GuideViewHelper.checkNeedDisPlayUserGuideInfo(getActivity(),title,"remotedraw",getString(R.string.draw_title),getString(R.string.remote_draw_tips),null);

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = super.onCreateView(inflater, container, savedInstanceState);
        if (mConversation == null) {
            activity.finish();
            return view;
        }

        registerBroadCastReceiver();

        updateContactInfo();

        userId = mConversation.getContactNumber();
        isAssistant = SPUtil.isAssistant(userId);

        if (isAssistant) {
            recordBtn.setUseRecognize(true);
            AsistantService.getInstance().initSpeech();
        }
        SearchPeopleEntity();

        return view;
    }


    /**
     * 查询联系人信息
     */
    private void SearchPeopleEntity() {

        String userUrl = MapUtils.getUserIconUrl(userId);
        if (!TextUtils.isEmpty(userUrl)) {
            if (adapter != null) {
                UserInfo userInfo = SPUtil.getUserInfo();
                if (userInfo!=null){
                    String userIcon = userUrl;
                    Log.i(TAG, "set icon  url first is .sender:" + userInfo.getIcon_url() + ";receive:" + userIcon);
                    adapter.setUserIcon(userIcon, userInfo.getIcon_url());
                }

            }
        }


        Observable.create(new Observable.OnSubscribe<PeopleEntity>() {
            @Override
            public void call(final Subscriber<? super PeopleEntity> subscriber) {
                final PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userId);

                if (PeopleEntityQuery.hasFoundPeople(peopleEntity)) {

                    //  UserInfo userInfo = SPUtil.getUserInfo();
                    subscriber.onNext(peopleEntity);

                } else {

                    ArrayList<String> userIds = new ArrayList<>();
                    userIds.add(userId);
                    Log.i(TAG, "peopleEntity is null.userId="+userId);
                    RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
                        @Override
                        public void onResultFriendList(final List<PeopleEntity> entities) {
                            if (!entities.isEmpty()){
                                subscriber.onNext(entities.get(0));
                            }

                        }

                        @Override
                        public void onQueryFailed(final List<String> requestUserIds) {


                        }
                    });


                }
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<PeopleEntity>() {
            @Override
            public void call(PeopleEntity peopleEntity) {
                if (adapter != null) {
                    UserInfo userInfo = SPUtil.getUserInfo();
                    String userIcon = peopleEntity.icon_url;
                    if (userInfo!=null){
                        MapUtils.setUserIconUrl(userId, userIcon);
                        adapter.setUserIcon(userIcon, userInfo.getIcon_url());
                    }

                }
                name = PeopleEntityQuery.getDisplayName(peopleEntity);
                updateContactInfo();

            }
        });

    }

    private String name;
    private String userId;

    private void updateContactInfo() {
        if (mConversation == null || mContext == null) {
            return;
        }
        String name = this.name;
        if (TextUtils.isEmpty(name)) {
            mConversation.getContactName();
            if (TextUtils.isEmpty(name)) {
                name = mConversation.getContactNumber();
            }
        }

        if (mConversation.conversationFlag == Conversation.CONVERSATION_FLAG_PRIVATE) {
            title.setText(name + getString(R.string.chat_private));
        } else {
            title.setText(name);
        }


        ImageUtils.loadCircleImage(mContext, headerImg, ImageUtils.getDefaultContactImageResource(userId));

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (isAssistant) {
            AsistantService.getInstance().releaseSpeech();
        }
        unregisterBroadCastReceiver();
    }

    @Override
    protected void initConversation(Intent mIntent, Conversation mConversation) {

    }

    DrawingFragment drawingFragment;
    private BroadcastReceiver paintInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {

                String pintInfo = intent.getStringExtra(MessagingApi.PARAM_PAINT_INFO);
                Log.i(TAG, "paintInfoReceiver~~" + pintInfo);
                if (TextUtils.isEmpty(pintInfo)) {
                    return;
                }
                String chatIdentity = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);

                boolean flag = isCurrentConversationMsg(chatIdentity);
                if (flag) {
                    //
                    final PaintModel paintModel = new PaintModel(pintInfo);
                    int action = paintModel.getPaintAction();
                    switch (action) {
                        case PaintModel.REQUEST: {
                            DialogManager.showOKCancelDialog(mContext, "", getString(R.string.accept_draw_tips), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    mConversation.sendPaintInfo(paintModel.accept());//accept
                                }
                            }, null);

                        }
                        break;
                        case PaintModel.ACCEPT: {
                            //dismiss request dialog or show drawWindow.
                            drawingFragment = DrawingFragment.getInstance(mConversation);
                            drawingFragment.show(activity.getFragmentManager(), "drawingFragment_dialog");
                            mConversation.sendPaintInfo(paintModel.display());//accept
                        }
                        break;
                        case PaintModel.DISPLAY: {
                            //dismiss request dialog or show drawWindow.
                            drawingFragment = DrawingFragment.getInstance(mConversation);
                            drawingFragment.show(activity.getFragmentManager(), "drawingFragment_dialog");
                        }
                        break;
                        case PaintModel.DRAW: {
                            if (drawingFragment != null && drawingFragment.isAdded()) {
                                drawingFragment.updateDraw(paintModel.getDrawData());
                            }

                        }
                        break;
                    }

                } else {
                    Log.i(TAG, "paintInfoReceiver not is belong to current Conversation.");
                }

            }

        }
    };


    private BroadcastReceiver ComposingStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                Log.i(TAG, "ComposingStatusReceiver~~");
                boolean composingStatus = intent.getBooleanExtra(MessagingApi.PARAM_COMPOSING_STATUS, false);
                if (!composingStatus) {
                    return;
                }
                String chatIdentity = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);

                boolean flag = isCurrentConversationMsg(chatIdentity);
                if (flag) {
                    handleComposingStatusChange(composingStatus);
                } else {
                    Log.i(TAG, "not is belong to current Conversation.");
                }

            }

        }
    };

    private void handleComposingStatusChange(boolean isComposing) {

        Log.i(TAG, "composing....");

    }

    @Override
    protected void registerBroadCastReceiver() {
        super.registerBroadCastReceiver();
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(ComposingStatusReceiver, new IntentFilter(MessagingApi.EVENT_COMPOSING));// 注册正在输入的广播
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(paintInfoReceiver, new IntentFilter(MessagingApi.EVENT_PAINT));// 注册paint, request accept,draw.

    }

    @Override
    protected void unregisterBroadCastReceiver() {
        super.unregisterBroadCastReceiver();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(ComposingStatusReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(paintInfoReceiver);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
            case R.id.header_img:
//                showToast("click header img");
                break;
            case R.id.call_phone:
//                showToast("call phone");
                /**
                 * CallDialog.getInstance(mDetailEntity.mobile,mDetailEntity.name,mDetailEntity.icon_url).show(getFragmentManager(), "call_dialog");

                 */
                PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(mConversation.getContactNumber());
                if (peopleEntity == null) {
                    Log.i(TAG, "can not find the people info.");
                    return;
                }
                CallDialog callDialog = CallDialog.getInstance(peopleEntity.mobile, PeopleEntityQuery.getDisplayName(peopleEntity), peopleEntity.icon_url);
                callDialog.setCallUserId(peopleEntity.subuser_id);
                callDialog.show(activity.getFragmentManager(), "call_dialog");


                break;
            case R.id.chat_details:
                ChatDetailsActivity.launchActivityForResult(this, mConversation.getConversationId(), userId, false, REQUEST_CODE_FOR_CHAT_DETAILS);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null || resultCode != Activity.RESULT_OK) {
            Log.i(TAG, "resultCode:" + resultCode + " requestCode:" + requestCode + " data:" + data);
            return;
        }
        if (requestCode == REQUEST_CODE_FOR_CHAT_DETAILS) {
            if (data.getBooleanExtra("clear_all_history", false)) {
                adapter.removeAllChatHistoryMessage();
                Log.i(TAG, " remove all chat history msgs.");
            }
        }

    }

    public void onNewIntent(Bundle data) {
        Log.i(TAG, "onNewIntent~~~");

        int launchFlag = data.getInt(Constants.LAUNCH_FLAG);


        String chatIdentity = data.getString(Constants.PHONE_NUMBER_KEY);
        mConversation = MessagingApi.getConversation(chatIdentity);
        if (mConversation == null) {
            Log.e(TAG, "get mConversation is null from onNewIntent.");
            return;
        }
        super.onNewIntent(data);

        if (Intent.FLAG_ACTIVITY_CLEAR_TOP == launchFlag) {
            //re layout info.
        }
        updateContactInfo();

        adapter.removeAllChatHistoryMessageInMemoryCache();

        userId = mConversation.getContactNumber();
        SearchPeopleEntity();

        recyclerView.swapAdapter(adapter, false);
        initData();
        chatModule.refresh(mConversation);
    }

    @Override
    public Message.Options getMsgOption() {
        Message.Options messageOptions = new Message.Options();

        if (isAssistant) {
            messageOptions.messageEncrypt = false;
        }

        if (burningModule) {
            //messageOptions.messageFlag = Message.MESSAGE_FLAG_BURNING;
            return messageOptions;
        } else {
            return messageOptions;
        }

    }
}
