package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;


public class SideBar extends View {
	private char[] l;
	private SectionIndexer sectionIndexter = null;
	private ListView list;
	private TextView mDialogText;
	private int m_nItemHeight = ScreenUtils.dp2px(getContext(), 15);
	private int choose = -1;

	public SideBar(Context context) {
		super(context);
		init();
	}

	public SideBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	private void init() {
		l = new char[] {};
//		l = new char[] { '#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
//				'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
//				'W', 'X', 'Y', 'Z' };
	}


	public void resetLetters(char[] alphaLetters) {
        l = alphaLetters;
		choose = -1;
		postInvalidate();
	}

	public SideBar(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}


	public void setListView(ListView _list) {
		setListView(_list,false);
	}

	public void setListView(ListView _list,boolean hasHead) {
		list = _list;
		this.hasHead = hasHead;
	}
	boolean hasHead = false;
	public void setTextView(TextView mDialogText) {
		this.mDialogText = mDialogText;
	}

	public boolean onTouchEvent(MotionEvent event) {
		super.onTouchEvent(event);

		float drawItemPos = (getMeasuredHeight() - m_nItemHeight *l.length)/2;

		int i = (int) (event.getY()-drawItemPos);


		int idx = i / m_nItemHeight;
		if (idx >= l.length) {
			idx = l.length - 1;
		} else if (idx < 0) {
			idx = 0;
		}

		if (l.length <=0 ){
			return  false;
		}

		if (event.getAction() == MotionEvent.ACTION_DOWN
				|| event.getAction() == MotionEvent.ACTION_MOVE) {
			mDialogText.setVisibility(View.VISIBLE);
			mDialogText.setText("" + l[idx]);
			choose = idx;
			ListAdapter adapter = list.getAdapter();

			if (sectionIndexter == null) {
				if (adapter instanceof  HeaderViewListAdapter){
					HeaderViewListAdapter ha = (HeaderViewListAdapter) list
							.getAdapter();
					sectionIndexter = (SectionIndexer) ha.getWrappedAdapter();
					hasHead = true;

				}else{

					sectionIndexter = (SectionIndexer) adapter;
				}

			}



			int position = sectionIndexter.getPositionForSection(l[idx]);

			if (hasHead){
				position = position + 1;
			}

			if (position == -1) {
				return true;
			}


			try {
				list.setSelection(position);
			}catch (Exception e){
				e.printStackTrace();
			}
		} else {
			choose = -1;
			mDialogText.setVisibility(View.INVISIBLE);
		}
		return true;
	}

	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setColor(getResources().getColor(R.color.gray));
		paint.setTextSize(ScreenUtils.dp2px(getContext(), 12));
		// paint.setTextSize(20);
		// paint.setColor(0xff595c61);
		Typeface font = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
		paint.setTypeface(font);
		paint.setFlags(Paint.ANTI_ALIAS_FLAG);
		paint.setTextAlign(Paint.Align.CENTER);
		float widthCenter = getMeasuredWidth() / 2;
		int layoutHeight = getMeasuredHeight();
		float drawItemPos = (layoutHeight - m_nItemHeight *l.length)/2;
		if (drawItemPos<0){
			drawItemPos = 0;
		}
		for (int i = 0; i < l.length; i++) {
			canvas.save();
			canvas.drawText(String.valueOf(l[i]), widthCenter, drawItemPos + m_nItemHeight
					+ (i * m_nItemHeight), paint);

			if (i == choose) {
				paint.setColor(getResources().getColor(R.color.colorPrimary));
				//paint.setFakeBoldText(true);
			}else {
				paint.setColor(getResources().getColor(R.color.gray));
			}
			canvas.restore();
		}
		super.onDraw(canvas);
	}

}
