package com.ultralinked.uluc.enterprise.contacts;



import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.ContentObserver;

import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.more.CreateCompanyActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.chat.group.GroupChatListActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadContactTask;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.AddNewContactActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.external.ExternalContactDispalyActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.orgnization.OrganizationActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.pendinglist.FragmentPendingInviteList;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class FragmentCompanyContacts extends BaseFragment implements View.OnClickListener, ReadContactTask.onContactReadFinishListener {

    public static final String CURRENT_COMPANY_ID = "_id";

    private ReadContactTask mReadContactTask;
    private String mSearchWord;
    //the choosed company

    private static final int LOADER_ID = 23;

    private ListView mExpandableListView;

    private static final String TAG = "FragmentCompanyContacts";

    private ContentObserver contactChangeObserver;
    private Parcelable listState;


    @Override
    public int getRootLayoutId() {
        return R.layout.contacts_company_layout;
    }


    View newContactBtn;
    View groupChatBtn;
    View organizationBtn;

    EditText mSearch_edittext;
    TextView chooseCompanyEdt;
    MainActivity mainActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mainActivity = (MainActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        searchByCompany();
    }


    BadgeView badgeView;

    private SideBar indexBar;
    private TextView mDialogText;
    private WindowManager mWindowManager;

    @Override
    public void initView(Bundle savedInstanceState) {

        mExpandableListView = bind(R.id.expandable_list_view);


        mWindowManager = (WindowManager) getActivity()
                .getSystemService(Context.WINDOW_SERVICE);

        mDialogText = (TextView) LayoutInflater.from(getActivity()).inflate(
                R.layout.side_bar_list_position, null);
        mDialogText.setVisibility(View.INVISIBLE);
        indexBar = bind(R.id.sideBar);
        indexBar.setListView(mExpandableListView,true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        try{
            mWindowManager.addView(mDialogText, lp);
            indexBar.setTextView(mDialogText);
        }catch (Exception e){
            e.printStackTrace();
        }


        View layout_head = getActivity().getLayoutInflater().inflate(
                R.layout.contacts_top_header, null);
        mExpandableListView.addHeaderView(layout_head);


        newContactBtn = layout_head.findViewById(R.id.new_contact);
        groupChatBtn =  layout_head.findViewById(R.id.group_chat);
        organizationBtn = layout_head.findViewById(R.id.organization);
        badgeView = (BadgeView) layout_head.findViewById(R.id.organization_badge);



        //set effect
        ImageUtils.buttonEffect(newContactBtn);
        ImageUtils.buttonEffect(groupChatBtn);
        ImageUtils.buttonEffect(organizationBtn);




        bind(R.id.choose_company_view).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!SPUtil.getUserHasCompany()){
                    Intent intent = new Intent(getActivity(), CreateCompanyActivity.class);
                    startActivity(intent);
                    return;
                }
                showDailog();
            }
        });

        bind(R.id.choose_company_edt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!SPUtil.getUserHasCompany()){
                    Intent intent = new Intent(getActivity(), CreateCompanyActivity.class);
                    startActivity(intent);
                    return;
                }
                showDailog();
            }
        });

       chooseCompanyEdt = bind(R.id.choose_company_edt);





        initListener(this, R.id.searchParent);

        initListener(this,newContactBtn, groupChatBtn, organizationBtn);

        try {
            initExpandListView();
        } catch (Exception e) {
            e.printStackTrace();
        }

        chooseCompanyEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSearch_edittext = bind(R.id.search_edittext);
        mSearch_edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (mReadContactTask != null) {

                    if (TextUtils.isEmpty(s)) {
                        mSearchWord = "";
                        mReadContactTask.resetLoader(null);
                    } else {
                        mSearchWord = s.toString();
                        mReadContactTask.resetLoader(mSearchWord);
                    }

                }
                //todo:expand the list

            }
        });



    }



    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
    }

    private void searchByCompany() {

        if(TextUtils.isEmpty(CompanySelector.getInstance(getContext()).getCompanyName())) {
            showDailog();
        }

        if (mReadContactTask != null) {

            String select = " '" + CompanySelector.getInstance(getContext()).getCompanyID() + "' ";

            mReadContactTask.restCompany(select);


        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.i(TAG,"onActivityCreated");
        mReadContactTask = new ReadContactTask(getActivity(), LOADER_ID);
        mReadContactTask.registerListener(this);

        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, mReadContactTask.getLoader());

        //show last time
        updateCompanyInfo(CompanySelector.getInstance(getContext()).getCompanyName());
        Uri uri = PersonnelContract.CONTENT_URI;
        contactChangeObserver = new ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri,true,contactChangeObserver);
    }

    private void updateCompanyInfo(String companyName) {
        String displayCompanyName = getString(R.string.my_company);
        if (!TextUtils.isEmpty(companyName)){
            displayCompanyName = companyName;
        }
       // TextView  companyDisplay = (TextView) organizationBtn.findViewById(R.id.organization_text);
        chooseCompanyEdt.setText(displayCompanyName);

        searchByCompany();
    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
        }

    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }
        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG,"contact hasChanged..");
            searchByCompany();
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            mWindowManager.removeView(mDialogText);
        }catch (Exception e){
            e.printStackTrace();
        }

        mReadContactTask.unregisterListener(getContext());
        getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID);
        closePopWindow();
        closeDialog();
        if (contactChangeObserver!=null){
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }
    }


    private int sign = -1;

    private  boolean priviteModelChecked;

    @Override
    public void onClick(View v) {

        String selectCompany = CompanySelector.getInstance(getContext()).getCompanyName();

        switch (v.getId()) {


            case R.id.new_contact:

                showPopWindow();

                break;
            case R.id.group_chat:
//                showToast("Group chat");
                GroupChatListActivity.launchActivity(getActivity());

                break;
            case R.id.organization:

                if (TextUtils.isEmpty(selectCompany)) {
                    showDailog();
                    return;
                }

               if (!SPUtil.getUserHasCompany()){
                   Intent intent = new Intent(getActivity(), CreateCompanyActivity.class);
                   startActivity(intent);
               }else{
                Intent intent = new Intent(getActivity(), OrganizationActivity.class);
                intent.putExtra(CURRENT_COMPANY_ID, CompanySelector.getInstance(getContext()).getCompanyID());
                startActivity(intent);
            }
                //showToast("Organization");
                break;

//            case R.id.external:
//                if (TextUtils.isEmpty(selectCompany)) {
//                    showDailog();
//                    return;
//                }
//                Intent intent2 = new Intent(getActivity(), ExternalContactDispalyActivity.class);
//                intent2.putExtra(CURRENT_COMPANY_ID, CompanySelector.getInstance(getContext()).getCompanyID());
//                startActivity(intent2);
//
//                //showToast("external");
//                break;


            case R.id.searchParent:
                mSearch_edittext.requestFocus();
                KeyBoardUtils.openKeybord(mSearch_edittext, getActivity());
                break;
        }

    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);


        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }




    @Override
    public void onResume() {
        super.onResume();

        Log.i(TAG, " onResume ");
        updateBadge();

    }


    public void updateBadge() {
        if (!isAdded()){
            return;
        }
        if (badgeView!=null&&FragmentPendingInviteList.mInviteList.size() > 0){
            badgeView.setVisibility(View.VISIBLE);
            badgeView.show();
            badgeView.setText(""+ FragmentPendingInviteList.mInviteList.size());
        }else{
            badgeView.hide();
            badgeView.setVisibility(View.GONE);
        }
    }

    CompanyAdapter mExpandableListAdapter;
//    ArrayList<String> dataListTitle = new ArrayList<>();
   HashMap<String, List<PeopleEntity>> dataListDetail = new HashMap<>();



    private void initExpandListView() throws Exception{
        mExpandableListAdapter = new CompanyAdapter(getActivity());

        mExpandableListView.setAdapter(mExpandableListAdapter);

        if (listState!=null){
            mExpandableListView.onRestoreInstanceState(listState);
        }
        mExpandableListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Adapter personalAdaper = parent.getAdapter();
                DetailPersonActivity.gotoDetailPersonActivity(getActivity(), (PeopleEntity) personalAdaper.getItem(position));
            }
        });

//        mExpandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
//
//            @Override
//            public void onGroupExpand(int groupPosition) {
//
//            }
//        });
//
//        mExpandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
//
//            @Override
//            public void onGroupCollapse(int groupPosition) {
//
//
//            }
//        });

//        mExpandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
//            @Override
//            public boolean onChildClick(ExpandableListView parent, View v,
//                                        int groupPosition, int childPosition, long id) {
//                final PeopleEntity temp = mExpandableListAdapter.getChild(groupPosition, childPosition);
//
//                DetailPersonActivity.gotoDetailPersonActivity(getActivity(), temp);
//
//                return false;
//            }
//        });
        //      设置分组单击监听事件
//        mExpandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
//            @Override
//            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
//                boolean groupExpanded = parent.isGroupExpanded(groupPosition);
//                if (groupExpanded) {
//                    parent.collapseGroup(groupPosition);
//                } else {
//                    parent.expandGroup(groupPosition, true);
//                }
//                mExpandableListAdapter.setIndicatorState(groupPosition, groupExpanded);
//
//                //when higher group is closed
//                int lastGroopPosition = groupPosition > 0 ? groupPosition - 1 : 0;
//                boolean lastGroupExpanded = parent.isGroupExpanded(lastGroopPosition);
//                if (!lastGroupExpanded) {
//                    mExpandableListView.smoothScrollToPosition(0);
//                }
//                return true;
//            }
//        });
    }


    @Override
    public void setAdapter(List<PeopleEntity> internal, char[]alphaLetters) {
        Log.i(TAG, "setAdapter");
        if (isDetached() || getActivity() == null || getActivity().isFinishing()){
            return;
        }
//        dataListDetail.clear();
//        dataListDetail.put(mainActivity.getString(R.string.internal), internal);
//        dataListDetail.put(mainActivity.getString(R.string.External), external);
//
//        dataListTitle = new ArrayList<String>();
//        dataListTitle.add(mainActivity.getString(R.string.internal));
//        dataListTitle.add(mainActivity.getString(R.string.External));
        mExpandableListAdapter.setData(internal);
        indexBar.resetLetters(alphaLetters);

//        if (mExpandableListAdapter.getGroupCount()>0){
//            mExpandableListView.expandGroup(0);
//        }


    }


    @Override
    protected void onSaveState(Bundle outState) {
        super.onSaveState(outState);
        Log.i(TAG,"contact onSaveState..");
        listState = mExpandableListView.onSaveInstanceState();
        outState.putParcelable("listState",listState);
      //  outState.putStringArrayList("dataTitle",dataListTitle);
        outState.putParcelableArrayList("companyMembers", (ArrayList<PeopleEntity>) dataListDetail.get(mainActivity.getString(R.string.internal)));
    }

    @Override
    protected void onRestoreState(Bundle savedInstanceState) {
        super.onRestoreState(savedInstanceState);
            Log.i(TAG,"contact onRestoreState..");

        listState = savedInstanceState.getParcelable("listState");

//         ArrayList<String> titleList = savedInstanceState.getStringArrayList("dataTitle");
//        if (titleList!=null){
//            dataListTitle = titleList;
//        }else{
//            Log.i(TAG,"contact onRestoreState..title data is null ");
//        }

        ArrayList<PeopleEntity> internal = savedInstanceState.getParcelableArrayList("companyMembers");
        if (internal!=null){
            dataListDetail.put(mainActivity.getString(R.string.internal), internal);
        }else{
            Log.i(TAG,"contact onRestoreState..data is null");
        }
    }



    ChoicePopWindow popupWindow;

    private void showPopWindow() {

        popupWindow = new ChoicePopWindow(getActivity());
        popupWindow.setAnimationStyle(R.style.popwin_anim_style);

        // 设置popWindow弹出窗体可点击，这句话必须添加，并且是true
        popupWindow.setFocusable(true);

        popupWindow.showAtLocation(getView().getRootView().findViewById(R.id.left_back), Gravity.BOTTOM, 0, 0);

        popupWindow.setListener(new ChoicePopWindow.onMenuClickListener() {
            @Override
            public void onChoiceSelect(int chooseType, int inputType) {

                Intent intent = new Intent(getActivity(), AddNewContactActicity.class);
                intent.putExtra("chooseType", chooseType);
                intent.putExtra("inputType", inputType);
                Log.i(TAG, "chooseType " + chooseType + "  inputType " + inputType);
                startActivity(intent);
                popupWindow.dismiss();
            }
        });

    }

    public void closePopWindow() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
            popupWindow = null;
        }
    }

    AlertDialog mChooseCompanyDialog;

    public void showDailog() {


        if (mChooseCompanyDialog!=null){
            mChooseCompanyDialog.dismiss();
            mChooseCompanyDialog = null;
        }

            ArrayList<DepartUtils.CompanyElement> rootdata = DepartUtils.getInstance().getCompanyMap();

            final DepartUtils.CompanyElement[] arrString = rootdata.toArray(new DepartUtils.CompanyElement[rootdata.size()]);

            String[] Items = new String[arrString.length];

           int checkItem = 0;
           String companyName = CompanySelector.getInstance(getContext()).getCompanyName();
            for (int i = 0; i < arrString.length; i++) {

                Items[i] = FragmentContacts.firstLetterToUpper(arrString[i].name);
                if (Items[i]!=null && Items[i].equalsIgnoreCase(companyName)){
                    checkItem = i;
                }
            }

         if (Items.length <=0){
             //empty not find company.
             Log.i(TAG,"no company found.");
             return;
         }

          if (Items.length == 1){
              //only one.
              DepartUtils.CompanyElement item = arrString[0];
              CompanySelector.getInstance(getContext()).setChoosedCompany(item.name, item._id);
              updateCompanyInfo(item.name);
              //send company change event.
              RxBus.getDefault().post(new Object());
              return;
          }




            mChooseCompanyDialog = new AlertDialog.Builder(getContext()).setTitle(R.string.choose_a_company)
                    .setIcon(R.mipmap.contact_organization).setSingleChoiceItems(
                            Items,
                            checkItem, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    DepartUtils.CompanyElement item = arrString[which];
                                    CompanySelector.getInstance(getContext()).setChoosedCompany(item.name, item._id);
                                    updateCompanyInfo(item.name);
                                    //send company change event.
                                    RxBus.getDefault().post(new Object());
                                    dialog.dismiss();
                                    mChooseCompanyDialog = null;
                                }
                            }).show();
            mChooseCompanyDialog.setCancelable(true);

    }

    public void closeDialog() {
        if (mChooseCompanyDialog != null) {
            mChooseCompanyDialog.dismiss();
        }
        mChooseCompanyDialog = null;
    }


}
