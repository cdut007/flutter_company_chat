package com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Locale;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 16/7/19.
 */

public class FragmentAddContactMannual extends com.trello.rxlifecycle.components.support.RxFragment {

    public static final String ARG_NAME = "contact_name";
    public static final String ARG_PHONE = "contact_phone";
    public static final String ARG_ENTITY = "contact_entity";
    public static final String ARG_INTERNAL_OR_EXTERNAL = "internal_or_external";

    public static final int RERUESTCODE_SELECT_DEPARMENT = 119;
    public static final String KEY_ADDNEW_COM_NAME = "key2getCompanyName";
    public static final String KEY_ADDNEW_DEPART_NAME = "key2getDepartName";
    public static final String KEY_ADDNEW_DEPART_ID = "key2getDepartId";
    private static final String TAG = "AddContactMannual";


    private TextView tvCompanyInput, tvDepartInput;
    private EditText tvNameInput, tvEmailInput;
    private EditViewPlus tvMobileInput;
    private Button btnInvite;
    private TextView titleCenter;

    private int Interl_OR_External = -1;
    private String mDepartIDSelected;
    private TextView tvCompany, tvDepart;
    private View view;




    public static FragmentAddContactMannual newInstance(PeopleEntity entity,String name, String phone, int chooseType) {
        // Create new instance of this fragment
        final FragmentAddContactMannual fragment = new FragmentAddContactMannual();

        // Create and populate the args bundle
        final Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        args.putString(ARG_PHONE, phone);
        args.putParcelable(ARG_ENTITY,entity);
        args.putInt(ARG_INTERNAL_OR_EXTERNAL, chooseType);
        // Assign the args bundle to the new fragment
        fragment.setArguments(args);

        // Return fragment
        return fragment;
    }



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_add_contact_mannual, container, false);

        initTitleBar(view);

        tvNameInput = (EditText) view.findViewById(R.id.tvNameInput);
        tvMobileInput = (EditViewPlus) view.findViewById(R.id.tvMobileInput);
        tvMobileInput.setCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
            }
        });

        tvCompany = (TextView) view.findViewById(R.id.tvCompany);
        tvDepart = (TextView) view.findViewById(R.id.tvDepart);

        tvCompanyInput = (TextView) view.findViewById(R.id.tvCompanyInput);
        tvDepartInput = (TextView) view.findViewById(R.id.tvDepartInput);

        tvEmailInput = (EditText) view.findViewById(R.id.tvEmailInput);

        btnInvite = (Button) view.findViewById(R.id.btnInvite);
        btnInvite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addToDepartment();
            }
        });

        tvCompanyInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                goToSelectContact();
            }
        });
        tvDepartInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                goToSelectContact();
            }
        });
        return view;
    }

    /**
     * Interl_OR_External paramters to determine which department to show
     */

    private void goToSelectContact() {
        Intent intent = new Intent(getActivity(), SelectDepActivity.class);
        intent.putExtra("Interl_OR_External", Interl_OR_External);
        startActivityForResult(intent, RERUESTCODE_SELECT_DEPARMENT);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setContact();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RERUESTCODE_SELECT_DEPARMENT) {
            if (data != null) {

                String Company = data.getStringExtra(KEY_ADDNEW_COM_NAME);
                String Department = data.getStringExtra(KEY_ADDNEW_DEPART_NAME);
                mDepartIDSelected = data.getStringExtra(KEY_ADDNEW_DEPART_ID);

                tvCompanyInput.setText(Company);
                tvDepartInput.setText(Department);
            }

        }else if(requestCode == CountryCodeChooseActivity.REQUEST_COUNTRY_CODE){
            com.ultralinked.uluc.enterprise.utils.Log.i(TAG,requestCode+"  "+resultCode);
            if(resultCode == Activity.RESULT_OK && data!=null)
                tvMobileInput.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
        }
    }

    private void setContact() {

        if (getArguments() == null) {

            return;
        }


        String name = getArguments().getString(ARG_NAME);
        String phone = getArguments().getString(ARG_PHONE);
        Interl_OR_External = getArguments().getInt(ARG_INTERNAL_OR_EXTERNAL);

        tvNameInput.setText(name);
        try {
            // phone must begin with '+'
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
            String currentLanguage = Locale.getDefault().getLanguage();
            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(phone,currentLanguage);
            int countryCode = numberProto.getCountryCode();
            if (countryCode>-1){
                tvMobileInput.setCountryCode("+"+countryCode);
            }
            phone = numberProto.getNationalNumber()+"";
        } catch (Exception e) {
            System.err.println("NumberParseException was thrown: " + android.util.Log.getStackTraceString(e));
        }

        tvMobileInput.setMobile(phone);

        PeopleEntity peopleEntity = getArguments().getParcelable(ARG_ENTITY);
        String companyId = null;

        String companyName = null;
        if (peopleEntity!=null){
//            "department_id": "DEPART1bce9ab8-3d0c-11e6-91d3-22000aae16d4",
//                    I/FragmentPendingInvite(15954):       "domain_name": "uc",
//                    I/FragmentPendingInvite(15954):       "email": "rf",
//                    I/FragmentPendingInvite(15954):       "inviter_id": "subusr1473268852002",
//                    I/FragmentPendingInvite(15954):       "mobile": "88880009",
//                    I/FragmentPendingInvite(15954):       "name": "88880009",
//                    I/FragmentPendingInvite(15954):       "status": "new"
            companyId = peopleEntity.companyid;
            companyName = peopleEntity.companyName;
            tvEmailInput.setText(peopleEntity.email);
            if (TextUtils.isEmpty(companyId)){
                companyId = CompanySelector.getInstance(getContext()).getCompanyID();
                companyName = CompanySelector.getInstance(getContext()).getCompanyName();
            }
        }else{
             companyId = CompanySelector.getInstance(getContext()).getCompanyID();

             companyName = CompanySelector.getInstance(getContext()).getCompanyName();
        }


        if (Interl_OR_External == ChoicePopWindow.CHOOSE_INTERNAL) {
            titleCenter.setText(getString(R.string.add_contact_titel_add_company_staff));
            tvCompanyInput.setText(companyName);
            mDepartIDSelected = companyId;

        } else if (Interl_OR_External == ChoicePopWindow.CHOOSE_EXTERNAL) {
            titleCenter.setText(getString(R.string.add_contact_titel_add_client));
            tvCompanyInput.setText(companyName);
            mDepartIDSelected = companyId;
            view.findViewById(R.id.tvDepartInput_layout).setVisibility(View.GONE);
            view.findViewById(R.id.tvDepartInput_layout_line).setVisibility(View.GONE);
        } else {
            titleCenter.setText(getString(R.string.add_contact_titel_add_private_contact));
        }

    }

    private void initTitleBar(View view) {

        ImageView left_back = (ImageView) view.findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });

        titleCenter = (TextView) view.findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.add_contact_titel_add_client));

        TextView titleRight = (TextView) view.findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }


    private void addToDepartment() {

        String name = tvNameInput.getText().toString();
        String mobile = tvMobileInput.getTextAll();
        String company = tvCompanyInput.getText().toString();
        String dept = tvDepartInput.getText().toString();
        String email = tvEmailInput.getText().toString();

        Log.i(TAG, "mDepartIDSelected " + mDepartIDSelected);

        // TODO: 16/8/1 add contact to internal/external api

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(getContext().getApplicationContext(), getResources().getString(R.string.add_contact_name_empty), Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mobile)) {
            Toast.makeText(getContext().getApplicationContext(), getString(R.string.add_contact_mobile_empty), Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(company)) {
            Toast.makeText(getContext().getApplicationContext(), getString(R.string.add_contact_company_empty), Toast.LENGTH_SHORT).show();
            return;
        }
//        if (TextUtils.isEmpty(dept) && Interl_OR_External == ChoicePopWindow.CHOOSE_INTERNAL) {
//            Toast.makeText(getContext().getApplicationContext(), getString(R.string.add_contact_dept_empty), Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (TextUtils.isEmpty(email)) {
//            Toast.makeText(getContext().getApplicationContext(), getString(R.string.add_contact_email_empty), Toast.LENGTH_SHORT).show();
//            return;
//        }
        if (Interl_OR_External == ChoicePopWindow.CHOOSE_INTERNAL) {
            //choose internal

            InvitePeople(name, mobile, email);

        } else if (Interl_OR_External == ChoicePopWindow.CHOOSE_EXTERNAL) {
            //choose external

            InvitePeople(name, mobile, email);

        }

        Log.i(TAG, "ARG_INTERNAL_OR_EXTERNAL " + Interl_OR_External);


    }

    private void InvitePeople(String name, String mobile, String email) {
        String str1 = getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
        progressDialog.show();

        ApiManager.getInstance().inVite(name,mobile, email, mDepartIDSelected)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"InvitePeopleComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        progressDialog.cancel();
                        String eMsg = HttpErrorException.handErrorMessage(e);

                        Toast.makeText(getContext(), eMsg+"", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "invite error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        progressDialog.cancel();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                Toast.makeText(getContext(), R.string.add_contact_invite_success, Toast.LENGTH_SHORT).show();
                                ShareUtils.tellFriend(getContext(),object.optString("content"));
                                //notify the contact refresh.
                                RxBus.getDefault().post(new PeopleEntity());
                            }else {
                                Toast.makeText(getContext(), R.string.add_contact_invite_failed, Toast.LENGTH_SHORT).show();
                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "invite  " + rs);
                    }

                });
    }


}
