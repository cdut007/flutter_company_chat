package com.ultralinked.uluc.enterprise.contacts.contract;

import java.io.Serializable;

/**
 * Created by ultralinked on 16/10/6.
 */

public class Roles implements Serializable{
    public String department_id;
    public String role_name;
    public String role_type;
}
