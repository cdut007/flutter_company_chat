package com.ultralinked.uluc.enterprise.moments.widgets.videolist.visibility.scroll;

import com.ultralinked.uluc.enterprise.moments.widgets.videolist.visibility.items.ListItem;

/**
 *
 * @author Wayne
 */
public interface ItemsProvider {

    ListItem getListItem(int position);

    int listItemSize();

}
