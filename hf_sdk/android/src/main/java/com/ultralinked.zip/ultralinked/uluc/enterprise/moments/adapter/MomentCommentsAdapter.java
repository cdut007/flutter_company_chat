package com.ultralinked.uluc.enterprise.moments.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendListener;
import com.ultralinked.uluc.enterprise.moments.bean.NewMomentItem;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Created by ultralinked.
 */
public class MomentCommentsAdapter extends MyBaseAdapter<NewMomentItem> {

     protected String TAG = "MomentCommentsAdapter";

    private final Context mcontext;



    public MomentCommentsAdapter(Context context) {
        super(context, R.layout.item_moment_comment,new ArrayList<NewMomentItem>());
        mcontext = context;
    }



    @Override
    public void setHolder(MyHolder holder, NewMomentItem momentItem) {


        ImageView img_avar =  holder.getView(R.id.img_photo);
        TextView txt_name =  holder.getView( R.id.txt_name);
        TextView txt_msg =  holder.getView( R.id.txt_msg);

        txt_name.setText(momentItem.nickname);
        txt_msg.setText(momentItem.comment_content);
        ImageUtils.loadCircleImage(mcontext,img_avar, momentItem.icon_url, ImageUtils.getDefaultContactImageResource(momentItem.nickname));





    }


}
