package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.media.AudioManager;

import com.ultralinked.voip.rtcapi.rtcapij;

/**
 * Created by ultralinked on 2016/7/26 0026.
 */
public class SpeakerMuteUtil {

    private AudioManager audioManager;
    private final int oldMode;
    private Context context;
    private int currVolume = 0;

    public SpeakerMuteUtil(Context context){
        this.context=context;
        audioManager= (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        oldMode=audioManager.getMode();
    }

    /**
     * 关闭扬声器
     */
    public void closeSpeaker() throws Exception{
        if(audioManager!=null && audioManager.isSpeakerphoneOn()){
            audioManager.setSpeakerphoneOn(false);
            audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, currVolume, AudioManager.STREAM_VOICE_CALL);
            rtcapij.netrtc_set_config("aec", "handset");
        }
    }

    /**
     * 打开扬声器
     */
    public void openSpeaker() throws Exception{
        if (audioManager!=null && !audioManager.isSpeakerphoneOn()) {
            //setSpeakerphoneOn() only work when audio mode set to MODE_IN_CALL.
            audioManager.setMode(AudioManager.MODE_IN_CALL);
            audioManager.setSpeakerphoneOn(true);
            audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), AudioManager.STREAM_VOICE_CALL);
            rtcapij.netrtc_set_config("aec", "handsfree");
        }
    }


    public void reset(){
        audioManager.setMode(oldMode);
        audioManager.setSpeakerphoneOn(false);
    }

    public void closeMute(){
        if(audioManager!=null && !audioManager.isMicrophoneMute()){
            audioManager.setMicrophoneMute(true);
        }
    }

    public void openMute(){
        if(audioManager!=null && audioManager.isMicrophoneMute()){
            audioManager.setMicrophoneMute(false);
        }
    }
}
