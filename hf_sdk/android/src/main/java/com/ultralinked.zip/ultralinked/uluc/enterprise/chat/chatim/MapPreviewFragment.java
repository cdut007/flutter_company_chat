package com.ultralinked.uluc.enterprise.chat.chatim;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.utils.LocationUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.LocationMessage;
import com.ultralinked.voip.api.MessagingApi;

import java.util.List;
import java.util.concurrent.ExecutionException;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public class MapPreviewFragment extends BaseFragment implements OnMapReadyCallback,GoogleMap.OnMapClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,LocationListener {
    private static final int REQUEST_CODE_FOR_LOCATION = 0x01;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;




    private BaseActivity activity;
    private ImageView back;
    private TextView title;
    private TextView send;
    private LocationRequest locationRequest;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (BaseActivity) context;
    }

    private GoogleMap googleMap;

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        googleMap.setOnMapClickListener(this);

        googleMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {

            @Override
            public void onMarkerDragStart(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                Location location = new Location(LocationManager.GPS_PROVIDER);
                LatLng latLng  = marker.getPosition();
                location.setLatitude(latLng.latitude);
                location.setLongitude(latLng.longitude);
                mLastLocation = location;
                updateToNewLocation(location);
            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }
        });

        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_CODE_FOR_LOCATION);
            return;
        }
        googleMap.setMyLocationEnabled(true);//need check permission

//        LatLng sydney = new LatLng(-34, 151);
//        googleMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_FOR_LOCATION) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) && permissions[1].equals(Manifest.permission.ACCESS_COARSE_LOCATION)
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED
                    ) {
                if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                Log.i(TAG, "set my location enable.");
                googleMap.setMyLocationEnabled(true);
            }
        } else {
            Log.i(TAG, "no location permission.");
        }

    }
    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_map;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);

        SupportMapFragment supportMapFragment = SupportMapFragment.newInstance();
        activity.getSupportFragmentManager().beginTransaction().add(R.id.fram_container, supportMapFragment).commit();
        supportMapFragment.getMapAsync(this);
        // Create an instance of GoogleAPIClient.
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(activity)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
        }

        createLocationRequest();

        return view;
    }


    @Override
    public void initView(Bundle savedInstanceState) {

        back = bind(R.id.left_back);
        title = bind(R.id.titleCenter);
        send = bind(R.id.titleRight);
        title.setText(com.holdingfuture.flutterapp.hfsdk.R.string.selecte_location);
        send.setText(com.holdingfuture.flutterapp.hfsdk.R.string.send);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mLastLocation == null) {
                    showToast(getString(R.string.locating));
                    return;
                }
                Intent data = new Intent();
                data.putExtra("location_type", "google");
                data.putExtra("lastLocation", mLastLocation);
                activity.setResult(Activity.RESULT_OK, data);
                activity.finish();
            }
        });


    }

    @Override
    public void onMapClick(LatLng latLng) {
        if (mLastLocation == null) {
            mLastLocation=new Location(LocationManager.GPS_PROVIDER);
        }

        mLastLocation.setLatitude(latLng.latitude);
        mLastLocation.setLongitude(latLng.longitude);
        updateToNewLocation(mLastLocation);

    }

   boolean isLocationSucc = false;
    @Override
    public void onLocationChanged(Location amapLocation) {

        if (amapLocation != null && !isLocationSucc) {
            Log.i(TAG,"onLocationChanged is.lat_lon:"+amapLocation.getLatitude()+"_"+amapLocation.getLongitude());
            mLastLocation = amapLocation;
            updateToNewLocation(amapLocation);
            isLocationSucc = true;
        } else {
            Log.i(TAG,"onLocationChanged but no update.");
        }

    }

    private void updateToNewLocation(Location amapLocation) {

        // Add a marker in Sydney and move the camera
        Log.i(TAG, "updateToNewLocation~~:" + amapLocation.getLatitude() + "  " + amapLocation.getLongitude());
        LatLng sydney = new LatLng(amapLocation.getLatitude(), amapLocation.getLongitude());
        googleMap.clear();
        MarkerOptions markerOpt = new MarkerOptions();

        markerOpt.position(sydney);
        markerOpt.title(getString(R.string.my_position));
        //markerOpt.snippet(snippt);
        //markerOpt.icon(icon)
        markerOpt.draggable(true);
        markerOpt.visible(true);
        Marker myMarker = googleMap.addMarker(markerOpt);
        myMarker.showInfoWindow();
       // googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(sydney) // Sets the center of
                // the map to ZINTUN
                .zoom(17).bearing(0) // Sets the orientation of the camera to
                // east
                .tilt(30) // Sets the tilt of the camera to 30 degrees
                .build(); // Creates a CameraPosition from the builder
        googleMap.animateCamera(CameraUpdateFactory
                .newCameraPosition(cameraPosition));
        updateNewAddress(googleMap,myMarker);
    }

    private void updateNewAddress(final GoogleMap googleMap,final  Marker myMarker) {
       final  LatLng latLng = myMarker.getPosition();
        Observable.create(new Observable.OnSubscribe<String[]>() {




            @Override
            public void call(Subscriber<? super String[]> subscriber) {

                String[] titles = LocationUtils.geocodeAddr(getActivity(),latLng.latitude,latLng.longitude);
                Log.i(TAG,"adrress:"+titles[0]+";route:"+titles[1]);
                subscriber.onNext(titles);
                subscriber.onCompleted();
            }

        })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())

                .subscribe(
                        new Observer <String[]>() {
                            @Override
                            public void onNext(String[] titles) {
                                String geocodeAddr = titles[1];
                                if (TextUtils.isEmpty(geocodeAddr)) {
                                    if (mLastLocation!=null){
                                        Bundle bundle = new Bundle();

                                        mLastLocation.setExtras(bundle);
                                    }
                                    return;
                                }
                                String route = titles[2];
                                if (mLastLocation!=null){
                                    Bundle bundle = new Bundle();
                                    bundle.putString(LocationMessage.SUBTITLE,geocodeAddr);
                                    bundle.putString(LocationMessage.TITLE,route);

                                    mLastLocation.setExtras(bundle);
                                }
                                myMarker.setSnippet(geocodeAddr);
                                myMarker.showInfoWindow();
                                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myMarker.getPosition(), 17));

                            }

                            @Override
                            public void onCompleted() {
                                Log.i(TAG,"updateNewAddress is compelete ");
                            }

                            @Override
                            public void onError(Throwable e) {
                               Log.i(TAG,"get the error info:"+ android.util.Log.getStackTraceString(e));
                            }
                        }

                );


    }


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.i(TAG,"onConnected~~");
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);
        if (mLastLocation != null) {
            Log.i(TAG, "location~~:" + mLastLocation.getLatitude() + "  " + mLastLocation.getLongitude());
            updateToNewLocation(mLastLocation);
        } else {
            Log.i(TAG,"mLastLocation is null.");
        }
        startLocation();

    }
    public void startLocation() {
        if (mGoogleApiClient.isConnected()) {
            Log.i(TAG,"mGoogleApiClient requestLocationUpdates.");

            LocationServices.FusedLocationApi.requestLocationUpdates(
                    mGoogleApiClient, locationRequest, this);
        }else{
            Log.i(TAG,"mGoogleApiClient is not connected.");
        }
    }


    private void createLocationRequest() {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG,"onConnectionSuspended~~");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.i(TAG,"onConnectionFailed~~");
    }

    @Override
    public void onStart() {
        mGoogleApiClient.connect();
        super.onStart();

    }

    @Override
    public void onStop() {
        if (mGoogleApiClient.isConnected()){
            try{

                LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient,this);
            }catch (Exception e){
                e.printStackTrace();
            }
            mGoogleApiClient.disconnect();
        }

        super.onStop();
    }
}
