package com.ultralinked.uluc.enterprise.login;

import java.util.HashMap;

/**
 * Created by ultralinked on 2016/7/6 0006.
 */
public interface LoginModel {

    void login(String username,String password);
    void refreshTokenConfig();
    void createUser(HashMap<String,String> map);
    void otpRequest(String mobile,String action, String type);
    void otpLogin(String mobile,String otp);
    void otpRegistCompany(String mobile,String company,String email,String username,String otp);
    void otpCreateCompany(String mobile,String company,String otp);
    void otpRegist(String mobile,String username,String otp);
}
