package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.ultralinked.uluc.enterprise.QrScanActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactLocalBook;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadPrivateContactTask;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.AddNewContactActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactMannual;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.secret.PrivateAdapter;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import xyz.sahildave.widget.SearchViewLayout;

public class FragmentNewFriend extends BaseFragment implements View.OnClickListener {


    private static final String TAG = "FragmentNewFriend";
    private NewFriendAdapter mNewFriendAdapter;


    protected TextView titleCenter;
    protected TextView titleRight;
    protected ImageView titleLeft;

    private String mSearchWord;

    private static final int LOADER_ID = 0x66;

    private ListView mNewFriendListView;

    private ContentObserver contactChangeObserver;
    private View layout_head;

    private static final int INVITED = 1, INVITED_BY_OTHER = 0;

    @Override
    public int getRootLayoutId() {
        return R.layout.contacts_new_friend_layout;
    }


    SearchViewLayout searchViewLayout;

    BaseActivity baseActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        baseActivity = (BaseActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadNewFriendData();
    }


    private void loadNewFriendData() {

        getFriendPendingList();
    }


    public void getFriendPendingList() {


        //load from cache frist.
        try {
            ACache mCache = ACache.get(getActivity());
            String pendingfriendList = mCache.getAsString(SPUtil.getUserID()+"_pendingfriendList");
            if (pendingfriendList != null) {

                JSONObject object = new JSONObject(pendingfriendList);
                JSONObject result = object.optJSONObject("result");
                String received = result.optJSONArray("received").toString();
                Type sToken = new TypeToken<List<PeopleEntity>>() {
                }.getType();
                Gson gson = new GsonBuilder().serializeNulls().create();
                List<PeopleEntity> pendingList = gson.fromJson(received, sToken);
                if (pendingList != null) {
                    mNewFriendAdapter.updateList(pendingList);
                }


//                String sended = result.optJSONArray("sended").toString();
//                Type sToken2 = new TypeToken<List<PeopleEntity>>() {
//                }.getType();
//                Gson gson2 = new GsonBuilder().serializeNulls().create();
//                List<PeopleEntity> pendingList2 = gson2.fromJson(sended, sToken2);


            }
        } catch (Exception e) {
            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
        }


        ApiManager.getInstance().getFriendPendingList()
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getFriendPendingListComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "get Friendpending invite  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                JSONObject result = object.optJSONObject("result");
                                String received = result.optJSONArray("received").toString();
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                List<PeopleEntity> pendingList = gson.fromJson(received, sToken);
                                if (pendingList != null) {
                                    mNewFriendAdapter.updateList(pendingList);
                                }


                                String sended = result.optJSONArray("sended").toString();
                                Type sToken2 = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson2 = new GsonBuilder().serializeNulls().create();
                                List<PeopleEntity> pendingList2 = gson2.fromJson(sended, sToken2);
                                if (pendingList2 != null) {
                                  //
                                }

                                ACache mCache = ACache.get(getActivity());
                                mCache.put(SPUtil.getUserID()+"_pendingfriendList",rs,365 * ACache.TIME_DAY);


                            }


                        } catch (JsonSyntaxException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "get Friend pending invite userInfo:  " + rs);
                    }         //请求成功

                });
    }

    RequestFriendManager requestFriendManager;

    @Override
    public void initView(Bundle savedInstanceState) {

        titleLeft = bind(R.id.left_back);
        titleRight = bind(R.id.titleRight);
        titleCenter = bind(R.id.titleCenter);
        titleCenter.setText(R.string.new_friend);
        goneView(titleRight);
        mNewFriendListView = bind(R.id.friend_list_view);
        requestFriendManager = RequestFriendManager.getInstance();

        initListView();

        selectInvitedOrByOther(INVITED_BY_OTHER);//默认选择beenInvited

        initSearchView();


    }


    private void initSearchView() {
        searchViewLayout = bind(R.id.search_view_container);
        final SearchFriendFragment searchFriendFragment = new SearchFriendFragment();
        searchViewLayout.setExpandedContentSupportFragment(getActivity(), searchFriendFragment);
        searchViewLayout.setCollapsedHint(getString(R.string.search_friend_tips));
        searchViewLayout.setExpandedHint(getString(R.string.search_friend_tips));


        //   ColorDrawable collapsed = new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        //  ColorDrawable expanded = new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.default_color_expanded));
        //   searchViewLayout.setTransitionDrawables(collapsed, expanded);
        searchViewLayout.setSearchListener(new SearchViewLayout.SearchListener() {
            @Override
            public void onFinished(String searchKeyword) {
                if (searchKeyword != null) {
                    if (searchKeyword.startsWith("+")) {
                        searchKeyword = searchKeyword.substring(1);
                    }
                    if (searchKeyword.startsWith("00")) {
                        searchKeyword = searchKeyword.substring(2);
                    }
                }
                searchFriendFragment.setSearchQuery(searchKeyword);
            }
        });

        searchFriendFragment.setOnContactSelectedListener(new FragmentAddContactLocalBook.OnContactsInteractionListener() {
            @Override
            public void onContactSelected(String name, String phone) {

                if (TextUtils.isEmpty(phone)) {
                    return;
                }

                phone = PhoneNumberUtils.normalizeNumber(phone);

                PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().queryFriendByMobileSql(phone);
                if (peopleEntity != null) {
                    //go to detail.
                    DetailPersonActivity.gotoDetailPersonActivity(mContext, peopleEntity);

                } else {
                    //invite
                    Intent intent = new Intent(mContext, AddNewFriendActicity.class);
                    peopleEntity = new PeopleEntity();
                    peopleEntity.name = name;
                    peopleEntity.nickname = name;
                    peopleEntity.mobile = phone;
                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, peopleEntity);
                    intent.putExtra(AddNewFriendActicity.KEY_QUERY_DETAIL_ENTITY, true);
                    mContext.startActivity(intent);
                }

            }

            @Override
            public void onSelectionCleared() {

            }
        });

        searchViewLayout.setOnToggleAnimationListener(new SearchViewLayout.OnToggleAnimationListener() {
            @Override
            public void onStart(boolean expanding) {
                if (expanding) {
                    searchFriendFragment.setSearchQuery("");
                    goneView(bind(R.id.top_bar));
                }
            }

            @Override
            public void onFinish(boolean expanded) {
                if (expanded) {
                    searchFriendFragment.setSearchQuery("");
                    goneView(bind(R.id.top_bar));
                } else {
                    visibleView(bind(R.id.top_bar));
                }
            }
        });
        searchViewLayout.setSearchBoxListener(new SearchViewLayout.SearchBoxListener() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.d(TAG, "beforeTextChanged: " + s + "," + start + "," + count + "," + after);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d(TAG, "onTextChanged: " + s + "," + start + "," + before + "," + count);
            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.d(TAG, "afterTextChanged: " + s);
                if (!TextUtils.isEmpty(s)) {
                    searchFriendFragment.setSearchQuery(s.toString());
                } else {
                    searchFriendFragment.setSearchQuery("");
                }

            }
        });

    }

    LinearLayout scanCode, mobileContacts;

    private void initListView() {

        layout_head = baseActivity.getLayoutInflater().inflate(
                R.layout.layout_head_newfriend, null);
        mNewFriendListView.addHeaderView(layout_head);

        scanCode = (LinearLayout) layout_head.findViewById(R.id.scan_bar_code);

        mobileContacts = (LinearLayout) layout_head.findViewById(R.id.mobile_contacts);

        mNewFriendAdapter = new NewFriendAdapter(mContext, requestFriendListener);

        mNewFriendListView.setAdapter(mNewFriendAdapter);

        initListener(this, R.id.left_back, R.id.scan_bar_code, R.id.mobile_contacts);

    }




    NewFriendAdapter.OnFriendClickListener requestFriendListener = new NewFriendAdapter.OnFriendClickListener() {
        @Override
        public void onItemClickListener(PeopleEntity entity) {

            if ("accepted".equals(entity.status)) {
                Log.i(TAG, "entity.subuser_id===" + entity.subuser_id);
                String id = entity.subuser_id;
                PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(id);
                if (peopleEntity != null) {

                    DetailPersonActivity.gotoDetailPersonActivity(baseActivity, peopleEntity);
                }
                return;
            }
            Intent intent = new Intent(baseActivity, AcceptNewFriendActicity.class);
            intent.putExtra(AcceptNewFriendActicity.KEY_DETAIL_ENTITY, entity);
            baseActivity.startActivity(intent);
        }

        @Override
        public void callFriendRequest(String action, PeopleEntity peopleEntity) {
            requestFriendManager.acceptFriend(baseActivity, peopleEntity, requestFriendListener);
        }

        @Override
        public void onFriendStatusChanged(PeopleEntity peopleEntity) {
            mNewFriendAdapter.updateItem(peopleEntity);

        }
    };


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        Uri uri = FriendContract.CONTENT_URI;
        contactChangeObserver = new FragmentNewFriend.ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri, true, contactChangeObserver);
    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
    }

    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "contact hasChanged..");
            loadNewFriendData();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID);
        if (contactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.left_back:
                baseActivity.finish();
                break;
            case R.id.scan_bar_code:
                PackageManager pm = getActivity().getPackageManager();
                String packageName= getActivity().getPackageName();
                int checkPm = pm.checkPermission(Manifest.permission.CAMERA, packageName);


                int checkPm2 = pm.checkPermission(Manifest.permission.RECORD_AUDIO, packageName);


                if(checkPm!= PackageManager.PERMISSION_GRANTED||checkPm2!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},0x9999);

                }else{
                    startActivity(new Intent(getActivity(), QrScanActivity.class));
                }

                break;
            case R.id.mobile_contacts:
                 startActivity(new Intent(getActivity(), MobileContactActicity.class));
                break;

        }

    }

    int lastSelectedItem = -1;

    private void selectInvitedOrByOther(int item) {
        if (lastSelectedItem == item) {
            return;
        }
        lastSelectedItem = item;

        if (item == INVITED_BY_OTHER) {
            mNewFriendListView.setAdapter(mNewFriendAdapter);
        }

    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }


    @Override
    public void onResume() {
        super.onResume();


        Log.i(TAG, " onResume ");
        updateBadge();

    }


    public void updateBadge() {
        if (!isAdded()) {
            return;
        }

    }


}
