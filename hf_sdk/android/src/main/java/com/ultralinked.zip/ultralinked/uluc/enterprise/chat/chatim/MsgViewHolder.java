package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ultralinked.contact.util.UiUtil;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.baseui.widget.BurningImageView;
import com.ultralinked.uluc.enterprise.baseui.widget.MessageCommonLayout;
import com.ultralinked.uluc.enterprise.chat.bean.CheckedItem;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Message;

import java.util.ArrayList;

/**
 * Created by CL on 2016/7/16.
 */
public class MsgViewHolder extends RecyclerViewHolder {
    protected final TextView msgStatus;
    protected TextView time;
    protected TextView dateLine;
    protected ImageView statusIcon;
    protected View bruningView;
    protected CheckBox deleteBox;
    protected ImageView resend;
    protected ImageView header;
    protected MessageCommonLayout msgContainerLayout;
    protected Message msg;
    protected ArrayList<Message> seletctMsg;
    protected int position;
    protected ProgressBar progressBar;

    public PeopleEntity getPeopleEntity() {
        return peopleEntity;
    }

    public void setPeopleEntity(PeopleEntity peopleEntity) {
        this.peopleEntity = peopleEntity;
    }

    protected PeopleEntity peopleEntity;


    private static final String TAG = "MsgViewHolder";

    protected Message getMessage() {
        return msg;
    }

    protected void setMessage(Message msg) {
        this.msg = msg;
    }

    protected void setPosition(int position) {
        this.position = position;
    }

    interface OnMessageItemClickListener {
        void onResend(Message msg);

        void onClickMessage(View itemView, Message msg);

        void onMessageLongClick(View itemView, Message msg);

        void onClickUserHead(View itemView, Message msg);

        void onLongClickUserHead(View itemView, Message msg);

    }


    public View getBruningView() {
        return bruningView;
    }

    protected OnMessageItemClickListener onMessageItemClickListener;

    public MsgViewHolder(final Context ctx, LayoutInflater mInflater, int itemLayoutId, final View itemView, final OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, itemView);
        msgContainerLayout = (MessageCommonLayout) getView(R.id.message_out_layout);
        FrameLayout frameLayout = (FrameLayout) msgContainerLayout.getChildAt(0);
        mInflater.inflate(itemLayoutId, frameLayout);


        dateLine = getTextView(R.id.time_line);
        deleteBox = getCheckBox(R.id.delete_msg_checkbox);
        resend = getImageView(R.id.resend);
        progressBar = getProgressBar(R.id.progressbar);

        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        } else {
            Log.i("BaseFileMsgViewHolder", "progressBar is null");
        }

        ImageUtils.buttonEffect(resend);

        header = getImageView(R.id.header);
        bruningView = getView(R.id.burning_img);

        time = getTextView(R.id.msg_time_text);
        if (time != null) {

            time.setTextColor(time.getResources().getColor(R.color.color_bcc8dd));

            time.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        }
        statusIcon = getImageView(R.id.msg_status_img);
        msgStatus = getTextView(R.id.msg_status);
        this.onMessageItemClickListener = onMessageItemClickListener;
        this.seletctMsg = seletctMsg;

        deleteBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if (msg != null) {
//
//                    Log.i(TAG, "deleteBox click :" + msg.getKeyId() + " isSelected:" + isChecked);
//                    deleteBox.setSelected(isChecked);
//
//                    if (seletctMsg != null) {
//                        if (isChecked) {
//                            Log.i(TAG,"add msg to delete. msgKeyId: "+msg.getKeyId());
//                            seletctMsg.add(msg);
//                        } else {
//                            Log.i(TAG, "remove msg from seletctMsg. msgKeyId: " + msg.getKeyId());
//                            seletctMsg.remove(msg);
//                        }
//                    }
//                } else {
//                    Log.i(TAG, "deleteBox click ,msg is null..");
//                }
            }
        });

        msgContainerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(ctx, "click: " + getAdapterPosition(), Toast.LENGTH_SHORT).show();
                int adapterPositon = MsgViewHolder.this.getAdapterPosition();
                int oldPosition = MsgViewHolder.this.getOldPosition();
                int layouPositon = MsgViewHolder.this.getLayoutPosition();
                   if (msg != null) {
                    if (MsgViewHolder.this.onMessageItemClickListener != null) {
                        MsgViewHolder.this.onMessageItemClickListener.onClickMessage(itemView, msg);

                    }
                }
            }
        });
        msgContainerLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (msg != null) {
                    if (MsgViewHolder.this.onMessageItemClickListener != null) {
                        MsgViewHolder.this.onMessageItemClickListener.onMessageLongClick(itemView, msg);

                    }
                }

                return true;
            }

        });


        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(ctx, "click: " + getAdapterPosition(), Toast.LENGTH_SHORT).show();
                if (msg != null) {
                    if (MsgViewHolder.this.onMessageItemClickListener != null) {
                        MsgViewHolder.this.onMessageItemClickListener.onResend(msg);
                    }
                } else {

                }
            }
        });


    }

}



class TextMsgViewHolder extends MsgViewHolder {
    protected TextView content;

    public static Drawable getSelectedItemDrawable(Context context) throws Exception{
        int[] attrs = new int[]{R.attr.selectableItemBackground};
        TypedArray ta = context.obtainStyledAttributes(attrs);
        Drawable selectedItemDrawable = ta.getDrawable(0);
        ta.recycle();
        return selectedItemDrawable;
    }

    public TextMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView,boolean isSender, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);

        msgContainerLayout.setClipRound(false);



        // set text content view max width
        CardView layout = (CardView) msgContainerLayout.findViewById(R.id.msg_container);

        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            try {
                layout.setForeground(getSelectedItemDrawable(ctx));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (isSender) {
            layout.setCardBackgroundColor(MessageCommonLayout.getChatBubbleColorEffect(ctx.getResources().getColor(R.color.bubble_send),
                    ctx.getResources().getColor(R.color.bubble_send_dark)));
             time.setTextColor(ctx.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_7f8b9f));
           content.setTextColor(ctx.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_chat_content));
        } else {
            layout.setCardBackgroundColor(ctx.getResources().getColorStateList(R.color.bubble_receive_color));
            time.setTextColor(ctx.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_7f8b9f));
           content.setTextColor(ctx.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_chat_content));
        }


    }

    public  void  setTextMaxWidth(boolean isMaxWidth){
        if (isMaxWidth){
            float scale = 0.66f;
            content.setMaxWidth((int) (ScreenUtils.getScreenWidth(content.getContext()) * scale));
        }else{
            float scale = 0.56f;
            content.setMaxWidth((int) (ScreenUtils.getScreenWidth(content.getContext()) * scale));
        }

    }
}

class Publish1MsgViewHolder extends MsgViewHolder {
    protected TextView content;
    protected ImageView mIcon;
    protected TextView title;
    public Publish1MsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        title = getTextView(R.id.title);
        mIcon = getImageView(R.id.img_photo);
    }
}


class Publish2MsgViewHolder extends MsgViewHolder {
    protected TextView content;
    protected ImageView mIcon;
    public  ViewGroup publish2MsgListView;
    public  static  final  int MaxViewItemCount = 5;
    public  static  final  int childIndexStart = 1;
    public Publish2MsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        mIcon = getImageView(R.id.img_photo);
        publish2MsgListView = (ViewGroup) getView(R.id.publish_more_msg_info_container);

        for (int i = 0; i < MaxViewItemCount; i++) {//max size is 5
            View childView =   mInflater.inflate(R.layout.layout_item_publishmsg_detail2_inner_item, null);
            childView.setTag(""+i);//set the index of click item.
            childView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (msg != null) {
                        if (Publish2MsgViewHolder.this.onMessageItemClickListener != null) {
                            Publish2MsgViewHolder.this.onMessageItemClickListener.onClickMessage(v, msg);

                        }
                    }
                }
            });
            childView.setVisibility(View.GONE);
            publish2MsgListView.addView(childView);
        }

    }
}


class VoipMsgViewHolder extends MsgViewHolder {
    protected TextView content;
    protected ImageView voipTypeIcon;

    public VoipMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        voipTypeIcon = getImageView(R.id.chatting_voipcall_icon);

    }
}


class UrlInfoMsgViewHolder extends MsgViewHolder {
    protected TextView content;
    protected TextView title;
    protected ImageView imgUrl;

    public UrlInfoMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        title = getTextView(R.id.url_title);
        imgUrl = getImageView(R.id.url_img);

    }
}

class BaseFileMsgViewHolder extends MsgViewHolder {

    protected ImageView download;

    public BaseFileMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);

        download = getImageView(R.id.download);

        if (download != null) {
            download.setVisibility(View.GONE);
        } else {
            Log.i("BaseFileMsgViewHolder", "download is null");
        }

    }
}

class FileMsgViewHolder extends BaseFileMsgViewHolder {
    protected TextView persent;
    protected ImageView imageView;
    protected TextView fileSize;
    protected TextView fileName;

    public FileMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        persent = getTextView(R.id.percent);
        imageView = getImageView(R.id.file_image);
        fileSize = getTextView(R.id.file_size);
        fileName = getTextView(R.id.file_name);

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Message msg = (Message) v.getTag();

            }
        });


    }
}


class FriendAcceptMsgViewHolder extends MsgViewHolder {
    protected ImageView imageView;
    protected TextView userName, content;
    protected View user_info_container;

    public FriendAcceptMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        imageView = getImageView(R.id.user_img);
        userName = getTextView(R.id.user_name);
        user_info_container = getView(R.id.user_info_container);
    }
}

class FriendRejectMsgViewHolder extends MsgViewHolder {
    protected ImageView imageView;
    protected TextView userName, content;
    protected View user_info_container;

    public FriendRejectMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        imageView = getImageView(R.id.user_img);
        userName = getTextView(R.id.user_name);
        user_info_container = getView(R.id.user_info_container);
    }
}

class FriendInviteMsgViewHolder extends MsgViewHolder {
    protected ImageView imageView;
    protected TextView userName, content;

    protected View cancelBtn, okBtn, user_info_container, cancel_ok_container;

    public FriendInviteMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
        imageView = getImageView(R.id.user_img);
        userName = getTextView(R.id.user_name);
        cancelBtn = getView(R.id.cancel_btn);
        okBtn = getView(R.id.ok_btn);
        user_info_container = getView(R.id.user_info_container);
        cancel_ok_container = getView(R.id.cancel_ok_container);
    }
}


class StickerMsgViewHolder extends BaseFileMsgViewHolder {
    protected ImageView imageView;
    protected int width;
    protected int height;


    public StickerMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        imageView = getImageView(R.id.content);
    }
}

class BurningMsgViewHolder extends BaseFileMsgViewHolder {
    protected BurningImageView imageView;
    protected int width;
    protected int height;


    public BurningMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        imageView = (BurningImageView) getImageView(R.id.content);
    }
}

class ImageMsgViewHolder extends BaseFileMsgViewHolder {
    protected ImageView imageView;
    protected int width;
    protected int height;

    public Object getPreBitmapTag() {
        return preBitmapTag;
    }

    public void setPreBitmapTag(Object preBitmapTag) {
        this.preBitmapTag = preBitmapTag;
    }

    protected Object preBitmapTag;

    public ImageMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        imageView = getImageView(R.id.content);
    }
}

class VideoMsgViewHolder extends BaseFileMsgViewHolder {
    protected ImageView imageView;
    protected int width;
    protected int height;

    protected Object preBitmapTag;

    public Object getPreBitmapTag() {
        return preBitmapTag;
    }

    public void setPreBitmapTag(Object preBitmapTag) {
        this.preBitmapTag = preBitmapTag;
    }


    public VideoMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        imageView = getImageView(R.id.content);

    }
}

class VoiceMsgViewHolder extends BaseFileMsgViewHolder {
    protected ImageView imageView;
    protected View voiceAnim;
    protected TextView totalTime;
    protected  ImageView voice_unplay_state;


    public VoiceMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        imageView = getImageView(R.id.content);
        voiceAnim = getView(R.id.voiceAnim);
        totalTime = getTextView(R.id.total_time);
        voice_unplay_state = getImageView(R.id.voice_state_iv);

    }
}

class LocationMsgViewHolder extends BaseFileMsgViewHolder {
    protected ImageView map;
    protected TextView location;

    public LocationMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        map = getImageView(R.id.content);
        location = getTextView(R.id.location);

    }
}

class VCardMsgViewHolder extends BaseFileMsgViewHolder {

    protected TextView title;
    protected ImageView vcardIv;
    protected TextView vcardName;
    protected TextView vcardConten;

    public VCardMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        title = getTextView(R.id.title);
        vcardIv = getImageView(R.id.vcard_img);
        vcardName = getTextView(R.id.vcard_name);
        vcardConten = getTextView(R.id.vcard_content);

    }
}

class TipsMsgViewHolder extends MsgViewHolder {
    TextView content;

    public TipsMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        try {
            content = getTextView(R.id.content);
            statusIcon.setVisibility(View.GONE);
            msgStatus.setVisibility(View.GONE);
            time.setVisibility(View.GONE);
            dateLine.setVisibility(View.GONE);
            deleteBox.setVisibility(View.GONE);
            resend.setVisibility(View.GONE);
            header.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

class CustomMsgViewHolder extends MsgViewHolder {
    TextView content;

    public CustomMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView, OnMessageItemClickListener onMessageItemClickListener, final ArrayList<Message> seletctMsg) {
        super(ctx, mInflater, itemLayoutId, itemView, onMessageItemClickListener, seletctMsg);
        content = getTextView(R.id.content);
    }
}

class ComposMsgViewHolder extends MsgViewHolder {
    ImageView composing;

    public ComposMsgViewHolder(Context ctx, LayoutInflater mInflater, int itemLayoutId, View itemView) {
        super(ctx, mInflater, itemLayoutId, itemView, null, null);
        dateLine.setVisibility(View.GONE);
        deleteBox.setVisibility(View.GONE);
        resend.setVisibility(View.GONE);
        composing = getImageView(R.id.composing);
        AnimationDrawable anim = (AnimationDrawable) composing.getDrawable();
        anim.start();
    }
}






