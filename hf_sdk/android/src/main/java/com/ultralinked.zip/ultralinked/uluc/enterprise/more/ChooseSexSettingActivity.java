/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.ultralinked.uluc.enterprise.more;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;

/**
 * Class to set sex
 * @author Administrator
 *
 */
public class ChooseSexSettingActivity extends BaseActivity {

	private LinearLayout mRadioGroup;

	@Override
	public int getRootLayoutId() {
		return R.layout.sex_choose_setting;
	}

	@Override
	public void initView(Bundle savedInstanceState) {
		mRadioGroup = bind(R.id.menu);
		findViewById(R.id.cancel_layout).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						finish();
					}
				});

		check(mRadioGroup, getCheckSexId(getIntent().getStringExtra("sex")));
		// test listening to checked change events

		int childCount = mRadioGroup.getChildCount();
		for (int i = 0; i < childCount; i++) {
			mRadioGroup.getChildAt(i).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					if (v.getId() == R.id.female_layout) {
						onCheckedChanged(mRadioGroup, R.id.female);
					} else if (v.getId() == R.id.male_layout) {
						onCheckedChanged(mRadioGroup, R.id.male);
					}
					finish();
				}
			});
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
		WindowManager m = getWindowManager();
		Display d = m.getDefaultDisplay();
		DisplayMetrics dm = new DisplayMetrics();
		d.getMetrics(dm);
		int width = dm.widthPixels;
		WindowManager.LayoutParams p = getWindow().getAttributes(); // 获取对话框当前的参数值
		float scale = 0.91f;
		p.width = (int) (width * scale); // 宽度设置为屏幕的0.8
		p.y=-ScreenUtils.dp2px(this, 2.66f);
		getWindow().setAttributes(p);
	//	getWindow().setGravity(Gravity.RIGHT); // 设置靠右对齐


	}

	private void check(ViewGroup view, int checkFontSizeId) {
		int count = view.getChildCount();
		for (int i = 0; i < count; i++) {
			View childView = view.getChildAt(i);
			if (childView instanceof ViewGroup) {
				check((ViewGroup) childView, checkFontSizeId);
			} else {
				if (childView instanceof CheckBox) {
					if (checkFontSizeId == childView.getId()) {
						((CheckBox) childView).setChecked(true);
					} else {
						((CheckBox) childView).setChecked(false);
					}
				}
			}
		}

	}

	private int getCheckSexId(String sexType) {

		if ("Female".equalsIgnoreCase(sexType)) {
			return R.id.female;
		} else {
			return R.id.male;
		}
	}

	private String getSexStr(int checkId) {

		if (checkId == R.id.female) {
			return "Female";
		} else {
			return "Male";
		}
	}

	public void onCheckedChanged(LinearLayout group, int checkedId) {

		check(mRadioGroup, checkedId);
		Intent intent = new Intent();
		intent.putExtra("sex",getSexStr(checkedId));
		setResult(RESULT_OK,intent);


	}


}
