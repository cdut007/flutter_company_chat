package com.ultralinked.uluc.enterprise.baseui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

public class MobileBrowserActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = "MobileBrowserActivity";

    WebView wbContent;

    public static final String SHPEINER_URL = "http://www.ultralinked.com/en/about-us/";// "http://www.shpeiner.com/ch/index.aspx";

    private String strUrl;
    private String title;
    private ProgressDialog dilogLoading;

    ImageView IbBack;
    ImageView IbForward;
    ImageView IbRefresh;

    @Override
    public void initView(Bundle savedInstanceState) {
        IbBack = bind(R.id.Ib_back);
        IbForward = bind(R.id.Ib_forward);
        IbRefresh = bind(R.id.Ib_refresh);
        ImageUtils.buttonEffect(IbBack);
        ImageUtils.buttonEffect(IbForward);
        ImageUtils.buttonEffect(IbRefresh);


        wbContent = bind(R.id.wb_Content);
        wbContent.setDownloadListener(new MyWebViewDownLoadListener());
        initListener(this, IbBack, IbForward, IbRefresh);

    }
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_mobile_browser;
    }



    private class MyWebViewDownLoadListener implements DownloadListener {

        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype,
                                    long contentLength) {
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        strUrl = getIntent().getStringExtra("Url");
        Log.i(TAG,"strurl=="+strUrl);
        title = getIntent().getStringExtra("title");
        if (TextUtils.isEmpty(strUrl)){
            strUrl = SHPEINER_URL;
            String companyName = CompanySelector.getInstance(this).getCompanyName();
            if (TextUtils.isEmpty(companyName)){
                title = "";//getString(R.string.ultralinked);
            }else{
                title = FragmentContacts.firstLetterToUpper(companyName);
            }
        }else{
            if (!strUrl.startsWith("http")){
                strUrl = "http://"+strUrl;
            }
        }




        titleCenter.setText(title);
        initWebView();

    }



    public void setClosePage(View view) {
        if (view != null) {
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MobileBrowserActivity.this.finish();
                }
            });
        }
    }


    ImageView leftBack;
    TextView titleCenter, titleRight;
    @Override
    protected void setTopBar() {
        super.setTopBar();
        leftBack = bind(R.id.left_back);
        titleCenter = bind(R.id.titleCenter);
        titleRight = bind(R.id.titleRight);

        goneView(titleRight);

        setClosePage(leftBack);
    }

    public void initWebView() {



        WebSettings webSettings = wbContent.getSettings();
        // 设置出现缩放工具
        webSettings.setBuiltInZoomControls(true);
        //自适应屏幕
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true);
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        Log.i(TAG, "___strUrl___" + strUrl);
        wbContent.loadUrl(strUrl);
        wbContent.requestFocusFromTouch();
        wbContent.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (dilogLoading == null || !dilogLoading.isShowing()) {
                    String str1 = getString(R.string.waiting);
                    dilogLoading = new ProgressDialog(getActivity());
                    dilogLoading.setCanceledOnTouchOutside(true);
                    dilogLoading.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    dilogLoading.setMessage(str1);
                    dilogLoading.setOnCancelListener(new DialogInterface.OnCancelListener() {

                        public void onCancel(DialogInterface arg0) {
                            if (dilogLoading.isShowing()) {
                                dilogLoading.dismiss();
                            }
                        }
                    });
                }
                try{
                    dilogLoading.setCancelable(true);
                    dilogLoading.show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                try{
                    if (dilogLoading!=null)
                        dilogLoading.dismiss();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return false;
            }

            @Override   //转向错误时的处理
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                // TODO Auto-generated method stub
                Log.i(TAG,"Oh no! " + description);
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (wbContent.canGoBack() && keyCode == KeyEvent.KEYCODE_BACK) {
            wbContent.goBack();   //goBack()表示返回webView的上一页面
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_BACK) {
            this.finish();
            return true;
        }
        return false;
    }

    public static void actionStart(Context context, String url, String title) {
        Intent intent = new Intent(context, MobileBrowserActivity.class);
        intent.putExtra("Url", url);
        intent.putExtra("title", title);
        context.startActivity(intent);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.Ib_back:
                if (wbContent.canGoBack()) {
                    wbContent.goBack();
                }
                break;
            case R.id.Ib_forward:
                if (wbContent.canGoForward()) {
                    wbContent.goForward();
                }

                break;
            case R.id.Ib_refresh:
                wbContent.reload();

                break;
            default:
                break;
        }
    }


}
