package com.ultralinked.uluc.enterprise.moments.widgets.videolist.model;

import android.media.MediaPlayer;

import com.ultralinked.uluc.enterprise.moments.widgets.videolist.widget.TextureVideoView;


/**
 * @author james
 */
public interface VideoLoadMvpView {

    TextureVideoView getVideoView();

    void videoBeginning();

    void videoStopped();

    void videoPrepared(MediaPlayer player);

    void videoResourceReady(String videoPath);
}
