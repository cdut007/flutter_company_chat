package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.content.Context;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.List;

/**
 * Created by ultralinked on 16/7/25.
 */
public class DetailAdapter extends BaseAdapter {

    private static final String TAG = "DetailAdapter";
    private final Context mcontext;

    private List<PeopleEntity> listData;

    public DetailAdapter(Context context) {

        mcontext = context;
    }

    public void setData(List<PeopleEntity> raw) {

        listData = raw;

        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return listData == null ? 0 : listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData == null ? null : listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return listData == null ? 0 : position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        ViewHolder holder;

        if (convertView != null) {
            holder = (ViewHolder) convertView.getTag();//取出ViewHolder对象

        } else {
            convertView = LayoutInflater.from(mcontext).inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.depart_list_item, null);
            holder = new ViewHolder();
            holder.bind(convertView);
            convertView.setTag(holder);//绑定ViewHolder对象
        }

        PeopleEntity entity = listData.get(position);

        holder.title.setText(PeopleEntityQuery.getDisplayName(entity));

        holder.detail.setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.detail);


        int defaultId =  ImageUtils.getDefaultContactImageResource(entity.subuser_id);

        ImageUtils.loadCircleImage(convertView.getContext(), holder.head, defaultId);


        return convertView;
    }

    public final class ViewHolder {
        public TextView title;
        public ImageView head;
        public ImageView detail;
        public String _Id;

        public void bind(View view) {

            this.title = (TextView) view.findViewById(R.id.Orgtitle);
            this.head = (ImageView) view.findViewById(R.id.Orgimage);
            this.detail = (ImageView) view.findViewById(R.id.OrgDetail);
        }
    }
}
