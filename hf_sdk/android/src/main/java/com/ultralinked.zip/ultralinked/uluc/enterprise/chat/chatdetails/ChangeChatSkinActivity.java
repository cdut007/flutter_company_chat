package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.GroupChatImActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.login.LoginActivity;
import com.ultralinked.uluc.enterprise.more.SettingPersonalActivity;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.utils.FileUtils;

import java.util.List;

import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;

public class ChangeChatSkinActivity extends BaseActivity implements View.OnClickListener {

    private ImageView leftBack;
    private View tvSetWallPaper, tvSetFromGallery, clearBackgroud;
    private String chatId;
    private int chatType, chatFlag;
    private boolean settingAll;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_change_chat_skin;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            settingAll = bundle.getBoolean("settingAll");
        }

        chatId = getIntent().getStringExtra("conversation_id");
        chatType = getIntent().getIntExtra("convType", -1);
        chatFlag = getIntent().getIntExtra("flag", -1);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack = bind(R.id.left_back);
        tvSetWallPaper = bind(R.id.set_wallpaper);
        goneView(tvSetWallPaper);
        tvSetFromGallery = bind(R.id.set_gallery);
        clearBackgroud = bind(R.id.clear_set_skin);

        bind(R.id.titleRight).setVisibility(View.GONE);
        if (settingAll){
            ((TextView) bind(R.id.titleCenter)).setText(R.string.title_change_all_chat_skin);
        }else{
            ((TextView) bind(R.id.titleCenter)).setText(R.string.title_change_chat_skin);
        }

        initListener(this, leftBack, tvSetWallPaper, tvSetFromGallery, clearBackgroud);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;
            case R.id.set_wallpaper:
                // lunchActivity(AccountSecurity.class);
                break;
            case R.id.set_gallery: {
                DialogManager.showItemsDialog(this, getString(R.string.img_from), new String[]{getString(R.string.take_photo), getString(R.string.gallery)}, v, new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (position == 0) {
                            GalleryFinal.openCamera(SettingPersonalActivity.OPEN_CAMERA_CODE, mOnHandlerResultCallback);
                        } else {
                            GalleryFinal.openGallerySingle(SettingPersonalActivity.OPEN_GALLY_CODE, mOnHandlerResultCallback);
                        }
                    }
                });
            }
            break;
            case R.id.clear_set_skin: {
                if (settingAll) {
                    ChatModule.clearAllChatBackgroudThemeSkin();
                } else {
                    ChatModule.clearChatBackgroudThemeSkin(chatId);
                }

                RxBus.getDefault().post("clearTheme");
                setResult(RESULT_OK);
                finish();

            }
            break;

            default:
        }
    }

    /**
     * 图片选择器的回调
     */
    private GalleryFinal.OnHanlderResultCallback mOnHandlerResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int requestCode, List<PhotoInfo> resultList) {
            if (resultList == null) {
                Log.i(TAG, " requestCode:" + requestCode + " resultList is null.");
                return;
            }
            if (requestCode == SettingPersonalActivity.OPEN_CAMERA_CODE || requestCode == SettingPersonalActivity.OPEN_GALLY_CODE) {
                for (PhotoInfo photoInfo : resultList) {
                    String filePath = photoInfo.getPhotoPath();
                    if (FileUtils.isFileExist(filePath)) {
                        setThemeSkinBackgroud(filePath);

                    } else {
                        Log.d(TAG, "the photo file is not exist.. filePath:" + filePath);
                    }
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            showToast(errorMsg);
            Log.i(TAG, " requestCode:" + requestCode + " errorMsg:" + errorMsg);
        }
    };

    public void setThemeSkinBackgroud(String filePath) {

        if (settingAll) {
            ChatModule.setAllChatBackgroudThemeSkin(filePath);
        } else {
            ChatModule.setChatBackgroudThemeSkin(chatId, filePath);
            if (chatType == Conversation.GROUP_CHAT) {
                GroupChatImActivity.launchToGroupChatIm(this, chatId, chatFlag);
            } else {
                SingleChatImActivity.launchToSingleChatIm(this, chatId, chatFlag);
            }
        }


        RxBus.getDefault().post("updateTheme");
        setResult(RESULT_OK);
        finish();
    }


}
