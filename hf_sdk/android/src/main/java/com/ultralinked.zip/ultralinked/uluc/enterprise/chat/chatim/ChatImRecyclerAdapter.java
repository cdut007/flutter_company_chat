package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.baidu.mapapi.model.LatLng;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.baseui.widget.BruningView;
import com.ultralinked.uluc.enterprise.baseui.widget.ProgressImageView;
import com.ultralinked.uluc.enterprise.chat.bean.ComposMessage;
import com.ultralinked.uluc.enterprise.chat.bean.MsgTime;
import com.ultralinked.uluc.enterprise.chat.bean.UrlInfo;
import com.ultralinked.uluc.enterprise.chat.bean.VCardInfo;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AcceptNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendAdapter;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.service.PlayMusicService;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MapUtils;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.EventMessage;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.ImageMessage;
import com.ultralinked.voip.api.LocationMessage;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.StickerMessage;
import com.ultralinked.voip.api.SubscribeMessage;
import com.ultralinked.voip.api.SystemMessage;
import com.ultralinked.voip.api.TextMessage;
import com.ultralinked.voip.api.TipsMessage;
import com.ultralinked.voip.api.VcardMessage;
import com.ultralinked.voip.api.VideoMessage;
import com.ultralinked.voip.api.VoiceMessage;
import com.ultralinked.voip.api.VoipCallMessage;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.ultralinked.uluc.enterprise.utils.ImageUtils.loadImageAsGif;

/**
 * Created by Chenlu on 2016/7/7 0007.
 */
public class ChatImRecyclerAdapter extends BaseRecyclerAdapter<Message, RecyclerViewHolder> {


    boolean isGroup;

    public ChatImRecyclerAdapter(Context ctx, List<Message> list, boolean isGroup) {
        super(ctx, list);
        this.isGroup = isGroup;
    }

    public void setDatas(List<Message> list) {
        mData = list;
    }

    private static final String TAG = "ChatImRecyclerAdapter";

    @Override
    public int getItemLayoutId(int viewType) {
        switch (viewType) {
            case ITEM_TYPE_TEXT_SEND:
            case ITEM_TYPE_FILE_SEND:
            case ITEM_TYPE_IMAGE_SEND:
            case ITEM_TYPE_CUSTOM_SEND:
            case ITEM_TYPE_VIDEO_SEND:
            case ITEM_TYPE_LOCATION_SEND:
            case ITEM_TYPE_VOICE_SEND:
            case ITEM_TYPE_VCARD_SEND:
            case ITEM_TYPE_VOIP_SEND:
            case ITEM_TYPE_STICKER_SEND:
            case ITEM_TYPE_URL_INFO_SEND:
            case ITEM_TYPE_EVENT_FRIEND_INVITE_SEND:
            case ITEM_TYPE_EVENT_FRIEND_ACCEPT_SEND:
            case ITEM_TYPE_EVENT_FRIEND_REJECT_SEND:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_send;

            case ITEM_TYPE_TEXT_RECEIVE:
            case ITEM_TYPE_FILE_RECEIVE:
            case ITEM_TYPE_IMAGE_RECEIVE:
            case ITEM_TYPE_CUSTOM_RECEIVE:
            case ITEM_TYPE_VIDEO_RECEIVE:
            case ITEM_TYPE_LOCATION_RECEIVE:
            case ITEM_TYPE_VOICE_RECEIVE:
            case ITEM_TYPE_VCARD_RECEIVE:
            case ITEM_TYPE_VOIP_RECEIVE:
            case ITEM_TYPE_STICKER_RECEIVE:
            case ITEM_TYPE_URL_INFO_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_INVITE_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_ACCEPT_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_REJECT_RECEIVE:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_receive;


            case ITEM_TYPE_PUBLISH_INFO1:
            case ITEM_TYPE_PUBLISH_INFO2:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_tips;

            case ITEM_TYPE_TIPS:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_tips;
            case ITEM_TYPE_SYSTEM:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_tips;
            case ITEM_TYPE_COMPSING:
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_receive;
            default:
                Log.i(TAG, "unknow item type. viewType:" + viewType);
                return com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_layout_tips;
        }

    }

    private MsgViewHolder.OnMessageItemClickListener resendClickListener;

    public void setOnMessageResendClickListener(MsgViewHolder.OnMessageItemClickListener onMessageResendClickListener) {
        this.resendClickListener = onMessageResendClickListener;
    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return super.onCreateViewHolder(parent, viewType);
    }

    @Override
    public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
        RecyclerViewHolder holder = null;
        int itemLayoutId = 0;
        switch (viewType) {
            case ITEM_TYPE_STICKER_SEND:
            case ITEM_TYPE_STICKER_RECEIVE:
                itemLayoutId = R.layout.chat_im_item_sticker_msg;
                holder = new StickerMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;

            case ITEM_TYPE_URL_INFO_SEND:
            case ITEM_TYPE_URL_INFO_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_url_info;
                holder = new UrlInfoMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_TEXT_SEND:
            case ITEM_TYPE_TEXT_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_text;
                holder = new TextMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, viewType == ITEM_TYPE_TEXT_SEND, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_FILE_SEND:
            case ITEM_TYPE_FILE_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_file;
                holder = new FileMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_IMAGE_SEND:
            case ITEM_TYPE_IMAGE_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_image;
                holder = new ImageMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_CUSTOM_SEND:
            case ITEM_TYPE_CUSTOM_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_custom;
                holder = new CustomMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_VIDEO_SEND:
            case ITEM_TYPE_VIDEO_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_video;
                holder = new VideoMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_LOCATION_SEND:
            case ITEM_TYPE_LOCATION_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_location;
                holder = new LocationMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_VOICE_SEND:
            case ITEM_TYPE_VOICE_RECEIVE:
                if (viewType == ITEM_TYPE_VOICE_SEND) {
                    itemLayoutId = R.layout.chat_im_item_voice_send;
                } else {
                    itemLayoutId = R.layout.chat_im_item_voice_receive;
                }
                holder = new VoiceMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_VCARD_SEND:
            case ITEM_TYPE_VCARD_RECEIVE:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_vcard;
                holder = new VCardMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;

            case ITEM_TYPE_EVENT_FRIEND_INVITE_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_INVITE_SEND:
                itemLayoutId = R.layout.chat_im_item_friend_invite;
                holder = new FriendInviteMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_EVENT_FRIEND_ACCEPT_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_ACCEPT_SEND:
                itemLayoutId = R.layout.chat_im_item_friend_accept;
                holder = new FriendAcceptMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;

            case ITEM_TYPE_EVENT_FRIEND_REJECT_RECEIVE:
            case ITEM_TYPE_EVENT_FRIEND_REJECT_SEND:
                itemLayoutId = R.layout.chat_im_item_friend_reject;
                holder = new FriendRejectMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;

            case ITEM_TYPE_TIPS:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_tips;
                holder = new TipsMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;
            case ITEM_TYPE_SYSTEM:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_tips;
                holder = new TipsMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;

            case ITEM_TYPE_VOIP_SEND:
            case ITEM_TYPE_VOIP_RECEIVE:
                if (viewType == ITEM_TYPE_VOIP_SEND) {
                    itemLayoutId = R.layout.chat_im_item_voip_call_send;
                } else {
                    itemLayoutId = R.layout.chat_im_item_voip_call_receive;
                }
                holder = new VoipMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);
                break;


            case ITEM_TYPE_COMPSING:
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_composing;
                holder = new ComposMsgViewHolder(mContext, mInflater, itemLayoutId, itemView);
                break;
            case ITEM_TYPE_PUBLISH_INFO1:
                itemLayoutId = R.layout.layout_item_publishmsgdetail;
                holder = new Publish1MsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);

                break;
            case ITEM_TYPE_PUBLISH_INFO2:
                itemLayoutId = R.layout.layout_item_publishmsgdetail2;
                holder = new Publish2MsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);

                break;
            default:
                Log.i(TAG, " viewType:" + viewType);
                itemLayoutId = com.holdingfuture.flutterapp.hfsdk.R.layout.chat_im_item_tips;
                holder = new TipsMsgViewHolder(mContext, mInflater, itemLayoutId, itemView, resendClickListener, selectedDeleteMsg);

                break;
        }

        if (holder != null && holder instanceof MsgViewHolder) {
            final MsgViewHolder msgViewHolder = (MsgViewHolder) holder;
            if (msgViewHolder.header != null) {
                msgViewHolder.header.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (msgViewHolder.onMessageItemClickListener != null) {
                            msgViewHolder.onMessageItemClickListener.onClickUserHead(v, (Message) v.getTag(R.id.header));
                        }
                    }
                });

                msgViewHolder.header.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {

                        if (msgViewHolder.onMessageItemClickListener != null) {
                            Message msg = (Message) v.getTag(R.id.header);
                            if (!MessageUtils.isAllowToLink(msg)) {
                                return true;
                            }
                            msgViewHolder.onMessageItemClickListener.onLongClickUserHead(v, msg);
                        }
                        return true;
                    }
                });
            }
        }

        return holder;
    }

    private boolean isEdit;

    @Override
    public void bindData(RecyclerViewHolder viewHolder, int position, Message itemData) {
        if (viewHolder instanceof ComposMsgViewHolder) {
            bindComposMsgViewHolder((ComposMsgViewHolder) viewHolder, position, itemData);
            return;
        }
        MsgViewHolder holder = (MsgViewHolder) viewHolder;

        holder.setPosition(position);
        holder.setMessage(itemData);// 将消息与holder绑定

        holder.resend.setVisibility(View.GONE);
        holder.deleteBox.setVisibility(isEdit ? View.VISIBLE : View.GONE);
        boolean isSelected = false;
        if (isEdit) {
            // isSelected = tag.isSelected();
        } else {
            isSelected = false;
        }
        holder.deleteBox.setSelected(isSelected);
//       if (itemData.getType() == Message.MESSAGE_TYPE_SUBSCRIBE){
//           holder.header.setVisibility(View.VISIBLE);
//       }else{
//           holder.header.setVisibility(View.GONE);
//       }

        holder.header.setTag(R.id.header, itemData);
        holder.msgStatus.setVisibility(View.GONE);

        holder.statusIcon.setVisibility(itemData.isSender() ? View.VISIBLE : View.GONE);

        setMessageHeader(holder, position, itemData);//设置头像与名字

        MsgTime preMsgTime = position == 0 ? MsgTime.getEmptyInstance() : ChatModule.getMessageDayTime(mData.get(position - 1));
        MsgTime msgTime = ChatModule.getMessageDayTime(itemData);

        holder.dateLine.setText(msgTime.getDay());

        if (msgTime.getDay().equals(preMsgTime.getDay())) {
            holder.dateLine.setVisibility(View.GONE);
        } else {
            holder.dateLine.setVisibility(View.VISIBLE);
        }


        int statusResId = getMsgStatusIcon(itemData);
        holder.statusIcon.setImageResource(statusResId);
        // holder.msgStatus.setText(ChatModule.convertMsgStatus2String(itemData));

        if (itemData.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
            ((BruningView) holder.bruningView).setBurnMsg(itemData, new BruningView.BurningViewListener() {
                @Override
                public void burningView(Message message) {

                }
            });
            holder.bruningView.setVisibility(View.VISIBLE);
        } else {
            holder.bruningView.setVisibility(View.GONE);
        }


        holder.time.setText(msgTime.getTime());
        //gone send msg time when in progress status.
        if (itemData.isSender() && itemData.getStatus() == Message.STATUS_IN_PROGRESS) {
            holder.time.setVisibility(View.INVISIBLE);
            // holder.time.setText("Sending    ");// fix
            if (holder.progressBar != null) {//only sender has
                holder.progressBar.setVisibility(View.VISIBLE);
            }
            if (holder.bruningView != null) {
                holder.bruningView.setVisibility(View.GONE);
            }

        } else {
            if (holder.progressBar != null) {//only sender has
                holder.progressBar.setVisibility(View.GONE);
            }

            holder.time.setVisibility(View.VISIBLE);
        }

        if (itemData.getStatus() == Message.STATUS_FAILURE) {
            if (itemData.isSender()) {
                holder.bruningView.setVisibility(View.GONE);
                holder.resend.setVisibility(View.VISIBLE);
            }
        }


        //根据不同的消息类型绑定相应的布局
//        if (itemData.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
//            if (itemData.getStatus() == Message.STATUS_READ) {
//                // notifyItemRemoved(position);
//                itemData.burning_fire();
//                Log.i(TAG, " message bindBruningMsgViewHolder:" + itemData.getType());
//                bindBruningMsgViewHolder((BurningMsgViewHolder) holder, position, itemData);
//            } else {
//                bindBruningMsgViewHolder((BurningMsgViewHolder) holder, position, itemData);

        switch (itemData.getType()) {

            case Message.MESSAGE_TYPE_TEXT: {
                if (MessageUtils.hasUrlLinkInfo(itemData) && holder instanceof UrlInfoMsgViewHolder) {
                    bindUrlInfoMsgViewHolder((UrlInfoMsgViewHolder) holder, position, itemData);
                } else {
                    bindTextMsgViewHolder((TextMsgViewHolder) holder, position, itemData);
                }
            }

            break;
            case Message.MESSAGE_TYPE_FILE:
                bindFileMsgViewHolder((FileMsgViewHolder) holder, position, itemData, msgTime.getTime());
                break;
            case Message.MESSAGE_TYPE_STICKER:
                bindStickerMsgViewHolder((StickerMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_IMAGE:
                bindImageMsgViewHolder((ImageMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_CUSTOM:
                bindCustomMsgViewHolder((CustomMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_VIDEO:
                bindVideoMsgViewHolder((VideoMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_LOCATION:
                bindLocationMsgViewHolder((LocationMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_VOICE:
                bindVoiceMsgViewHolder((VoiceMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_VCARD:
                bindVCardMsgViewHolder((VCardMsgViewHolder) holder, position, itemData);
                break;

            case Message.MESSAGE_TYPE_VOIP:
                bindVoipMsgViewHolder((VoipMsgViewHolder) holder, position, itemData);
                break;

            case Message.MESSAGE_TYPE_EVENT:
                bindEventMsgViewHolder(holder, position, itemData);
                break;

            case Message.MESSAGE_TYPE_TIPS:
                bindTipsMsgViewHolder((TipsMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_SYSTEM:
                bindTipsMsgViewHolder((TipsMsgViewHolder) holder, position, itemData);
                break;
            case Message.MESSAGE_TYPE_SUBSCRIBE:
                if (AsistantService.hasMoreItemsInfo((SubscribeMessage) itemData)) {
                    bindPublish2MsgViewHolder((Publish2MsgViewHolder) holder, position, itemData);
                } else {
                    bindPublish1MsgViewHolder((Publish1MsgViewHolder) holder, position, itemData);
                }
                break;
            case ComposMessage.MESSAGE_TYPE_COMPOSMESSAGE:
                holder.header.setVisibility(View.GONE);
                Log.i(TAG, "composing msg, is composing:" + ((ComposMessage) itemData).isComposing());
                break;
        }


    }

    private void bindComposMsgViewHolder(ComposMsgViewHolder viewHolder, int position, Message msg) {
        viewHolder.bruningView.setVisibility(View.GONE);
        setMessageHeader(viewHolder, position, msg);
    }

    private Map<String, PeopleEntity> peopleEntityMap = new HashMap<>();


    String sender_url, recever_url;

    public void setUserIcon(String userIcon, String sender) {
        this.sender_url = sender;
        this.recever_url = userIcon;
        notifyDataSetChanged();
    }

    /**
     * 设置消息对应的联系人头像
     *
     * @param holder
     * @param position
     * @param msg
     */
    private void setMessageHeader(final MsgViewHolder holder, int position, final Message msg) {
        if (holder instanceof TipsMsgViewHolder) {
            holder.header.setVisibility(View.GONE);
            return;
        }


        final String userId = msg.getSender();
        if (TextUtils.isEmpty(userId)) {
            Log.i(TAG, "userid is empty");
            return;
        }
        String url = null;
        PeopleEntity peopleEntity = peopleEntityMap.get(userId);
        PeopleEntity prePeopleEntity = holder.getPeopleEntity();
        if (peopleEntity != null) {
            url = peopleEntity.icon_url;
        }


        if (!TextUtils.isEmpty(url)) {
            if (!(prePeopleEntity != null && url.equals(prePeopleEntity.icon_url))) {

                ImageUtils.loadCircleImage(mContext, holder.header, url, ImageUtils.getDefaultContactImageResource(userId));

                holder.setPeopleEntity(peopleEntity);
            }

        } else {
            //check is scorll or not.
            if (isGroup) {
                //for memory string cache.
                String userIconUrl = MapUtils.getUserIconUrl(userId);
                if (!TextUtils.isEmpty(userIconUrl)) {
                    ImageUtils.loadCircleImage(mContext, holder.header, userIconUrl, ImageUtils.getDefaultContactImageResource(userId));

                }

            } else {
                if (msg.isSender()) {
                    ImageUtils.loadCircleImage(mContext, holder.header, sender_url, ImageUtils.getDefaultContactImageResource(userId));
                } else {
                    ImageUtils.loadCircleImage(mContext, holder.header, recever_url, ImageUtils.getDefaultContactImageResource(userId));

                }
            }

            Observable.create(new Observable.OnSubscribe<PeopleEntity>() {
                @Override
                public void call(Subscriber<? super PeopleEntity> subscriber) {
                    PeopleEntity entity = PeopleEntityQuery.getInstance().getByID(userId);
                    if (entity != null) {
                        subscriber.onNext(entity);
                        subscriber.onCompleted();
                    } else {
                        Log.i(TAG, "peopleEntity is null. userId:" + userId);
                    }
                }
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<PeopleEntity>() {
                @Override
                public void call(PeopleEntity peopleEntity) {

                    ImageUtils.loadCircleImage(mContext, holder.header, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(userId));
                    refreshNameDisplay(holder, msg, userId, peopleEntity);
                    holder.setPeopleEntity(peopleEntity);
                    if (PeopleEntityQuery.hasFoundPeople(peopleEntity)) {
                        peopleEntityMap.put(userId, peopleEntity);
                    }

                }
            }, new Action1<Throwable>() {
                @Override
                public void call(Throwable throwable) {
                    Log.i(TAG, "error load header, " + throwable.getMessage());
                    holder.header.setImageResource(ImageUtils.getDefaultContactImageResource(userId));

                }
            });
        }

        refreshNameDisplay(holder, msg, userId, peopleEntity);


    }

    private void refreshNameDisplay(MsgViewHolder holder, Message msg, String userId, PeopleEntity peopleEntity) {
        TextView tvName = holder.getTextView(R.id.name);
        if (msg.getChatType() == Message.CHAT_TYPE_GROUP && !msg.isSender()) {
            if (tvName != null) {
                String name = null;

                if (peopleEntity != null) {
                    name = PeopleEntityQuery.getDisplayName(peopleEntity);
                } else {
                    Message.PeerInfo peerInfo = msg.getPeerInfo();
                    if (peerInfo != null) {
                        name = peerInfo.userName;
                        Log.i(TAG, "get name from peerInfo, name:" + name);
                    }
                }
                if (TextUtils.isEmpty(name)) {
                    name = "unKnown";
                    Log.i(TAG, "get name from by default, name: unKnown+ userid:" + userId + " msg:" + msg.toString());
                }
                tvName.setText(name);
                tvName.setVisibility(View.VISIBLE);
            } else {
            }

        } else {
            if (tvName != null) {
                tvName.setVisibility(View.GONE);
            }
        }
    }


    private int getMsgStatusIcon(Message msg) {
        int resId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.message_status_sent;
        switch (msg.getStatus()) {
            case Message.STATUS_DELIVERY_OK:
                resId = R.mipmap.message_status_sent;
                break;
            case Message.STATUS_DRAFT:
                resId = R.mipmap.message_status_sending;
                break;
            case Message.STATUS_FAILURE:
                resId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.message_status_failed;
                break;
            case Message.STATUS_IN_PROGRESS:
                resId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.message_status_sending;
                break;
            case Message.STATUS_OK:
                if (msg.getChatType() == Message.CHAT_TYPE_GROUP) {
                    resId = R.mipmap.message_status_sent;
                } else {
                    resId = R.mipmap.message_status_delivery;
                }
                break;
            case Message.STATUS_READ:
            case Message.MESSAGE_FLAG_BURNING:
                resId = R.mipmap.message_status_read;
                break;
        }
        return resId;
    }

    private void bindTipsMsgViewHolder(TipsMsgViewHolder holder, int position, Message itemData) {
        try {
            holder.statusIcon.setVisibility(View.GONE);
            holder.msgStatus.setVisibility(View.GONE);
            holder.time.setVisibility(View.GONE);
            // holder.dateLine.setVisibility(View.GONE);
            holder.deleteBox.setVisibility(View.GONE);
            holder.resend.setVisibility(View.GONE);
            holder.header.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (itemData.getType() == Message.MESSAGE_TYPE_SYSTEM) {
            SystemMessage systemMessage = (SystemMessage) itemData;
            holder.content.setText(MessageUtils.getSystemMsgContent(systemMessage));
        } else {
            TipsMessage tMsg = (TipsMessage) itemData;

            String actionType = tMsg.getActionType();
            List<String> member = tMsg.members;
            StringBuffer sb = new StringBuffer();

            if (member != null) {
                for (String m : member
                        ) {
                    PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(m);
                    if (peopleEntity != null) {

                        sb.append(PeopleEntityQuery.getDisplayName(peopleEntity)).append(",");

                    } else {

                    }
                }
                if (!TextUtils.isEmpty(sb.toString())) {
                    sb = sb.deleteCharAt(sb.length() - 1);
                }

            }
            if (actionType != null) {
                if (actionType.equals("join")) {
                    sb.append(" " + mContext.getString(R.string.chat_join_group));
                } else if (actionType.equals("left") || actionType.equals("kicked")) {
                    sb.append(" " + mContext.getString(R.string.chat_left_group));
                }
            }
            holder.content.setText(sb.toString());
        }


    }


    private void bindPublish1MsgViewHolder(Publish1MsgViewHolder holder, int position, Message itemData) {
        try {
            holder.header.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }


        SubscribeMessage subscribeMessage = (SubscribeMessage) itemData;
        ImageUtils.loadImageByString(mContext, holder.mIcon, subscribeMessage.imgUrl, R.mipmap.no_pic, R.mipmap.no_pic);
        holder.title.setText(subscribeMessage.title);
        holder.content.setText(subscribeMessage.content);

    }

    private void bindPublish2MsgViewHolder(Publish2MsgViewHolder holder, int position, Message itemData) {

        try {
            holder.header.setVisibility(View.GONE);
            holder.time.setVisibility(View.GONE);
            holder.dateLine.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ViewGroup viewGroup = holder.publish2MsgListView;
        SubscribeMessage subscribeMessage = (SubscribeMessage) itemData;
        ImageUtils.loadImageByString(mContext, holder.mIcon, subscribeMessage.imgUrl, R.mipmap.no_pic, R.mipmap.no_pic);
        holder.content.setText(subscribeMessage.content);

        int count = viewGroup.getChildCount();
        int size = subscribeMessage.subscribes.size();
        int viewAppearCount = 0;
        for (int i = Publish2MsgViewHolder.childIndexStart; i < count; i++) {
            viewAppearCount++;
            if (viewAppearCount <= size) {
                View childView = viewGroup.getChildAt(i);
                viewGroup.getChildAt(i).setVisibility(View.VISIBLE);
                TextView content = (TextView) childView.findViewById(R.id.txt_title2);
                ImageView icon = (ImageView) childView.findViewById(R.id.img_photo2);
                int pos = Integer.parseInt(childView.getTag().toString());
                SubscribeMessage.Subscribe subsricbe = subscribeMessage.subscribes.get(pos);
                ImageUtils.loadImageByString(mContext, icon, subsricbe.imgUrl, R.mipmap.no_pic, R.mipmap.no_pic);
                content.setText(subsricbe.content);
            } else {
                viewGroup.getChildAt(i).setVisibility(View.GONE);
            }

        }


    }

    private void bindVoipMsgViewHolder(VoipMsgViewHolder holder, int position, Message itemData) {


        VoipCallMessage voipCallMessage = (VoipCallMessage) itemData;
        int secs = voipCallMessage.during;//毫秒数

        long minute = secs / 60;
        long sec = (secs) % 60;
        String secString = sec < 10 ? "0" + sec : sec + "";
        String minString = minute < 10 ? "0" + minute : minute + "";
        String hour = "00";
        String time = hour + ":" + minString + ":" + secString;

        holder.content.setText(mContext.getString(R.string.voip_during_info, time));

        if (voipCallMessage.callType == CallSession.TYPE_VIDEO) {
            if (itemData.isSender()) {
                holder.voipTypeIcon.setImageResource(R.mipmap.voip_video_my_icon);
            } else {
                holder.voipTypeIcon.setImageResource(R.mipmap.voip_video_other_icon);
            }
        } else {
            holder.voipTypeIcon.setImageResource(R.mipmap.voip_voice_icon);
        }

        holder.statusIcon.setVisibility(View.GONE);

        if (itemData.isSender()) {
            holder.content.setTextColor(mContext.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_chat_content));
        } else {

            holder.content.setTextColor(mContext.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_chat_content));
        }

        updateBubbleInfo(holder, itemData);
    }


    private void bindVCardMsgViewHolder(VCardMsgViewHolder holder, int position, Message itemData) {
        VcardMessage vcardMessage = (VcardMessage) itemData;
        holder.statusIcon.setVisibility(View.GONE);

        holder.title.setText(com.holdingfuture.flutterapp.hfsdk.R.string.vcard);
        String filePath = vcardMessage.getFilePath();
        if (com.ultralinked.voip.api.utils.FileUtils.isFileExist(filePath)) {
            PeopleEntity peopleEntity = VCardInfo.getInstance(filePath).getPeopleEntity();
            if (peopleEntity != null) {
                holder.vcardName.setText(PeopleEntityQuery.getDisplayName(peopleEntity));
                holder.vcardConten.setText(PhoneNumberUtils.formatMobile(peopleEntity.mobile));
                ImageUtils.loadCircleImage(mContext, holder.vcardIv, peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(peopleEntity.subuser_id));


            } else {
                holder.vcardName.setText(vcardMessage.getVcardName());
                holder.vcardConten.setText(PhoneNumberUtils.formatMobile(vcardMessage.getMobileTel()));
                Log.e(TAG, "error, people is null.");
            }

        } else {
            holder.vcardName.setText(vcardMessage.getVcardName());
            holder.vcardConten.setText(PhoneNumberUtils.formatMobile(vcardMessage.getMobileTel()));
        }


    }

    private void bindVoiceMsgViewHolder(VoiceMsgViewHolder holder, int position, Message itemData) {
        VoiceMessage vMsg = (VoiceMessage) itemData;
        int totalTime = vMsg.getDuration();
        updateBubbleInfo(holder, itemData);
        VoiceAnimImageView voiceAnimImageView = (VoiceAnimImageView) holder.voiceAnim;
        voiceAnimImageView.setIsSender(itemData.isSender());
        if (VoiceMessage.getCurrentPlayingId() == itemData.getKeyId()) {
            voiceAnimImageView.start(itemData.getKeyId());
        } else {
            voiceAnimImageView.stop();
        }
        if (totalTime <=0){
            totalTime = 1;
        }
        holder.totalTime.setText(totalTime + "\"");
        if (!itemData.isSender()) {
            if (vMsg.isPlayed) {
                holder.voice_unplay_state.setVisibility(View.GONE);
            } else {
                holder.voice_unplay_state.setVisibility(View.VISIBLE);
            }

        }

    }


    private void bindEventMsgViewHolder(MsgViewHolder holder, int position, Message itemData) {
        EventMessage eventMessage = (EventMessage) itemData;
        int msgDetailType = parseEventMsgType(eventMessage);
        if (msgDetailType == ITEM_TYPE_EVENT_FRIEND_INVITE_RECEIVE ||
                msgDetailType == ITEM_TYPE_EVENT_FRIEND_INVITE_SEND) {
            //invite friend.
            bindFriendInviteMsgViewHolder((FriendInviteMsgViewHolder) holder, position, eventMessage);
        } else if (msgDetailType == ITEM_TYPE_EVENT_FRIEND_ACCEPT_RECEIVE ||
                msgDetailType == ITEM_TYPE_EVENT_FRIEND_ACCEPT_SEND) {
            //accept friend.
            bindFriendAcceptMsgViewHolder((FriendAcceptMsgViewHolder) holder, position, eventMessage);
        } else if (msgDetailType == ITEM_TYPE_EVENT_FRIEND_REJECT_RECEIVE ||
                msgDetailType == ITEM_TYPE_EVENT_FRIEND_REJECT_SEND) {
            //reject friend.
            bindFriendRejectMsgViewHolder((FriendRejectMsgViewHolder) holder, position, eventMessage);
        } else {
            //just display or donothing.
            bindCustomMsgViewHolder((CustomMsgViewHolder) holder, position, itemData);
        }
    }


    private void bindFriendAcceptMsgViewHolder(FriendAcceptMsgViewHolder holder, int position, EventMessage itemData) {

        try {
            JSONObject jsonObject = new JSONObject(itemData.dataStr);

            PeopleEntity entity = GsonUtil.fromJson(jsonObject.optJSONObject("user_info").toString(), PeopleEntity.class);
            holder.userName.setText(PeopleEntityQuery.getDisplayName(entity));
            holder.content.setText(jsonObject.optString("content"));
            ImageUtils.loadCircleImage(mContext, holder.imageView, entity.icon_url, ImageUtils.getDefaultContactImageResource(entity.subuser_id));
            holder.user_info_container.setTag(entity);
            holder.user_info_container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //go to detail.
                    PeopleEntity peopleEntity = (PeopleEntity) v.getTag();
                    DetailPersonActivity.gotoDetailPersonActivity(mContext, peopleEntity);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void bindFriendRejectMsgViewHolder(FriendRejectMsgViewHolder holder, int position, EventMessage itemData) {

        try {
            JSONObject jsonObject = new JSONObject(itemData.dataStr);

            PeopleEntity entity = GsonUtil.fromJson(jsonObject.optJSONObject("user_info").toString(), PeopleEntity.class);
            holder.userName.setText(PeopleEntityQuery.getDisplayName(entity));
            holder.content.setText(jsonObject.optString("content"));
            ImageUtils.loadCircleImage(mContext, holder.imageView, entity.icon_url, ImageUtils.getDefaultContactImageResource(entity.subuser_id));

            holder.user_info_container.setTag(entity);
            holder.user_info_container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //invite again.
                    Intent intent = new Intent(mContext, AddNewFriendActicity.class);
                    PeopleEntity peopleEntity = (PeopleEntity) v.getTag();
                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, peopleEntity);
                    mContext.startActivity(intent);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void bindFriendInviteMsgViewHolder(final FriendInviteMsgViewHolder holder, int position, final EventMessage itemData) {

        try {
            JSONObject jsonObject = new JSONObject(itemData.dataStr);

            PeopleEntity entity = GsonUtil.fromJson(jsonObject.optJSONObject("user_info").toString(), PeopleEntity.class);
            holder.userName.setText(PeopleEntityQuery.getDisplayName(entity));
            holder.content.setText(jsonObject.optString("content"));
            ImageUtils.loadCircleImage(mContext, holder.imageView, entity.icon_url, ImageUtils.getDefaultContactImageResource(entity.subuser_id));
            final boolean isFriend = PeopleEntityQuery.getInstance().isFriend(entity.subuser_id);
            if (isFriend) {
                holder.content.setText(R.string.start_chat);
                holder.cancel_ok_container.setVisibility(View.GONE);
            } else {
                holder.cancel_ok_container.setVisibility(View.VISIBLE);
                boolean isRejected = false;
                if (isRejected) {

                }
            }

            holder.user_info_container.setTag(entity);
            holder.user_info_container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, AcceptNewFriendActicity.class);
                    PeopleEntity peopleEntity = (PeopleEntity) v.getTag();
                    intent.putExtra(AcceptNewFriendActicity.KEY_DETAIL_ENTITY, peopleEntity);
                    mContext.startActivity(intent);
                }
            });


            Button reject = (Button) holder.cancelBtn;
            reject.setVisibility(View.GONE);
            reject.setText(R.string.reject_btn);
            holder.cancelBtn.setTag(entity);
            holder.cancelBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RequestFriendManager.getInstance().rejectFriend((BaseActivity) mContext, (PeopleEntity) v.getTag());
                    //if success callback , make a new message.
                }
            });
            Button accept = (Button) holder.okBtn;
            accept.setText(R.string.accept_btn);
            holder.okBtn.setTag(entity);
            holder.okBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RequestFriendManager.getInstance().acceptFriend((BaseActivity) mContext, (PeopleEntity) v.getTag(), new NewFriendAdapter.OnFriendClickListener() {
                        @Override
                        public void onItemClickListener(PeopleEntity entity) {

                        }

                        @Override
                        public void callFriendRequest(String action, PeopleEntity peopleEntity) {

                        }

                        @Override
                        public void onFriendStatusChanged(PeopleEntity peopleEntity) {
//                            updateItem(itemData);
//                            //
//                            notifyDataSetChanged();

                            try {
                                holder.cancel_ok_container.setVisibility(View.GONE);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    });
                    //if success callback ,make a new message.
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void bindLocationMsgViewHolder(LocationMsgViewHolder holder, int position, Message itemData) {
        LocationMessage lMsg = (LocationMessage) itemData;
//        holder.location.setText(lMsg.getLocationDesc());

        int w = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_182_0_dp);
        int h = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_112_0_dp);


        String urlString;
        if (App.checkPlayServices(mContext)) {
            String latLng = lMsg.getLatitude() + "," + lMsg.getLongitude();
            urlString = new StringBuffer("http://maps.googleapis.com/maps/api/staticmap?center=").append(latLng)
                    .append("&zoom=14&size=")
                    .append(w)
                    .append("x")
                    .append(h)
                    .append("&sensor=true&markers=color:red%7Clabel:S%7C+")
                    .append(latLng).toString();

        } else {
            //http://api.map.baidu.com/staticimage?width=423&height=300&center=116.426777,39.911013&zoom=11&markers=116.417004,39.91367&markerStyles=l,0

            LatLng latLng = MapUtils.convertGpsToBaidu(lMsg.getLatitude(), lMsg.getLongitude());
            String center = latLng.longitude + "," + latLng.latitude;
            urlString = new StringBuffer().append("http://api.map.baidu.com/staticimage?")
                    .append("width")
                    .append(w)
                    .append("&height=")
                    .append(h)
                    .append("&center=")
                    .append(center)
                    .append("&zoom=14&markers=")
                    .append(center)
                    .append("&markerStyles=l").toString();


        }


        ImageUtils.loadImageByString(mContext, holder.map, urlString, R.mipmap.no_map, R.mipmap.no_map);

    }

    private void bindVideoMsgViewHolder(final VideoMsgViewHolder holder, int position, Message itemData) {
        final VideoMessage videoMsg = (VideoMessage) itemData;

        final String filePath = videoMsg.getFilePath();
        int status = videoMsg.getStatus();

        boolean showDownload = checkNeedShowDownLoad(holder, videoMsg);
        if (!showDownload) {
            holder.download.setImageResource(R.mipmap.video_icon);
            holder.download.setVisibility(View.VISIBLE);
        }
        String path = mContext.getFilesDir() + File.separator + FileUtils.getFileNameNoEx(filePath) + ".JPEG";
        // adjustVideoViewSize(holder,videoMsg,path);
        if (FileUtils.isFileExist(path)) {
            if (path.equals(holder.getPreBitmapTag())) {
            } else {
                ImageUtils.loadImageByString(mContext, holder.imageView, path);
                holder.setPreBitmapTag(path);
            }
        } else if (FileUtils.isFileExist(filePath)) {
            Observable.from(new String[]{filePath}).map(new Func1<String, String>() {
                @Override
                public String call(String s) {
                    Bitmap bitmap = ImageUtils.getFirstFrameBitmapFromVideo(s);
                    InputStream is = new ByteArrayInputStream(ImageUtils.bitmap2Bytes(bitmap));

                    String path = mContext.getFilesDir() + File.separator + FileUtils.getFileNameNoEx(filePath) + ".JPEG";
                    FileUtils.writeFile(path, is);

                    return path;
                }

            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<String>() {
                @Override
                public void onCompleted() {
                }

                @Override
                public void onError(Throwable e) {
                    Log.i(TAG, "load video first frame bitmap failed. so add previewImage.");
                    Bitmap bitmap = videoMsg.getPreviewImage();
                    if (bitmap != null) {
                        if (bitmap.equals(holder.getPreBitmapTag())) {
                        } else {

                            ImageUtils.loadImageByBitmap(mContext, holder.imageView, bitmap);
                        }
                    } else {
                        Log.i(TAG, "the previewImage is null. filePath:" + filePath + " msgKeyId:" + videoMsg.getKeyId());
                    }
                }

                @Override
                public void onNext(String path) {
                    if (path.equals(holder.getPreBitmapTag())) {
                    } else {
                        // adjustVideoViewSize(holder,videoMsg,path);
                        ImageUtils.loadImageByString(mContext, holder.imageView, path);
                    }
                }
            });
        } else {//load thumb
            if (videoMsg.getThumbUrl() != null) {
                ImageUtils.loadImageByString(mContext, holder.imageView, videoMsg.getThumbUrl(), R.mipmap.no_video, R.mipmap.no_video);
            } else {
                Bitmap bitmap = videoMsg.getPreviewImage();
                if (bitmap != null) {
                    if (bitmap.equals(holder.getPreBitmapTag())) {
                    } else {

                        ImageUtils.loadImageByBitmap(mContext, holder.imageView, bitmap);
                    }
                } else {
                    Log.i(TAG, "the previewImage is null. filePath:" + filePath + " msgKeyId:" + videoMsg.getKeyId());
                }
            }

        }
    }


    /**
     * 检查是否需要下载
     */
    private boolean checkNeedShowDownLoad(BaseFileMsgViewHolder holder, FileMessage msg) {
        String filePath = msg.getFilePath();
        if (msg.getStatus() == Message.STATUS_IN_PROGRESS) {
            holder.download.setVisibility(View.GONE);

            if (holder instanceof ImageMsgViewHolder) {
                if (msg.getTotalFileSize() > 0) {
                    ((ProgressImageView) ((ImageMsgViewHolder) holder).imageView).setProgress((int) (100 * msg.getFileCurSize() * 1.0f / msg.getTotalFileSize()));
                }
            }

            if (holder instanceof VideoMsgViewHolder) {
                if (msg.getTotalFileSize() > 0) {
                    ((ProgressImageView) ((VideoMsgViewHolder) holder).imageView).setProgress((int) (100 * msg.getFileCurSize() * 1.0f / msg.getTotalFileSize()));
                }
            }

            return true;
        } else {
            //set to 0.
            if (holder instanceof ImageMsgViewHolder) {
                ((ProgressImageView) ((ImageMsgViewHolder) holder).imageView).setProgress(100);

            }

            if (holder instanceof VideoMsgViewHolder) {
                ((ProgressImageView) ((VideoMsgViewHolder) holder).imageView).setProgress(100);

            }
            if (FileUtils.isFileExist(filePath)) {
                holder.download.setVisibility(View.GONE);
                return false;
            } else {

                holder.download.setImageResource(R.mipmap.download);
                holder.download.setVisibility(View.VISIBLE);

                return true;
            }
        }


    }

    private void bindCustomMsgViewHolder(CustomMsgViewHolder holder, int position, Message itemData) {
        holder.content.setText(itemData.getBody());//just display.
    }

    private void bindStickerMsgViewHolder(StickerMsgViewHolder holder, int position, Message itemData) {
        String stickerName = ((StickerMessage) itemData).getStickerName();
        String name = ImStickerMap.getInstance(mContext).getStickerName(stickerName);
        String stickerPath = ChatModule.CopyStickerToFolder(mContext, name);
        loadImageAsGif(mContext, holder.imageView, stickerPath, R.drawable.message_gif, R.drawable.message_gif);

    }


    private void bindBruningMsgViewHolder(BurningMsgViewHolder holder, int position, Message itemData) {

        // ImageUtils.loadImageByString(mContext, holder.imageView,null,R.mipmap.no_pic, R.mipmap.no_pic);
        // holder.imageView.setText( MessageUtils.getMsgBody(itemData));
        // holder.imageView.setTextColor(mContext.getResources().getColor(R.color.color_e0635a));

    }

    private void bindImageMsgViewHolder(ImageMsgViewHolder holder, int position, Message itemData) {

        ImageMessage imageMessage = (ImageMessage) itemData;
        int status = imageMessage.getStatus();
        String filePath = imageMessage.getFilePath();
        checkNeedShowDownLoad(holder, imageMessage);

        adjustImageViewSize(holder, (ImageMessage) itemData);
        Bitmap bitmap = imageMessage.getPreviewImage();
        if (bitmap != null) {

        } else {
            Log.i(TAG, "PreviewImage is null, msg:" + imageMessage.toString());
        }
        if (FileUtils.isFileExist(filePath)) {
            if (bitmap != null && !bitmap.isRecycled()) {
                Object preBitmapTag = holder.getPreBitmapTag();
                if (filePath.equals(preBitmapTag)) {

                } else {

                    ImageUtils.loadImageByString(mContext, holder.imageView, filePath);
                    holder.setPreBitmapTag(filePath);
                }

            } else {
                if (filePath.equals(holder.getPreBitmapTag())) {
                } else {

                    ImageUtils.loadImageByString(mContext, holder.imageView, filePath);
                }
            }

        } else {
            //load thumb
            if (imageMessage.getThumbUrl() != null) {
                ImageUtils.loadImageByString(mContext, holder.imageView, imageMessage.getThumbUrl(), R.mipmap.no_pic, R.mipmap.no_pic);

            } else {
                if (bitmap != null) {
                    if (bitmap.equals(holder.getPreBitmapTag())) {

                    } else {
                        ImageUtils.loadImageByBitmap(mContext, holder.imageView, bitmap);
                        holder.setPreBitmapTag(bitmap);
                    }
                } else {
                    Log.i(TAG, "the previewImage is null. filePath:" + filePath + " msgKeyId:" + imageMessage.getKeyId());
                }
            }
        }
    }

    private void adjustImageViewSize(ImageMsgViewHolder holder, ImageMessage msg) {
        Bitmap previewImage = msg.getPreviewImage();


        int width;
        int height;
        float scacle;

        String filePath = msg.getFilePath();
        int degree = -1;
        if (com.ultralinked.voip.api.utils.FileUtils.isFileExist(filePath)) {
            degree = ImageUtils.readPictureDegree(filePath);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filePath, options);
            width = options.outWidth;
            height = options.outHeight;
            if (degree % 180 == 90) {
                width = options.outHeight;
                height = options.outWidth;
            }

        } else {
            if (previewImage != null) {

                width = previewImage.getWidth();
                height = previewImage.getHeight();

            } else {
                if (msg.width > 0) {
                    width = msg.width;
                    height = msg.height;
                } else {
                    width = 1;
                    height = 1;
                    Log.e(TAG, "no previewImage and no src file. msg:" + msg.toString());
                }

            }

        }

        scacle = height * 1.0f / width;
        //fix too much small or larger
        if (scacle < 0.1f) {
            scacle = 1f;
        } else if (scacle > 10f) {
            scacle = 1f;
        }
        if (width > height) {
            //hen ping
            holder.width = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_160_0_dp);
            holder.height = (int) (holder.width * scacle);
        } else {
            holder.width = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_120_0_dp);
            holder.height = (int) (holder.width * scacle);
        }

        holder.msgContainerLayout.getLayoutParams().width = holder.width;
        holder.msgContainerLayout.getLayoutParams().height = holder.height;
        holder.imageView.getLayoutParams().width = holder.width;
        holder.imageView.getLayoutParams().height = holder.height;

    }

    private void adjustVideoViewSize(VideoMsgViewHolder holder, VideoMessage msg, String preImagePath) {
        Bitmap previewImage = msg.getPreviewImage();
        if (previewImage == null) {
            Log.e(TAG, " video previewImag is null, msg:" + msg.toString());
        }
        int width;
        int height;
        float scacle;

        String filePath = preImagePath;
        int degree = -1;
        if (com.ultralinked.voip.api.utils.FileUtils.isFileExist(filePath)) {
            degree = ImageUtils.readPictureDegree(filePath);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filePath, options);
            width = options.outWidth;
            height = options.outHeight;
            if (degree % 180 == 90) {
                width = options.outHeight;
                height = options.outWidth;
            }

        } else {
            if (previewImage != null) {

                width = previewImage.getWidth();
                height = previewImage.getHeight();

            } else {
                width = 1;
                height = 1;
            }

        }

        scacle = height * 1.0f / width;
        //fix too much small or larger
        if (scacle < 0.1f) {
            scacle = 1f;
        } else if (scacle > 10f) {
            scacle = 1f;
        }
        if (width > height) {
            //hen ping
            holder.width = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_160_0_dp);
            holder.height = (int) (holder.width * scacle);
        } else {
            holder.width = mContext.getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_120_0_dp);
            holder.height = (int) (holder.width * scacle);
        }


        holder.msgContainerLayout.getLayoutParams().width = holder.width;
        holder.msgContainerLayout.getLayoutParams().height = holder.height;
        holder.imageView.getLayoutParams().width = holder.width;
        holder.imageView.getLayoutParams().height = holder.height;

    }

    private void bindFileMsgViewHolder(FileMsgViewHolder holder, int position, Message itemData, String msgTime) {
        int width = holder.msgContainerLayout.getWidth();
        int merWidth = holder.msgContainerLayout.getMeasuredWidth();
        holder.msgContainerLayout.getLayoutParams().width = mContext.getResources().getDimensionPixelOffset(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_235_0_dp);

        FileMessage fMsg = (FileMessage) itemData;
        int status = fMsg.getStatus();
        String filePath = fMsg.getFilePath();
        checkNeedShowDownLoad(holder, fMsg);

        int totalFileSize = fMsg.getTotalFileSize();
        int persent = totalFileSize == 0 ? 0 : (int) (fMsg.getFileCurSize() * 1.0 / totalFileSize * 100);
        String currentPersent = "null";
        if (totalFileSize == 0) {
            currentPersent = "totalFileSize is 0";
        } else {
            currentPersent = persent + "%";
        }
        holder.persent.setText(currentPersent);
        if (status == Message.STATUS_OK) {
            holder.persent.setVisibility(View.GONE);
        }

        holder.statusIcon.setVisibility(View.GONE);
        holder.time.setText(msgTime);
        int size = ((FileMessage) itemData).getTotalFileSize();
        String fileSize = FileUtils.showFileSize(size);
        holder.fileSize.setText(fileSize);
        holder.fileName.setText(fMsg.getFileName());

    }

    private void bindUrlInfoMsgViewHolder(UrlInfoMsgViewHolder holder, int position, Message itemData) {
        UrlInfo urlInfo = (UrlInfo) itemData.tag;
        holder.title.setText(urlInfo.title);
        if (TextUtils.isEmpty(urlInfo.content)) {
            TextMessage message = (TextMessage) itemData;
            holder.content.setText(message.getText());
        } else {
            holder.content.setText(urlInfo.content);
        }

        if (!TextUtils.isEmpty(urlInfo.imgUrl)) {
            holder.imgUrl.setVisibility(View.VISIBLE);
            ImageUtils.loadImageByString(mContext, holder.imgUrl, urlInfo.imgUrl, R.mipmap.no_pic);
        } else {
            holder.imgUrl.setVisibility(View.GONE);
        }


    }

    private void bindTextMsgViewHolder(TextMsgViewHolder holder, int position, Message itemData) {

        holder.setTextMaxWidth(false);

//        if (itemData.getStatus() == Message.STATUS_FAILURE || itemData.getMessageFlag() == Message.MESSAGE_FLAG_BURNING){
//            holder.setTextMaxWidth(false);
//        }else{
//            holder.setTextMaxWidth(true);
//        }


        TextMessage tMsg = (TextMessage) itemData;
        int tsize = (int) (1.7 * holder.content.getTextSize());
        int size = tsize + (tsize % 2 == 0 ? 0 : 1);

        SpannableStringBuilder contentBuilder = null;

        SpannableString text = ImEmotionMap.genSpanString(
                tMsg.getText(), (size));

        String linkUserName = MessageUtils.linkMyself(itemData);
        if (linkUserName != null) {//@ link message.
            int findPos = TextUtils.indexOf(text, linkUserName);
            if (findPos > -1) {
                text.setSpan(new BackgroundColorSpan(mContext.getResources().getColor(R.color.color_f0b012)),
                        findPos, findPos + linkUserName.length(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }


        contentBuilder = new SpannableStringBuilder(text);
        //check the httplink info.
        ChatModule.checkUrlLink((BaseActivity) mContext, itemData, contentBuilder);
        holder.content.setText(contentBuilder);


    }

    private void updateBubbleInfo(MsgViewHolder holder, Message itemData) {
        if (itemData.isSender()) {

            holder.time.setTextColor(mContext.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_7f8b9f));

        } else {

            holder.time.setTextColor(mContext.getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_7f8b9f));

        }
    }

    public static final int ITEM_TYPE_SEND_BASE = 1;
    private static final int ITEM_TYPE_TEXT_SEND = 1;
    private static final int ITEM_TYPE_FILE_SEND = ITEM_TYPE_SEND_BASE + 1;
    private static final int ITEM_TYPE_IMAGE_SEND = ITEM_TYPE_SEND_BASE + 2;
    private static final int ITEM_TYPE_CUSTOM_SEND = ITEM_TYPE_SEND_BASE + 3;
    private static final int ITEM_TYPE_VIDEO_SEND = ITEM_TYPE_SEND_BASE + 4;
    private static final int ITEM_TYPE_LOCATION_SEND = ITEM_TYPE_SEND_BASE + 5;
    private static final int ITEM_TYPE_VOICE_SEND = ITEM_TYPE_SEND_BASE + 6;
    private static final int ITEM_TYPE_VCARD_SEND = ITEM_TYPE_SEND_BASE + 7;
    private static final int ITEM_TYPE_STICKER_SEND = ITEM_TYPE_SEND_BASE + 8;
    private static final int ITEM_TYPE_URL_INFO_SEND = ITEM_TYPE_SEND_BASE + 9;
    private static final int ITEM_TYPE_EVENT_FRIEND_INVITE_SEND = ITEM_TYPE_SEND_BASE + 10;
    private static final int ITEM_TYPE_EVENT_FRIEND_ACCEPT_SEND = ITEM_TYPE_SEND_BASE + 11;
    private static final int ITEM_TYPE_EVENT_FRIEND_REJECT_SEND = ITEM_TYPE_SEND_BASE + 12;
    private static final int ITEM_TYPE_VOIP_SEND = ITEM_TYPE_SEND_BASE+13;
    private static final int ITEM_TYPE_SEND_END = ITEM_TYPE_VOIP_SEND;

    public static final int ITEM_TYPE_RECEIVE_BASE = ITEM_TYPE_SEND_END;
    private static final int ITEM_TYPE_TEXT_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 1;
    private static final int ITEM_TYPE_FILE_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 2;
    private static final int ITEM_TYPE_IMAGE_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 3;
    private static final int ITEM_TYPE_CUSTOM_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 4;
    private static final int ITEM_TYPE_VIDEO_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 5;
    private static final int ITEM_TYPE_LOCATION_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 6;
    private static final int ITEM_TYPE_VOICE_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 7;
    private static final int ITEM_TYPE_VCARD_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 8;
    private static final int ITEM_TYPE_STICKER_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 9;
    private static final int ITEM_TYPE_URL_INFO_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 10;
    private static final int ITEM_TYPE_EVENT_FRIEND_INVITE_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 11;
    private static final int ITEM_TYPE_EVENT_FRIEND_ACCEPT_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 12;
    private static final int ITEM_TYPE_EVENT_FRIEND_REJECT_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 13;
    private static final int ITEM_TYPE_VOIP_RECEIVE = ITEM_TYPE_RECEIVE_BASE + 14;
    private static final int ITEM_TYPE_RECEIVE_END = ITEM_TYPE_VOIP_RECEIVE;

    public static final int ITEM_TYPE_SYSTEM_BASE = ITEM_TYPE_RECEIVE_END;
    private static final int ITEM_TYPE_TIPS = ITEM_TYPE_SYSTEM_BASE+1;
    private static final int ITEM_TYPE_COMPSING = ITEM_TYPE_SYSTEM_BASE+2;
    private static final int ITEM_TYPE_PUBLISH_INFO1 = ITEM_TYPE_SYSTEM_BASE+3;
    private static final int ITEM_TYPE_PUBLISH_INFO2 =ITEM_TYPE_SYSTEM_BASE+4;
    private static final int ITEM_TYPE_SYSTEM = ITEM_TYPE_SYSTEM_BASE+5;


    @Override
    public int getItemViewType(int position) {
        Message msg = mData.get(position);
        boolean isSender = msg.isSender();

        //for normal message.
        int itemType = 0;
        int msgType = msg.getType();
        switch (msgType) {
            case Message.MESSAGE_TYPE_TEXT: {
                if (MessageUtils.hasUrlLinkInfo(msg)) {
                    if (isSender) {
                        itemType = ITEM_TYPE_URL_INFO_SEND;
                    } else {
                        itemType = ITEM_TYPE_URL_INFO_RECEIVE;
                    }
                } else {
                    if (isSender) {
                        itemType = ITEM_TYPE_TEXT_SEND;
                    } else {
                        itemType = ITEM_TYPE_TEXT_RECEIVE;
                    }
                }
            }
            break;
            case Message.MESSAGE_TYPE_FILE:
                if (isSender) {
                    itemType = ITEM_TYPE_FILE_SEND;
                } else {
                    itemType = ITEM_TYPE_FILE_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_IMAGE:
                if (isSender) {
                    itemType = ITEM_TYPE_IMAGE_SEND;
                } else {
                    itemType = ITEM_TYPE_IMAGE_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_STICKER:
                if (isSender) {
                    itemType = ITEM_TYPE_STICKER_SEND;
                } else {
                    itemType = ITEM_TYPE_STICKER_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_CUSTOM:
                if (isSender) {
                    itemType = ITEM_TYPE_CUSTOM_SEND;
                } else {
                    itemType = ITEM_TYPE_CUSTOM_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_VIDEO:
                if (isSender) {
                    itemType = ITEM_TYPE_VIDEO_SEND;
                } else {
                    itemType = ITEM_TYPE_VIDEO_RECEIVE;
                }

                break;
            case Message.MESSAGE_TYPE_LOCATION:
                if (isSender) {
                    itemType = ITEM_TYPE_LOCATION_SEND;
                } else {
                    itemType = ITEM_TYPE_LOCATION_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_VOICE:
                if (isSender) {
                    itemType = ITEM_TYPE_VOICE_SEND;
                } else {
                    itemType = ITEM_TYPE_VOICE_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_VCARD:
                if (isSender) {
                    itemType = ITEM_TYPE_VCARD_SEND;
                } else {
                    itemType = ITEM_TYPE_VCARD_RECEIVE;
                }
                break;

            case Message.MESSAGE_TYPE_SUBSCRIBE:
                if (AsistantService.hasMoreItemsInfo((SubscribeMessage) msg)) {
                    itemType = ITEM_TYPE_PUBLISH_INFO2;
                } else {
                    itemType = ITEM_TYPE_PUBLISH_INFO1;
                }
                break;
            case Message.MESSAGE_TYPE_VOIP:
                if (isSender) {
                    itemType = ITEM_TYPE_VOIP_SEND;
                } else {
                    itemType = ITEM_TYPE_VOIP_RECEIVE;
                }
                break;
            case Message.MESSAGE_TYPE_EVENT:
                itemType = parseEventMsgType((EventMessage) msg);
                break;
//            case Message.MESSAGE_TYPE_PUBLISH:
//                itemType = parsePublishMsgType((PublishMessage)msg);
//                break;

            case Message.MESSAGE_TYPE_TIPS:
                itemType = ITEM_TYPE_TIPS;
                break;
            case Message.MESSAGE_TYPE_SYSTEM:
                itemType = ITEM_TYPE_SYSTEM;
                break;
            case ComposMessage.MESSAGE_TYPE_COMPOSMESSAGE:
                itemType = ITEM_TYPE_COMPSING;
                break;
        }

        return itemType;
    }


    private int parseEventMsgType(EventMessage msg) {
        boolean isSender = msg.isSender();
        int itemType;
        String data = msg.dataStr;
        try {
            JSONObject eventJson = new JSONObject(data);
            String event = eventJson.optString("event");
            if ("invite_friend".equals(event)) {
                if (isSender) {
                    itemType = ITEM_TYPE_EVENT_FRIEND_INVITE_SEND;
                } else {
                    itemType = ITEM_TYPE_EVENT_FRIEND_INVITE_RECEIVE;
                }
            } else if ("accept_friend".equals(event)) {
                if (isSender) {
                    itemType = ITEM_TYPE_EVENT_FRIEND_ACCEPT_SEND;
                } else {
                    itemType = ITEM_TYPE_EVENT_FRIEND_ACCEPT_RECEIVE;
                }
            } else if ("reject_friend".equals(event)) {
                if (isSender) {
                    itemType = ITEM_TYPE_EVENT_FRIEND_REJECT_SEND;
                } else {
                    itemType = ITEM_TYPE_EVENT_FRIEND_REJECT_RECEIVE;
                }
            } else {//unkonwn type.
                if (isSender) {
                    itemType = ITEM_TYPE_CUSTOM_SEND;
                } else {
                    itemType = ITEM_TYPE_CUSTOM_RECEIVE;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();//never go to here.
            if (isSender) {
                itemType = ITEM_TYPE_CUSTOM_SEND;
            } else {
                itemType = ITEM_TYPE_CUSTOM_RECEIVE;
            }
        }

        return itemType;
    }


    public void showCheckBoxForEdit() {
        isEdit = true;
        notifyDataSetChanged();

    }

    public void setCancelEdit() {
        isEdit = false;
        notifyDataSetChanged();
    }


    public void removeAllChatHistoryMessage() {
        mData.clear();
        notifyDataSetChanged();
    }


    public void removeAllChatHistoryMessageInMemoryCache() {
        mData.clear();
        notifyDataSetChanged();
    }

    private ArrayList<Message> selectedDeleteMsg = new ArrayList<Message>();

    public ArrayList<Message> getSelectedDeleteMsgs() {

        return selectedDeleteMsg;
    }


}
