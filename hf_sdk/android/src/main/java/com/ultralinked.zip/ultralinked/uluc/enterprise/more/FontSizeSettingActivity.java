/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.channguyen.rsv.RangeSliderView;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.WrapContentLinearLayoutManager;
import com.ultralinked.uluc.enterprise.baseui.widget.MessageRecyclerView;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatImRecyclerAdapter;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.TextMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Class to set font size
 *
 * @author Administrator
 */
public class FontSizeSettingActivity extends BaseActivity {


    RangeSliderView fontScaleChoose;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_setting_chat_font_size;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
    }

    private int getCheckFontSizeId(SPUtil.ScaleType scaleType) {

        if (scaleType == SPUtil.ScaleType.HUGE) {
            return 4;
        } else if (scaleType == SPUtil.ScaleType.LARGE) {
            return 3;
        } else if (scaleType == SPUtil.ScaleType.MEDIUM) {
            return 2;
        } else if (scaleType == SPUtil.ScaleType.STANDARD) {
            return 1;
        } else if (scaleType == SPUtil.ScaleType.SMALL) {
            return 0;
        }
        return 1;
    }


    MessageRecyclerView font_recycler_view;
    private void createMsgDisplay(List<Message> msgList) throws  Exception{
        TextMessage message = new TextMessage();
        message.setChatType(Message.CHAT_TYPE_SINGLE);
        message.setType(Message.MESSAGE_TYPE_TEXT);

        String jsonData = TextMessage.getTextJson(getString(R.string.preview_text_size),null);
        message.setStatus(Message.STATUS_DELIVERY_OK);
        message.setSender(true);
        message.setReceiver(App.getInstance().getString(R.string.app_name));
        message.setSender(SPUtil.getUserID());
        message.setBody(jsonData);
        message.parseData(new JSONObject(jsonData));
        msgList.add(message);

        //2
        TextMessage message2 = new TextMessage();
        message2.setChatType(Message.CHAT_TYPE_SINGLE);
        message2.setType(Message.MESSAGE_TYPE_TEXT);
        message2.setSender(false);
        jsonData = TextMessage.getTextJson(getString(R.string.darg_change_text_size),null);
        message2.setSender(App.getInstance().getString(R.string.app_name));
        message2.setReceiver(SPUtil.getUserID());
        message2.setBody(jsonData);
        message2.parseData(new JSONObject(jsonData));
        msgList.add(message2);

//        //3
//        jsonData = TextMessage.getTextJson(content,null);
//        message.setSender(App.getInstance().getString(R.string.app_name));
//        message.setReceiver(SPUtil.getUserID());
//        message.setBody(jsonData);
//        message.parseData(new JSONObject(jsonData));
//        msgList.add(message);


    }

    @Override
    public void initView(Bundle savedInstanceState) {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.font_size);
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        font_recycler_view = bind(R.id.font_recycler_view);
        List<Message> msgList = new ArrayList<>();
        LinearLayoutManager  layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        font_recycler_view.setLayoutManager(layoutManager);

        try {
            createMsgDisplay(msgList);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ChatImRecyclerAdapter adapter = new ChatImRecyclerAdapter(this, msgList, false);
        font_recycler_view.setAdapter(adapter);
        fontScaleChoose = bind(R.id.font_choose);
        fontScaleChoose.setOnSlideListener(new RangeSliderView.OnSlideListener() {
            @Override
            public void onSlide(int index) {
                Log.i(TAG, "choose font Type:" + index);
                int type = (index + 1);

                if (type == SPUtil.ScaleType.HUGE.getNumVal()) {
                    SPUtil.setFontScale(FontSizeSettingActivity.this, SPUtil.ScaleType.HUGE);
                } else if (type == SPUtil.ScaleType.LARGE.getNumVal()) {
                    SPUtil.setFontScale(FontSizeSettingActivity.this, SPUtil.ScaleType.LARGE);
                } else if (type == SPUtil.ScaleType.MEDIUM.getNumVal()) {
                    SPUtil.setFontScale(FontSizeSettingActivity.this, SPUtil.ScaleType.MEDIUM);
                } else if (type == SPUtil.ScaleType.STANDARD.getNumVal()) {
                    SPUtil.setFontScale(FontSizeSettingActivity.this, SPUtil.ScaleType.STANDARD);
                } else if (type == SPUtil.ScaleType.SMALL.getNumVal()) {
                    SPUtil.setFontScale(FontSizeSettingActivity.this, SPUtil.ScaleType.SMALL);
                }


                try {
                    List<Message> msgList = new ArrayList<>();
                    createMsgDisplay(msgList);
                    ChatImRecyclerAdapter adapter = new ChatImRecyclerAdapter(FontSizeSettingActivity.this, msgList, false);
                    font_recycler_view.setAdapter(adapter);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        fontScaleChoose.setInitialIndex(getCheckFontSizeId(SPUtil.getFontScaleType(this)));
    }


}
