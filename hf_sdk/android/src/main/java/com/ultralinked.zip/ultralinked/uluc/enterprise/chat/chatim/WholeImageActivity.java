package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.photoview.PhotoView;
import com.ultralinked.uluc.enterprise.baseui.widget.photoview.PhotoViewAttacher;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.ConfigApi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by lly on 2016/9/19.
 */
public class WholeImageActivity extends BaseActivity{

    PhotoView mPhotoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_whole_image;
    }



    public  String getSavedFilePath(String origalFilePath){

        String appName =  ConfigApi.appName;

        String savedDir = com.ultralinked.voip.api.utils.FileUtils.getSDPath() + File.separator  + appName + File.separator + "saved" + File.separator;
        FileUtils.createFileDir(savedDir);

        return  savedDir + FileUtils.getFileName(origalFilePath);

    }


    @Override
    public void initView(Bundle savedInstanceState) {
        Uri uri = getIntent().getParcelableExtra("uri");
        mPhotoView = bind(R.id.image_view);
      final  TextView save = bind(R.id.titleRight);
          final TextView title = bind(R.id.titleCenter);
        ImageUtils.buttonEffect(save);
        View back = bind(R.id.left_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

       final String path = uri.getPath();
         String FileSavedPath = "";
        if (FileUtils.isFileExist(path)){
            FileSavedPath = getSavedFilePath(path);

            if (FileUtils.isFileExist(FileSavedPath)){
                goneView(save);
                title.setText(getText(R.string.preview));

            }else{

                Log.i(TAG,"save file path will be =="+FileSavedPath);
            }
        }else{
            Log.i(TAG,"file not exsit=="+path);
        }
        final String savedFilePath = FileSavedPath;

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveImage(path,savedFilePath);
                showToast(R.string.image_save_succ);
                goneView(save);
                title.setText(getText(R.string.preview));
            }
        });



        Glide.with(this).load(uri).diskCacheStrategy(DiskCacheStrategy.ALL).error(R.mipmap.no_pic).into(mPhotoView);

        mPhotoView.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
            @Override
            public void onPhotoTap(View view, float x, float y) {
               // WholeImageActivity.this.finish();
            }

            @Override
            public void onOutsidePhotoTap() {
                //WholeImageActivity.this.finish();
            }
        });
    }


    public  File saveImage(String filePath, String savedFilePath) {

        File file = new File(savedFilePath);
        Bitmap bmp = BitmapFactory.decodeFile(filePath);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
            if (bmp!=null&&!bmp.isRecycled()){
                bmp.recycle();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
       //save to gallery.
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri);
        sendBroadcast(intent);
        return  file;
    }


}
