package com.ultralinked.uluc.enterprise.chat.group;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.chat.chatdetails.GroupChatDetailsFragment;
import com.ultralinked.uluc.enterprise.chat.chatdetails.GroupQRCodeActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.GroupMember;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.holdingfuture.flutterapp.hfsdk.R.id.group_qr_code;

/**
 * Created by mac on 16/11/12.
 */

public class ChooseGroupMemberActivity extends BaseActivity{

    public static final int REQUEST_DELETE_MEMBERS = 0x11;
    public static final int REQUEST_AT_MEMBERS = 0x12;

    public static final String REQUEST_CODE = "requestcode";


    //not contain myself.





    public static void startForResult(Fragment context, int requestCode , Bundle data) {
        Intent intent = new Intent(context.getContext(), ChooseGroupMemberActivity.class);
        if (requestCode == REQUEST_DELETE_MEMBERS) {
            intent.putExtra(REQUEST_CODE, REQUEST_DELETE_MEMBERS);
        } else if (requestCode == REQUEST_AT_MEMBERS) {
            intent.putExtra(REQUEST_CODE, REQUEST_AT_MEMBERS);
        } else {
            throw new NullPointerException("ChooseGroupMemberActivity has a bad request code");
        }

        if (data!=null){
            intent.putExtra("data",data);
        }

        context.startActivityForResult(intent, requestCode);
    }


    public static void startForResult(Fragment context, int requestCode) {
        startForResult(context,requestCode,null);
    }

    void kickMember(String memberId){
        groupConversation.kickMember(memberId);
    }

    private TextView titleRight;
    private EditText mSearchEdittext;
    private TextView titleCenter;
    private ListView chooseMemeberList;
    private ChooseMemberAdapter adapter;
    private List<GroupMember> groupMembers;
    private GroupConversation groupConversation;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_choose_group_member;
    }

    int mode = -1;


    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleRight = (TextView) findViewById(R.id.titleRight);
        mode = getIntent().getIntExtra(REQUEST_CODE, -1);
        if (mode  == REQUEST_AT_MEMBERS) {
            titleCenter.setText(R.string.select_member_title);
            titleRight.setVisibility(View.GONE);
        } else if (mode == REQUEST_DELETE_MEMBERS) {
            titleCenter.setText(R.string.delete_member_title);
            titleRight.setVisibility(View.VISIBLE);
        }


        titleRight.setText(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_done);

        titleRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mode == REQUEST_AT_MEMBERS) {
                  //  createAtMember();
                } else if (mode == REQUEST_DELETE_MEMBERS) {
                    deleteMembers();
                }
            }
        });
    }

    List<String> selectedMembers = new ArrayList<>();

    private void deleteMembers() {

        Log.i(TAG, "deleteMembers size " + selectedMembers.size());
        for (String entityId:selectedMembers
             ) {
            kickMember(entityId);
        }
        finish();
    }

    private  void toggleDeleteMember(PeopleEntity enity){

        if (!selectedMembers.contains(enity.subuser_id)){
            selectedMembers.add(enity.subuser_id);
        }else{
            selectedMembers.remove(enity.subuser_id);
        }
        adapter.notifyDataSetChanged();
        CaculateSelectedNumber();

    }

    /**
     * change title when item checked
     */
    private void CaculateSelectedNumber() {

        int total = selectedMembers.size();
        if (0 == total) {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.delete_member_title));
        } else if (1 == total) {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title_count_one));
        } else {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title_count, ""+total));
        }

    }

    private void createAtMember(PeopleEntity entity) {
        Intent intent = new Intent();
        ArrayList<String> selectedMembers = new ArrayList<String>();
        selectedMembers.add(entity.subuser_id);
        intent.putStringArrayListExtra("select_members",selectedMembers);
        setResult(RESULT_OK,intent);
        finish();
    }


    private void initSearchView() {
        mSearchEdittext = (EditText) findViewById(R.id.search_edittext);
        mSearchEdittext.addTextChangedListener(new TextWatcher() {


            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                //before search record which data is checked
                freshSearchData(s);

            }
        });
    }


    List<PeopleEntity> members = new ArrayList<>();

    private void freshSearchData(Editable s) {
        List<PeopleEntity> searchList = new ArrayList<>();
        if (TextUtils.isEmpty(s)){
            refreshGroupMembersInfo();
        }else{
            String keyword = s.toString();
            List<PeopleEntity> mData = new ArrayList<>(members);
            for (PeopleEntity entity:mData
                 ) {
                if (PeopleEntityQuery.getDisplayName(entity).contains(keyword)){
                    searchList.add(entity);
                }
            }
            adapter.updateList(searchList);
        }
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        initTitleBar();
        initSearchView();
        chooseMemeberList = bind(R.id.listview);
        chooseMemeberList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (mode == REQUEST_AT_MEMBERS) {
                    createAtMember(adapter.getItem(position));
                } else if (mode == REQUEST_DELETE_MEMBERS) {
                    toggleDeleteMember(adapter.getItem(position));
                }
            }
        });

        Bundle data = getIntent().getBundleExtra("data");

        groupConversation = GroupConversation.getConversationByGroupId(data.getString("group_id"));
        if (groupConversation == null) {
            finish();
            Log.e(TAG,"mConversation is null.");
            return ;
        }
        if (mode == REQUEST_AT_MEMBERS){
            ArrayList<String> filterAtMemebers = data.getStringArrayList("linkedMembers");
        }else{

        }

        initData();

        registerReceiver();

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unRegisterReceiver();
    }

    private void registerReceiver() {
        IntentFilter groupMemberChangIntentFilter = new IntentFilter(MessagingApi.EVENT_GROUP_MEMBER_CHANGE);
        groupMemberChangIntentFilter.addAction(MessagingApi.EVENT_GROUP_INFO_CHANGED);

        LocalBroadcastManager.getInstance(this).registerReceiver(groupMemberChangeReceiver,groupMemberChangIntentFilter);
    }
    private void unRegisterReceiver() {

        LocalBroadcastManager.getInstance(this).unregisterReceiver(groupMemberChangeReceiver);

    }


    private BroadcastReceiver groupMemberChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (MessagingApi.EVENT_GROUP_INFO_CHANGED.equals(action) || MessagingApi.EVENT_GROUP_MEMBER_CHANGE.equals(action)) {


                String from = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
                String grouptitle = intent.getStringExtra(MessagingApi.PARAM_GROUP_TITLE);
                String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
                Log.i(TAG, "groupMemberChangeReceiver~~ from: " + from + "  grouptitle:" + grouptitle + " groupId:" + groupId);


                if (!TextUtils.isEmpty(groupId)) {

                    if (groupId.equals(groupConversation.getGroupID())) {
                        //update groupconversation
                        groupConversation = GroupConversation.getConversationByGroupId(groupConversation.getGroupID());
                        refreshGroupMembersInfo();
                    } else {
                        Log.i(TAG, "not belong to current group. groupId:" + groupId + " groupName:" + grouptitle);
                    }

                } else {
                    Log.i(TAG,"groupMemberChangeReceiver~~ groupid is empty.");
                }



            }
        }
    };


    //refresh group members
    private void refreshGroupMembersInfo() {
        if(groupConversation == null){
            Log.i(TAG,"the group conversation is null.");
            return;
        }
        groupMembers = groupConversation.getGroupMember();
        if (groupMembers == null || groupMembers.isEmpty()) {
            Log.i(TAG,"the group member is only yourself.");
            return;
        }



        //adjust recyclerview height

        Observable.create(new Observable.OnSubscribe<List<PeopleEntity>>() {
            @Override
            public void call(Subscriber<? super List<PeopleEntity>> subscriber) {
                List<PeopleEntity> peopleEntities = new ArrayList<PeopleEntity>();
                List<PeopleEntity> queryPeopleEntities = new ArrayList<PeopleEntity>();

                String mySelfId = SPUtil.getUserID();

                for (int i = 0; i < groupMembers.size(); i++) {
                    String userId = groupMembers.get(i).getMemberName();
                    if (userId.equals(mySelfId)){
                        continue;
                    }

                    PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userId);

                    if (!PeopleEntityQuery.hasFoundPeople(peopleEntity)){

                        if (peopleEntity == null) {
                            peopleEntity = new PeopleEntity();
                            peopleEntity.subuser_id = userId;
                        }

                        Message.PeerInfo peerInfo =  groupMembers.get(i).getPeerInfo();
                        if (peerInfo!=null && !TextUtils.isEmpty(peerInfo.userName)){
                            peopleEntity.name = peerInfo.userName;
                            peopleEntity.nickname = peerInfo.nickName;
                        }else{
                            peopleEntity.name = userId;
                        }

                        //add to api query userInfos.
                        queryPeopleEntities.add(peopleEntity);
                    }


                    peopleEntities.add(peopleEntity);

                }

                callQueryStrangerMemberInfos(queryPeopleEntities);//update to persnal table.
                subscriber.onNext(peopleEntities);
            }
        }).compose(this.<List<PeopleEntity>>bindToLifecycle()).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<List<PeopleEntity>>() {
            @Override
            public void call(List<PeopleEntity> peopleEntities) {
                members = peopleEntities;
                adapter.updateList(peopleEntities);
            }
        });


    }

    private void callQueryStrangerMemberInfos(List<PeopleEntity> queryPeopleEntities) {
        if (queryPeopleEntities.isEmpty()){
            return;
        }

        List<String> userIds = new ArrayList<>();

        for (PeopleEntity people:queryPeopleEntities
                ) {
            userIds.add(people.subuser_id);
        }

        RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
            @Override
            public void onResultFriendList(final List<PeopleEntity> entities) {
                if (getActivity()!=null && !getActivity().isFinishing()){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mergeGroupMemberInfo(entities);
                        }
                    });
                }
            }

            @Override
            public void onQueryFailed(List<String> requestUserIds) {

            }
        });

    }



    private void mergeGroupMemberInfo(List<PeopleEntity> queryPeoples) {


        for (PeopleEntity people:queryPeoples) {
            adapter.updateItem(people);
        }

    }



    protected void initData() {
       boolean multiChoice = mode == REQUEST_DELETE_MEMBERS;
        adapter = new ChooseMemberAdapter(this,multiChoice,new ArrayList<PeopleEntity>());

        chooseMemeberList.setAdapter(adapter);


        refreshGroupMembersInfo();

    }




    public class ChooseMemberAdapter extends MyBaseAdapter<PeopleEntity> {


        private  boolean checkBoxEnable = false;

        public ChooseMemberAdapter(Context context, boolean multiChoice,ArrayList<PeopleEntity> list) {
            super(context,R.layout.choose_member_list_item_select, list);
            checkBoxEnable  = multiChoice;
        }




        @Override
        public void setHolder(MyHolder holder, PeopleEntity entity) {

            TextView tvTitle = holder.getView(R.id.expandedListItem);
            ImageView IvHead = holder.getView(R.id.expandedListItem_Head);
            CheckBox checkBox = holder.getView(R.id.expandedListItem_CheckBox);
            int defaultId =  ImageUtils.getDefaultContactImageResource(entity.subuser_id);
            ImageUtils.loadCircleImage(getContext(), IvHead, entity.icon_url, defaultId);
            String name = PeopleEntityQuery.getDisplayName(entity);
            tvTitle.setText(name);
            if (checkBoxEnable){
                if (selectedMembers.contains(entity.subuser_id)){
                    checkBox.setBackgroundResource(R.mipmap.choose_click);
                    checkBox.setChecked(true);
                }else{
                    checkBox.setBackgroundResource(R.mipmap.choose);
                    checkBox.setChecked(false);
                }

            }else{
                checkBox.setVisibility(View.GONE);
            }


        }





        }


}
