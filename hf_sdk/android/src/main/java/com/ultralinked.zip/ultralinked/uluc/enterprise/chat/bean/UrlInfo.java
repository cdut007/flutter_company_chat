package com.ultralinked.uluc.enterprise.chat.bean;

import java.io.Serializable;

/**
 * Created by ultralinked on 16/9/26.
 */
public class UrlInfo implements Serializable{

    @Override
    public String toString() {
        return "UrlInfo{" +
                "title='" + title + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", content='" + content + '\'' +
                '}';
    }

    public String title;
    public String imgUrl;
    public String content;
}
