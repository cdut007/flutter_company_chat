package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MyCustomDialog;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


//only for private setting page.
public class SetPasswordActivity extends BaseActivity implements View.OnClickListener {

    EditText etNewPsd, etComfPsd;
    private String lunchType;//set login psd or set private psd
    private MyCustomDialog dialog;
    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_set_password;
    }


    @Override
    public void initView(Bundle savedInstanceState) {
        etNewPsd = bind(R.id.etNewPassword);
        etComfPsd = bind(R.id.etConPassword);
        lunchType=getIntent().getExtras().getString("lunch_model");
        Log.i(TAG,"type======"+lunchType);

        initListener(this, R.id.tvResetPsd, R.id.btRequest, R.id.left_back);
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        ((TextView) bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.set_password);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.tvResetPsd:
                Bundle bundle=new Bundle();
                bundle.putString("lunch_type",lunchType);
                lunchActivity(ResetPsdActivity.class,bundle);
                finish();
                break;

            case R.id.btRequest:

                String psd1 = etNewPsd.getText().toString();
                String psd2 = etComfPsd.getText().toString();
                if (TextUtils.isEmpty(psd1) || TextUtils.isEmpty(psd2)) {
                    showToast(getString(R.string.empty_password));
                    return;
                } else if (!psd1.equals(psd2)) {
                    showToast(getString(R.string.inconsistent_password));
                    return;
                } else if("login_psd".equals(lunchType)){
                    //setLoginPsd(psd1);
                } else if("private_psd".equals(lunchType)){
                    setPrivatePsd(psd1);
                }
                dialog=MyCustomDialog.getInstance(this);
                dialog.showWaiting("Requesting ...",false);
                break;
            case R.id.left_back:
                finish();
                break;
        }
    }

    private void setLoginPsd(String oldpas,String psd1) {
        ApiManager.getInstance().changeUserPassword(oldpas,psd1)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"setLoginPsdComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, HttpErrorException.handErrorMessage(e));
                        showToast(com.holdingfuture.flutterapp.hfsdk.R.string.option_error);
                        dialog.dismiss();
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);

                        showToast(com.holdingfuture.flutterapp.hfsdk.R.string.option_success);
                        SPUtil.saveLoginModel(SPUtil.LOGIN_BY_PSD);
                        dialog.dismiss();
                        finish();
                    }

                });
    }

    private void setPrivatePsd(final String psd1) {
        //private psd
        ApiManager.getInstance().changePrivatePsd(psd1)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"setPrivatePsdComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG,eMsg);
                        dialog.dismiss();
                        showToast(eMsg+"");
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        SPUtil.saveUserPrivatePsd(psd1);
                        Log.i("option success!");
                        dialog.dismiss();
                        finish();
                    }

                });
    }
}
