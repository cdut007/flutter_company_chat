package com.ultralinked.uluc.enterprise.pay;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DividerGridDecoration;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/20.
 */

public class RechargeActivity extends BaseActivity implements View.OnClickListener, BaseRecyclerAdapter.OnItemClickListener {

    EditText mEditAmount;
    RecyclerView mRecycler;

    List<ProductInfo> mProductList;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_recharge;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        mRecycler = bind(R.id.recycler_recharge);
        mEditAmount = bind(R.id.edit_recharge_amount);
        bind(R.id.btn_submit_amount).setOnClickListener(this);
        getNetworkInfo();
    }

    @Override
    protected void setTopBar() {
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.account_top_up);
        bind(R.id.left_back).setOnClickListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        KeyBoardUtils.closeInputMethod(this);
        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.btn_submit_amount:
                String amount = mEditAmount.getText().toString();
                if (TextUtils.isEmpty(amount)) {
                    showToast(getString(R.string.recharge_no_amount_prompt));
                } else {
                    jumpToPaymentActivity(new ProductInfo(amount));
                }
                break;
        }
    }

    private void getNetworkInfo() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getProductList()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "getNetworkInfo success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getNetworkInfo fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            if (TextUtils.isEmpty(response)) {
                                return;
                            }
                            Log.i(TAG, response);
                            mProductList = new Gson().fromJson(response, new TypeToken<List<ProductInfo>>() {
                            }.getType());
                            for (Iterator<ProductInfo> iterator = mProductList.iterator(); iterator.hasNext(); ) {
                                ProductInfo tempInfo = iterator.next();
                                if (tempInfo.getProduct_id().equals("custom")) {
                                    iterator.remove();
                                }
                            }
                            mRecycler.setLayoutManager(new GridLayoutManager(RechargeActivity.this, 3));
                            mRecycler.addItemDecoration(new DividerGridDecoration(3, getResources().getDimensionPixelSize(R.dimen.px_20_0_dp), true));
                            AmountAdapter adapter = new AmountAdapter(RechargeActivity.this, mProductList);
                            adapter.setOnItemClickListener(RechargeActivity.this);
                            mRecycler.setAdapter(adapter);
                        } catch (Exception e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    private void jumpToPaymentActivity(ProductInfo info) {
        info.setProduct_type("charge");
        Intent intent = new Intent(this, PaymentActivity.class);
        intent.putExtra("product", info);
        startActivity(intent);
    }

    @Override
    public void onItemClick(View itemView, int pos) {
        if (mProductList != null && !mProductList.isEmpty()) {
            jumpToPaymentActivity(mProductList.get(pos));
        }
    }

    class AmountAdapter extends BaseRecyclerAdapter<ProductInfo, RecyclerViewHolder> {

        AmountAdapter(Context ctx, List list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_recharge_amount;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, ProductInfo itemData) {
            holder.getTextView(R.id.txt_item_amount).setText(String.format(getString(R.string.recharge_amount), itemData.getPrice()));
        }

    }
}
