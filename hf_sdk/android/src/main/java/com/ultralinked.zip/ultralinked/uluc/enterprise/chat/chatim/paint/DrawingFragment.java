package com.ultralinked.uluc.enterprise.chat.chatim.paint;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.trello.rxlifecycle.components.support.RxAppCompatActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.chatim.PaintModel;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.DrawingView;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.CenterCircleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.CircleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.DrawingBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.EllipseBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.IsoscelesTriangleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.LineBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.PenBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.PolygonBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.RectangleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.RhombusBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.RightAngledTriangleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.RoundedRectangleBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.drawing.ShapeBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.brush.text.TextBrush;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.drawingview.model.DrawingStep;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.jsonmodel.Json;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * DrawingFragment
 * AndroidDrawingBoard <com.vilyever.androiddrawingboard>
 * Created by vilyever on 2015/9/21.
 * Feature:
 */
public class DrawingFragment extends DialogFragment {
    private final DrawingFragment self = this;

    private DrawingView drawingView;

    private Button undoButton;
    private Button redoButton;
    private Button clearButton;

    private ThicknessAdjustController thicknessAdjustController;

    private List<Button> singleSelectionButtons;

    private List<ShapeBrush> shapeBrushes = new ArrayList<>();
    private PenBrush penBrush;
    private TextBrush textBrush;
    private com.ultralinked.voip.api.Conversation conversation;
    private RxAppCompatActivity activity;

    /* #Constructors */
    public DrawingFragment() {
        // Required empty public constructor
    }
    Dialog dialog;

    public static DrawingFragment getInstance(com.ultralinked.voip.api.Conversation conversation) {
        DrawingFragment burningFragment = new DrawingFragment();
        burningFragment.conversation = conversation;
        return burningFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = (RxAppCompatActivity) activity;
    }



    public void updateDraw(JSONObject drawData) {
        Log.i("updateDraw",drawData.toString());
        try{
            DrawingStep drawingStep =  new Json<>(DrawingStep.class).modelFromJson(drawData);
            self.drawingView.drawNextOverStep(drawingStep);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.dialog = new Dialog(getActivity(), R.style.CustomDatePickerDialog);
        DrawResource.context = getActivity();

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ViewGroup rootView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.remote_draw_drawing_fragment, null);


        self.drawingView = (DrawingView) rootView.findViewById(R.id.drawingView);
        self.drawingView.setUndoRedoStateDelegate(new DrawingView.UndoRedoStateDelegate() {
            @Override
            public void onUndoRedoStateChange(DrawingView drawingView, boolean canUndo, boolean canRedo) {
                self.undoButton.setEnabled(canUndo);
                self.redoButton.setEnabled(canRedo);
            }
        });

        self.drawingView.setInterceptTouchDelegate(new DrawingView.InterceptTouchDelegate() {
            @Override
            public void requireInterceptTouchEvent(DrawingView drawingView, boolean isIntercept) {

            }
        });

        self.drawingView.setDrawingStepDelegate(new DrawingView.DrawingStepDelegate() {
            @Override
            public void onDrawingStepBegin(DrawingView drawingView, DrawingStep step) {
                Log.i("onDrawingStepBegin","");

                sendDrawInfo(step);
            }

            @Override
            public void onDrawingStepChange(DrawingView drawingView, DrawingStep step) {
                Log.i("onDrawingStepChange","");
                //sendDrawInfo(step);
            }

            @Override
            public void onDrawingStepEnd(DrawingView drawingView, DrawingStep step) {
                Log.i("onDrawingStepEnd","");
                sendDrawInfo(step);
            }

            @Override
            public void onDrawingStepCancel(DrawingView drawingView, DrawingStep step) {
                Log.i("onDrawingStepCancel","");
                sendDrawInfo(step);
            }
        });

        self.drawingView.setBackgroundDatasource(new DrawingView.BackgroundDatasource() {
            @Override
            public Drawable gainBackground(DrawingView drawingView, String identifier) {
                return null;
            }
        });

        self.undoButton = (Button) rootView.findViewById(R.id.undoButton);
        self.undoButton.setEnabled(false);
        self.undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                self.drawingView.undo();
            }
        });

        self.redoButton = (Button) rootView.findViewById(R.id.redoButton);
        self.redoButton.setEnabled(false);
        self.redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                self.drawingView.redo();
            }
        });

        self.clearButton = (Button) rootView.findViewById(R.id.clearButton);
        self.clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                self.drawingView.clear();
            }
        });

        self.penBrush = PenBrush.defaultBrush();
        self.drawingView.setBrush(self.penBrush);

        self.textBrush = TextBrush.defaultBrush().setTypefaceStyle(Typeface.ITALIC);

        self.shapeBrushes.add(PolygonBrush.defaultBrush());
        self.shapeBrushes.add(LineBrush.defaultBrush());
        self.shapeBrushes.add(RectangleBrush.defaultBrush());
        self.shapeBrushes.add(RoundedRectangleBrush.defaultBrush());
        self.shapeBrushes.add(CircleBrush.defaultBrush());
        self.shapeBrushes.add(EllipseBrush.defaultBrush());
        self.shapeBrushes.add(RightAngledTriangleBrush.defaultBrush());
        self.shapeBrushes.add(IsoscelesTriangleBrush.defaultBrush());
        self.shapeBrushes.add(RhombusBrush.defaultBrush());
        self.shapeBrushes.add(CenterCircleBrush.defaultBrush());

        initColor();
        self.singleSelectionButtons = new ArrayList<>();
        dialog.setContentView(rootView);
        dialog.setCanceledOnTouchOutside(true);
        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.CENTER;
        float scale = Float.valueOf(getActivity().getResources().getString(R.string.dialog_width_scale));
        int width = (int) (ScreenUtils.getScreenWidth(getActivity())* scale);
        int height = (int) (ScreenUtils.getScreenHeight(getActivity())* 0.6);
        wlp.width = width;
        wlp.height = height;
        window.setAttributes(wlp);


        return dialog;
    }

    private void initColor() {
        Random random = new Random();
        int color = Color.argb(Math.abs(random.nextInt()) % 256, Math.abs(random.nextInt()) % 256, Math.abs(random.nextInt()) % 256, Math.abs(random.nextInt()) % 256);

        self.penBrush.setColor(color);
        self.textBrush.setColor(color);
        for (DrawingBrush brush : self.shapeBrushes) {
            brush.setColor(color);
        }
    }

    private  Handler mDrawingHandler = null;

    private void sendDrawInfo(final DrawingStep step) {
        if (mDrawingHandler == null){
            HandlerThread mTypingThreadHandler = new HandlerThread("sendDrawing");
            mTypingThreadHandler.start();
            mDrawingHandler = new Handler(mTypingThreadHandler.getLooper());
        }

        mDrawingHandler.post(new Runnable() {
            @Override
            public void run() {
                PaintModel paintModel = new PaintModel();
                DrawingStep drawingStep = step.copy();
                drawingStep.setRemote(true);
                drawingStep.setStepOver(true);
                conversation.sendPaintInfo(paintModel.paint(drawingStep.toJson()));
            }
        });

    }


    boolean small = false;
    public void dismiss() {
        if (mDrawingHandler!=null){
            mDrawingHandler.getLooper().quit();
            mDrawingHandler =null;
        }
        if (dialog != null) {
            dialog.dismiss();
        }
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mDrawingHandler!=null){
            mDrawingHandler.getLooper().quit();
            mDrawingHandler =null;
        }
    }

    /* #Accessors */
    public ThicknessAdjustController getThicknessAdjustController() {
        if (self.thicknessAdjustController == null) {
            self.thicknessAdjustController = new ThicknessAdjustController(self.getActivity());
            self.thicknessAdjustController.setThicknessDelegate(new ThicknessAdjustController.ThicknessDelegate() {
                @Override
                public void thicknessDidChangeFromThicknessAdjustController(ThicknessAdjustController controller, int thickness) {
                    self.penBrush.setSize(thickness);
                    self.textBrush.setSize(thickness);
                    for (DrawingBrush brush : self.shapeBrushes) {
                        brush.setSize(thickness);
                    }
                }
            });
        }
        return thicknessAdjustController;
    }

    /* #Private Methods */
    private void selectButton(List<Button> buttons, Button button) {
        for (Button b : buttons) {
            b.setSelected(b == button);
        }
    }

}
