package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.os.Bundle;

import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;

public class MobileContactActicity extends BaseFragmentActivity  {

    @Override
    public void initView(Bundle savedInstanceState) {
        Class<?> className = LocalContactFriendFragment.class;
        setFragment(className, new Bundle());

    }


}
