package com.ultralinked.uluc.enterprise.more;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tendcloud.tenddata.TCAgent;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.more.model.PhoneProduct;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func2;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/20.
 */
public class CallSettingActivity extends BaseActivity implements View.OnClickListener, BaseRecyclerAdapter.OnItemClickListener {

    RecyclerView mRecycler;
    NumberAdapter adapter;
    ImageView mImageTemporarily, mImageRigister;
    TextView mTextRegisterNumber;

    PhoneProduct registerNumber;

    List<PhoneProduct> boughtNumbers;
    String currentNumber = "-1000";

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_call_setting;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TCAgent.onPageStart(getActivity(),"通话设置");
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        TCAgent.onPageStart(getActivity(),"通话设置");
        mRecycler = bind(R.id.recycler_call_setting);
        mImageTemporarily = bind(R.id.img_temporarily_no_set);
        mImageRigister = bind(R.id.img_register_number);
        mTextRegisterNumber = bind(R.id.txt_register_number);

        initListener(this, R.id.relative_temporarily_no_set, R.id.relative_register_number);
        getNetworkInfo();
    }

    @Override
    protected void setTopBar() {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.call_setting);
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.relative_temporarily_no_set:
                setDedicatedNumber("-1000");
                break;
            case R.id.relative_register_number:
                if (registerNumber != null)
                    setDedicatedNumber(registerNumber.getPhone_no());
                break;
        }
    }

    private void getNetworkInfo() {
        showDialog(getString(R.string.loading));
        Observable.zip(ApiManager.getInstance().queryCurrentOutgoingCallDisplayNumberSetting(), ApiManager.getInstance().getBoughtPhoneProductList(), new Func2<ResponseBody, ResponseBody, String>() {
            @Override
            public String call(ResponseBody responseBody, ResponseBody responseBody2) {
                try {

                    String rs = responseBody.string();
                    Log.i(TAG, "queryCurrentOutgoingCallDisplayNumberSetting = " + rs);

                    JSONObject object = new JSONObject(rs);

                    if (200 == object.optInt("code")) {
                        String result = object.optString("result");
                        if (!TextUtils.isEmpty(result) && !result.equals("null")) {
                            currentNumber = result;
                            SPUtil.saveCurrentOutgoingCallDisplayNumberSetting(currentNumber);
                        } else {
                            //if set failed , just reset the status to back
                            Log.e(TAG, "success but server returns null");
                        }
                    }

                    String response = responseBody2.string();
                    Log.i(TAG, "getBoughtPhoneProductList = " + response);
                    boughtNumbers = new Gson().fromJson(response, new TypeToken<List<PhoneProduct>>() {
                    }.getType());
                    if (boughtNumbers != null && boughtNumbers.size() > 0) {
                        for (PhoneProduct product : boughtNumbers) {
                            product.setNo_with_plus(PhoneNumberUtils.formatNumber(PhoneNumberUtils.formatMobile(product.getPhone_no())));
                        }
//                        String ownNumber = SPUtil.getUserInfo().getMobile();
//                        if (!TextUtils.isEmpty(ownNumber)) {
//                            registerNumber = new PhoneProduct(ownNumber, PhoneNumberUtils.formatMobile(ownNumber));
//                        }
//                            boughtNumbers.add(0, new PhoneProduct(ownNumber, PhoneNumberUtils.formatMobile(ownNumber)));
//                        boughtNumbers.add(new PhoneProduct("-1000", "-1000"));
                    } else {
                        boughtNumbers = new ArrayList<>();
//                        String ownNumber = SPUtil.getUserInfo().getMobile();
//                        if (!TextUtils.isEmpty(ownNumber)) {
//                            registerNumber = new PhoneProduct(ownNumber, PhoneNumberUtils.formatMobile(ownNumber));
//                        }
//                        boughtNumbers.add(0, new PhoneProduct(ownNumber, PhoneNumberUtils.formatMobile(ownNumber)));
//                        boughtNumbers.add(new PhoneProduct("-1000", "-1000"));
                    }
                } catch (Exception ex) {
                    Log.e(TAG, android.util.Log.getStackTraceString(ex));
                }
                return currentNumber;
            }
        })

                .compose(this.<String>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getNetworkInfo success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getNetworkInfo fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(String response) {
                        String ownNumber = SPUtil.getUserInfo().getMobile();
                        if (!TextUtils.isEmpty(ownNumber)) {
                            registerNumber = new PhoneProduct(ownNumber, PhoneNumberUtils.formatMobile(ownNumber));
                        }
                        mTextRegisterNumber.setText(registerNumber.getNo_with_plus());
                        mRecycler.setLayoutManager(new LinearLayoutManager(CallSettingActivity.this));
                        mRecycler.addItemDecoration(new DividerLinearDecoration(CallSettingActivity.this, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_20_0_dp, R.dimen.px_0_0_dp));
                        adapter = new NumberAdapter(CallSettingActivity.this, boughtNumbers);
                        adapter.setOnItemClickListener(CallSettingActivity.this);
                        mRecycler.setAdapter(adapter);
                        if (currentNumber.equals("-1000")) {
                            mImageTemporarily.setImageResource(R.mipmap.choose_click);
                        } else if (currentNumber.equals(registerNumber.getPhone_no())) {
                            mImageRigister.setImageResource(R.mipmap.choose_click);
                        }
                        if (boughtNumbers.size() <= 0) {
                            bind(R.id.txt_exclusive_title).setVisibility(View.GONE);
                        }
                    }
                });
    }

    public void setCurrentNumber(String number) {
        boolean isNotify = false;
        if (currentNumber.equals("-1000")) {
            mImageTemporarily.setImageResource(R.mipmap.choose);
        } else if (currentNumber.equals(registerNumber.getPhone_no())) {
            mImageRigister.setImageResource(R.mipmap.choose);
        } else {
            isNotify = true;
        }
        this.currentNumber = number;
        if (currentNumber.equals("-1000")) {
            mImageTemporarily.setImageResource(R.mipmap.choose_click);
        } else if (currentNumber.equals(registerNumber.getPhone_no())) {
            mImageRigister.setImageResource(R.mipmap.choose_click);
        } else {
            isNotify = true;
        }
        if (isNotify) {
            adapter.notifyDataSetChanged();
        }
    }

    private void setDedicatedNumber(String number) {
        if (TextUtils.isEmpty(number)) {
            return;
        }
        if (number.equals(currentNumber)) {
            return;
        }
        Log.i(TAG, "request the set call display number:" + number);
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().requestCurrentOutgoingCallDisplayNumberSetting(number)
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "Set exclusive number successfully");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String error = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "Set exclusive number fail: " + error);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String rs;
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                JSONObject result = object.optJSONObject("result");
                                if (result != null) {
                                    String tempNumber = result.optString("currentOutgoingCallDisplayNumber");
                                    SPUtil.saveCurrentOutgoingCallDisplayNumberSetting(tempNumber);
                                    setCurrentNumber(tempNumber);
                                } else {
                                    //if set failed , just reset the status to back
                                }
                            } else {
                                //if set failed , just reset the status to back
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse setRequestThePrivacy error:" + android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    @Override
    public void onItemClick(View itemView, int pos) {
        setDedicatedNumber(boughtNumbers.get(pos).getPhone_no());
    }

    class NumberAdapter extends BaseRecyclerAdapter<PhoneProduct, RecyclerViewHolder> {

        public NumberAdapter(Context ctx, List<PhoneProduct> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_call_setting;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, PhoneProduct itemData) {
            holder.getTextView(R.id.txt_item_call_setting).setText(itemData.getNo_with_plus());
            if (itemData.getPhone_no().equals(currentNumber)) {
                holder.getImageView(R.id.img_item_call_setting).setImageResource(R.mipmap.choose_click);
            } else {
                holder.getImageView(R.id.img_item_call_setting).setImageResource(R.mipmap.choose);
            }
        }
    }
}
