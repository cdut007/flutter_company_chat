package com.ultralinked.uluc.enterprise.more;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.CustomListPopup;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.more.model.PhoneNoModel;
import com.ultralinked.uluc.enterprise.more.model.PhoneProduct;
import com.ultralinked.uluc.enterprise.pay.PaymentActivity;
import com.ultralinked.uluc.enterprise.pay.ProductInfo;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/13.
 */

public class DedicatedNumberActivity extends BaseActivity implements View.OnClickListener {

    List<PhoneNoModel> modelList;
    List<PhoneProduct> currentList;
    PhoneProduct currentProduct;
    int currentQuantity = 1;
    String currentPrice = "";
    String currentNumber = "";

    TextView mCountryCode, mChosenNo, mPeriod, mPrice, mCountryCenter;
    Button mConfirm;
    ViewPager mImgPager;
    CustomListPopup mListPopup;

    SparseIntArray countryImgs;
    SparseIntArray quantities;

    int selectedNumberPosition = 0;
    int selectedPricePosition = 0;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_dedicated_number;
    }

    @Override
    protected void setTopBar() {
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.exclusive_number);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        mCountryCode = bind(R.id.txt_country);
        mChosenNo = bind(R.id.txt_chosen_no);
        mPeriod = bind(R.id.txt_period);
        mPrice = bind(R.id.txt_price);
        mCountryCenter = bind(R.id.txt_country_center);
        mConfirm = bind(R.id.btn_customize_confirm);
        mImgPager = bind(R.id.pager_country_img);
        initListener(this, R.id.linear_chosen_number, R.id.linear_period, R.id.img_left, R.id.img_right, R.id.btn_customize_confirm);

        countryImgs = new SparseIntArray(4);
        countryImgs.put(65, R.mipmap.singapore);
        countryImgs.put(1, R.mipmap.america);
        countryImgs.put(852, R.mipmap.hongkong);

        quantities = new SparseIntArray(5);
        quantities.put(0, 1);
        quantities.put(1, 2);
        quantities.put(2, 3);
        quantities.put(3, 6);
        quantities.put(4, 12);
        getNetworkData();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.linear_chosen_number:
                if (currentList != null) {
                    List<String> phoneNoList = new ArrayList<>();
                    for (PhoneProduct product : currentList) {
                        phoneNoList.add(product.getEasyNo());
                    }
                    showPopup(CustomListPopup.CHOSEN_NUMBER, phoneNoList);
                    if (mListPopup != null)
                        mListPopup.setSelectedPosition(selectedNumberPosition);
                }
                break;
            case R.id.linear_period:
                if (currentProduct != null) {
                    showPopup(CustomListPopup.USE_PERIOD, getQuantityList(currentProduct.getPrice()));
                    if (mListPopup != null)
                        mListPopup.setSelectedPosition(selectedPricePosition);
                }
                break;
            case R.id.img_left:
                leftMove();
                break;
            case R.id.img_right:
                rightMove();
                break;
            case R.id.btn_customize_confirm:
                if (currentProduct != null) {
                    ProductInfo info = new ProductInfo(currentProduct.getProduct_id(), currentPrice, "phone_no", currentQuantity + "");
                    startActivity(new Intent(this, PaymentActivity.class).putExtra("product", info));
                }
                break;
        }
    }

    private List<String> getQuantityList(String sPrice) {
        List<String> quantityList = new ArrayList<>();
        float price = Float.parseFloat(sPrice);
        quantityList.add(getString(R.string.one_month) + " —— U.S.$" + price);
        quantityList.add(getString(R.string.two_month) + " —— U.S.$" + price * 2);
        quantityList.add(getString(R.string.three_month) + " —— U.S.$" + price * 3);
        quantityList.add(getString(R.string.six_month) + " —— U.S.$" + price * 6);
        quantityList.add(getString(R.string.one_year) + " —— U.S.$" + price * 12);
        return quantityList;
    }

    private void leftMove() {
        if (modelList != null && !modelList.isEmpty()) {
            int currentPos = mImgPager.getCurrentItem();
            if (currentPos > 0) {
                mImgPager.setCurrentItem(currentPos - 1);
            }
        }
    }

    private void rightMove() {
        if (modelList != null && !modelList.isEmpty()) {
            int currentPos = mImgPager.getCurrentItem();
            if (currentPos < modelList.size()) {
                mImgPager.setCurrentItem(currentPos + 1);
            }
        }
    }

    private void setCurrentList(List<PhoneProduct> list) {
        currentList = list;
        PhoneProduct product = list.get(0);
        setCurrentProduct(product);
    }

    private void setCurrentProduct(PhoneProduct product) {
        setSelectedPricePosition(0);
        currentProduct = product;
        mChosenNo.setText(product.getEasyNo());
        mPrice.setText(String.format(getString(R.string.recharge_amount), product.getPrice()));
        setCurrentQuantity(1);
    }

    private void setSelectedNumberPosition(int selectedNumberPosition) {
        this.selectedNumberPosition = selectedNumberPosition;
    }

    private void setSelectedPricePosition(int selectedPricePosition) {
        this.selectedPricePosition = selectedPricePosition;
    }

    private void setCurrentQuantity(int quantity) {
        currentQuantity = quantity;
        float price = Float.parseFloat(currentProduct.getPrice());
        switch (quantity) {
            case 1:
                mPeriod.setText(R.string.one_month);
                break;
            case 2:
                mPeriod.setText(R.string.two_month);
                break;
            case 3:
                mPeriod.setText(R.string.three_month);
                break;
            case 6:
                mPeriod.setText(R.string.six_month);
                break;
            case 12:
                mPeriod.setText(R.string.one_year);
                break;
        }
        currentPrice = "" + quantity * price;
        mPrice.setText(String.format(getString(R.string.recharge_amount), currentPrice));
    }

    private void getNetworkData() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getPhoneProductList()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "getPhoneProductList success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getPhoneProductList fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String response = null;
                        try {
                            response = responseBody.string();
                        } catch (IOException e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                        if (response == null) {
                            Log.e(TAG, "getPhoneProductList response is null");
                            return;
                        }
                        Log.i(TAG, "getPhoneProductList = " + response);
                        modelList = new Gson().fromJson(response, new TypeToken<List<PhoneNoModel>>() {
                        }.getType());
                        if (modelList != null && !modelList.isEmpty()) {
                            for (PhoneNoModel model : modelList) {
                                ArrayList<CountryInfo> infos = CountryCodeStorageHelper.getInstance().getCountryCodeStorage(DedicatedNumberActivity.this).getAllCountryInfo();
                                for (CountryInfo info : infos) {
                                    if (("+" + model.getCountry_code()).equals(info.getCountryCode())) {
                                        model.setCountry_name(info.getFullName());
                                    }
                                }
                            }
                            final PhoneNoModel model = modelList.get(0);
                            mCountryCenter.setText(model.getCountry_name());
                            mCountryCode.setText("+" + model.getCountry_code() + " " + model.getCountry_name());
                            setCurrentList(model.getPhone_nos());
                            mImgPager.setAdapter(new PagerAdapter() {
                                @Override
                                public int getCount() {
                                    return modelList.size();
                                }

                                @Override
                                public boolean isViewFromObject(View view, Object object) {
                                    return view == object;
                                }

                                @Override
                                public Object instantiateItem(ViewGroup container, int position) {
                                    ImageView imageView = new ImageView(DedicatedNumberActivity.this);
                                    imageView.setImageResource(countryImgs.get(Integer.parseInt(modelList.get(position).getCountry_code())));
                                    container.addView(imageView);
                                    return imageView;
                                }

                                @Override
                                public void destroyItem(ViewGroup container, int position, Object object) {
                                }
                            });
                            mImgPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                                @Override
                                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                                }

                                @Override
                                public void onPageSelected(int position) {
                                    setSelectedNumberPosition(0);
                                    setSelectedPricePosition(0);
                                    PhoneNoModel noModel = modelList.get(position);
                                    mCountryCenter.setText(noModel.getCountry_name());
                                    mCountryCode.setText("+" + noModel.getCountry_code() + " " + noModel.getCountry_name());
                                    setCurrentList(noModel.getPhone_nos());
                                }

                                @Override
                                public void onPageScrollStateChanged(int state) {
                                }
                            });
                        } else {
                            Log.e(TAG, "Retrieve no data from server");
                        }
                    }
                });
    }

    private void showPopup(int type, List<String> list) {
        if (mListPopup == null) {
            mListPopup = new CustomListPopup(this, type, list);
            mListPopup.setOnProductChoseListener(new CustomListPopup.OnProductChoseListener() {
                @Override
                public void onPhoneChanged(int position) {
                    setSelectedNumberPosition(position);
                    setCurrentProduct(currentList.get(position));
                }

                @Override
                public void onQuantityChanged(int position) {
                    setSelectedPricePosition(position);
                    setCurrentQuantity(quantities.get(position));
                }

                @Override
                public void onBoughtNumberSelected(int position) {
                }
            });
            mListPopup.showAtLocation(mConfirm, Gravity.BOTTOM, 0, 0);
        } else {
            mListPopup.setPopup(type, list);
            mListPopup.showAtLocation(mConfirm, Gravity.BOTTOM, 0, 0);
        }
    }
}
