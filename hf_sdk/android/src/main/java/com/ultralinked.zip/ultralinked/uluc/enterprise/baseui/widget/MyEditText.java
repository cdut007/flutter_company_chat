package com.ultralinked.uluc.enterprise.baseui.widget;


import android.R.integer;
import android.content.Context;
import android.text.ClipboardManager;
import android.text.Spannable;
import android.text.SpannableString;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import com.ultralinked.uluc.enterprise.chat.chatim.ImEmotionMap;
import com.ultralinked.uluc.enterprise.utils.Log;

public class MyEditText  extends EditText{

public MyEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
private OnResizeListener mListener; 

public interface OnResizeListener { 
    void OnResize(int w, int h, int oldw, int oldh); 
} 
 
//public void setOnResizeListener(OnResizeListener l) { 
//    mListener = l; 
//    //判断是不是全屏模式。。
//} 

@Override 
protected void onSizeChanged(int w, int h, int oldw, int oldh) {     
    super.onSizeChanged(w, h, oldw, oldh); 
     
//    if (mListener != null) { 
//        mListener.OnResize(w, h, oldw, oldh); 
//    } 
} 


	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return super.onTouchEvent(event);
	}

 int eSize = 0;
public void setEditEmotionSize(int size ) {
	eSize =size;
}

@Override
public boolean onTextContextMenuItem(int id) {
		ClipboardManager clip = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
		switch (id) {
		case android.R.id.paste:
			CharSequence paste = clip.getText();
			if (paste != null && paste.length() > 0) {
				int size =0;
				boolean dealEmoji=false;
				if (eSize>0) {
					size =eSize;
					dealEmoji =true;
				}else {
					int tsize = (int) getTextSize();
					tsize = (int) (1.2f * tsize);
					size = tsize + (tsize % 2 == 0 ? 0 : 1);	
				}
				
				Log.i("edite text", "paste~~~~~~~~");
				SpannableString spannableString  = ImEmotionMap.genSpanString(paste.toString(), size);
				append(spannableString);
				
				setSelection(getText().length());
			}
			return true;
		}
	return super.onTextContextMenuItem(id);
}

}
