package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.Constants;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.chatdetails.ChatDetailsActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MapUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.GroupMember;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/7/6 0006.
 */
public class GroupChatImFragment extends BaseChatImFragment {

    private static final String TAG = "GroupChatImFragment";


    @Override
    public void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);

        goneView(saveContact);
        goneView(callPhone);
        goneView(subtitle);
        visibleView(title);
        visibleView(chatDetails);
        chatDetails.setImageResource(R.mipmap.group_add);
        ImageUtils.buttonEffect(chatDetails);
        initListener(this, backBtn, headerImg, chatDetails);

    }

    private GroupConversation groupConversation;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        if (mConversation == null) {
            Log.i("mConversation is null...");
            activity.finish();
            return view;
        }

        registerBroadCastReceiver();


        groupConversation = (GroupConversation) mConversation;
        Log.i(TAG, " groupComversation:" + groupConversation.getConversationId() + " gruopid:" + groupConversation.getGroupID());

        new Thread(new Runnable() {
            @Override
            public void run() {
                groupConversation.checkGroupMember();
            }
        }).start();

        updateGroupInfor();


        return view;
    }

    /**
     * 更新群聊头像信息
     */
    private void updateGroupInfor() {
        if (groupConversation == null) {
            Log.i("groupConversation is null");
            return;
        }
        title.setText(groupConversation.getGroupTopic());
        List<GroupMember> groupMembers = groupConversation.getGroupMember();
        if (groupMembers != null) {
            // subtitle.setText(mContext.getString(R.string.x_members_in_this_group).replace("x", groupMembers.size()+""));
            title.setText(groupConversation.getGroupTopic() + "(" + groupMembers.size() + ")");
            //checkMemberInfos.
            checkStrangerMembers(groupMembers);
        }


    }

    private void checkStrangerMembers(final List<GroupMember> groupMembers) {

        Observable.create(new Observable.OnSubscribe<List<PeopleEntity>>() {
            @Override
            public void call(Subscriber<? super List<PeopleEntity>> subscriber) {
                List<PeopleEntity> peopleEntities = new ArrayList<PeopleEntity>();
                List<PeopleEntity> queryPeopleEntities = new ArrayList<PeopleEntity>();

                for (int i = 0; i < groupMembers.size(); i++) {
                    String userId = groupMembers.get(i).getMemberName();
                    PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userId);

                    if (!PeopleEntityQuery.hasFoundPeople(peopleEntity)) {

                        if (peopleEntity == null) {
                            peopleEntity = new PeopleEntity();
                            peopleEntity.subuser_id = userId;
                        }

                        Message.PeerInfo peerInfo = groupMembers.get(i).getPeerInfo();
                        if (peerInfo != null && !TextUtils.isEmpty(peerInfo.userName)) {
                            peopleEntity.name = peerInfo.userName;
                            peopleEntity.nickname = peerInfo.nickName;
                        } else {
                            peopleEntity.name = userId;
                        }

                        //add to api query userInfos.
                        queryPeopleEntities.add(peopleEntity);
                    }

                    if (!TextUtils.isEmpty(peopleEntity.icon_url)) {
                        MapUtils.setUserIconUrl(peopleEntity.subuser_id, peopleEntity.icon_url);
                    }
                    peopleEntities.add(peopleEntity);

                }


                callQueryStrangerMemberInfos(queryPeopleEntities);//update to persnal table.
                subscriber.onNext(peopleEntities);
            }
        }).compose(this.<List<PeopleEntity>>bindToLifecycle()).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<List<PeopleEntity>>() {
            @Override
            public void call(List<PeopleEntity> peopleEntities) {

            }
        });
    }


    private void callQueryStrangerMemberInfos(List<PeopleEntity> queryPeopleEntities) {
        if (queryPeopleEntities.isEmpty()) {
            return;
        }

        List<String> userIds = new ArrayList<>();

        for (PeopleEntity people : queryPeopleEntities
                ) {
            userIds.add(people.subuser_id);
        }

        RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
            @Override
            public void onResultFriendList(final List<PeopleEntity> entities) {
                if (getActivity() != null && !getActivity().isFinishing()) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mergeGroupMemberInfo(entities);
                        }
                    });
                }
            }

            @Override
            public void onQueryFailed(List<String> requestUserIds) {

            }
        });

        //
    }


    private void mergeGroupMemberInfo(List<PeopleEntity> queryPeoples) {

        adapter.notifyDataSetChanged();
//        for (PeopleEntity people:queryPeoples) {
//            adapter.updateItem(people);
//        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unregisterBroadCastReceiver();


    }

    @Override
    protected void initConversation(Intent mIntent, com.ultralinked.voip.api.Conversation mConversation) {

    }


    private BroadcastReceiver mMessageFromHistoryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String chatID = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            int chatType = intent.getIntExtra(MessagingApi.PARAM_CHAT_TYPE, -1);
            if (chatType == Conversation.GROUP_CHAT) {

                if (groupConversation != null && groupConversation.getGroupID().equals(chatID)) {
                    groupConversation = GroupConversation.getConversationByGroupId(chatID);
                    if (groupConversation != null) {
                        Log.i(TAG, "mMessageFromHistoryReceiver chatID=" + chatID);
                        initGroupData();
                    }
                }

            }
        }
    };


    @Override
    protected void registerBroadCastReceiver() {
        super.registerBroadCastReceiver();

        LocalBroadcastManager.getInstance(activity).registerReceiver(mMessageFromHistoryReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_FROM_HISTORY));


        LocalBroadcastManager.getInstance(activity).registerReceiver(inviteGroupReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_INVITE));

        LocalBroadcastManager.getInstance(activity).registerReceiver(mGroupInfoChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_INFO_CHANGED));

        LocalBroadcastManager.getInstance(activity).registerReceiver(mGroupMemberChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_MEMBER_CHANGE));

    }

    /**
     * 监听群聊邀请的广播接收器
     */
    private BroadcastReceiver inviteGroupReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String from = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            String group = intent.getStringExtra(MessagingApi.PARAM_GROUP_TITLE);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            Log.i(TAG, "invite Group  " + from);
            if (groupConversation == null) {
                getActivity().finish();
                return;
            }
            if (groupConversation != null && groupConversation.getGroupID().equals(groupId)) {
                groupConversation = GroupConversation.getConversationByGroupId(groupId);
                updateGroupInfor();
            }


        }
    };
    private BroadcastReceiver mGroupInfoChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);


            if (groupConversation != null && groupConversation.getGroupID().equals(groupId)) {
                if (status == MessagingApi.KICK_OUT_BY_GROUP) {
                    if (getActivity() != null && !getActivity().isFinishing()) {
                        getActivity().finish();
                    }
                    showToast(getString(R.string.your_are_be_kicked));
                    return;
                }

                groupConversation = GroupConversation.getConversationByGroupId(groupId);
                updateGroupInfor();
            }
        }
    };
    private BroadcastReceiver mGroupMemberChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            if (groupConversation != null && groupConversation.getGroupID().equals(groupId)) {
                groupConversation = GroupConversation.getConversationByGroupId(groupId);
                updateGroupInfor();
            }
        }
    };

    @Override
    protected void unregisterBroadCastReceiver() {
        super.unregisterBroadCastReceiver();
        LocalBroadcastManager.getInstance(activity).unregisterReceiver(inviteGroupReceiver);
        LocalBroadcastManager.getInstance(activity).unregisterReceiver(mGroupInfoChangedReceiver);
        LocalBroadcastManager.getInstance(activity).unregisterReceiver(mGroupMemberChangedReceiver);
        LocalBroadcastManager.getInstance(activity).unregisterReceiver(mMessageFromHistoryReceiver);


    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
            case R.id.header_img:
//                showToast("click header img");
                break;
            case R.id.chat_details:
                if (groupConversation == null) {
                    //maybe delete.
                    getActivity().finish();
                    return;
                }
                ChatDetailsActivity.launchActivityForResult(this, groupConversation.getConversationId(), null, true, REQUEST_CODE_FOR_CHAT_DETAILS);
                break;

        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null || resultCode != Activity.RESULT_OK) {
            Log.i(TAG, "resultCode:" + resultCode + " requestCode:" + requestCode + " data:" + data);
            return;
        }
        if (requestCode == REQUEST_CODE_FOR_CHAT_DETAILS) {
            if (data.getBooleanExtra("clear_all_history", false)) {
                adapter.removeAllChatHistoryMessage();
                Log.i(TAG, " remove all chat history msgs.");
            }
        }

    }

    @Override
    public void onNewIntent(Bundle data) {
        super.onNewIntent(data);
        Log.i(TAG, "onNewIntent~~~");
        String chatIdentity = data.getString(Constants.GROUPKD_KEY);
        mConversation = GroupConversation.getConversationByGroupId(chatIdentity);
        if (mConversation == null) {
            Log.i("get mConversation is null from onNewIntent.");
            getActivity().finish();
            return;
        }
        groupConversation = (GroupConversation) mConversation;
        initGroupData();
    }

    private void initGroupData() {
        updateGroupInfor();
        recyclerView.swapAdapter(adapter, false);
        adapter.removeAllChatHistoryMessageInMemoryCache();
        initData();
        chatModule.refresh(groupConversation);
    }

    @Override
    public Message.Options getMsgOption() {
        Message.Options messageOptions = new Message.Options();
        return messageOptions;
    }
}
