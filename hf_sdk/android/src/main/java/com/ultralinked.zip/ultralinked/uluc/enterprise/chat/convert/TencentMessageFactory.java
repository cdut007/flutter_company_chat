package com.ultralinked.uluc.enterprise.chat.convert;

import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.CustomMessage;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.GroupMember;
import com.ultralinked.voip.api.IMessageConvertFactory;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.NetRtcXMPPCallbackImpl;

import org.xutils.common.Callback;

import java.io.File;
import java.util.List;

/**
 * Created by mac on 17/1/4.
 */

public class TencentMessageFactory implements IMessageConvertFactory {

    @Override
    public String im_version() {
        return null;
    }

    @Override
    public void deleteAllConversationMessages() {

    }

    @Override
    public List<Conversation> getConversations(int i, int i1) {
        return null;
    }

    @Override
    public List<Conversation> getAllConversationsByType(int i) {
        return null;
    }

    @Override
    public List<Conversation> getAllConversationsByFlag(int i, boolean b) {
        return null;
    }

    @Override
    public List<Message> getMessages(int i, int i1, int i2) {
        return null;
    }

    @Override
    public void deleteOneMessage(int i, int i1) {

    }

    @Override
    public Message getMessageById(int i, boolean b) {
        return null;
    }

    @Override
    public void deleteAllMessages(int i) {

    }

    @Override
    public void deleteMultipleMessages(int i, int[] ints, int i1) {

    }

    @Override
    public CustomMessage sendCustomFileMessage(String s, String s1, int i, File file, boolean b) {
        return null;
    }

    @Override
    public void sendCustomBroadcast(String s, String s1, int i) {

    }

    @Override
    public Message updateMessageBody(int i, int i1, String s) {
        return null;
    }

    @Override
    public CustomMessage insertCustomMessage(String s, String s1, String s2, String s3, int i) {
        return null;
    }

    @Override
    public CustomMessage sendCustomMessage(String s, String s1, int i) {
        return null;
    }

    @Override
    public void exitGroup(int i, String s) {

    }

    @Override
    public void createGroup(String s) {

    }

    @Override
    public void modifyTitle(String s, String s1) {

    }

    @Override
    public void deleteConversation(int i) {

    }

    @Override
    public void checkGroupMember(String s) {

    }

    @Override
    public int createConversation(String s, boolean b) {
        return 0;
    }

    @Override
    public int setConversationDraft(int i, byte[] bytes) {
        return 0;
    }

    @Override
    public void setConversationPriority(int i, boolean b) {

    }

    @Override
    public void sendAppToken(String s, String s1) {

    }

    @Override
    public void setConversationMute(String s, boolean b, boolean b1) {

    }

    @Override
    public void setConversationProperty(String s, boolean b, String s1) {

    }

    @Override
    public String getConversationProperties(String s, boolean b) {
        return null;
    }

    @Override
    public void reSendMsg(int i, int i1, boolean b) {

    }

    @Override
    public void flushLog() {

    }

    @Override
    public void kickMember(String s, String s1) {

    }

    @Override
    public void setConversationBlock(String s, boolean b, boolean b1) {

    }

    @Override
    public boolean getConversationIsBlock(String s) {
        return false;
    }

    @Override
    public boolean getConversationIsMute(String s) {
        return false;
    }

    @Override
    public GroupConversation getConversationByGroupId(String s) {
        return null;
    }

    @Override
    public List<Message> getMessagesByMessageId(int i, int i1, int i2, boolean b, boolean b1) {
        return null;
    }

    @Override
    public void setConfig(String s, String s1) {

    }

    @Override
    public Conversation createConversationWithFlag(String s, int i) {
        return null;
    }

    @Override
    public List<GroupMember> getGroupMemembers(String s, String s1) {
        return null;
    }

    @Override
    public void JoinGroup(String s) {

    }

    @Override
    public void inviteToGroup(String s, String s1) {

    }

    @Override
    public int getAllUnreadMessageCounts() {
        return 0;
    }

    @Override
    public int getAllUnreadMessageCountsByConvType(boolean b) {
        return 0;
    }

    @Override
    public int getConversationUnreadMessageCounts(int i) {
        return 0;
    }

    @Override
    public void conversationRead(int i) {

    }

    @Override
    public void messageRead(int i, int i1) {

    }

    @Override
    public void uploadFile(File file, FileMessage fileMessage) {

    }

    @Override
    public Conversation getConversationById(int i) {
        return null;
    }

    @Override
    public List<Message> searchMessageListOfConversationByKeyword(Conversation conversation, String s) {
        return null;
    }

    @Override
    public List<Conversation> searchConversations(String s) {
        return null;
    }

    @Override
    public void uploadThumbFile(File file, FileMessage fileMessage, Callback.ProgressCallback<String> progressCallback) {

    }

    @Override
    public void setIMCallbackObject(Object o) {

    }

    @Override
    public void FileUrlCallback(Message message) {

    }

    @Override
    public void updateMsgStatus(int i, int i1, int i2) {

    }

    @Override
    public void LoginXmpp(MLoginApi.Account account) {

    }

    @Override
    public boolean isLogin() {
        return false;
    }

    @Override
    public int relogin() {
        return 0;
    }

    @Override
    public void disconnect() {

    }

    @Override
    public void accept(FileMessage fileMessage) {

    }

    @Override
    public void reject(FileMessage fileMessage) {

    }

    @Override
    public String getPreviewImageBase64(FileMessage fileMessage) {
        return null;
    }

    @Override
    public void cancel(FileMessage fileMessage) {

    }

    @Override
    public NetRtcXMPPCallbackImpl getIMCallbackObject() {
        return null;
    }
}
