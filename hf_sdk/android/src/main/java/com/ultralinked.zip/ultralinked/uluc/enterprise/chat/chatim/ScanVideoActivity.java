package com.ultralinked.uluc.enterprise.chat.chatim;

/**
 * Created by Administrator on 2016/7/15 0015.
 */
public class ScanVideoActivity {
    public static final String VIDEO_SCAN = "com.ultralinked.image.scan.video";
}
