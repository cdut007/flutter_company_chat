package com.ultralinked.uluc.enterprise.login;

import okhttp3.ResponseBody;

/**
 * Created by ultralinked on 2016/6/24 0024.
 *
 * login model method defined interface
 */

public interface LoginModelFab {
    void error(String msg);
    void success(ResponseBody msg);
}
