package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;

public class ChangePrivatePsd extends BaseActivity implements View.OnClickListener{

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_reset_psd;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.tvSetPsd).setVisibility(View.GONE);
        initListener(this, R.id.btRequest);
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView)bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.change_private_password);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.btRequest:


                return;
        }
    }
}
