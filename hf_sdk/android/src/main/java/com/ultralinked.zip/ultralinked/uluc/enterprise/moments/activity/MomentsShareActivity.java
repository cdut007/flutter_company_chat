package com.ultralinked.uluc.enterprise.moments.activity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonSyntaxException;
import com.ultralinked.contact.util.ToastUtil;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.ChatUtils;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.more.SettingPersonalActivity;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.BitmapUtils;
import com.ultralinked.voip.api.utils.FileUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


//朋友圈分享页面
public class MomentsShareActivity extends BaseActivity implements OnClickListener {

    private static final int SHARE_TEXT = 1;
    private static final int SHARE_PHOTOS = 2;
    private static final int SHARE_VIDEO = 3;
    private static final int SHARE_LINK = 4;

    private boolean isAllowShare;


    public static final int FILE_PERMISION_CODE = 0x123;
    public static final int OPEN_CAMERA_CODE = 0x1991;
    public static final int OPEN_GALLY_CODE = 0x1992;

    //create shareModel frist.

    EditText shareText;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_moment_post_share;
    }


    private void chooseImage() {
        if (checkPermission("file", FILE_PERMISION_CODE)) {
            DialogManager.showItemsDialog(this, getString(R.string.img_from), new String[]{getString(R.string.take_photo), getString(R.string.gallery)}, addImage, new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) {
                        GalleryFinal.openCamera(OPEN_CAMERA_CODE, mOnHandlerResultCallback);
                    } else {
                        GalleryFinal.openGalleryMuti(OPEN_GALLY_CODE, 9,mOnHandlerResultCallback);
                    }
                }
            });
        } else {
            Log.i(TAG, "has no permission:" + Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
    }


    List<String> sharedImages = new ArrayList<>();


    ViewGroup addPickContainer;

    /*Initialize data set image pager adapter*/
    protected void addInImagePrev(List<String> imageFileList) {

        addPickContainer.removeAllViews();
        for (int i = imageFileList.size()-1; i >=0; i--) {
            addPickContainer.addView(createImageView(imageFileList.get(i)));
        }

    }


    /*Create a image view,and load the local image in this view*/
    private ImageView createImageView(final String imageFile) {
        final ImageView imageView = new ImageView(this);
        imageView.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        int size = getResources().getDimensionPixelSize(R.dimen.px_64_0_dp);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        int padding = getResources().getDimensionPixelSize(R.dimen.px_4_0_dp);
        params.leftMargin = padding;
        params.rightMargin = padding;
        params.topMargin = padding;
        params.bottomMargin = padding;
        params.gravity = Gravity.CENTER_VERTICAL;
        // imageView.setPadding(padding, padding, padding, padding);
        imageView.setLayoutParams(params);

        ImageUtils.loadImageByString(this, imageView, imageFile);

        imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeletePhotoDialog(imageFile);
            }
        });

        return imageView;
    }

    private void showDeletePhotoDialog(final String imageFile) {
        DialogManager.showOKCancelDialog(this, "", getString(R.string.delete_this_photo), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sharedImages.remove(imageFile);
                addInImagePrev(sharedImages);
            }
        }, null);
    }

    /**
     * 图片选择器的回调
     */
    private GalleryFinal.OnHanlderResultCallback mOnHandlerResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int requestCode, List<PhotoInfo> resultList) {
            if (resultList == null) {
                Log.i(TAG, " requestCode:" + requestCode + " resultList is null.");
                return;
            }
            if (requestCode == OPEN_CAMERA_CODE || requestCode == OPEN_GALLY_CODE) {
                for (PhotoInfo photoInfo : resultList) {
                    String filePath = photoInfo.getPhotoPath();
                    if (FileUtils.isFileExist(filePath)) {

                        if (!sharedImages.contains(filePath)) {
                            sharedImages.add(filePath);
                            addInImagePrev(sharedImages);
                        }

                        // uploadImg(filePath);

                    } else {
                        Log.d(TAG, "the photo file is not exist.. filePath:" + filePath);
                    }
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            showToast(errorMsg);
            Log.i(TAG, " requestCode:" + requestCode + " errorMsg:" + errorMsg);
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // must start here ,cause ondestroy may throws unregister error..
        int checkShareAvaliable = ChatUtils.checkAllowedShareIntent(this, getIntent());
        switch (checkShareAvaliable) {
            case 0:// prepare share flag with outside
                isAllowShare = true;
                break;
            case 1:// go to provision
                App.getInstance().goToLoginActivity(false);
                finish();
                return;
            case 2:// files > 5 items
                int maxNum = getResources().getInteger(R.integer.max_send_media_num);
                ToastUtil.showToast(this, getString(R.string.chat_share_file_reach_max_limited, maxNum), Toast.LENGTH_LONG);
                finish();
                return;
            case 3:// unkonw errors
            {

            }
            break;
            default:// do nothing.
                break;
        }

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // TODO
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private ImageView leftBack, addImage;

    @Override
    public void initView(Bundle savedInstanceState) {


        leftBack = bind(R.id.left_back);

        shareText = bind(R.id.et_usertel);

        addImage = bind(R.id.btnaddimg);

        addPickContainer = bind(R.id.ll_banner);

        ((TextView) bind(R.id.titleCenter)).setText(getString(R.string.moments_share));

        initListener(this, addImage, leftBack);

        TextView share = bind(R.id.titleRight);
        share.setText(R.string.send);
        ImageUtils.buttonEffect(share);

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence info = shareText.getText();
                if (!TextUtils.isEmpty(info)) {
                    if (sharedImages.isEmpty()) {
                        try {
                            shareInfo.put("content", info.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        callShareMomentInfoToServer(shareInfo);
                    } else {
                        try {
                            shareInfo.put("content", info.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                       uploadImages();
                    }
                }

            }
        });

        initData(getIntent());

    }

    JSONObject shareInfo = new JSONObject();

    public static MultipartBody filesToMultipartBody(List<String> files) {
        MultipartBody.Builder builder = new MultipartBody.Builder();

        for (String filePath : files) {
            // TODO: 16-4-2  这里为了简单起见，没有判断file的类型
            File file = new File(filePath);
            RequestBody requestBody = RequestBody.create(MediaType.parse("image/png"), file);
            builder.addFormDataPart("file_"+file.getName(), file.getName(), requestBody);
        }

        builder.setType(MultipartBody.FORM);
        MultipartBody multipartBody = builder.build();
        return multipartBody;
    }



    public static List<String> compressedImages(Activity activity,List<String> sharedImages){
        List<String> image_urls = new ArrayList<>();

        for (String image_url:sharedImages
             ) {
            File imgFile = new File(image_url);
            if (imgFile.length() > ImageUtils.minImgFileLen) {

                Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                com.ultralinked.voip.api.Log.i("uploadImg", "Image file too large!");
                if (bitmap != null) {
                    File compresedFile = new File(ChatModule.imageCompressedPath + imgFile.getName());
                   ImageUtils.compressImage(activity,image_url,compresedFile.getAbsolutePath());
                    if (compresedFile != null && compresedFile.exists()) {
                        image_urls.add(compresedFile.getAbsolutePath());
                    } else {
                        com.ultralinked.voip.api.Log.i("uploadImg", "getThumbnail is null from compress");
                        continue;
                    }

                } else {
                    com.ultralinked.voip.api.Log.i("uploadImg", "getThumbnail is null from corp path");
                    continue;
                }


            }else{
                image_urls.add(image_url);
            }
        }



        return image_urls;

    }

    private void uploadImages() {
//        Log.i(TAG, filePath);

        try {
            showDialog(getString(R.string.loading));
            ApiManager.getInstance().uploadImagesToMoments(filesToMultipartBody(compressedImages(this,sharedImages))).subscribeOn(Schedulers.io()).compose(this.<ResponseBody>bindToLifecycle())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<ResponseBody>() {
                        @Override
                        public void onNext(ResponseBody responseBody) {
                           closeDialog();
                            String rs = "";
                            try {
                                rs = responseBody.string();

                                JSONObject object = new JSONObject(rs);
                                if (200 == object.optInt("code")) {
                                   // shareInfo.put("iconurl");
                                    JSONObject result = object.optJSONObject("result");
                                    JSONArray imgurls = result.optJSONArray("image_urls");
                                    JSONArray thumb_urls = result.optJSONArray("thumb_urls");
                                    shareInfo.put("image_urls",imgurls);
                                    shareInfo.put("thumb_urls",thumb_urls);
                                    callShareMomentInfoToServer(shareInfo);
                                } else {

                                    showToast("errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                                    Log.i(TAG, "uploadImagesToMoments error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));


                                }


                            } catch (JsonSyntaxException e) {
                                //showToast(getString(R.string.blance_transfer_failed));
                                com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                            } catch (JSONException e) {
                                //showToast(getString(R.string.blance_transfer_failed));
                                com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                            } catch (IOException e) {
                                //showToast(getString(R.string.blance_transfer_failed));
                                com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                            }

                            Log.i(TAG, "get uploadImagesToMoments:  " + rs);

                        }

                        @Override
                        public void onCompleted() {
                            Log.i(TAG, "uploadImagesToMoments is compelete ");
                        }

                        @Override
                        public void onError(Throwable e) {
                            closeDialog();
                            String eMsg = HttpErrorException.handErrorMessage(e);
                            Log.i(TAG, "get uploadImagesToMoments the error info:" + eMsg);
                            showToast(eMsg+"");
                        }

                    });

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            Log.e(TAG, "update fail");
        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            initData(createShareInfo());
        }
    }

    private Intent createShareInfo() {
        Intent intent = new Intent();
        return intent;
    }

    private void callShareMomentInfoToServer(JSONObject shareInfo) {

        showDialog(getString(R.string.loading));


        List<String> thumb_imgUrls = new ArrayList<>();

        JSONArray thumbimgUrlArrays = shareInfo.optJSONArray("thumb_urls");

        if (thumbimgUrlArrays!=null && thumbimgUrlArrays.length()>0){

            for (int i = 0; i < thumbimgUrlArrays.length(); i++) {
                thumb_imgUrls.add(thumbimgUrlArrays.optString(i));
            }
        }


        List<String> imgUrls = new ArrayList<>();

        JSONArray imgUrlArrays = shareInfo.optJSONArray("image_urls");

        if (imgUrlArrays!=null && imgUrlArrays.length()>0){

            for (int i = 0; i < imgUrlArrays.length(); i++) {
                imgUrls.add(imgUrlArrays.optString(i));
            }
        }

        String type = "";
        if (!imgUrls.isEmpty()){
            type = "image";
            Log.i(TAG,"post is image");
        }

        ApiManager.getInstance().shareMoments(type, shareInfo.optString("content"),imgUrls,thumb_imgUrls)
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "shareMomentsComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        closeDialog();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        showToast(" " + eMsg);

                        Log.e(TAG, "shareMoments  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        closeDialog();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                showToast(object.optString("result"));
                                LocalBroadcastManager.getInstance(MomentsShareActivity.this).sendBroadcast(new Intent(MomentsActivity.EVENT_POST_NEW_MOMENTS));
                                //sendMomentsShareSuccessMessage();
                                finish();
                            } else {

                                showToast("errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                                Log.i(TAG, "shareMoments error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));


                            }


                        } catch (JsonSyntaxException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        Log.i(TAG, "get shareMoments:  " + rs);
                    }         //请求成功

                });

    }


    protected void initData(Intent intent) {
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                handleSendText(intent);
            } else if (type.startsWith("image/")) {
                handleSendImage(intent);
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
            if (type.startsWith("image/")) {
                handleSendMultipleImages(intent);
            }
        } else {
            // Handle other intents, such as being started from the home screen
        }
    }

    void handleSendText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        String sharedTitle = intent.getStringExtra(Intent.EXTRA_TITLE);
        if (sharedText != null) {
            // Update UI to reflect text being shared
            showToast(sharedText);
        }
    }

    void handleSendImage(Intent intent) {
        Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (imageUri != null) {
            // Update UI to reflect image being shared
            showToast(imageUri.toString());
        }
    }

    void handleSendMultipleImages(Intent intent) {
        ArrayList<Uri> imageUris = intent
                .getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (imageUris != null) {
            // Update UI to reflect multiple images being shared
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;
            case R.id.btnaddimg:
                chooseImage();
                break;
            default:
                break;
        }
    }

}
