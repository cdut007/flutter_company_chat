package com.ultralinked.uluc.enterprise.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Administrator on 2016/8/2 0002.
 */
public class ChatUtils {

    private static final String TAG = "ChatUtils";

    private static boolean checkCfgIsOk(Context context) {
        return !TextUtils.isEmpty(SPUtil.getUserID());
    }


    /**
     * @param uri ,目前只有 video image amr 需要check 大小，text vcard no need
     * @return
     */
    public static Message createParseSharedMessagewithUri(
            Activity activity, ChatModule chatModel, Uri uri, int sharedMsgType) {
        String sendingFileName = null;
        Uri selectedImangeUri = uri;
        if (selectedImangeUri == null) {
            Log.i(TAG, "selectedImangeUri == null");
            return null;
        }

        if (sharedMsgType == ChatModule.MESSAGE_SHARED_TEXT) {
            Log.i(TAG, "sendingShare MESSAGE_TYPE_TEXT ");
            return null;
        }

        // image and video
        if (selectedImangeUri.toString().startsWith(
                "content://com.google.android.apps.photos.content")) {
            Log.i(TAG, "sendingShareFileFrom google drive == "
                    + selectedImangeUri);
            return null;// not support currently....
            /*
			 * String sendName = com.starhub.messageplus.utils.FileUtils
			 * .getPhotoFileName(); String picPathString =
			 * ChatModel.imageCachePath + sendName; final File imageFromNet =
			 * new File(picPathString);
			 *
			 * com.starhub.messageplus.utils.FileUtils.saveNetworkPicture(
			 * ChatMessagingConversationBaseActivity.this,
			 * selectedImangeUri.toString(), imageFromNet, new Runnable() {
			 *
			 * @Override public void run() { if (isFinishing()||(lifeStatus ==
			 * Status.onDestory)) { return; } runOnUiThread( new Runnable() {
			 * public void run() { copyFileDialog("copy image...", imageFromNet,
			 * ChatModel.imageCachePath, Message.MESSAGE_TYPE_VIDEO, true); }
			 * });
			 *
			 * } });
			 */

        }

        sendingFileName = FileUtils.Uri2Filename(
                activity.getApplication(), selectedImangeUri);
        if (sendingFileName == null) {
            Log.i(TAG, "sendingFileName == null");
            return null;
        }
        // judge file type.
        File sendingFile = new File(sendingFileName);
        Log.i(TAG, "sharedIntent file path&&&&&&" + sendingFile);
        if (!sendingFile.exists()) {// maybe need to decode ..
            try {
                sendingFileName = URLDecoder.decode(sendingFileName, "utf-8");
            } catch (UnsupportedEncodingException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            sendingFile = new File(sendingFileName);
            // double check file is exist or not
            if (!sendingFile.exists()) {
                Log.i(TAG, "sendingShareFile not exsit");
                return null;
            } else {
                // check file size
                if (!FileUtils
                        .checkSendfileSizeIsOk(sendingFile)) {
                    Log.i(TAG, "sendingShareFile reach max limited");
                    return null;
                } else {
                    return createSharedFileMsg(chatModel,
                            sendingFile, sharedMsgType);
                }
            }
        } else {
            if (!FileUtils.checkSendfileSizeIsOk(sendingFile)) {
                Log.i(TAG, "sendingShareFile reach max limited");
                return null;
            } else {
                return createSharedFileMsg(chatModel,
                        sendingFile, sharedMsgType);
            }
        }

    }

    private static Message createSharedFileMsg(ChatModule chatModel, File file, int sharedMsgType) {
        // muliti items only images,videos
        // single text,amr,image,video,vcard

        String filePathStr = file.getAbsolutePath();
        if (sharedMsgType == ChatModule.MESSAGE_SHARED_IMAGE) {
            return chatModel.sendImage(filePathStr, null);
        } else if (sharedMsgType == ChatModule.MESSAGE_SHARED_VCARD) {
            return chatModel.sendVCard(filePathStr, null);
        } else if (sharedMsgType == ChatModule.MESSAGE_SHARED_VIOCE) {
            // cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION))
            // 这是获取音频的时长 ..

            MediaPlayer mediaPlayer = null;
            try {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(filePathStr);
                mediaPlayer.prepare();
                int musicTime = mediaPlayer.getDuration() / 1000;
                Log.i(TAG, "musicTime===" + musicTime);
                if (musicTime < 1) {
                    if (mediaPlayer.getDuration() > 0) {
                        musicTime = 1;// not reach 1 sec.
                        Log.i(TAG, "fix not reach 1 sec issue.");
                    } else {
                        return null;
                    }

                }
                return chatModel.sendVoice(filePathStr,
                        musicTime, null);// time
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
            }

            return null;// not support currently.
        } else if (sharedMsgType == ChatModule.MESSAGE_SHARED_VIDEO) {

            return chatModel.sendVideo(filePathStr, null);
        }
        return null;

    }


    /**
     * 分享判断文件是否超过20M,否则finish
     *
     * @param intent
     * @return
     */
    public static int getParseSharedTypeWithIntent(Intent intent,
                                                   List<Uri> shareUris, List<String> shareContent) {

        String action = intent.getAction();

        if (Intent.ACTION_SEND.equals(action)) {

            String type = intent.getType();
            if (type == null) {
                return ChatModule.UNKONW_SHARED_TYPE;
            }
            Log.i(TAG, "send:" + type);
            if (type.startsWith("video/")) {
                Uri videoUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                Log.i(TAG, type + " share url by ACTION_SEND_MULTIPLE ="
                        + videoUri);
                if (videoUri != null) {
                    shareUris.add(videoUri);
                }

                return ChatModule.MESSAGE_SHARED_VIDEO;
            } else if ("text/x-vcard".equals(type)) {
                Uri vcardUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                Log.i(TAG, type + " share url by ACTION_SEND_MULTIPLE ="
                        + vcardUri);
                if (vcardUri != null) {
                    shareUris.add(vcardUri);
                }

                return ChatModule.MESSAGE_SHARED_VCARD;
            } else if (type.startsWith("image/")) {
                Uri pictureUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                Log.i(TAG, type + " share url by ACTION_SEND_MULTIPLE ="
                        + pictureUri);
                if (pictureUri != null) {
                    shareUris.add(pictureUri);
                }

                return ChatModule.MESSAGE_SHARED_IMAGE;
            } else if ("audio/amr".equals(type)) {
                Uri voiceUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                Log.i(TAG, type + " share url by ACTION_SEND_MULTIPLE ="
                        + voiceUri);
                if (voiceUri != null) {
                    shareUris.add(voiceUri);
                }

                return ChatModule.MESSAGE_SHARED_VIOCE;
            } else if ("text/plain".equals(type)) {
                String content = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (!TextUtils.isEmpty(content)) {
                    shareContent.add(content);
                }
                Log.i(TAG, type + " share url by send =" + content);
                return ChatModule.MESSAGE_SHARED_TEXT;
            } else if ("*/*".equals(type)) {
                String content = intent.getStringExtra(Intent.EXTRA_TEXT);
                Log.i(TAG, type + " */* share url by send =" + content);
                if (!TextUtils.isEmpty(content)) {
                    shareContent.add(content);
                    return ChatModule.MESSAGE_SHARED_TEXT;
                }

            }

        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            String type = intent.getType();
            Log.i(TAG, "send ACTION_SEND_MULTIPLE:" + type);
            ArrayList<Uri> pictureUrisArrayList = intent
                    .getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (pictureUrisArrayList != null) {
                Log.i(TAG, type + " share url by ACTION_SEND_MULTIPLE size="
                        + pictureUrisArrayList.size());
                shareUris.addAll(pictureUrisArrayList);
            }

            if (type.startsWith("video/")) {
                return ChatModule.MESSAGE_SHARED_VIDEO;
            } else if ("text/x-vcard".equals(type)) {
                return ChatModule.MESSAGE_SHARED_VCARD;
            } else if (type.startsWith("image/")) {

                return ChatModule.MESSAGE_SHARED_IMAGE;
            } else if ("audio/amr".equals(type)) {
                return ChatModule.MESSAGE_SHARED_VIOCE;
            }
        }

        return ChatModule.UNKONW_SHARED_TYPE;

    }

    /**
     * 0 允许分享</br> 1 如果没有激活 则跳转至激活界面</br> 2 分享文件超过10个</br> 3 其它错误,退出</br>
     *
     * @param intent
     */
    public static int checkAllowedShareIntent(Context context, Intent intent) {

        String action = intent.getAction();

        if (Intent.ACTION_SEND.equals(action)) {// only one no need check size
            if (!checkCfgIsOk(context)) {
                return 1;
            }
            String type = intent.getType();
            if (type == null) {
                return 3;
            } else {
                return 0;
            }

        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            if (!checkCfgIsOk(context)) {
                return 1;
            }
            String type = intent.getType();
            if (type == null) {
                return 3;
            }
            Log.i(TAG, "send ACTION_SEND_MULTIPLE:" + type);
            ArrayList<Uri> pictureUrisArrayList = intent
                    .getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (pictureUrisArrayList != null) {
                int maxNum = context.getResources().getInteger(
                        R.integer.max_send_media_num);
                if (pictureUrisArrayList.size() > maxNum) {
                    return 2;
                } else {
                    return 0;
                }

            } else {
                return 3;
            }

        }

        return -1;

    }


    // 实现超文本链接的点击 拦截
    private void SetLinkClickIntercept(TextView textView) {

        textView.setMovementMethod(LinkMovementMethod.getInstance());
        CharSequence text = textView.getText();
        if (text instanceof Spannable) {
            int end = text.length();
            Spannable sp = (Spannable) textView.getText();
            URLSpan[] urls = sp.getSpans(0, end, URLSpan.class);
            if (urls.length == 0) {
                return;
            }

            SpannableStringBuilder spannable = new SpannableStringBuilder(text);
            // 只拦截 http:// URI
            LinkedList<String> myurls = new LinkedList<String>();
            for (URLSpan uri : urls) {
                String uriString = uri.getURL();
                if (uriString.indexOf("http://") == 0 || uriString.indexOf("https://") == 0) {
                    myurls.add(uriString);
                }
            }
            // 循环把链接发过去
            for (URLSpan uri : urls) {
                String uriString = uri.getURL();
                if (uriString.indexOf("http://") == 0 || uriString.indexOf("https://") == 0) {
//                    MyURLSpan myURLSpan = new MyURLSpan(uriString, myurls);
//                    spannable.setSpan(myURLSpan, sp.getSpanStart(uri), sp.getSpanEnd(uri),
//                            Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
                }
            }
            textView.setText(spannable);
        }
    }

    public static void createGroupConversation(final BaseActivity activity, final ArrayList<PeopleEntity> selecteds) {
        //group chat
        final EditText editText = new EditText(activity);
        new AlertDialog.Builder(activity).setTitle(activity.getString(R.string.group_chat_create_hint))
                .setIcon(android.R.drawable.ic_dialog_info).setView(editText)
                .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ArrayList<String> memberName = new ArrayList<String>();
                        for (PeopleEntity p : selecteds) {
                            memberName.add(p.subuser_id);
                        }
                        if (memberName.size() > 0) {
                            String groupName = editText.getText().toString();
                            if (TextUtils.isEmpty(groupName)) {
                                MessagingApi.createGroup(groupName);

                            } else {
                                activity.showToast(activity.getString(R.string.group_chat_create_hint));
                            }
                        }

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }
}
