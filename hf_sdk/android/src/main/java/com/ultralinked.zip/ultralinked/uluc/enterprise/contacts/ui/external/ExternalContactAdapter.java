package com.ultralinked.uluc.enterprise.contacts.ui.external;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 16/7/21.
 */
public class ExternalContactAdapter extends BaseAdapter {

    private static final String TAG = "ExternalContactAdapter";
    ArrayList<DepartUtils.CompanyElement> elements = new ArrayList<>();
    LayoutInflater mInflater;

    public void setData(List<DepartUtils.CompanyElement> data) {

        elements.clear();

        for (DepartUtils.CompanyElement element : data) {

            if ("external".equalsIgnoreCase(element.type)) {
                elements.add(element);
            }
        }

    }


    public ExternalContactAdapter(Context context) {

        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return elements == null ? 0 : elements.size();
    }

    @Override
    public Object getItem(int position) {
        return elements == null ? null : elements.get(position);
    }

    @Override
    public long getItemId(int position) {
        return elements == null ? 0 : position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView != null) {
            holder = (ViewHolder) convertView.getTag();//取出ViewHolder对象

        } else {

            convertView = mInflater.inflate(R.layout.depart_list_item, null);
            holder = new ViewHolder();
            holder.bind(convertView);
            convertView.setTag(holder);//绑定ViewHolder对象
        }

        DepartUtils.CompanyElement source = elements.get(position);

        holder.title.setText(source.name);
        holder._Id = source._id;

        int defaultId = -1;

        switch (position % 4) {

            case 1:
                defaultId = R.mipmap.avatar_group1;
                break;
            case 2:
                defaultId = R.mipmap.avatar_group2;
                break;

            case 3:
                defaultId = R.mipmap.avatar_group3;
                break;
            default:
                defaultId = R.mipmap.avatar_group4;
                break;
        }

        ImageUtils.loadCircleImage(convertView.getContext(), holder.head, defaultId);


        holder.detail.setImageResource(R.mipmap.more);

        return convertView;
    }

    public final class ViewHolder {
        public TextView title;
        public ImageView head;
        public ImageView detail;
        public String _Id;
        public int position;

        public void bind(View view) {

            this.title = (TextView) view.findViewById(R.id.Orgtitle);
            this.head = (ImageView) view.findViewById(R.id.Orgimage);
            this.detail = (ImageView) view.findViewById(R.id.OrgDetail);
        }
    }

    public boolean isLeaf(DepartUtils.CompanyElement object) {

        return object.children2 == null || object.children2.length() == 0;

    }
}
