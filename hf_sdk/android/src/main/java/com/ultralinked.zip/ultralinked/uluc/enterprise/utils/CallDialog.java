package com.ultralinked.uluc.enterprise.utils;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.ultralinked.contact.util.ToastUtil;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.call.VideoCallActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatBottomMenuPagerAdapter;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.call.IncallActivity;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/8/1 0001.
 */
public class CallDialog extends DialogFragment implements View.OnClickListener {
    String TAG = "Dialog";
    View root;
    TextView ip2ip, ip2phone, callback, cancel,videocall;
    Dialog dialog;
    String callMobile, callName, callIcon;
    private RxAppCompatActivity activity;

    private String callUserId;

    public void setCallStartListener(OnCallStartListener callStartListener) {
        this.callStartListener = callStartListener;
    }

    public  interface  OnCallStartListener{
        void go2Call();
    }

    private  OnCallStartListener callStartListener;



    public static CallDialog getInstance(String callMobile, String callName, String callIcon) {
        CallDialog callDialog = new CallDialog();
        Bundle bundle = new Bundle();
        bundle.putString("callMobile", callMobile);
        bundle.putString("callName", callName);
        bundle.putString("callIcon", callIcon);
        callDialog.setArguments(bundle);
        return callDialog;
    }
int autoPerfrm=-1;
    public void setCallUserId(String callUserId) {
        this.callUserId = callUserId;
    }
    public void makeCall(Activity activity,String callMobile, String callName, String callIcon,String callUserId ,int autoPerfrom) {
       setCallUserId(callUserId);
        this.activity = (RxAppCompatActivity) activity;
        this.callMobile = callMobile;
        this.callName = callName;
        this.callIcon = callIcon;
        autoPerfrm = autoPerfrom;
        if (autoPerfrm!=-1){
            switch (autoPerfrm){
                case ChatBottomMenuPagerAdapter.VIDEO_CALL:
                   videoCall();
                    break;
                case ChatBottomMenuPagerAdapter.VOICE_CALL:
                    IP2IP();
                    break;
                case ChatBottomMenuPagerAdapter.CALLBACK_CALL:
                    IP2callBack();
                    break;
                case ChatBottomMenuPagerAdapter.IP2_PHONE_CALL:
                    IP2Phone();
                    break;
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callMobile = getArguments().getString("callMobile");
        callName = getArguments().getString("callName");
        callIcon = getArguments().getString("callIcon");
        Log.i(TAG, TAG);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = (RxAppCompatActivity) activity;
        Log.i(TAG, TAG);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Log.i(TAG);
        int offSetHegiht = ScreenUtils.getViewHeight(getActivity().findViewById(R.id.bottom_menu));
        if (offSetHegiht>0){
            this.dialog = new Dialog(getActivity(), R.style.normal_windows);
        }else{
            this.dialog = new Dialog(getActivity(), R.style.CustomDatePickerDialog);
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        root = LayoutInflater.from(getActivity()).inflate(R.layout.call_dialog, null);
        dialog.setContentView(root);
        dialog.setCanceledOnTouchOutside(true);
        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.y = offSetHegiht;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);

        ip2ip = (TextView) root.findViewById(R.id.call_ip2ip);
        root.findViewById(R.id.call_video_layout).setVisibility(View.GONE);
        if (TextUtils.isEmpty(callName)){
            root.findViewById(R.id.call_ip2ip_layout).setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(callUserId)){

            root.findViewById(R.id.call_video_layout).setVisibility(View.GONE);
        }

        ip2phone = (TextView) root.findViewById(R.id.call_ip2phone);
        videocall = (TextView) root.findViewById(R.id.call_video);
        callback = (TextView) root.findViewById(R.id.call_back);
        cancel = (TextView) root.findViewById(R.id.call_cancel);
        ip2ip.setOnClickListener(this);
        ip2phone.setOnClickListener(this);
        callback.setOnClickListener(this);
        cancel.setOnClickListener(this);
        videocall.setOnClickListener(this);

        return dialog;
    }


    @Override
    public void onClick(View v) {
        Log.i(TAG, "click ");
        switch (v.getId()) {
            case R.id.call_ip2ip:
                IP2IP();
                dismiss();
                break;
            case R.id.call_video:
                videoCall();
                dismiss();
                break;
            case R.id.call_ip2phone:
                IP2Phone();
                dismiss();
                break;
            case R.id.call_back:
                IP2callBack();
                dismiss();
                break;
            case R.id.call_cancel:
                dismiss();
                break;
        }
    }

    public void videoCall() {
        call(IncallActivity.VIDEO_call);
        Log.i(TAG);
    }

    public void IP2IP() {
        call(IncallActivity.IP2IP);
        Log.i(TAG);
    }

    public void IP2Phone() {
        Log.i(TAG);
        call(IncallActivity.IP2Phone);
    }

    public void IP2callBack() {
        Log.i(TAG);
        String str1 = activity.getString(R.string.waiting);
        final ProgressDialog progressDialog = new ProgressDialog(activity);
        progressDialog.setCanceledOnTouchOutside(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(str1);
        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            public void onCancel(DialogInterface arg0) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });

        progressDialog.show();
        ApiManager.getInstance().callback(SPUtil.getCode() + SPUtil.getMobile(), callMobile)
                .compose(activity.<ResponseBody>bindToLifecycle())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"IP2callBackComplted");
                    }                      @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "IP2callBack error " + eMsg);
                        progressDialog.cancel();
                        ToastUtil.showToast(activity,activity.getString(R.string.make_call_back_failed),Toast.LENGTH_LONG);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {
                        progressDialog.cancel();
                        try {

                            Log.d(TAG, responseBody.string());

                            ToastUtil.showToast(activity,activity.getString(R.string.make_call_back_succ),Toast.LENGTH_LONG);
                        } catch (IOException e) {
                            ToastUtil.showToast(activity,activity.getString(R.string.make_call_back_failed),Toast.LENGTH_LONG);
                            e.printStackTrace();
                        }
                    }

                });
    }

    public void call(final int callType) {
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                if (IncallActivity.VIDEO_call == callType){
                    if (callStartListener!=null){
                        callStartListener.go2Call();
                    }
                    VideoCallActivity.launch(activity,callUserId,false);
                }else{
                    if (callStartListener!=null){
                        callStartListener.go2Call();
                    }
                    Log.i("callDialog", "call mobile:===" + callMobile+";call name="+callName);
                    IncallActivity.lunch(activity, callMobile, callName, callIcon, false, callType);
                }
            }
        }).compose(activity.<String>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS).subscribe();
    }

    public void dismiss() {
        if (dialog != null) {
            dialog.dismiss();
        }
    }
}
