package com.ultralinked.uluc.enterprise.chat;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.view.MotionEvent;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.ImEmotionMap;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.Message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.bingoogolapple.badgeview.BGABadgeView;
import cn.bingoogolapple.badgeview.BGABadgeable;
import cn.bingoogolapple.badgeview.BGADragDismissDelegate;

/**
 * Created by ultralinked on 2016/7/4 0004.
 */
public class ChatAdapter extends MyBaseAdapter<Conversation> {
    private BaseActivity context;
    private ChatFilter mFilter;
    private ArrayList<Conversation> mUnfilteredData;
    private int emotionSize;


    public ChatAdapter(BaseActivity context, int resource, List<Conversation> list) {
        super(context, resource, list);
        this.context = context;
        //setMode(Attributes.Mode.Single);
    }

    @Override
    public void updateList(List<Conversation> list) {
        super.updateList(list);
        if (mUnfilteredData != null) {
            mUnfilteredData = null;
        }
    }

    String splitSingleLineStr(String content) {
        // get screen witdh , mearsure text max witdh >=screen width
        if (!TextUtils.isEmpty(content) && content.length() > 160) {
            return content.substring(0, 160);
        }
        return content;
    }


    SpannableString getFormattedStr(String lastMsgSenderUser, Conversation conversation) {
        String msgBody = MessageUtils.getMsgBody(lastMsgSenderUser,conversation);

        String info = splitSingleLineStr(msgBody);
        SpannableString emotionSpannableString = ImEmotionMap.genSpanString(info, 1 * emotionSize,
                ImageSpan.ALIGN_BASELINE);
        String linkUserName = MessageUtils.linkMyself(conversation.getLastMessage());
        if (linkUserName != null) {//@ link message.
            int findPos = TextUtils.indexOf(emotionSpannableString, linkUserName);
            if (findPos > -1) {
                emotionSpannableString.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.color_red)),
                        findPos, findPos + linkUserName.length(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        return emotionSpannableString;

    }

    private void mesureTextSize(TextView textView) {
        //
        int tsize = (int) textView.getTextSize();
        tsize *= 1.2f;
        emotionSize = tsize + (tsize % 2 == 0 ? 0 : 1);

    }

    public void setConversationItemListener(OnConversationItemListener conversationItemListener) {
        this.conversationItemListener = conversationItemListener;
    }


    public interface OnConversationItemListener {
        void removeUnread(int unreadCount, Conversation conversation);

    }

    private OnConversationItemListener conversationItemListener;


    private View getParentViewById(View view, int id) {

        View viewParent = (View) view.getParent();
        if (viewParent != null) {
            if (viewParent.getId() == id) {
                return viewParent;
            } else {
                return getParentViewById(viewParent, id);
            }
        } else {
            return null;
        }
    }

    private void onItemClick(String tag, View view) {
        try {
//            Conversation conversation = (Conversation) view.getTag();
//            if (conversationSwipeItemClickListener!=null) {
//                conversationSwipeItemClickListener.onClickItem(tag, conversation);
//                closeAllItems();
//                SwipeLayout swipeLayout = (SwipeLayout) getParentViewById(view,R.id.chat_swipe_item);
//                swipeLayout.close(true);
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //SwipeLayout lastOpenSwipe;
    @Override
    protected void onItemViewCreated(MyHolder holder, Conversation item) {
        super.onItemViewCreated(holder, item);
        if (emotionSize == 0) {
            mesureTextSize((TextView) holder.getView(R.id.tv_chat_info));
        }
        final BGABadgeView unreadCountView = holder.getView(R.id.unread_msg_count);
        unreadCountView.setDragDismissDelegage(new BGADragDismissDelegate() {
            @Override
            public void onDismiss(BGABadgeable badgeable) {
                Conversation conversation = (Conversation) unreadCountView.getTag();
                if (conversation != null) {
                    if (conversationItemListener != null) {
                        conversationItemListener.removeUnread(conversation.getUnReadMsgCount(), conversation);
                    }

                    conversation.read();

                    notifyDataSetChanged();

                }
            }
        });


//        SwipeLayout swipeLayout = holder.getView(R.id.chat_swipe_item);
//
//        holder.getView(R.id.delete).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//               onItemClick("delete",view);
//             //  closeAllItems();
//            }
//        });
//
//        holder.getView(R.id.stick_on_top).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                onItemClick("stick",view);
//               // closeAllItems();
//            }
//        });


////set show mode.
//        swipeLayout.setShowMode(SwipeLayout.ShowMode.LayDown);
//
////add drag edge.(If the BottomView has 'layout_gravity' attribute, this line is unnecessary)
//        swipeLayout.addDrag(SwipeLayout.DragEdge.Right, holder.getView(R.id.bottom_wrapper));
//
//        swipeLayout.addSwipeListener(new SwipeLayout.SwipeListener() {
//            @Override
//            public void onClose(SwipeLayout layout) {
//                //when the SurfaceView totally cover the BottomView.
//            }
//
//            @Override
//            public void onUpdate(SwipeLayout layout, int leftOffset, int topOffset) {
//                //you are swiping.
//            }
//
//            @Override
//            public void onStartOpen(SwipeLayout layout) {
//
//                closeCurrentSwipeView();
//
//            }
//
//            @Override
//            public void onOpen(SwipeLayout layout) {
//                //when the BottomView totally show.
//                lastOpenSwipe = layout;
//
//            }
//
//            @Override
//            public void onStartClose(SwipeLayout layout) {
//
//            }
//
//            @Override
//            public void onHandRelease(SwipeLayout layout, float xvel, float yvel) {
//                //when user's hand released.
//            }
//        });
    }

    public boolean closeCurrentSwipeView() {

//        try{
//            if (lastOpenSwipe!=null && lastOpenSwipe.getOpenStatus() == SwipeLayout.Status.Open){
//                lastOpenSwipe.close();
//                return true;
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//        }

        return false;

    }


    HashMap<String, PeopleEntity> peopleEntityHashMap = new HashMap<>();

    HashMap<String, Boolean> queryFromNetworkMap = new HashMap<>();

    @Override
    public void setHolder(MyHolder viewHolder, Conversation conversation) {

        /*根据是否置顶改变item背景颜色*/
        if (conversation.isTopUp) {
            viewHolder.setItemBackgroundDrawable(R.id.stick_back, R.drawable.list_selector_chat_up);
            //viewHolder.setText(R.id.stick_on_top,context.getString(R.string.cancel_stick_on_top));
        } else {
            viewHolder.setItemBackgroundDrawable(R.id.stick_back, R.drawable.list_selector_white);
            // viewHolder.setText(R.id.stick_on_top,context.getString(R.string.stick_on_top));
        }

//        viewHolder.getView(R.id.stick_on_top).setTag(conversation);
//        viewHolder.getView(R.id.delete).setTag(conversation);

        String time = conversation.getTime();
        time = ChatModule.convertTimeForChatListItem(context, time);


        viewHolder.setText(R.id.tv_chat_time, time);
        BGABadgeView unreadCountView = viewHolder.getView(R.id.unread_msg_count);
        View unreadFlag = viewHolder.getView(R.id.chat_unread_flag);
        unreadCountView.setTag(conversation);
        int unreadCount = conversation.getUnReadMsgCount();
        if (unreadCount > 0) {
            unreadFlag.setVisibility(View.VISIBLE);
            if (unreadCount > 99) {
                unreadCountView.showTextBadge("99+");
            } else {
                unreadCountView.showTextBadge("" + unreadCount);
            }
        } else {
            unreadFlag.setVisibility(View.GONE);
            unreadCountView.hiddenBadge();
        }

        String name = "";
        String senderLastMsgName = "";
        if (conversation.isGroup()) {// 群聊没有uerid
            viewHolder.setImage(R.id.ivPhoto, com.holdingfuture.flutterapp.hfsdk.R.mipmap.avatar_group1);
            name = ((GroupConversation) conversation).getGroupTopic();
            Message lastMsg = conversation.getLastMessage();
            if (lastMsg != null) {
                boolean isSender = lastMsg.isSender();
                if (!isSender) {
                    String userid = lastMsg.getSender();
                    PeopleEntity entity = peopleEntityHashMap.get(userid);
                    if (entity != null) {
                        senderLastMsgName = PeopleEntityQuery.getDisplayName(entity);
                    } else {
                        //from database.
                        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userid);
                        if (PeopleEntityQuery.hasFoundPeople(peopleEntity)) {
                            senderLastMsgName = PeopleEntityQuery.getDisplayName(peopleEntity);
                            peopleEntityHashMap.put(userid, peopleEntity);
                        } else {
                            //from  network.
                            Boolean fromNetWork = queryFromNetworkMap.get(userid);
                            if (fromNetWork == null || fromNetWork.booleanValue() == false) {
                                queryFromNetworkMap.put(userid, true);

                                ArrayList<String> userIds = new ArrayList<>();
                                userIds.add(userid);
                                RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
                                    @Override
                                    public void onResultFriendList(final List<PeopleEntity> entities) {


                                        if (context != null && !context.isFinishing()) {
                                            context.runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    if (!entities.isEmpty()) {
                                                        queryFromNetworkMap.remove(entities.get(0).subuser_id);
                                                        peopleEntityHashMap.put(entities.get(0).subuser_id, entities.get(0));
                                                        notifyDataSetChanged();
                                                    }
                                                }
                                            });
                                        }
                                    }

                                    @Override
                                    public void onQueryFailed(final List<String> requestUserIds) {

                                        if (context != null && !context.isFinishing()) {
                                            context.runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    queryFromNetworkMap.put(requestUserIds.get(0), false);
                                                }
                                            });
                                        }


                                    }
                                });
                            }

                        }
                    }

                    if (!TextUtils.isEmpty(senderLastMsgName)){
                        senderLastMsgName = senderLastMsgName + ":";
                    }

                } else {
                    Log.i(TAG,"the last message is null");
                }
            }


        } else {
            String userid = conversation.getContactNumber();
            PeopleEntity entity = peopleEntityHashMap.get(userid);
            if (entity != null) {
                name = PeopleEntityQuery.getDisplayName(entity);
                ImageUtils.loadCircleImage(context, (ImageView) viewHolder.getView(R.id.ivPhoto), entity.icon_url, ImageUtils.getDefaultContactImageResource(userid));

            } else {
                //from database.
                PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userid);
                if (PeopleEntityQuery.hasFoundPeople(peopleEntity)) {
                    name = PeopleEntityQuery.getDisplayName(peopleEntity);
                    peopleEntityHashMap.put(userid, peopleEntity);
                    ImageUtils.loadCircleImage(context, (ImageView) viewHolder.getView(R.id.ivPhoto), peopleEntity.icon_url, ImageUtils.getDefaultContactImageResource(userid));
                } else {
                    //from  network.
                    Boolean fromNetWork = queryFromNetworkMap.get(userid);
                    if (fromNetWork == null || fromNetWork.booleanValue() == false) {
                        queryFromNetworkMap.put(userid, true);

                        ArrayList<String> userIds = new ArrayList<>();
                        userIds.add(userid);
                        RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
                            @Override
                            public void onResultFriendList(final List<PeopleEntity> entities) {


                                if (context != null && !context.isFinishing()) {
                                    context.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (!entities.isEmpty()) {
                                                queryFromNetworkMap.remove(entities.get(0).subuser_id);
                                                peopleEntityHashMap.put(entities.get(0).subuser_id, entities.get(0));
                                                notifyDataSetChanged();
                                            }
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onQueryFailed(final List<String> requestUserIds) {

                                if (context != null && !context.isFinishing()) {
                                    context.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            queryFromNetworkMap.put(requestUserIds.get(0), false);
                                        }
                                    });
                                }


                            }
                        });
                    }

                    name = conversation.getContactNumber();
                    Log.i(TAG, "peopleEntity is null.userid：" + userid);
                    viewHolder.setImage(R.id.ivPhoto, ImageUtils.getDefaultContactImageResource(userid));
                }
            }
        }


        viewHolder.setText(R.id.tv_chat_info, getFormattedStr(senderLastMsgName, conversation));

        conversation.setTag(name);
        viewHolder.setText(R.id.tv_chat_name, name);
        if (!TextUtils.isEmpty(conversation.getDraft())) {
            viewHolder.getView(R.id.draft).setVisibility(View.VISIBLE);
        } else {
            viewHolder.getView(R.id.draft).setVisibility(View.GONE);
        }

    }


    private static final String TAG = "ChatAdapter";

    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ChatFilter();
        }
        return mFilter;
    }


//    protected SwipeItemAdapterMangerImpl mItemManger = new SwipeItemAdapterMangerImpl(this);
//
//
//    @Override
//    public int getSwipeLayoutResourceId(int position) {
//        return 0;//R.id.chat_swipe_item;
//    }
//
//    @Override
//    public void openItem(int position) {
//        mItemManger.openItem(position);
//    }
//
//    @Override
//    public void closeItem(int position) {
//        mItemManger.closeItem(position);
//    }
//    @Override
//    public void closeAllExcept(SwipeLayout layout) {
//        mItemManger.closeAllExcept(layout);
//    }
//
//    @Override
//    public void closeAllItems() {
//        mItemManger.closeAllItems();
//    }
//
//    @Override
//    public List<Integer> getOpenItems() {
//        return mItemManger.getOpenItems();
//    }
//
//    @Override
//    public List<SwipeLayout> getOpenLayouts() {
//        return mItemManger.getOpenLayouts();
//    }
//
//    @Override
//    public void removeShownLayouts(SwipeLayout layout) {
//        mItemManger.removeShownLayouts(layout);
//    }
//
//    @Override
//    public boolean isOpen(int position) {
//        return mItemManger.isOpen(position);
//    }
//
//    @Override
//    public Attributes.Mode getMode() {
//        return mItemManger.getMode();
//    }
//
//    @Override
//    public void setMode(Attributes.Mode mode) {
//        mItemManger.setMode(mode);
//    }

    // 异步过滤数据，避免数据多耗时长堵塞主线程
    class ChatFilter extends Filter {
        // 执行筛选
        @Override
        protected FilterResults performFiltering(CharSequence prefix) {
            FilterResults results = new FilterResults();

            if (mUnfilteredData == null) {
                mUnfilteredData = new ArrayList<Conversation>(list);
            }

            if (prefix == null || prefix.length() == 0) {
                ArrayList<Conversation> list = mUnfilteredData;
                results.values = list;
                results.count = list.size();
            } else {
                String prefixString = prefix.toString().toLowerCase();

                ArrayList<Conversation> unfilteredValues = mUnfilteredData;
                int count = unfilteredValues.size();

                ArrayList<Conversation> newValues = new ArrayList<Conversation>(count);

                for (int i = 0; i < count; i++) {
                    Conversation h = unfilteredValues.get(i);
                    if (h != null) {
                        String str = (String) h.getTag();
                        if (str != null) {
                            str = str.toLowerCase();
                        }
                        if (!TextUtils.isEmpty(str) && str.contains(prefixString)) {
                            newValues.add(h);
                        }

                    }
                }

                results.values = newValues;
                results.count = newValues.size();
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            //noinspection unchecked
            list = (List<Conversation>) results.values;
            if (results.count > 0) {
                notifyDataSetChanged();
            } else {
                notifyDataSetInvalidated();
            }
        }
    }
}
