package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.view.MotionEvent;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.call.CallFragment;
import com.ultralinked.uluc.enterprise.call.FragmentTools;


public class CompanyDetailActivity extends BaseFragmentActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        Class<?> className = FragmentTools.class;
        Bundle bundle = new Bundle();
        bundle.putString(FragmentTools.KEY_COMPANY_NAME,getIntent().getStringExtra(FragmentTools.KEY_COMPANY_NAME));
        bundle.putParcelable(FragmentTools.KEY_DETAIL,getIntent().getParcelableExtra(FragmentTools.KEY_DETAIL));
        setFragment(className, bundle);

    }


}
