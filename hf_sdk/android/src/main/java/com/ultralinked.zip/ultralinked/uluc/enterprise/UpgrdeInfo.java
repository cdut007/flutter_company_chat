package com.ultralinked.uluc.enterprise;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.UUID;

/**
 * Created by ultralinked on 16/10/10.
 */
public class UpgrdeInfo {

    public static boolean isNewVersion() {

//        if (true){
//
//            return  true;
//        }

        int curAppVer = getVersionCode(App.getInstance());
        if (curAppVer> GuideViewHelper.getAppVersion()){
            GuideViewHelper.setAppVersion(curAppVer);//maybe store when request succ.
            return  true;
        }
        return false;
    }


    /**
     * @return 设备唯一标识符
     */
    public static  String getUUID() {

        TelephonyManager tm =(TelephonyManager)App.getInstance().getSystemService(Context.TELEPHONY_SERVICE);
        String tmDevice, tmSerial, tmPhone, androidId;
        // 357784053869432
        tmDevice = "" + tm.getDeviceId();
        tmSerial = tm.getSimSerialNumber();
        if (TextUtils.isEmpty(tmSerial)){
            tmSerial = "";
        }
        //357784053869432
        String uniqueId = tmDevice + tmSerial;
        return uniqueId;

    }


    public static int getVersionCode(Context context)//获取版本号(内部识别号)
    {
        try {
            PackageInfo pi=context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pi.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return -1;
        }
    }

    public static String getVendor() {
        return Build.BRAND+"-"+Build.MODEL;
    }

    public static String getDeviceName() {
        return Build.MODEL+"";
    }
}
