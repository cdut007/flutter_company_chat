package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

/**
 * Created by mac on 16/10/19.
 */

import android.content.Intent;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.utils.Log;

import android.widget.AdapterView;
import android.widget.Toast;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.RawMatchsFriendPerson;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.*;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;

import org.json.JSONObject;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


/**
 * Created by ultralinked on 16/7/19.
 */

public class SearchFriendFragment extends BaseFragment implements LoaderManager.LoaderCallbacks<Cursor> {

    public SearchFriendFragment() {
        // Required empty public constructor
    }


    // Identifier for the permission request
    private static final int READ_CONTACTS_PERMISSIONS_REQUEST = 0x121;
    private static final int LOADERID = 0x12;
    private static final String TAG = "SearchFriendFragment";
    private ListView mListView;
    private InviteContactAdapter mAdapter;
    private boolean mIsSearchResultView;
    private String mSearchTerm;
    private com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactLocalBook.OnContactsInteractionListener mOnContactSelectedListener;


    /**
     * This interface must be implemented by any activity that loads this fragment. When an
     * interaction occurs, such as touching an item from the ListView, these callbacks will
     * be invoked to communicate the event back to the activity.
     */
    public interface OnContactsInteractionListener {
        /**
         * Called when a contact is selected from the ListView.
         */
        void onContactSelected(String name, String phone);

        /**
         * Called when the ListView selection is cleared like when
         * a contact search is taking place or is finishing.
         */
        void onSelectionCleared();

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    View empty_detailView;

    public void setOnContactSelectedListener(FragmentAddContactLocalBook.OnContactsInteractionListener mOnContactSelectedListener) {
        this.mOnContactSelectedListener = mOnContactSelectedListener;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        goneView(bind(R.id.top_bar));
        goneView(bind(R.id.search_layout));
        mListView = bind(R.id.pickContactList);
        goneView(bind(R.id.sideBar));
        empty_detailView = bind(R.id.empty_detail);
        goneView(bind(R.id.image));
        mListView.setEmptyView(empty_detailView);

        mListView.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Cursor cursor = mAdapter.getCursor();

                cursor.moveToPosition(position);

                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                if (mOnContactSelectedListener != null) {
                    mOnContactSelectedListener.onContactSelected(name, phone);
                }

            }
        });


        mListView.requestFocus();
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.fragment_add_contact_local;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSIONS_REQUEST);
        } else {
           // getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        }

        //getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        mAdapter = new InviteContactAdapter(getActivity(), new NewFriendAdapter.OnFriendClickListener() {
            @Override
            public void onItemClickListener(PeopleEntity entity) {

            }

            @Override
            public void callFriendRequest(String action, PeopleEntity peopleEntity) {
                peopleEntity.mobile = PhoneNumberUtils.normalizeNumber(peopleEntity.mobile);
                queryContact(peopleEntity);

            }

            @Override
            public void onFriendStatusChanged(PeopleEntity peopleEntity) {

            }
        });

        mListView.setAdapter(mAdapter);

    }


    public void queryContact(final PeopleEntity peopleEntity) {


        ApiManager.getInstance().queryUser(peopleEntity.mobile)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "QueryFriendComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        Log.e(TAG, "Query error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                RawMatchsFriendPerson rawFriendPerson = GsonUtil.fromJson(rs, RawMatchsFriendPerson.class);
                                if (rawFriendPerson != null && rawFriendPerson.matchs != null) {
                                    if (rawFriendPerson.matchs.size() >= 1) {

                                        PeopleEntity entity = rawFriendPerson.matchs.get(0);
                                        // go to detail or add friend page.
                                        if (entity.is_friend) {
                                            DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
                                        } else {
                                            Intent intent = new Intent(getActivity(), AddNewFriendActicity.class);
                                            intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, entity);
                                            startActivity(intent);
                                        }
                                        //   RequestFriendManager.getInstance().inviteFriend((BaseActivity) getActivity(),entity);
                                    }

                                } else {
                                    //not found. just share.
                                }

                            } else if (202 == object.optInt("code")) {
                                String shareInfo = object.optString("description");
                                //showToast(R.string.add_contact_invite_success);
                                String mobile = peopleEntity.mobile;
                                Log.i(TAG, "invite mobile info:" + mobile);

                                ShareUtils.tellFriend(getContext(), shareInfo, mobile);
                            } else {
                                showToast(R.string.add_contact_invite_failed);

                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
                        }

                        Log.i(TAG, "Query  " + rs);
                    }

                });

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_CONTACTS_PERMISSIONS_REQUEST) {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST ");
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
            } else {
                Toast.makeText(getContext().getApplicationContext(), "Read Contacts permission denied", Toast.LENGTH_SHORT).show();
                getActivity().finish();
            }
        } else {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST no");
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        Uri contentUri;
        if (mSearchTerm == null) {
            // Since there's no search string, use the content URI that searches the entire
            // Contacts table
            contentUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        } else {
            // Since there's a search string, use the special content Uri that searches the
            // Contacts table. The URI consists of a base Uri and the search string.
            contentUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(mSearchTerm));
        }


        return new CursorLoader(getContext(), contentUri,
                null, ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + " > 0", null, "sort_key");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data.getCount() <= 0) {

            mAdapter.changeCursor(data);
           showSearchAdd();

        } else {
            empty_detailView.setVisibility(View.GONE);
            mAdapter.changeCursor(data);
        }

    }

    private void showSearchAdd() {
        empty_detailView.setVisibility(View.VISIBLE);
        //no data
        if (RegexValidateUtils.checkCellphone(mSearchTerm)) {
            TextView title = bind(R.id.title);
            String info = getString(R.string.addfriend_from_local_contact) + " " + mSearchTerm;
            SpannableStringBuilder sp = new SpannableStringBuilder(info);

            try {
                sp.setSpan(new ForegroundColorSpan(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.color_primary)), info.length() - mSearchTerm.length(), info.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            title.setText(sp);

            visibleView(bind(R.id.txt_invite));
            goneView(bind(R.id.description));
            bind(R.id.txt_invite).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PeopleEntity entity = new PeopleEntity();

                    if (mSearchTerm != null) {
                        if (mSearchTerm.startsWith("+")) {
                            mSearchTerm = mSearchTerm.substring(1);
                        }
                        if (mSearchTerm.startsWith("00")) {
                            mSearchTerm = mSearchTerm.substring(2);
                        }
                    }
                    entity.mobile = mSearchTerm;

                    queryContact(entity);
                }
            });
        } else {
            TextView title = bind(R.id.title);
            title.setText(getString(R.string.please_enter_right_mobile_format));
            goneView(bind(R.id.txt_invite));
            goneView(bind(R.id.description));
            empty_detailView.setOnClickListener(null);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.changeCursor(null);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //getActivity().getSupportLoaderManager().destroyLoader(LOADERID);
    }


    public void setSearchQuery(String query) {

        if (empty_detailView == null) {
            return;
        }

        empty_detailView.setVisibility(View.GONE);
        if (TextUtils.isEmpty(query)) {
            mSearchTerm = null;
            mIsSearchResultView = false;
        } else {
            mSearchTerm = query;

            if (mSearchTerm != null) {
                if (mSearchTerm.startsWith("+")) {
                    mSearchTerm = mSearchTerm.substring(1);
                }
                if (mSearchTerm.startsWith("00")) {
                    mSearchTerm = mSearchTerm.substring(2);
                }
            }
            mIsSearchResultView = true;
        }
        try {
            showSearchAdd();

          //  getActivity().getSupportLoaderManager().restartLoader(LOADERID, null, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}


