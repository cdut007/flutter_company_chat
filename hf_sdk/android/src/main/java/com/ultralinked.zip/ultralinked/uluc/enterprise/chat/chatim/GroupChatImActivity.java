package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.Conversation;

/**
 * Created by Administrator on 2016/8/19 0019.
 */
public class GroupChatImActivity extends BaseChatImActivity{
    private static final String TAG = "GroupChatImActivity";

    /**
     * 启动到群聊界面
     * @param context
     * @param groupId
     */
    public static void launchToGroupChatIm(@NonNull Context context, @NonNull String groupId, int chatFlag) {
        Bundle data = new Bundle();
        data.putString(Constants.GROUPKD_KEY,groupId);
        data.putInt(Constants.CHAT_TYPE_KEY, Conversation.GROUP_CHAT);
        data.putInt(Constants.CHAT_FLAG,chatFlag);

        Intent intent = new Intent(context, GroupChatImActivity.class);
        intent.putExtras(data);
        context.startActivity(intent);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG,"onNewIntent~~~");

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TCAgent.onPageStart(getActivity(),"群聊");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"群聊");
    }

}
