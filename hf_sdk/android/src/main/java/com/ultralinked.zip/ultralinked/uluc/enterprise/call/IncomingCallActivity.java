package com.ultralinked.uluc.enterprise.call;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.skyfishjy.library.RippleBackground;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MediaManger;
import com.ultralinked.voip.api.MessagingApi;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.ultralinked.voip.api.MessagingApi.init;
import static com.ultralinked.voip.api.MessagingApi.mContext;

public class IncomingCallActivity extends BaseActivity implements View.OnClickListener {

    String callFrome, fromName = "", fromMobile, iconUrl;
    PeopleEntity peopleEntity;
    ImageView ivCallIcon;
    TextView tvCallName;
    ImageView btReject, btAccept;
    private CallSession callSession;
    private long callId;
    RippleBackground rippleBackground;
    public static IncomingCallActivity instance;

    public static void lunchIncoming(Context context, long callId) {
        CallModel.stopTerminateTone();
        notifyCallIncomingPlayVibrator();
        Intent intent = new Intent(context, IncomingCallActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("call_id", callId);
        context.startActivity(intent);
    }


    private static Vibrator vibrator;


    private static void notifyCallIncomingPlayVibrator() {

        AudioManager audioManager = (AudioManager) App.getInstance().getSystemService(Context.AUDIO_SERVICE);
        if (audioManager.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE) {
            startVibrate();
        }

    }

    private static void startVibrate() {

        stopVibrate();
        vibrator = (Vibrator) App.getInstance().getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null) {
            vibrator.vibrate(new long[]{1000L, 1000L}, 0);
        }

    }

    private static void stopVibrate() {
        if (null != vibrator) {
            vibrator.cancel();
            vibrator = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG, "incoming call from the onNewIntent");
        initCall(intent);

    }

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_incoming_call;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(callStatusChangedReceiver,
                new IntentFilter(CallApi.EVENT_CALL_STATUS_CHANGE));

        int flags;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            flags = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
        } else {
            flags = WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD;
        }
        getWindow().addFlags(flags);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        instance = this;

        rippleBackground = bind(R.id.ripple_content);
        ivCallIcon = bind(R.id.ivCallPhoto);
        tvCallName = bind(R.id.tvCallName);
        btReject = bind(R.id.btReject);
        btAccept = bind(R.id.btAccept);

        initCall(getIntent());

        rippleBackground.startRippleAnimation();

        initListener(this, btAccept, btReject);

    }


    private void initCall(Intent intent) {

        callId = intent.getLongExtra("call_id", 0);

        callSession = CallApi.getCallSessionById(callId);
        if (null == callSession) {
            Log.i(TAG, "the call session is null.");
            MediaManger.getInstance(this).stopAlarmRing();
            finish();
            return;
        }

        callFrome = callSession.callFrom;

        Log.i(TAG, "call from == " + callFrome);

        if (callSession.callId != -1 && callSession.callId != callId) {
            //incoming call id is prew call ,current call already exist.
            MediaManger.getInstance(this).stopAlarmRing();
            callSession.terminate();
            finish();
            Log.i(TAG, "the call is already not in right position,just end it.");
            return;
        }

        if (TextUtils.isEmpty(callFrome)) {
            MediaManger.getInstance(this).stopAlarmRing();
            callSession.terminate();
            finish();
            Log.i(TAG, "the call from name is empty  end it.");
            return;
        }


        if (IncallActivity.hasCall) {
            MediaManger.getInstance(this).stopAlarmRing();
            callSession.terminate();
            Log.i(TAG, "current has a call");
            finish();
            return;
        }


        peopleEntity = PeopleEntityQuery.getInstance().getByID(callFrome);

        if (peopleEntity != null) {
            iconUrl = peopleEntity.icon_url;
            fromName = PeopleEntityQuery.getDisplayName(peopleEntity);
            fromMobile = peopleEntity.mobile;
        } else {
            fromName = getString(R.string.unknown);
            fromMobile = getString(R.string.unknown);
        }

        ImageUtils.loadCircleImage(IncomingCallActivity.this, ivCallIcon, iconUrl, ImageUtils.getDefaultContactImageResource(callFrome));
        tvCallName.setText(fromName);

    }


    boolean insertCallLog = false;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btReject:
                stopVibrate();
                if (callSession != null) {
                    callSession.terminate();
                    insertCallLog = true;

                    if (callFrome != null && callFrome.startsWith("subusr")) {
                        if (callSession.type == CallSession.TYPE_VIDEO) {
                            MessagingApi.insertVoipCallLogMessage(callFrome, callFrome, SPUtil.getUserID(), 0, CallSession.TYPE_VIDEO, Conversation.SINGLE_CHAT);
                        } else {
                            MessagingApi.insertVoipCallLogMessage(callFrome, callFrome, SPUtil.getUserID(), 0, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);

                        }
                    }

                }

                Observable.just(" end call").compose(this.<String>bindToLifecycle())
                        .delay(2, TimeUnit.SECONDS).subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
//                        saveCallLog(fromName, fromMobile, "miss", iconUrl);
                        finish();
                    }
                });
                break;

            case R.id.btAccept:
                stopVibrate();
                if (callSession != null) {
                    if (callSession.type == CallSession.TYPE_VIDEO) {
                        CallApi.setVideoICEEnable(true);
                        VideoCallActivity.launch(IncomingCallActivity.this, callSession.callFrom, true);
                        callSession.accept();
                        finish();

                    } else {

                        IncallActivity.lunch(IncomingCallActivity.this, fromMobile, fromName, iconUrl, true, callSession.type);
                        callSession.accept();
                        finish();
                    }

                } else {
                    finish();
                }
                break;
        }
    }

    /* Deal with call incoming event when call status was changed. */
    private BroadcastReceiver callStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            CallSession session = (CallSession) intent.getSerializableExtra(CallApi.PARAM_CALL_SESSION);
            int newStatus = session.callState;

            String from = session.callFrom;
            Log.i(TAG, "callStatusChangedReceive newStatus :  " + newStatus + " from  =" + from + ";callType:" + session.type);


            if (isFinishing()) {
                return;
            }


            switch (newStatus) {


                case CallSession.STATUS_RECORD_FAIL:
                    if (callSession != null) {
                        callSession.terminate();
                    }
                    showToast(R.string.chat_recording_voice_failed);
                    break;

                case CallSession.STATUS_CONNECTED:
                case CallSession.SATTUS_ICE_CONNECTED:

                    break;
                case CallSession.STATUS_IDLE:

                    if (session != null && session.callId != -1 && session.callId != callId) {
                        Log.i(TAG, "the call is terminate not from the current call");
                        return;
                    }
                    MediaManger.getInstance(IncomingCallActivity.this).stopAlarmRing();
                    String releaseReason = (String) intent.getSerializableExtra(CallApi.PARAM_SIP_REASON_TEXT);
                    Log.i(TAG, "callStatusChangedReceive releaseReason :  " + releaseReason);
                    if (!insertCallLog) {
                        if (callFrome != null && callFrome.startsWith("subusr")) {
                            if (callSession != null && callSession.type == CallSession.TYPE_VIDEO) {
                                MessagingApi.insertVoipCallLogMessage(callFrome, callFrome, SPUtil.getUserID(), 0, CallSession.TYPE_VIDEO, Conversation.SINGLE_CHAT);
                            } else {
                                MessagingApi.insertVoipCallLogMessage(callFrome, callFrome, SPUtil.getUserID(), 0, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);

                            }
                        }
                    }

                    //add miss call log.
                    saveCallLog(fromName, fromMobile, "miss", iconUrl);


                    finish();
                    break;
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sub != null) {
            sub.unsubscribe();
        }
        stopVibrate();
        rippleBackground.stopRippleAnimation();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(callStatusChangedReceiver);
        instance = null;
    }

    @Override
    public void onBackPressed() {

    }

    Subscription sub;

    private void saveCallLog(final String callName, final String callMobile, final String callType, final String iconUrl) {
        sub = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
//                         "call_from"  "call_name"  "call_endtime"  "call_duration"  "call_icon" "call_type"
                String sql = " insert into call_log (call_from, call_name, call_endtime, call_duration, call_icon,call_type) values (?,?,?,?,?,?)";
                SQLiteDatabase db = SqliteUtils.getInstance(IncomingCallActivity.this).getDb();
                if (db != null) {
                    db.beginTransaction();
                    db.execSQL(sql, new Object[]{
                            fromMobile,
                            fromName,
                            System.currentTimeMillis(),
                            "0",
                            iconUrl,
                            callType});
                    db.setTransactionSuccessful();
                    db.endTransaction();
                    subscriber.onNext("save ok!");
                } else {
                    subscriber.onNext("save error!");
                    Log.i(TAG, "db is null");
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        finish();
                        Log.i(TAG, "Call " + s);
                    }
                });
    }
}
