package com.ultralinked.uluc.enterprise.moments.adapter.viewholder;

import android.media.MediaPlayer;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.widgets.CommentListView;
import com.ultralinked.uluc.enterprise.moments.widgets.ExpandTextView;
import com.ultralinked.uluc.enterprise.moments.widgets.PraiseListView;
import com.ultralinked.uluc.enterprise.moments.widgets.SnsPopupWindow;
import com.ultralinked.uluc.enterprise.moments.widgets.videolist.model.VideoLoadMvpView;
import com.ultralinked.uluc.enterprise.moments.widgets.videolist.widget.TextureVideoView;


/**
 * Created by yiw on 2016/8/16.
 */
public abstract class FeedViewHolder extends RecyclerView.ViewHolder {

    public final static int TYPE_URL = 1;
    public final static int TYPE_IMAGE = 2;
    public final static int TYPE_VIDEO = 3;
    public final static int TYPE_GAME = 4;
    public final static int TYPE_TEXT = 5;
    public int viewType;

    public TextView timeDayTv;

    public TextView timeMonthTv;


    public FeedViewHolder(View itemView, int viewType) {
        super(itemView);
        this.viewType = viewType;

        ViewStub viewStub = (ViewStub) itemView.findViewById(R.id.viewStub);

        initSubView(viewType, viewStub);

        timeMonthTv = (TextView) itemView.findViewById(R.id.timeMonth);
        timeDayTv = (TextView) itemView.findViewById(R.id.timeDay);

    }

    public abstract void initSubView(int viewType, ViewStub viewStub);


}
