package com.ultralinked.uluc.enterprise.chat.chatim;



import java.io.IOException;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.widget.RecyclingBitmapDrawable;
import com.ultralinked.uluc.enterprise.baseui.widget.RecyclingImageView;


public class StickerAdapter extends BaseAdapter {
	private Context mContext;
	private String stickers[];
	private LayoutInflater mInflater;
	
	int size;
	public StickerAdapter(Context context ,String emotions[],int size) {
		this.mContext = context;
		this.stickers = emotions;
		this.size = size;
		this.mInflater=	 LayoutInflater.from(context); 
		initCacheConfig();
	}

	
//	public EmotionAdapter(Context context ,Bitmap emotions[]) {
//		this.mContext = context;
//		this.emotions = emotions;
//		this.mInflater=	 LayoutInflater.from(context); 
//	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return stickers.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return stickers[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		
		 ViewHolder viewHolder;
		if(convertView == null) {
	            viewHolder=new ViewHolder();
	     
				convertView=mInflater.inflate(R.layout.item_sticker_face, null);
				
	            viewHolder.iv_face=(RecyclingImageView)convertView.findViewById(R.id.sticker_item_iv_face);
	            
	            convertView.setTag(viewHolder);
	            
	        } else {
	        	
	            viewHolder=(ViewHolder)convertView.getTag();
	            
	        }

		if (stickers[position]!=null) {
			
			String stickName = "sticker/"+stickers[position];
		//	Uri uri = Uri.parse("asset:///"+stickName);
			try {
				RecyclingBitmapDrawable stiker = new RecyclingBitmapDrawable(mContext.getResources(), BitmapFactory.decodeStream(mContext.getAssets().open(stickName)));
				viewHolder.iv_face.setImageDrawable(stiker);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//	mImageFetcher.loadImage("asset:///"+stickName, viewHolder.iv_face);	
			
		}
		
		
		convertView.setTag(viewHolder);
		
		return convertView;
	}

	
	private void initCacheConfig() {
	}
	private static final String IMAGE_CACHE_DIR = "thumbs";
	public class ViewHolder{
		
		RecyclingImageView iv_face;
		
	}
	public void clearCache() {
	}
}
