package com.ultralinked.uluc.enterprise.chat.bean;

import com.ultralinked.voip.api.Message;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/8/11 0011.
 */
public class CheckedItem implements Serializable{
    private boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

}
