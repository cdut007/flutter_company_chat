package com.ultralinked.uluc.enterprise.moments.spannable;

/**
 * @author yiw
 * @Description:
 * @date 16/1/2 19:44
 */
public interface ISpanClick {
    void onClick(int position);
}
