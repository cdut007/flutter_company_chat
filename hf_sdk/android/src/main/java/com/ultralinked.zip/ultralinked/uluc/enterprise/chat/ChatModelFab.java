package com.ultralinked.uluc.enterprise.chat;

import java.util.List;

/**
 * Created by ultralinked on 2016/7/4 0004.
 */
public interface ChatModelFab {

    void updateConversations(List<com.ultralinked.voip.api.Conversation> conversations);

    void updateUnreadCount(int conversationsUnreadCount);
}
