package com.ultralinked.uluc.enterprise.contacts.ui.pendinglist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.AddNewContactActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactLocalBook;
import com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact.FragmentAddContactMannual;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;

public class PendingInviteListActicity extends BaseActivity implements FragmentPendingInviteList.OnContactsInteractionListener {


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_pending_contact;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (savedInstanceState != null) {

        } else {

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();


            transaction.replace(R.id.container,new FragmentPendingInviteList(), "pendingInvite").commit();

        }
    }

    @Override
    public void onContactSelected(PeopleEntity entity) {
        if (entity!=null){
            if ("accept".equals(entity.status)){
                Log.i(TAG,"entity.subuser_id==="+entity.subuser_id);
                PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(entity.subuser_id);
                if (peopleEntity!=null){

                    DetailPersonActivity.gotoDetailPersonActivity(getActivity(), peopleEntity);
                }
                return;
            }
            Intent intent = new Intent(getActivity(), AddNewContactActicity.class);
            intent.putExtra("chooseType", ChoicePopWindow.CHOOSE_INTERNAL);
            intent.putExtra("inputType", ChoicePopWindow.INPUTTYPE_INVITE_EXIST);
            intent.putExtra(FragmentAddContactMannual.ARG_ENTITY,entity);
            startActivity(intent);
        }

    }

    @Override
    public void onSelectionCleared() {

    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
