package com.ultralinked.uluc.enterprise.contacts.contract;

import android.net.Uri;

/**
 * Created by ultralinked on 16/6/30.
 */
public interface BaseContract {

    String CONTENT_AUTHORITY = "com.ultralinked.uluc.enterprise.contacts";

    Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);
}
