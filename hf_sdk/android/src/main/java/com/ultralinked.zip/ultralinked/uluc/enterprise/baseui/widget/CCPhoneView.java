package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseTextWatcher;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Created by lly on 2016/9/20.
 */
public class CCPhoneView extends FrameLayout implements View.OnClickListener,View.OnLongClickListener{

    /*回调接口，提供相关控件事件的处理*/
    public interface OnEventListener{
        void onCountryCodeTouch(String code);
        boolean onInputNumberTouch(MotionEvent event);
        void onCountryCodeTextChanged(Editable s);
        void onInputNumberTextChanged(Editable s);
    }
    public void setOnEventListener(final OnEventListener onEventListener){
        mCountryCode.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onEventListener.onCountryCodeTouch(mCountryCode.getText().toString());
            }
        });
        mCountryName.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onEventListener.onCountryCodeTouch(mCountryCode.getText().toString());
            }
        });
        mCountryCode.addTextChangedListener(new BaseTextWatcher(){
            @Override
            public void afterTextChanged(Editable s) {
                onEventListener.onCountryCodeTextChanged(s);
            }
        });
        mInputNumber.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return onEventListener.onInputNumberTouch(event);
            }
        });
        mInputNumber.addTextChangedListener(new BaseTextWatcher(){
            @Override
            public void afterTextChanged(Editable s) {
                onEventListener.onInputNumberTextChanged(s);
            }
        });
        mCountryCode.setText(getStringWithPlus(SPUtil.getCode()));

    }


    EditText  mInputNumber;
    ImageView mDeleteNumber;
    TextView mCountryName;
    TextView mCountryCode;
    boolean canChangeCode = false;
    Context context;

    public CCPhoneView(Context context) {
        this(context, null);
    }

    public CCPhoneView(final Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context =context;
        View view = LayoutInflater.from(context).inflate(R.layout.cc_phone_view, this);
        mCountryCode = (TextView) view.findViewById(R.id.country_code);
        mInputNumber = (EditText) view.findViewById(R.id.input_number);
        mCountryName = (TextView) view.findViewById(R.id.country_name);
        mDeleteNumber = (ImageView) view.findViewById(R.id.image_delete_number);
        ImageUtils.buttonEffect(mDeleteNumber);
        cancelSoftInput(mCountryCode);
        cancelSoftInput(mInputNumber);
        mInputNumber.requestFocus();
        mDeleteNumber.setOnClickListener(this);
        mDeleteNumber.setOnLongClickListener(this);
    }

    @Override
    public void onClick(View v) {
        delete();
    }

    @Override
    public boolean onLongClick(View v) {
        mInputNumber.setText("");
        return true;
    }


    public void add(String tag) {
        if (mCountryCode.getText().length() < 5 && canChangeCode) {
            CharSequence countryCode = mCountryCode.getText();
            mCountryCode.setText(countryCode + tag);
        } else {
            Editable inputNumber = mInputNumber.getText();
            inputNumber.insert(mInputNumber.getSelectionStart(), tag);
        }
    }

    public void delete() {
        if (mInputNumber.getText().length() > 0) {
            int cursor = mInputNumber.getSelectionStart();
            Editable inputNumber = mInputNumber.getText();
            if (cursor != 0) {
                inputNumber.delete(cursor - 1, cursor);
            } else {
                inputNumber.delete(mInputNumber.getText().length() - 1, mInputNumber.getText().length());
            }
        } else {
            if (mCountryCode.getText().length() > 1) {
                CharSequence countryCode = mCountryCode.getText();
                int length = mCountryCode.getText().length();
                mCountryCode.setText(countryCode.subSequence(0,length-1));
            }
        }
    }

    public void setCode(String code) {
        mCountryCode.setText(code);
        canChangeCode = false;
    }


    public void setCodeAndName(String code, String name) {
        mCountryCode.setText(code);

        mCountryName.setText(name);
        canChangeCode = false;
    }

    public void setCountryName(String name){
        if(TextUtils.isEmpty(name)){
            canChangeCode = true;
            mCountryName.setText(context.getString(R.string.unknown));
        }else{
            canChangeCode = false;
            mCountryName.setText(name);
        }
    }

    public void setInputNumber(String number){
        mInputNumber.setText(number);
        mInputNumber.setSelection(number.length());
    }

    public String getStringWithPlus(String code) {
        return "+" + code;
    }

    public String getMobile() {
        return mCountryCode.getText().toString() + mInputNumber.getText().toString();
    }

    /*取消EditText的输入法弹出框*/
    private void cancelSoftInput(TextView view) {
        if (android.os.Build.VERSION.SDK_INT <= 10) {//4.0以下 danielinbiti
            view.setInputType(InputType.TYPE_NULL);
        } else {
           /*
            *getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            * 或者在manifest里面配置android:windowSoftInputMode="stateAlwaysHidden".
            * */
            try {
                Class<EditText> cls = EditText.class;
                Method setShowSoftInputOnFocus;
                setShowSoftInputOnFocus = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
                setShowSoftInputOnFocus.setAccessible(true);
                setShowSoftInputOnFocus.invoke(view, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
