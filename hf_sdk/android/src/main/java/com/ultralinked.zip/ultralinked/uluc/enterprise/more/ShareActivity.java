package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/6.
 */

public class ShareActivity extends BaseActivity implements View.OnClickListener {

    String invitation_url = "";

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_share;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        initListener(this, R.id.left_back, R.id.btn_share);
    }

    @Override
    protected void setTopBar() {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.rewarding_share);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.btn_share:
                getInvitationUrl();
                break;
        }
    }

    private void getInvitationUrl() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getInvitationUrl()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "get invitation url success: " + invitation_url);
                        closeDialog();
                        if (!TextUtils.isEmpty(invitation_url)) {
                            ShareUtils.tellFriend(ShareActivity.this, invitation_url);
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "get invitation url fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            JSONObject response = new JSONObject(responseBody.string());
                            if (response.optInt("code") == 200) {
                                invitation_url = response.optString("invitation_url");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }


}
