package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

/**
 * Created by ultralinked on 16/7/19.
 */
public class InviteContactAdapter extends CursorAdapter implements SectionIndexer {

    private static final String TAG = "InviteContactAdapter";

    private final LayoutInflater mInflater;

    public InviteContactAdapter(Context context,NewFriendAdapter.OnFriendClickListener friendClickListener) {

        super(context, null /* cursor */, false /* autoRequery */);

        mInflater = LayoutInflater.from(context);
        this.requestFriendListener = friendClickListener;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = mInflater.inflate(R.layout.item_invite_contact, parent, false);
        view.setTag(new ViewHolder(view));
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        ViewHolder holder = (ViewHolder) view.getTag();
        int bindPosition = cursor.getPosition();
        holder.position = bindPosition;

        String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
        holder.title.setText(name);

        String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
        holder.description.setText(phone);

        String photoThubnailUri = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI));

        int defaultId =  ImageUtils.getDefaultContactImageResource(phone);
        ImageUtils.loadCircleImage(context, holder.image, photoThubnailUri, defaultId);

        PeopleEntity peopleEntity = new PeopleEntity();
        peopleEntity.status="new";
        peopleEntity.name = name;
        peopleEntity.nickname = name;
        peopleEntity.mobile = phone;
        holder.inviteBtn.setTag(peopleEntity);

        holder.inviteBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PeopleEntity entity = (PeopleEntity) v.getTag();
                if(!"new".equals(entity.status))
                {
                    return;
                }
                requestFriendListener.callFriendRequest(entity.status,entity);

            }
        });


    }


    NewFriendAdapter.OnFriendClickListener requestFriendListener;

    private static class ViewHolder {
        public final ImageView image;
        public final TextView title;
        public final TextView description;
        public final TextView inviteBtn;
        int position;

        public ViewHolder(View v) {
            image = (ImageView) v.findViewById(R.id.image);
            title = (TextView) v.findViewById(R.id.title);
            description = (TextView) v.findViewById(R.id.description);
            inviteBtn = (TextView) v.findViewById(R.id.txt_invite);
        }

    }


    @Override
    public Object[] getSections() {
        return null;
    }

    @Override
    public int getPositionForSection(int section) {

        return 0;
    }


    @Override
    public int getSectionForPosition(int position) {
        return 0;
    }


}
