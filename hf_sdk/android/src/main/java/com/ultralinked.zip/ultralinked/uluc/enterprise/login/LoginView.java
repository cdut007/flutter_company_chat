package com.ultralinked.uluc.enterprise.login;

/**
 * Created by ultralinked on 2016/6/8 0008.
 *
 * this seems to be Login callback
 */
public interface LoginView {

    void loginSuccess();

    void loginError(String error);

    void showDialog();

    void hideDialog();

}
