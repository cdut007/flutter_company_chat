package com.ultralinked.uluc.enterprise.chat.chatim;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.call.CallModel;
import com.ultralinked.uluc.enterprise.chat.viewpagerindicator.IconPagerAdapter;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;

public class ChatBottomMenuPagerAdapter extends PagerAdapter implements
		IconPagerAdapter {
	private static final String TAG = "ChatBottomMenuPagerApapter";
	public static final int pageCount = 21,stickerPageCount = 8;
	private Context mContext;
	private List<View> viewList;
	private final OnChildItemSelectId alertDo;
	private final OnGroupItemSelected itemSelected;
	private ArrayList<String> menuItems;
	private ArrayList<Integer> resourceID;
	private View menuLayout = null;
	private int conversationType = Conversation.SINGLE_CHAT;

	public static final int  IMAGE=R.mipmap.chat_gallery;
	public static final int  VIDEO=R.mipmap.chat_camera;
	public static final int  VCARD=R.mipmap.chat_contacts;
	public static final int  LOCATION=R.mipmap.chat_location;
	public static final int  FILE=R.mipmap.chat_file;
	//public static final int  CALL=R.mipmap.btn_chat_call_state;
    public static final int  VOICE_CALL=R.mipmap.chat_voice_call;
    public static final int  VIDEO_CALL=R.mipmap.chat_video_call;
    public static final int  CALLBACK_CALL=R.mipmap.chat_other_call;

	public static final int  IP2_PHONE_CALL=0x1024;
	//public static final int  IP2Phone_CALL=R.mipmap.chat_sound_call;



	public ChatBottomMenuPagerAdapter(Context ctx, int conversationType,
									  OnChildItemSelectId childItemId, OnGroupItemSelected itemSelected,
			CallModel callType) {
		this.mContext = ctx;
		viewList = new ArrayList<View>();
		this.alertDo = childItemId;
		this.itemSelected = itemSelected;
		this.conversationType = conversationType;
		this.mode = callType;

		/*init the menu resource.*/
		menuItems = new ArrayList<String>();
		menuItems.add(mContext.getString(R.string._gallery));
		menuItems.add(mContext.getString(R.string.camera));
		menuItems.add(mContext.getString(R.string.contact_card));
		menuItems.add(mContext.getString(R.string.file));
		menuItems.add(mContext.getString(R.string.location));

		resourceID = new ArrayList<Integer>();
		resourceID.add(IMAGE);
		resourceID.add(VIDEO);
		resourceID.add(VCARD);
		resourceID.add(FILE);
		resourceID.add(LOCATION);
		/*end init the menu resource.*/

        if (conversationType == Conversation.SINGLE_CHAT){

            menuItems.add(mContext.getString(R.string.ip_to_ip));
            menuItems.add(mContext.getString(R.string.ip_to_ip_video));
            menuItems.add(mContext.getString(R.string.other_call));


            resourceID.add(VOICE_CALL);
            resourceID.add(VIDEO_CALL);
            resourceID.add(CALLBACK_CALL);

			//resourceID.add(IP2Phone_CALL);

        }

		loadMenuLayout();

	}

	public void releaseResource() {
		// TODO Auto-generated method stub
	//	mContext.unregisterReceiver(receiver);

	}

	private CallModel mode = new CallModel();

	public interface OnChildItemSelectId {
		void onClick(int whichButton, int resourceType, int page, String resDesc);
	}

	public interface OnGroupItemSelected {
		void onClick(int whichButton);
	}


	MenuAdapter menuAdapter;

	// bottom main menu.
	public void loadMenuLayout() {
		viewList.clear();
		if (menuLayout == null) {
			LayoutInflater inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			menuLayout = inflater.inflate(
					R.layout.chat_im_bottom_menu, null);
			GridView menu = (GridView) menuLayout
					.findViewById(R.id.chat_menu);


			menu.setAdapter(menuAdapter = new MenuAdapter(resourceID));
			menu.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// if (position == 0)
					// switchTo(position);
					int itemClcikId =resourceID.get(position);

					itemSelected.onClick(itemClcikId);
				}
			});
		}
		viewList.add(menuLayout);
	}

	public void changeMenuItemState(int idle) {
		// TODO Auto-generated method stub
//		mode.callType = idle;
//		if (menuAdapter != null) {
//			menuAdapter.changeResourceID(idle, conversationType, resourceids);// setback
//
//		}
	}



	class MenuAdapter extends BaseAdapter {
		ArrayList<Integer> resourcesIds;

		public MenuAdapter(ArrayList<Integer> map) {
			resourcesIds = map;
		}

		public void changeResourceID(int modeType, int conversationType, ArrayList<Integer> resourceids) {

			resourcesIds = resourceids;
			notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return menuItems.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return menuItems.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				holder = new ViewHolder();
				LayoutInflater inflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(
						R.layout.chat_im_bottom_menu_item, null);
				holder.menuItem = (TextView) convertView
						.findViewById(R.id.chat_bottom_menu_item_text);
				holder.menuImage = (ImageView) convertView
						.findViewById(R.id.chat_bottom_menu_item_image);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			holder.menuItem.setText(menuItems.get(position));
			holder.menuImage.setImageResource(resourcesIds.get(position));
			//add press
			ImageUtils.buttonEffect(holder.menuItem);
			ImageUtils.buttonEffect(holder.menuImage);
			return convertView;
		}
	}

	static class ViewHolder {
		public TextView menuItem;
		public ImageView menuImage;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		// page count
		return viewList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		// TODO Auto-generated method stub
		return arg0 == arg1;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		try {
			container.removeView(viewList.get(position));
		} catch (Exception e) {
			Log.i(TAG, "current page count is less then previous count");
		}
	}

	@Override
	public int getItemPosition(Object object) {

		return super.getItemPosition(object);
	}

	@Override
	public CharSequence getPageTitle(int position) {

		return super.getPageTitle(position);
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		container.addView(viewList.get(position));

		return viewList.get(position);
	}

	@Override
	public int getIconResId(int index) {
		// TODO Auto-generated method stub
		return R.drawable.dot_state;
	}



}
