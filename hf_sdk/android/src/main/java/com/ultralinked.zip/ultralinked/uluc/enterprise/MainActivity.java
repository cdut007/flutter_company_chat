package com.ultralinked.uluc.enterprise;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.tencent.bugly.crashreport.CrashReport;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.BottomMainTableLinearLayout;
import com.ultralinked.uluc.enterprise.call.CallFragment;
import com.ultralinked.uluc.enterprise.call.IncallActivity;
import com.ultralinked.uluc.enterprise.call.IncomingCallActivity;
import com.ultralinked.uluc.enterprise.call.VideoCallActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.pendinglist.FragmentPendingInviteList;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.chat.ChatListFragment;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.login.LoginView;
import com.ultralinked.uluc.enterprise.more.FragmentMore;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.google.gson.JsonSyntaxException;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.CallSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.bingoogolapple.badgeview.BGABadgeView;
import me.leolin.shortcutbadger.ShortcutBadger;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


public class MainActivity extends BaseActivity implements View.OnClickListener {

    ImageView tabs[];
    TextView tabstv[];
    ViewPager viewPager;
    SparseArray<Fragment> fragments;
    Subscription subscribe;
    public static MainActivity instance;
    private static final String TAG = "MainActivity";

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_main;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        super.onCreate(savedInstanceState);

        //清除所有通知消息
        App.getInstance().cancelAllNotificaiton();

        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);

        if (CallApi.getCurrentCallId() != -1) {
            CallSession callSession = CallApi.getCallSessionById(CallApi.getCurrentCallId());
            if (callSession != null) {
                if ((callSession.callState == CallSession.STATUS_CONNECTED || callSession.callState == CallSession.SATTUS_ICE_CONNECTED)) {

                    if (callSession.isIncomingCall && !callSession.isAccepted) {
                        IncomingCallActivity.lunchIncoming(this, callSession.callId);
                    } else {
                        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(callSession.callFrom);
                        if (peopleEntity == null) {

                            return;
                        }

                        if (callSession.type == CallSession.TYPE_VIDEO) {
                            VideoCallActivity.launch(this, callSession.callFrom, true);
                        } else {
                            IncallActivity.lunch(this, peopleEntity.mobile, peopleEntity.name, peopleEntity.icon_url, true, callSession.type);
                        }
                    }

                } else {

                    IncomingCallActivity.lunchIncoming(this, callSession.callId);
                }
            }
        }

        instance = this;
        checkUserLogin();
        initObservers();
        getContactInfos();

        if (getIntent().getBooleanExtra("login", false)) {
            if (!TextUtils.isEmpty(SPUtil.getUserID())) {
                CrashReport.setUserId(SPUtil.getUserID());
            }
            MessageUtils.insertWelcomeTips();
        } else {
            // AsistantService.getInstance().checkPushAsistantMsg();
        }


        if (getIntent().getBooleanExtra("register", false)) {
            if (!TextUtils.isEmpty(SPUtil.getUserID())) {
                CrashReport.setUserId(SPUtil.getUserID());
            }
            MessageUtils.insertWelcomeTips();

        }

        checkInvokeCallPage(getIntent());

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG,"main activity onNewIntent");
        checkInvokeCallPage(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (viewPager.getCurrentItem() == 2){
            checkInvokeCallPage(getIntent());
        }
    }

    private void checkInvokeCallPage(Intent intent) {
        if (intent.getBooleanExtra("dial", false)) {
            viewPager.setCurrentItem(2, false);
             CallFragment callFragment = getFragmentCalls();
            if (callFragment!=null){
                Log.i(TAG,"show keypad");
                callFragment.showKeypad();
            }
            //RxBus.getDefault().post(true);//display keypad.

        }
    }


    private void checkUserLogin() {

        App.grLogin(true);
        //refresh token when app killed.
        //  if (UpgrdeInfo.isNewVersion()) {
        LoginView loginView = new LoginView() {
            @Override
            public void loginSuccess() {

                Log.i(TAG, "refresh token config success.");

            }

            @Override
            public void loginError(String error) {
                Log.e(TAG, error);
            }

            @Override
            public void showDialog() {
            }

            @Override
            public void hideDialog() {
            }
        };
        LoginPresenter loginPresenter = new LoginPresenter(loginView, this);
        loginPresenter.onlyRefreshSettings = true;
        loginPresenter.refreshTokenConfig();
        //   }

    }


    public void getContactInfos() {
        getDepartment();
        getFriend();
        //for pendingList.only for admin later.
        //getPendingList();
    }

    private Subscription rxContactreFreshSubscription;

    private void initObservers() {
        rxContactreFreshSubscription = RxBus.getDefault().toObservable(PeopleEntity.class)
                .subscribe(new Action1<PeopleEntity>() {
                               @Override
                               public void call(PeopleEntity peopleEntity) {
                                   Log.i(TAG, "update the ContactreFreshSubscription~~~~");
                                   getUser();

                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG, "update the subscribe error:" + android.util.Log.getStackTraceString(throwable));
                            }
                        });
    }


    BottomMainTableLinearLayout bottomMainTableLinearLayout;

    @Override
    public void initView(Bundle savedInstanceState) {
        tabs = new ImageView[]{
                bind(R.id.tab1),
                bind(R.id.tab2),
                bind(R.id.tab3),
                bind(R.id.tab4)
        };
        tabstv = new TextView[]{
                bind(R.id.tabtv1),
                bind(R.id.tabtv2),
                bind(R.id.tabtv3),
                bind(R.id.tabtv4)
        };
        initListener(this, R.id.mainTab1, R.id.mainTab2, R.id.mainTab3, R.id.mainTab4);
        tabs[0].setSelected(true);
        viewPager = bind(R.id.viewPager);
        fragments = new SparseArray<>();
        fragments.put(0, new ChatListFragment());
        fragments.put(1, new FragmentContacts());
        fragments.put(2, new CallFragment());
        fragments.put(3, new FragmentMore());

        initViewPager();

    }

    private void initViewPager() {
        viewPager.setOffscreenPageLimit(4);
        viewPager.setCurrentItem(0);
        tabstv[0].setSelected(true);
        viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return fragments.size();
            }

            @Override
            public Parcelable saveState() {
                return super.saveState();
            }

            @Override
            public void restoreState(Parcelable state, ClassLoader loader) {
                super.restoreState(state, loader);
            }


        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                Log.i(TAG, "onPageSelected(int position)" + position);
                for (int i = 0; i < tabs.length; i++) {
                    BaseFragment fragment = getFragment(i);
                    if (i != position) {
                        tabs[i].setSelected(false);
                        tabstv[i].setSelected(false);
                        if (fragment != null) {
                            fragment.onHidden(true);
                        }
                    } else {
                        tabs[i].setSelected(true);
                        tabstv[i].setSelected(true);
                        if (fragment != null) {
                            fragment.onHidden(false);
                        }
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        bottomMainTableLinearLayout = bind(R.id.bottom_menu);
        bottomMainTableLinearLayout.setViewPager(viewPager, tabs, tabstv);

    }


    public boolean currentIsChatListResumed() {
        int itemPos = viewPager.getCurrentItem();
        if (itemPos == 0) {
            return resumed;
        }

        return false;
    }

    public boolean currentIsPrivateContact() {

        FragmentMore fragmentMore = getFragmentMore();
        if (fragmentMore != null) {
            return fragmentMore.isPrivateModel();
        }

        return false;
    }

    private BaseFragment getFragment(int index) {
        Fragment fragment = fragments.get(index);
        if (fragment != null) {
            return (BaseFragment) fragment;
        }
        return null;
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        CallFragment callFragment = getFragmentCalls();
        if (callFragment != null) {
            callFragment.onWindowFocusChanged(hasFocus);
        }

    }


    @Override
    public void onBackPressed() {

        CallFragment callFragment = getFragmentCalls();
        if (callFragment != null) {
            boolean onback = callFragment.onBackPressed();
            if (!onback) {
                // exitApp();
                // super.onBackPressed();
                moveTaskToBack(true);
            }

        } else {
            //  exitApp();
            //super.onBackPressed();
            moveTaskToBack(true);
        }

    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {

        View view = getCurrentFocus();
        if (view != null && (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_MOVE) && view instanceof EditText && !view.getClass().getName().startsWith("android.webkit.")) {
            int scrcoords[] = new int[2];
            view.getLocationOnScreen(scrcoords);
            float x = ev.getRawX() + view.getLeft() - scrcoords[0];
            float y = ev.getRawY() + view.getTop() - scrcoords[1];
            if (x < view.getLeft() || x > view.getRight() || y < view.getTop() || y > view.getBottom())
                ((InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow((this.getWindow().getDecorView().getApplicationWindowToken()), 0);
        }

//        CallFragment callFragment = (CallFragment) getFragmentCalls();
//        if (callFragment != null && (ev.getAction() == MotionEvent.ACTION_MOVE || ev.getAction() == MotionEvent.ACTION_DOWN)) {
//            boolean dispatchToutch = callFragment.dispatchTouchEvent(ev);
//            if (dispatchToutch) {
//                return super.dispatchTouchEvent(ev);
//                //return false;
//            }
//        }

        return super.dispatchTouchEvent(ev);
    }


    private FragmentMore getFragmentMore() {
        int itemPos = viewPager.getCurrentItem();
        if (itemPos == 3 && fragments.get(3) instanceof FragmentMore) {
            FragmentMore fragmentMore = (FragmentMore) fragments.get(3);
            return fragmentMore;
        }

        return null;
    }


    private CallFragment getFragmentCalls() {
        int itemPos = viewPager.getCurrentItem();
        if (itemPos == 2 && fragments.get(2) instanceof CallFragment) {
            CallFragment fragmentCalls = (CallFragment) fragments.get(2);
            return fragmentCalls;
        }

        return null;
    }

    private FragmentContacts getFragmentContacts() {
        int itemPos = viewPager.getCurrentItem();
        if (itemPos == 1 && fragments.get(1) instanceof FragmentContacts) {
            FragmentContacts fragmentContacts = (FragmentContacts) fragments.get(1);
            return fragmentContacts;
        }

        return null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mainTab1:
                viewPager.setCurrentItem(0, false);
                break;
            case R.id.mainTab2:
              //  RxBus.getDefault().post(viewPager.getCurrentItem() != 1);
                viewPager.setCurrentItem(1, false);
                break;
            case R.id.mainTab3:
                viewPager.setCurrentItem(2, false);
                break;
            case R.id.mainTab4:
                viewPager.setCurrentItem(3, false);
                break;
        }
    }

    @Override
    protected void onDestroy() {
        instance = null;
        unregisterObservers();
        super.onDestroy();
    }

    private void unregisterObservers() {
        if (rxContactreFreshSubscription != null && !rxContactreFreshSubscription.isUnsubscribed()) {
            rxContactreFreshSubscription.unsubscribe();
        }

        if (subscribe != null && !subscribe.isUnsubscribed())
            subscribe.unsubscribe();
    }

    /**
     * rx get department structure , save as json string
     */
    public void getDepartment() {
        ApiManager.getInstance().getDepart(false)
                .compose(this.<ResponseBody>bindToLifecycle())

//                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .subscribeOn(Schedulers.io())
                .throttleFirst(3, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        String httpError = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, httpError);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String rs = "";

                        try {
                            rs = responseBody.string();
                            DepartUtils.getInstance().save_DEPARMENT_COMPANY_JSON_STRING(rs);

                            List companys = DepartUtils.getInstance().getCompanyMap();
                            if (companys.size() > 0) {
                                if (!SPUtil.getUserHasCompany()) {
                                    SPUtil.saveUserHasCompany(true);
                                    RxBus.getDefault().post("change company state");
                                }
                            } else {
                                if (SPUtil.getUserHasCompany()) {
                                    SPUtil.saveUserHasCompany(false);
                                    RxBus.getDefault().post("change company state");
                                }
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        getUser();
                        getPrivate();
                        android.util.Log.i(TAG, "rs == " + rs);

                    }
                });
    }


    public void getFriend() {//refresh the friend list  when someone invite or reject accept.

        ApiManager.getInstance().getFriends()
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getFriendsComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "getFriends error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            Save2MutliProvider.save_FRIEND(rs);

                        } catch (Exception e) {
                            Log.e(TAG, "Exception " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "getFriends  " + rs);
                    }        //请求成功

                });
    }

    public void getUser() {
        ApiManager.getInstance().getUsers()
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getUserComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "getuser error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            Save2MutliProvider.save_Personnel_Relation(rs);

                        } catch (JsonSyntaxException e) {
                            Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            Log.e(TAG, "IOException " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "getuser  " + rs);
                    }        //请求成功

                });
    }

    public void getPrivate() {

        ApiManager.getInstance().getPrivate()
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                //三秒执行一次
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getPrivateComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "getPrivate error " + eMsg);

                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            Save2MutliProvider.save_PRIVATE(rs);

                        } catch (IOException e) {
                            Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            Log.e(TAG, "JSONException " + e.getMessage());
                        }
                        android.util.Log.i(TAG, "getPrivate  " + rs);
                    }           //请求成功

                });
    }

    //getPendingList ,maybe remove lator.

    public void getPendingList() {

        ApiManager.getInstance().getPendingList()
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getPendingListComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "get pending invite  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<PeopleEntity>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                List<PeopleEntity> pendingList = gson.fromJson(result, sToken);
                                if (pendingList != null) {
                                    FragmentPendingInviteList.mInviteList = pendingList;
                                    FragmentContacts fragmentContacts = getFragmentContacts();
                                    if (fragmentContacts != null) {
                                        fragmentContacts.updateBadge();
                                    }
                                }


                            }


                        } catch (JsonSyntaxException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "get pending invite userInfo:  " + rs);
                    }           //请求成功

                });
    }


    long time;

    private void exitApp() {
        if (System.currentTimeMillis() - time < 3000) {
            finish();
        } else {
            time = System.currentTimeMillis();
            showToast(R.string.press_back_exit_app_info);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                time = 0;
            }
        }, 3000);
    }




    public  int getPrivateUnreadMessageCount(){
        try{
            if (chatBadgeView!=null){

               int  currentCount = Integer.parseInt((String) chatBadgeView.getTag());
               int unread= MessageUtils.getAllPrivateUnreadMessageCount(currentCount);
                return  unread;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    BGABadgeView chatBadgeView,meBadgeView;

    public void updateMeBadge(boolean show) {

        meBadgeView = bind(R.id.me_badge);

        if (show) {
            meBadgeView.showCirclePointBadge();
        } else {
            meBadgeView.hiddenBadge();
        }

    }


    public void updateUnreadMessageCount(int count, int flag) {
        //chat
        chatBadgeView = bind(R.id.chat_badge);
        // FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) chatBadgeView.getLayoutParams();
        int currentCount = 0;

        if (chatBadgeView.getTag() != null) {
            currentCount = Integer.parseInt((String) chatBadgeView.getTag());
            if (currentCount < 0) {
                currentCount = 0;
            }
        }

        if (flag == ChatModule.Add_New_Counts) {

        } else if (flag == ChatModule.Decrease_Message_Counts) {
            count = currentCount - count;

        } else if (flag == ChatModule.Increase_New_Counts) {
            count = count + currentCount;

        }

        chatBadgeView.setTag("" + count);
        chatBadgeView.getBadgeViewHelper().setDragable(false);

        if (count < 0) {
            count = 0;
        }

        ShortcutBadger.applyCount(this, count);

        if (count > 0) {

            if (count > 99) {
                chatBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(4);
                chatBadgeView.showTextBadge("99+");
            } else if (count >= 10) {
                chatBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(4);
                chatBadgeView.showTextBadge("" + count);
            } else {
                chatBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(8);
                chatBadgeView.showTextBadge("" + count);
            }

        } else {
            chatBadgeView.hiddenBadge();
        }

    }
}
