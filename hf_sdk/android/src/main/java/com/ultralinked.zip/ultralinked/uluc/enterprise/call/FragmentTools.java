package com.ultralinked.uluc.enterprise.call;


import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bigkoo.convenientbanner.ConvenientBanner;
import com.bigkoo.convenientbanner.holder.CBViewHolderCreator;
import com.bigkoo.convenientbanner.holder.Holder;
import com.bigkoo.convenientbanner.listener.OnItemClickListener;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.ArrayList;
import java.util.List;


public class FragmentTools extends BaseFragment {

    public static final String KEY_DETAIL = "detail";
    public static final String KEY_COMPANY_NAME = "company_name";
    BaseActivity activity;
    LinearLayout manageBtn;
    TextView mCompanyName;
    private PieChart mChart;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (BaseActivity) context;
    }

    ConvenientBanner convenientBanner;

    @Override
    public void onResume() {
        super.onResume();
        //开始自动翻页
        convenientBanner.startTurning(3000);
    }
    @Override
    public void onPause() {
        super.onPause();
        //停止翻页
        convenientBanner.stopTurning();
    }

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_tools;
    }


   static List<String> logosUrls = new ArrayList<>();
    static {
//        logosUrls.add("http://www.shpeiner.com/upload/2016618105550.jpg");
//        logosUrls.add("http://www.shpeiner.com/upload/2016618105838.jpg");
//        logosUrls.add("http://www.shpeiner.com/upload/2016618105148.jpg");
//        logosUrls.add("http://www.shpeiner.com/upload/2016618105819.jpg");
        logosUrls.add("android.resource://"+ App.getInstance().getPackageName()+"/drawable/"+R.drawable.banner);
        logosUrls.add("android.resource://"+ App.getInstance().getPackageName()+"/drawable/"+R.drawable.banner2);
        logosUrls.add("android.resource://"+ App.getInstance().getPackageName()+"/drawable/"+R.drawable.banner3);
    }


    private void setData(int count) {

        // 准备x"轴"数据：在i的位置，显示x[i]字符串
        //ArrayList<String> xVals = new ArrayList<String>();

        // 真实的饼状图百分比分区。
        // Entry包含两个重要数据内容：position和该position的数值。
        ArrayList<PieEntry> yVals = new ArrayList<PieEntry>();

//        for (int xi = 0; xi < count; xi++) {
//            xVals.add("Quarterly" + (xi + 1));  //饼块上显示成
//
//
//        }

        // 饼图数据
        /**
         * 将一个饼形图分成四部分， 四部分的数值比例为14:14:34:38
         * 所以 14代表的百分比就是14%
         */
        float quarterly1 = 28;
        float quarterly2 = 34;
        float quarterly3 = 38;

        yVals.add(new PieEntry(quarterly1, 1));
        yVals.add(new PieEntry(quarterly2, 2));
        yVals.add(new PieEntry(quarterly3, 3));

        //  xVals,yDataSet
        PieDataSet yDataSet = new PieDataSet(yVals, "Quarterly");
        yDataSet.setSliceSpace(0f); //设置个饼状图之间的距离
        // 每个百分比占区块绘制的不同颜色
        ArrayList<Integer> colors = new ArrayList<Integer>();
        colors.add(Color.rgb(0xfe,0xd1,0x91));
        colors.add(Color.rgb(0x90,0xeb,0xfe));
        colors.add(Color.rgb(0xf3,0x89,0x97));
        yDataSet.setColors(colors);

        // 将x轴和y轴设置给PieData作为数据源

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        float px = 5 * (metrics.densityDpi / 160f);
        yDataSet.setSelectionShift(px);

        PieData data = new PieData(yDataSet);


        // 设置成PercentFormatter将追加%号
        data.setValueFormatter(new PercentFormatter());

        // 文字的颜色
        data.setValueTextColor(Color.WHITE);
        //data.setv

        // 最终将全部完整的数据喂给PieChart
       // mChart.setHoleColorTransparent(true);

        mChart.setHoleRadius(60f);  //半径
        mChart.setTransparentCircleRadius(64f); // 半透明圈
        //pieChart.setHoleRadius(0)  //实心圆

        mChart.setDescription(getArguments().getString(KEY_COMPANY_NAME));

        // mChart.setDrawYValues(true);
        mChart.setDrawCenterText(false);  //饼状图中间可以添加文字

        mChart.setDrawHoleEnabled(true);


        mChart.setRotationAngle(90); // 初始旋转角度
        mChart.setData(data);
        mChart.invalidate();
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });
        TextView titleCenter = bind(R.id.titleCenter);
        titleCenter.setText(R.string.company_detail);
        mCompanyName = bind(R.id.text_company_name);
        mChart = bind(R.id.chart);
       // mChart.setDescription("by Zhang Phil @ http://blog.csdn.net/zhangphil");
        String[] x = new String[] { "A类事物", "B类事物", "C类事物" };
        setData(x.length);

        manageBtn=bind(R.id.manage_btn);
        convenientBanner  = bind(R.id.convenientBanner);
        manageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // lunchActivity(CallActivity.class);
                MobileBrowserActivity.actionStart(getActivity(), SPUtil.getWebManagerUrl(),mCompanyName.getText().toString());
            }
        });

        String companyName = "";
        if (savedInstanceState==null){
            companyName = getArguments().getString(KEY_COMPANY_NAME);
        }

        if (TextUtils.isEmpty(companyName)){
            companyName = CompanySelector.getInstance(activity).getCompanyName();
        }

        mCompanyName.setText(TextUtils.isEmpty(companyName)?"":FragmentContacts.firstLetterToUpper(companyName));

        //自定义你的Holder，实现更多复杂的界面，不一定是图片翻页，其他任何控件翻页亦可。
        convenientBanner.setPages(
                new CBViewHolderCreator<LocalImageHolderView>() {
                    @Override
                    public LocalImageHolderView createHolder() {
                        return new LocalImageHolderView();
                    }
                }, logosUrls)
                //设置两个点图片作为翻页指示器，不设置则没有指示器，可以根据自己需求自行配合自己的指示器,不需要圆点指示器可用不设
                .setPageIndicator(new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused})
                //设置指示器的方向
                .setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.ALIGN_PARENT_RIGHT);

        convenientBanner.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

                MobileBrowserActivity.actionStart(getActivity(),MobileBrowserActivity.SHPEINER_URL,mCompanyName.getText().toString());
            }
        });
        //设置翻页的效果，不需要翻页效果可用不设
        //.setPageTransformer(Transformer.DefaultTransformer); 集成特效之后会有白屏现象，新版已经分离，如果要集成特效的例子可以看Demo的点击响应。
//        convenientBanner.setManualPageable(false);//设置不能手动影响

    }



    public class LocalImageHolderView implements Holder<String> {
        private ImageView imageView;
        @Override
        public View createView(Context context) {
            imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return imageView;
        }

        @Override
        public void UpdateUI(Context context, final int position, String url) {
            ImageUtils.loadImageByString(mContext, imageView,url,R.mipmap.no_pic, R.mipmap.no_pic);

        }
    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
        if (mCompanyName!=null){
            String companyName = CompanySelector.getInstance(activity).getCompanyName();
            mCompanyName.setText(TextUtils.isEmpty(companyName)?"":
            FragmentContacts.firstLetterToUpper(companyName));

        }

    }
}
