package com.ultralinked.uluc.enterprise.baseui.baseadapter;

import android.content.Context;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 2016/7/22 0022.
 */
public abstract class MyBaseAdapter<T> extends BaseAdapter {

    /**
     * listview的item资源id
     */
    private int resourceId;

    /**
     * TAG 打印日子用 实用
     */
    private String TAG;
    /**
     * 上下文
     */
    private Context context;
    /**
     * 数据
     */
    protected List<T> list = new ArrayList<>();

    private MyHolder holder;


    protected Context getContext() {
        return context;
    }

    String searchStr = "";



    public String getSearchStr() {
        return searchStr;
    }
    public void setSearchStr(String searchStr) {
        this.searchStr = searchStr;
    }

    boolean isSearchMode = false;

    public boolean isSearchMode() {
        return isSearchMode;
    }
    public void setSearchMode(boolean searchMode) {
        this.isSearchMode = searchMode;
        if (!searchMode) {
            setSearchStr("");
        }
    }


    public MyBaseAdapter(Context context, int resource, List<T> list) {
        this.list = list;
        this.context = context;
        this.resourceId = resource;
        TAG = this.getClass().getSimpleName();
    }

    @Override
    public int getCount() {
        return list == null ? -1 : list.size();
    }

    @Override
    public T getItem(int position) {
        return list.get(position);
    }

    public void removeItem(int position) {
        this.list.remove(position);
        notifyDataSetChanged();
    }

    public void removeItem(T t) {
        this.list.remove(t);
        notifyDataSetChanged();
    }

    public void updateItem(T t) {
        int pos = list.indexOf(t);
        if (pos>=0){
            list.set(pos,t);
            notifyDataSetChanged();
        }

    }

    public void updateList(List<T> list) {
        updateList(list,false);
    }

    public void updateList(List<T> list,boolean search) {
        this.list = list;
        setSearchMode(search);
        notifyDataSetChanged();
    }


    public List<T> getList() {
        return list;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    protected  void onItemViewCreated(MyHolder holder,T item){

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resourceId, parent,false);
            holder=new MyHolder(convertView,context);

            convertView.setTag(holder);
            onItemViewCreated(holder,getItem(position));
        }else {
            holder= (MyHolder) convertView.getTag();
        }

        //holder.tag = getItem(position);

        holder.setPosition(position);

        setHolder(holder,getItem(position));

        return convertView;
    }

    /**
     * 设置
     * @param holder
     * @param t
     */
    public abstract void setHolder(MyHolder holder,T t);

    public static class MyHolder {
        private SparseArray<View> mViews;
        private View contentView;
        private Context context;
        private int position;
        public  Object tag;

        public MyHolder(View contentView,Context context){
            this.context=context;
            mViews = new SparseArray<>();
            this.contentView=contentView;
        }

        public View getContentView() {
            return contentView;
        }

        @SuppressWarnings("unchecked")
        private <T extends View> T bindId(int viewId, View convertView) {
            View view = mViews.get(viewId);
            if(view==null){
                view = convertView.findViewById(viewId);
                mViews.put(viewId, view);
            }
            return (T) view;
        }

        public void setText(int textViewID,SpannableStringBuilder msg){
            TextView textView=bindId(textViewID,contentView);
            if(textView!=null){
                textView.setText(msg);
            }
        }

        public void setText(int textViewID,SpannableString msg){
            TextView textView=bindId(textViewID,contentView);
            if(textView!=null){
                textView.setText(msg);
            }
        }

        public void setText(int textViewID,String msg){
            TextView textView=bindId(textViewID,contentView);
            if(textView!=null){
                textView.setText(msg);
            }
        }

        public void setTextColor(int textViewID,int color){
            TextView textView=bindId(textViewID,contentView);
            if(textView!=null){
                textView.setTextColor(color);
            }
        }

        public void setImage(int imageViewID,String url){
            ImageView imageView=bindId(imageViewID,contentView);
            if(imageView!=null){
                int imgResId =  ImageUtils.getContactResource(position);
                ImageUtils.loadCircleImage(context,imageView,url, imgResId);
            }
        }

        public void setImage(int imageViewID,int rsId){
            ImageView imageView=bindId(imageViewID,contentView);
            if(imageView!=null){

                ImageUtils.loadCircleImage(context,imageView,rsId);
            }
        }

        public void setItemBackgroundDrawable(int itemId, int rsId){
            View view = bindId(itemId,contentView);
            if(view != null){
                view.setBackground(context.getResources().getDrawable(rsId));
            }
        }

        public void setListener(int viewID,View.OnClickListener listener){
            bindId(viewID,contentView).setOnClickListener(listener);
        }

        public <T extends View> T getView(int id) {
            bindId(id,contentView);
            return  bindId(id,contentView);
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int postion){
            this.position=postion;
        }
    }

}
