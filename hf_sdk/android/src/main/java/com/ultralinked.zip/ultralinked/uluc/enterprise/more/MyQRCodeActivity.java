package com.ultralinked.uluc.enterprise.more;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.GroupConversation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.bingoogolapple.qrcode.zxing.QRCodeEncoder;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class MyQRCodeActivity extends BaseActivity implements View.OnClickListener{

    private ImageView leftBack,displayQRCode;
    TextView tvName, tvMobile;
    ImageView tvGender;
    ImageView ivUserPhoto;
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_my_qrcode;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack=bind(R.id.left_back);
        displayQRCode=bind(R.id.img_code);
        tvGender=bind(R.id.iv_sex);
        tvName=bind(R.id.tvname);
        ivUserPhoto=bind(R.id.head);
        tvMobile=bind(R.id.tvmsg);


        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.title_my_qr_code);
        initListener(this, leftBack, displayQRCode);

       UserInfo userInfo = getIntent().getParcelableExtra("user_info");
        if (null != userInfo) {
            displayVcardInfo(userInfo);
        }

        createQRCodeUrl();
    }

    private void displayVcardInfo(UserInfo userInfo) {
        ImageUtils.loadCircleImage(this, ivUserPhoto, userInfo.getIcon_url(), ImageUtils.getDefaultContactImageResource(userInfo.getId()));
        tvName.setText(UserInfo.getDisplayName(userInfo));
        tvMobile.setText(PhoneNumberUtils.formatMobile(userInfo.getMobile()));

        int type = userInfo.getGender();
        try {

            if (type == 0){
                tvGender.setTag("Female");
                tvGender.setImageResource(R.mipmap.female);
            }else{
                tvGender.setImageResource(R.mipmap.male);
                tvGender.setTag("Male");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //show QR code
        ACache mCache = ACache.get(getActivity());
        String myQRCode =  mCache.getAsString(SPUtil.getUserID()+"_myQRCode");
        if (myQRCode!=null){
            displayQrcode(myQRCode);
        }

    }

    private void createQRCodeUrl() {

        ApiManager.getInstance().createQrCodeUrl("vcard",new HashMap<String, String>())
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        android.util.Log.i(TAG,"createVcardQRCodeUrlComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "gcreateVcardQRCodeUrl  error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                String result = object.optString("result");

                                ACache mCache = ACache.get(getActivity());
                                mCache.put(SPUtil.getUserID()+"_myQRCode",result,365 * ACache.TIME_DAY);

                                displayQrcode(result);
                            }


                        } catch (JsonSyntaxException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        }
                        catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }
                        catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        android.util.Log.i(TAG, "createVcardQRCodeUrl:  " + rs);
                    }         //请求成功

                });



    }

    void displayQrcode(final String content){

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    //  Bitmap logo = BitmapFactory.decodeResource(getResources(),R.mipmap.logo);
                    final  Bitmap bitmap = QRCodeEncoder.syncEncodeQRCode(content, ScreenUtils.dp2px(MyQRCodeActivity.this,232), Color.BLACK);
                    if (bitmap == null){
                        Log.i(TAG,"the qr bitmap is null:"+displayQRCode.getWidth());
                        return;
                    }
                    if (getActivity() == null ||isFinishing()){
                        return;
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            displayQRCode.setImageBitmap(bitmap);
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        }).start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.img_code:

                break;


            default:
        }
    }




}
