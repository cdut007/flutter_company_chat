package com.ultralinked.uluc.enterprise.chat;

import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;

import java.util.List;

/**
 * Created by ultralinked on 2016/7/4 0004.
 */
public class ChatPresenter implements ChatModelFab {

    private ChatViewFab chatView;
    private ChatPresenterImp chatModel;

    public ChatPresenter(ChatViewFab listener){
        chatView=listener;
        chatModel=new ChatPresenterImp(this);
    }

    public void initData(boolean chatType,boolean isPrivate){

        chatModel.initChatData(chatType,isPrivate);
    }




    @Override
    public void updateConversations(List<Conversation> conversations) {
        chatView.updateConversation(conversations);
    }

    @Override
    public void updateUnreadCount(int conversationsUnreadCount) {
        chatView.updateUnreadMessageCount(conversationsUnreadCount, ChatModule.Add_New_Counts);
    }
}
