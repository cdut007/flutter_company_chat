package com.ultralinked.uluc.enterprise.pay;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lly on 2016/12/26.
 */

public class BillingDetailsActivity extends BaseActivity implements View.OnClickListener {

    TextView mAmount, mType, mOrder_id, mStatus, mMethod, mTime;
    Button mRefresh;

    RechargeRecordModel model;

    public static String SUCCESS = "success";

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_billing_details;
    }

    @Override
    protected void setTopBar() {
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.billing_detail);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        mAmount = bind(R.id.txt_detail_amount);
        mType = bind(R.id.txt_detail_type);
        mMethod = bind(R.id.txt_detail_method);
        mStatus = bind(R.id.txt_detail_status);
        mOrder_id = bind(R.id.txt_detail_order);
        mTime = bind(R.id.txt_detail_time);
        mRefresh = bind(R.id.btn_refresh);

        Intent intent = getIntent();
        model = (RechargeRecordModel) intent.getSerializableExtra("recordModel");
        if (model != null) {

            String direction = model.getDirection();
            if (!TextUtils.isEmpty(direction)) {
                switch (direction) {
                    case "out":
                        mAmount.setText(String.format(getString(R.string.out_recharge_amount), model.getPayment_value()));
                        break;
                    case "in":
                        mAmount.setText(String.format(getString(R.string.recharge_amount), model.getPayment_value()));
                        break;
                    default:
                        mAmount.setText(String.format(getString(R.string.recharge_amount), model.getPayment_value()));
                        break;
                }
            } else {
                mAmount.setText(String.format(getString(R.string.recharge_amount), model.getPayment_value()));
            }

            String type = model.getProduct_type();
            mType.setText(TextUtils.isEmpty(type)?"":type);

            String paymentProviderId = model.getPayment_providerid();
            if (!TextUtils.isEmpty(paymentProviderId)) {
                int providerId = -1000;
                try {
                    providerId = Integer.valueOf(paymentProviderId);
                } catch (NumberFormatException ex) {
                    Log.e(TAG, "paymentProviderId error: " + android.util.Log.getStackTraceString(ex));
                }
                switch (providerId) {
                    case 1:
                        mMethod.setText(R.string.aliPay);
                        break;
                    case 2:
                        mMethod.setText(R.string.weixin);
                        break;
                    case 3:
                        mMethod.setText(R.string.payPal);
                        break;
                    case 4:
                        mMethod.setText(R.string.reward);
                        break;
                    case 5:
                        mMethod.setText(R.string.balance);
                        break;
                }
            }

            String payment_id = model.getPayment_id();
            mOrder_id.setText(TextUtils.isEmpty(payment_id)?"":payment_id);

            String created_at = model.getCreated_at();
            mTime.setText(TextUtils.isEmpty(created_at)?"":created_at);

            if (TextUtils.isEmpty(model.getPayment_success())) {
                mStatus.setText("");
            } else {
                int status = -1000;
                try {
                    status = Integer.parseInt(model.getPayment_success());
                } catch (NumberFormatException ex) {
                    Log.e(TAG, android.util.Log.getStackTraceString(ex));
                }
                switch (status) {
                    case PaymentActivity.CANCEL:
                        mStatus.setText(R.string.canceled);
                        break;
                    case PaymentActivity.UNCOMPLETED:
                        mStatus.setText(R.string.failed);
                        break;
                    case PaymentActivity.WAITING_CONFIRM:
                        mStatus.setText(R.string.waiting_confirm);
                        break;
                    case PaymentActivity.COMPLETED:
                        mStatus.setText(R.string.success);
                        break;
                    default:
                        mStatus.setText("");
                        break;
                }
                if (status == PaymentActivity.CANCEL||status == PaymentActivity.COMPLETED) {
                    mRefresh.setVisibility(View.GONE);
                }else {
                    mRefresh.setOnClickListener(this);
                }
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.left_back:
                this.finish();
                break;
            case R.id.btn_refresh:
                refresh();
                break;
        }
    }

    void refresh() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().queryOrder(model)
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "refresh successfully");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "refresh fail：" + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            Log.i(TAG+"query response: ",response);
                            JSONObject object = new JSONObject(response);
                            switch (model.getPayment_providerid()) {
                                case "2":
                                    if (object.optString("trade_state").equalsIgnoreCase("SUCCESS"))
                                        refreshUI();
                                    break;
                                case "3":
                                    if (object.optString("state").equalsIgnoreCase("approved"))
                                        refreshUI();
                                    break;
                            }
                        } catch (Exception e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    void refreshUI() {
        mStatus.setText(R.string.success);
        mRefresh.setVisibility(View.GONE);
        RxBus.getDefault().post(SUCCESS); //Notify TransactionRecordsActivity to refresh data
    }
}
