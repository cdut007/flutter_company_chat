package com.ultralinked.uluc.enterprise.contacts.ui.orgnization;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.FragmentCompanyContacts;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.DataWrapper;
import com.ultralinked.uluc.enterprise.contacts.ui.MyHandler;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailListActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.pendinglist.PendingInviteListActicity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;


/**
 * only show this company's organization
 */
public class OrganizationActivity extends AppCompatActivity implements MyHandler.MyHandlerListener, TextWatcher {

    public static final String TAG = "OrgAct";


    private ListView mOrganizationList;
    private OrganizationAdapter mAdapter;


    private int mStep = 0;
    private HashMap<Integer, ArrayList<DataWrapper>> UserClickPath = new HashMap<>();
    private HashMap<Integer, String> UserClickPathTitle = new HashMap<>();


    private TextView titleCenter;
    private MyHandler mHandler;
    private final int GET_DATAWRAPPER_OK = 123;
    private EditText mSearchEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(com.holdingfuture.flutterapp.hfsdk.R.layout.activity_organization);

        final String _Id = getIntent().getStringExtra(FragmentCompanyContacts.CURRENT_COMPANY_ID);

        initTitleBar();

        initSearchView();

        mHandler = new MyHandler(this);
        mHandler.setListener(this);
        mHandler.post(new Runnable() {
            @Override
            public void run() {

                ArrayList<DataWrapper> mDatas = new ArrayList<>();

                ArrayList<DepartUtils.CompanyElement> subdata1 = getInitialDataByID(_Id);

                for (DepartUtils.CompanyElement item : subdata1) {

                    if ("internal".equalsIgnoreCase(item.type)) {

                        mDatas.add(new DataWrapper(item, null));

                    }
                }

                ArrayList<PeopleEntity> subdata2 = PeopleEntityQuery.getInstance().getByDeptID(_Id);

                for (PeopleEntity item : subdata2) {

                    mDatas.add(new DataWrapper(null, item));
                }

                Message msg = Message.obtain();
                msg.what = GET_DATAWRAPPER_OK;
                msg.obj = mDatas;
                mHandler.sendMessage(msg);
            }
        });

        initListView();

    }

    private void initSearchView() {

        mSearchEditText = (EditText) findViewById(R.id.search_edittext);
        mSearchEditText.addTextChangedListener(this);

    }

    private void initListView() {

        mAdapter = new OrganizationAdapter(this);

        mOrganizationList = (ListView) findViewById(R.id.organizationList);

        mOrganizationList.setAdapter(mAdapter);

        mOrganizationList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                DataWrapper item = ((OrganizationAdapter) parent.getAdapter()).getItem(position);

                if (item.type == 0) {

                    final DepartUtils.CompanyElement dept = item.element;

                    if (DepartUtils.INVITE_ORG_FLAG.equals(dept._id)){
                        Intent gotoDetal = new Intent(OrganizationActivity.this, PendingInviteListActicity.class);
                        gotoDetal.putExtra(DetailListActivity.KEY_DETAIL, dept);
                        gotoDetal.putExtra(DetailListActivity.KEY_PAENET_DEPT_NAME, dept.name);
                        startActivity(gotoDetal);
                        return;
                    }

                    if (dept.children2 == null || dept.children2.length() == 0) {// it is a leaf, open detail page
                        Log.i(TAG, "I am a leaf with name " + dept.name + "; id =" + dept._id);


                        Intent gotoDetal = new Intent(OrganizationActivity.this, DetailListActivity.class);
                        gotoDetal.putExtra(DetailListActivity.KEY_DETAIL, dept);
                        gotoDetal.putExtra(DetailListActivity.KEY_PAENET_DEPT_NAME, dept.name);
                        startActivity(gotoDetal);
                        return;
                    } else {// has child

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                ArrayList<DataWrapper> nextDatas = new ArrayList<>();

                                Log.i(TAG, " children2 " + dept.children2.length());

                                ArrayList<DepartUtils.CompanyElement> subChildren = DepartUtils.getInstance().readCompanyStructure(dept.children2);
                                Log.i(TAG, " subChildren " + subChildren.size());

                                for (DepartUtils.CompanyElement item : subChildren) {

                                    if ("internal".equalsIgnoreCase(item.type)) {

                                        nextDatas.add(new DataWrapper(item, null));

                                    }
                                }
                                ArrayList<PeopleEntity> subdata2 = PeopleEntityQuery.getInstance().getByDeptID(dept._id);

                                Log.i(TAG, " onclick subdata2 " + (subdata2 == null ? 0 : subdata2.size()));

                                for (PeopleEntity item : subdata2) {

                                    nextDatas.add(new DataWrapper(null, item));
                                }

                                mStep += 1;
                                UserClickPath.put(mStep, nextDatas);
                                UserClickPathTitle.put(mStep, dept.name);
                                titleCenter.setText(dept.name);

                                Message msg = Message.obtain();
                                msg.what = GET_DATAWRAPPER_OK;
                                msg.obj = nextDatas;
                                mHandler.sendMessage(msg);

                                Log.i(TAG, "notifyDataSetChanged ");
                            }
                        });
                    }

                } else if (item.type == 1) {

                    final PeopleEntity people = item.peopleEntity;
                    Log.i(TAG, "PeopleEntity subuser is  " + people.subuser_id);
                    DetailPersonActivity.gotoDetailPersonActivity(OrganizationActivity.this, people);
                }
            }
        });
    }


    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.organization));


        TextView titleRight = (TextView) findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onBackPressed() {

        goBack();

    }

    private void goBack() {

        if (mStep == 0) {

            UserClickPath.clear();
            UserClickPath = null;
            finish();

        } else {

            UserClickPath.put(mStep, null);
            UserClickPathTitle.put(mStep, null);
            mStep -= 1;
            titleCenter.setText(UserClickPathTitle.get(mStep));
            mAdapter.setData(UserClickPath.get(mStep));
            mAdapter.notifyDataSetChanged();
        }
    }


    private ArrayList<DepartUtils.CompanyElement> getInitialDataByID(String id) {
        //all these companys are stored
        ArrayList<DepartUtils.CompanyElement> data = DepartUtils.getInstance().getCompanyMap();
        for (DepartUtils.CompanyElement item : data) {

            if (item._id.equals(id)) {

                return DepartUtils.getInstance().readCompanyStructure(true,item.children2);
            }
        }
        return data;
    }

    //all the datas for organization
    private ArrayList<DataWrapper> mOrgDatas;

    @Override
    public void handleMessage(Message msg) {
        //record each step's data
        switch (msg.what) {

            case GET_DATAWRAPPER_OK:

                mOrgDatas = (ArrayList<DataWrapper>) msg.obj;
                UserClickPath.put(mStep, mOrgDatas);
                UserClickPathTitle.put(mStep, getString(com.holdingfuture.flutterapp.hfsdk.R.string.organization));

                if (mOrgDatas != null && mOrgDatas.size() > 0) {

                    DataWrapper inviteOrg = null;
                    for (DataWrapper org:mOrgDatas ) {
                        if (org.element != null && DepartUtils.INVITE_ORG_FLAG.equals(org.element._id)) {
                            inviteOrg = org;
                            com.ultralinked.uluc.enterprise.utils.Log.i(TAG, "find the org id info");
                            break;
                        }
                    }
                    if (inviteOrg!=null){
                        mOrgDatas.remove(inviteOrg);
                    }

                    Collections.sort(mOrgDatas, new Comparator<DataWrapper>() {
                        @Override
                        public int compare(DataWrapper lhs, DataWrapper rhs) {

                            int resutl = lhs.type - rhs.type;

                            if (resutl == 0) {

                                if (lhs.type == 0) {

                                    return lhs.element.name.compareToIgnoreCase(rhs.element.name);

                                } else if (lhs.type == 1) {

                                    if (lhs.peopleEntity == null) {

                                        Log.i(TAG, " peopleEntity == null");
                                    }
                                    return PeopleEntityQuery.getDisplayName(lhs.peopleEntity).compareToIgnoreCase(PeopleEntityQuery.getDisplayName(rhs.peopleEntity));
                                }
                            }
                            return resutl;
                        }
                    });

                    //find the invite to the top
                    if (inviteOrg!=null){
                        mOrgDatas.add(0,inviteOrg);
                    }

                }
                mAdapter.setData(mOrgDatas);
                mAdapter.notifyDataSetChanged();
                break;
        }

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

        if (s == null || s.length() == 0) {

            mAdapter.setData(mOrgDatas);
            mAdapter.notifyDataSetChanged();

        } else {

            filterDataOnSearch(s.toString());

        }
    }

    private void filterDataOnSearch(String search) {

        ArrayList<DataWrapper> temp = new ArrayList<>();

        for (DataWrapper dataWrapper : mOrgDatas) {

            if (dataWrapper.type == 0 && dataWrapper.element.name.contains(search)) {

                temp.add(dataWrapper);

            } else if (dataWrapper.type == 1 && PeopleEntityQuery.getDisplayName(dataWrapper.peopleEntity).contains(search)) {

                temp.add(dataWrapper);
            }
        }

        mAdapter.setData(temp);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        mSearchEditText.removeTextChangedListener(this);
        super.onDestroy();
    }
}
