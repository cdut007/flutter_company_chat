package com.ultralinked.uluc.enterprise.contacts.ui.secret;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.ContactsExpandableAdapter;
import com.ultralinked.uluc.enterprise.contacts.FriendAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.bingoogolapple.badgeview.BGABadgeView;

/**
 * Created by Created by ultralinked.
 */
public class PrivateAdapter extends FriendAdapter {


    public PrivateAdapter(Context context) {
        super(context,R.layout.item_private_contact);
        TAG = "PrivateAdapter";
    }


    HashMap<String, Integer> unreadMsgMap = new HashMap<>();

    public void setUnreadMsgMap(HashMap<String, Integer> unreadMsgMap) {
        this.unreadMsgMap = unreadMsgMap;
        Log.i(TAG, "set unreadMsgMap info:" + unreadMsgMap.size());
        notifyDataSetChanged();
    }

    public HashMap<String, Integer> getUnreadMsgMap() {
        return unreadMsgMap;
    }

    @Override
    public void setHolder(MyHolder holder, PeopleEntity peopleEntity) {
        super.setHolder(holder, peopleEntity);
        BGABadgeView messageBadgeView = holder.getView(R.id.unread_msg_count);
        Integer count = unreadMsgMap.get(peopleEntity.subuser_id);
        if (count != null) {
            if (count.intValue() > 0) {
                if (count > 99) {
                    messageBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(4);
                    messageBadgeView.showTextBadge("99+");
                } else if (count >= 10) {
                    messageBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(4);
                    messageBadgeView.showTextBadge("" + count);
                } else {
                    messageBadgeView.getBadgeViewHelper().setBadgeHorizontalMarginDp(8);
                    messageBadgeView.showTextBadge("" + count);
                }

            } else {
                messageBadgeView.hiddenBadge();
            }
        } else {
            messageBadgeView.hiddenBadge();
        }
    }
}
