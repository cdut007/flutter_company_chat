package com.ultralinked.uluc.enterprise.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.ListPreloader;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.iflytek.thirdparty.P;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.voip.api.BitmapUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by Chenlu on 2016/6/29 0029.
 *
 * @ClassName: ImageUtils
 * @Description: 图片展示工具类
 */

public class ImageUtils {


    /*************************
     * 加载图片
     ********************************/

    /*
    加载失败后默认显示的图片资源
     */
    public static int errorResId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.ic_action_name;


    /**
     * 从网络加载图片到ImageView上
     *
     * @param context
     * @param imageView
     * @param uri
     */
    public static void loadFromNetWork(Context context, ImageView imageView, Uri uri) {
        Glide.with(context).load(uri).error(errorResId).into(imageView);

    }

    /**
     * 从本地存储中获取图片加载
     *
     * @param context
     * @param imageView
     * @param file
     */
    public static void loadFromLocaltorage(Context context, ImageView imageView, File file) {
        Glide.with(context).load(file).diskCacheStrategy(DiskCacheStrategy.ALL).into(imageView);
    }

    /**
     * 从本地存储或网络加载图片
     *
     * @param context
     * @param imageView
     * @param pathOrUrl    可以是本地文件的路径、网络图片的url、uri
     * @param defaultResId 获取图片失败时显示的默认图片
     */
    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl, int defaultResId) {
        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).error(defaultResId).into(imageView);
    }

    /**
     *
     * @param context
     * @param imageView
     * @param pathOrUrl
     * @param defaultResId
     * @param placeholder 占位图
     */
    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl, int defaultResId,int placeholder) {
        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).error(defaultResId).placeholder(placeholder).into(imageView);
    }

    /**
     *
     * @param context
     * @param imageView
     * @param pathOrUrl
     * @param defaultResId
     * @param placeholder 占位图
     */
    public static void loadImageAsGif(Context context, ImageView imageView, String pathOrUrl, int defaultResId,int placeholder) {
        Glide.with(context).load(pathOrUrl).asGif().diskCacheStrategy(DiskCacheStrategy.ALL).error(defaultResId).placeholder(placeholder).into(imageView);
    }

    /**
     *
     * @param context
     * @param imageView
     * @param pathOrUrl
     * @param defaultResId
     * @param placeholder 占位图
     */
    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl, int defaultResId,Drawable placeholder) {
        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).error(defaultResId).placeholder(placeholder).into(imageView);
    }
    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl, int defaultResId,Drawable placeholder,int reqWidth,int reqHeight) {
        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).error(defaultResId).placeholder(placeholder).override(reqWidth,reqHeight).into(imageView);
    }

    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl, Drawable errorDrawable,Drawable placeholder,int reqWidth,int reqHeight) {
        if (context instanceof Activity){
            if (((Activity)context).isDestroyed()){
                return;
            }
        }

        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).error(errorDrawable).placeholder(placeholder).override(reqWidth,reqHeight).into(imageView);
    }


    public static void loadImageByString(Context context, ImageView imageView, String pathOrUrl) {
        if (context instanceof Activity){
            if (((Activity)context).isDestroyed()){
                imageView.setImageResource(R.mipmap.no_pic);
                return;
            }
        }


        Glide.with(context).load(pathOrUrl).diskCacheStrategy(DiskCacheStrategy.ALL).into(imageView);
    }

    public static void loadImageByBitmap(Context context, ImageView imageView, Bitmap bitmap) {
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
           bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
           byte[] bytes=baos.toByteArray();
//           bitmap.recycle();

           Glide.with(context).load(bytes).diskCacheStrategy(DiskCacheStrategy.ALL).dontAnimate().dontTransform().placeholder(new BitmapDrawable(bitmap)).into(imageView);
    }


    /**
     * 加载圆角图片
     *
     * @param context
     * @param imageView
     * @param radiusDp  圆角的半径 （单位：dp）
     * @param url
     */
    public static void loadRoundImage(Context context, ImageView imageView, int radiusDp, String url) {
        Glide.with(context)
                .load(url)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .fitCenter()
                .centerCrop()
                .transform(new GlideRoundTransform(context, radiusDp))
                .into(imageView);
    }
    public static void loadRoundImage(Context context, ImageView imageView, int radiusDp, Bitmap bitmap) {
        if (bitmap == null) {
            return;
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] bytes=baos.toByteArray();
        bitmap.recycle();

        Glide.with(context)
                .load(bytes)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .fitCenter()
                .centerCrop()
                .transform(new GlideRoundTransform(context, radiusDp))
                .into(imageView);
    }
    public static void loadRoundImage(Context context, ImageView imageView, int radiusDp, int resId) {
        Glide.with(context)
                .load(resId)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .fitCenter()
                .centerCrop()
                .transform(new GlideRoundTransform(context, radiusDp))
                .into(imageView);
    }

    /**
     * 加载圆形图片
     *
     * @param context
     * @param imageView
     * @param resId
     */
    public static void loadCircleImage(Context context, ImageView imageView, int resId) {
        if (context==null){
            return;
        }
        if (context instanceof Activity){
            if (((Activity)context).isDestroyed()){
                return;
            }
        }
        if (resId <= 0){
            return;
        }

        imageView.setImageResource(resId);


//        Glide.with(context)
//                .load(resId)
//                .diskCacheStrategy(DiskCacheStrategy.ALL)
//                .placeholder(resId)
//                .fitCenter()
//                .centerCrop()
//                .transform(new GlideCircleTransform(context))
//                .into(imageView);

    }
    public static void loadCircleImage(Context context, ImageView imageView, String url,int defaultImgId) {
        if (context instanceof Activity){
            if (((Activity)context).isDestroyed()){
                return;
            }
        }

        if (TextUtils.isEmpty(url)){
            imageView.setImageResource(defaultImgId);
            return;
        }


        Glide.with(context)
                .load(url)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(defaultImgId)
                .priority(Priority.HIGH)
                .fitCenter()
                .centerCrop()
                .dontAnimate()
                .transform(new GlideCircleTransform(context))
                .error(defaultImgId)
        .into(imageView);




    }


    /******************************图片属性处理******************************************/

    /**
     * 读取图片属性：旋转的角度
     *
     * @param path
     * @return
     */
    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation =
                    exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;

    }

    /**
     * 旋转图片一定角度
     *
     * @param angle
     * @param bitmap
     * @return
     */
    public static Bitmap rotateBitmap(int angle, Bitmap bitmap) {
        // 旋转图片 动作
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        // 创建新的图片
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        //如果返回的不是同一个bitmap对象，则将原来的回收掉
        if (resizedBitmap != bitmap) {
            bitmap.recycle();
        }
        return resizedBitmap;
    }

    /**
     * 将原图片按指定的宽高压缩
     *
     * @param filePath
     * @param reqHeight
     * @param reqWidth
     * @return
     * @throws IOException
     * @Description:压缩图片
     */
    public static Bitmap compressSource(String filePath, int reqHeight, int reqWidth) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        options.inSampleSize = getSampleSize(options, reqHeight, reqWidth);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(filePath, options);
    }

    /**
     * @param options
     * @param reqHeight
     * @param reqWidth
     * @return
     * @Description:获取图片压缩的比率
     */
    private static int getSampleSize(BitmapFactory.Options options, int reqHeight, int reqWidth) {
        int height = options.outHeight;
        int width = options.outWidth;
        int sampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            int heightRatio = Math.round((float) height / (float) reqHeight);
            int widthRatio = Math.round((float) width / (float) reqWidth);
            sampleSize = heightRatio > widthRatio ? widthRatio : heightRatio;
        }
        return sampleSize;
    }

    public static byte[] bitmap2Bytes(Bitmap bm) {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
      return baos.toByteArray();
    }
    public static Bitmap bytes2Bimap(byte[] b) {
        if (b.length != 0) {
             return BitmapFactory.decodeByteArray(b, 0, b.length);
           } else {
                return null;
       }
     }

    public static Bitmap getFirstFrameBitmapFromVideo(String videpPath) {
        return ThumbnailUtils.createVideoThumbnail(videpPath, MediaStore.Images.Thumbnails.MINI_KIND);
    }


    public static int getDefaultContactImageResource(String userId) {
        int  defaultId = getContactResource(getRandomIndexByUserId(userId));
        return defaultId;
    }

    public  static  int getRandomIndexByUserId(String userId){
        if (TextUtils.isEmpty(userId)){
            return 0;
        }
        char c=userId.charAt(userId.length()-1);
        int pos = c % 4;
        return pos;
    }


    public static int getContactResource(int index) {

        int defaultId = R.mipmap.default_head;
//        switch (index % 4) {
//
//            case 1:
//                defaultId = R.mipmap.avatar_1;
//                break;
//            case 2:
//                defaultId = R.mipmap.avatar_2;
//                break;
//            case 3:
//                defaultId = R.mipmap.avatar_3;
//                break;
//            default:
//                defaultId = R.mipmap.avatar_4;
//                break;
//        }
        return defaultId;
    }

    public static void buttonEffect(TextView bubbleView) {
        buttonEffect(bubbleView,true);
    }

    public static void buttonEffect(TextView bubbleView,boolean enableText) {

        StateListDrawable states = new StateListDrawable() {
            @Override
            protected boolean onStateChange(int[] stateSet) {

                boolean isStatePressedInArray = false;
                for (int state : stateSet) {
                    if (state == android.R.attr.state_selected) {
                        isStatePressedInArray = true;
                    }

                    if (state == android.R.attr.state_pressed) {
                        isStatePressedInArray = true;
                    }
                    if (state == android.R.attr.state_focused) {
                        isStatePressedInArray = true;
                    }
                }

                if (isStatePressedInArray) {
                    super.setColorFilter(0x99999999, PorterDuff.Mode.MULTIPLY);
                } else {
                    super.clearColorFilter();
                }

                return super.onStateChange(stateSet);
            }

            @Override
            public boolean isStateful() {
                return true;
            }
        };



            Drawable[] compoundDrawables = bubbleView.getCompoundDrawables();

            if (compoundDrawables!=null&&compoundDrawables.length>0){//only one image is consider.
                for (int i = 0; i < compoundDrawables.length; i++) {
                    Drawable compoundDrawable = compoundDrawables[i];
                    if (compoundDrawable == null){
                        continue;
                    }

                    states.addState(new int[] { android.R.attr.state_pressed },
                            compoundDrawable);
                    states.addState(new int[] {}, compoundDrawable);
                    switch (i){//Returns drawables for the left, top, right, and bottom borders.
                        case 0:
                            bubbleView.setCompoundDrawablesWithIntrinsicBounds(states,null,null,null);
                            break;
                        case 1:
                            bubbleView.setCompoundDrawablesWithIntrinsicBounds(null,states,null,null);
                            break;
                        case 2:
                            bubbleView.setCompoundDrawablesWithIntrinsicBounds(null,null,states,null);
                            break;
                        case 3:
                            bubbleView.setCompoundDrawablesWithIntrinsicBounds(null,null,null,states);
                            break;
                    }
                }
            }

          //set Text state
         CharSequence content  = bubbleView.getText();
        if (TextUtils.isEmpty(content)){
            return;
        }

        ColorStateList colorStateList = bubbleView.getTextColors();

        if (enableText){
            //not define the press color.
            int maskColor = 0x99999999 | colorStateList.getDefaultColor();
            bubbleView.setTextColor(new ColorStateList(new int[][] { new int[] { android.R.attr.state_pressed },
                    new int[] { android.R.attr.state_focused }, new int[] {} }, new int[] {
                    maskColor, maskColor,
                    colorStateList.getDefaultColor() }));
        }



    }


    public static void buttonEffect(View bubbleView) {
        if (bubbleView.getBackground() == null || bubbleView.getBackground() instanceof  StateListDrawable
                || bubbleView instanceof  Switch) {

            return;
        }

        StateListDrawable states = new StateListDrawable() {
            @Override
            protected boolean onStateChange(int[] stateSet) {

                boolean isStatePressedInArray = false;
                for (int state : stateSet) {
                    if (state == android.R.attr.state_selected) {
                        isStatePressedInArray = true;
                    }

                    if (state == android.R.attr.state_pressed) {
                        isStatePressedInArray = true;
                    }
                }

                if (isStatePressedInArray) {
                    super.setColorFilter(0x99999999, PorterDuff.Mode.MULTIPLY);
                } else {
                    super.clearColorFilter();
                }

                return super.onStateChange(stateSet);
            }

            @Override
            public boolean isStateful() {
                return true;
            }
        };



            states.addState(new int[] { android.R.attr.state_pressed },
                    bubbleView.getBackground());
            states.addState(new int[] {}, bubbleView.getBackground());
            if (Build.VERSION.SDK_INT >= 16) {
                bubbleView.setBackground(states);
            } else {
                bubbleView.setBackgroundDrawable(states);
            }



    }

    public static void buttonEffect(ImageView bubbleView) {
        if (bubbleView.getDrawable() != null && !(bubbleView.getDrawable() instanceof StateListDrawable)) {
            StateListDrawable states = new StateListDrawable() {
                @Override
                protected boolean onStateChange(int[] stateSet) {

                    boolean isStatePressedInArray = false;
                    for (int state : stateSet) {
                        if (state == android.R.attr.state_selected) {
                            isStatePressedInArray = true;
                        }

                        if (state == android.R.attr.state_pressed) {
                            isStatePressedInArray = true;
                        }
                    }

                    if (isStatePressedInArray) {
                        super.setColorFilter(0x99999999, PorterDuff.Mode.MULTIPLY);
                    } else {
                        super.clearColorFilter();
                    }

                    return super.onStateChange(stateSet);
                }

                @Override
                public boolean isStateful() {
                    return true;
                }
            };
            states.addState(new int[] { android.R.attr.state_pressed },
                    bubbleView.getDrawable());
            states.addState(new int[] {}, bubbleView.getDrawable());
            bubbleView.setImageDrawable(states);
        }else{
            //do nothing.
        }


    }





    public  static long minImgFileLen = 500 * 1024;

    /**
     * @param
     *            picPath
     */
    public static void compressImage(Context context, String picPath) {
        compressImage(context, picPath, picPath);
    }

    public static void compressImage(Context context, String orgpicPath,
                                     String destPicPath) {
        // TODO Auto-generated method stub
        File file = new File(orgpicPath);
        if (file.exists()) {

            if (file.length() <= minImgFileLen) {
                // no need compress.
                Bitmap bmp = BitmapFactory.decodeFile(orgpicPath);
                if (bmp == null) {
                    return;
                }
                transImage(orgpicPath, destPicPath, bmp.getWidth(),
                        bmp.getHeight(), 100, context, bmp, false, true);
                return;
            }

            transImage(orgpicPath, destPicPath, 1024, 720, 60, context, null,
                    true, true);
        }
    }



    public static Bitmap getBitmap(Context context, String imageFile,
                                   boolean calcuRotation) {
        // set pic h & w
        WindowManager m = ((Activity)context).getWindowManager();
        Display d = m.getDefaultDisplay();
        // LayoutParams p = getWindow().getAttributes();
        DisplayMetrics dm = new DisplayMetrics();
        d.getMetrics(dm);
        int height = dm.heightPixels;
        int width = dm.widthPixels;
        height = (int) (height * 0.5);
        width = (int) (width * 0.5);
        Bitmap mBitmap=null;
        Bitmap temp =getBitmap(context, imageFile, calcuRotation, width, height);
        if (temp!=null&&!temp.isRecycled()) {
            mBitmap =temp;
//			mBitmap = Util.transform(new Matrix(), temp, width, height, true,
//					Util.RECYCLE_INPUT);
        }
        return mBitmap;
    }

    public static Bitmap getBitmap(Context context, String imageFile,
                                   boolean calcuRotation, int width, int height) {

        Bitmap newimgbitmap = decodeBitmap(context, imageFile, calcuRotation, width, height);

        return newimgbitmap;
    }

    static Canvas canvas = new Canvas();
    private static Bitmap decodeBitmap(Context context, String imageFile,
                                       boolean calcuRotation, int width, int height) {
        if (imageFile == null) {
            Log.i("scanImage", "getBitmap bull due to the imageFile path is null");
            return null;
        }
        // in case of vm out of boundry.
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile(imageFile, opts);
        boolean needScale = false;
        int scaleWitdh = opts.outWidth;
        int scaleHeight = opts.outHeight;

        if (Build.VERSION.SDK_INT >= 14) {

            int maxheighth = canvas.getMaximumBitmapHeight() / 8 - 1;
            if (opts.outHeight > maxheighth) {

                Log.i("hei", "height==" + opts.outHeight);
                opts.outHeight = maxheighth;
                scaleHeight = maxheighth;
                needScale = true;
            }

            int maxWidth = canvas.getMaximumBitmapWidth() / 8 - 1;
            if (opts.outWidth > maxWidth) {
                Log.i("hei", "height==" + opts.outHeight);
                Log.i("width", maxWidth + "width==" + opts.outWidth);
                opts.outWidth = maxWidth;
                needScale = true;
                scaleWitdh = maxWidth;
                // width=canvas.getMaximumBitmapWidth()/2;
            }
        }

        // opts.inSampleSize = ImageTools.computeSampleSize(opts, -1, 512 *
        // 512);
        opts.inSampleSize = calculateInSampleSize(opts, width,
                height);
        opts.inJustDecodeBounds = false;

        try {
            Bitmap bmp = BitmapFactory.decodeFile(imageFile, opts);
            /**
             * 获取图片的旋转角度，有些系统把拍照的图片旋转了，有的没有旋转
             */
            int degree = BitmapUtils.readPictureDegree(imageFile);
            /**
             * 把图片旋转为正的方向
             *
             */
            if (bmp==null||bmp.isRecycled()) {
                return null;
            }
            Bitmap newbitmap = rotaingImageView(degree, bmp);
            if (bitmap != null) {
                bitmap.recycle();
                bitmap = null;
            }
            if (needScale) {
                return resizeBitmapImage(newbitmap, scaleWitdh, scaleHeight);
            }
            return newbitmap;

        } catch (OutOfMemoryError err) {
            err.printStackTrace();
        }
        // String title = "Picture view";
        // // show primitive image
        // AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        // builder.setTitle(title);
        // builder.setView(viewImage);
        //
        // Dialog dialog = builder.create();
        // dialog.getWindow().setLayout(opts.outWidth, opts.outHeight);
        // dialog.show();
        if (needScale) {
            return resizeBitmapImage(bitmap, scaleWitdh, scaleHeight);
        }
        return bitmap;

    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        int height = options.outHeight;
        int width = options.outWidth;
        int inSampleSize = 1;


        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee
            // a final image with both dimensions larger than or equal to the
            // requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }

        return inSampleSize;
    }


    public static Bitmap rotaingImageView(int angle, Bitmap bitmap) {

        System.out.println("angle2=" + angle);
        if (angle == 0) {
            return bitmap;
        }
        // 旋转图片 动作
        Matrix matrix = new Matrix();
        ;
        matrix.postRotate(angle);
        // 创建新的图片
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        // mot change orginal bitmap..
        // if (bitmap!=null) {
        // bitmap.recycle();
        // bitmap=null;
        // }
        return resizedBitmap;
    }

    private static Bitmap resizeBitmapImage(Bitmap temp, int scaleWitdh,
                                            int scaleHeight) {
        // lator detail more,,,,

        if (temp != null && temp.getWidth() > scaleWitdh) {
            // 获得图片的宽高
            int width = temp.getWidth();
            int height = temp.getHeight();
            // 设置想要的大小
            int newWidth = scaleWitdh;

            // 计算缩放比例
            float scaleWidth = ((float) newWidth) / width;
            // float scaleHeight = ((float) newHeight) / height;
            // 取得想要缩放的matrix参数
            Matrix matrix = new Matrix();
            matrix.postScale(scaleWidth, scaleWidth);
            // 得到新的图片
            try {
                Bitmap mBitmap = Bitmap.createBitmap(temp, 0, 0, width, height,
                        matrix, true);
                if (!temp.isRecycled()) {
                    temp.recycle();
                    temp = null;
                }
                Log.i("hei", "height==" + scaleWitdh);
                return mBitmap;
            } catch (OutOfMemoryError e) {
                // TODO: handle exception
                e.printStackTrace();
            }

        } else if (temp != null && temp.getHeight() > scaleHeight) {

            // 获得图片的宽高
            int width = temp.getWidth();
            int height = temp.getHeight();
            // 设置想要的大小
            int newHeight = scaleHeight;

            // 计算缩放比例
            float scaledHeight = ((float) newHeight) / height;
            // float scaleHeight = ((float) newHeight) / height;
            // 取得想要缩放的matrix参数
            Matrix matrix = new Matrix();
            matrix.postScale(scaledHeight, scaledHeight);
            // 得到新的图片
            try {
                Bitmap mBitmap = Bitmap.createBitmap(temp, 0, 0, width, height,
                        matrix, true);
                if (!temp.isRecycled()) {
                    temp.recycle();
                    temp = null;
                }

                return mBitmap;
            } catch (OutOfMemoryError e) {
                // TODO: handle exception
                e.printStackTrace();
            }

        }

        if (temp != null) {
            Log.i("hei~~", "height==" + temp.getHeight());
        }

        return temp;
    }

    public static boolean transImage(String fromFile, String toFile, int width,
                                     int height, int quality, Context context, Bitmap imgBitmap,
                                     boolean getBitmap, boolean reCalcuRotation) {
        try {
            Bitmap bitmap;
            if (getBitmap) {
                bitmap = getBitmap(context, fromFile, reCalcuRotation);
            } else {
                bitmap = imgBitmap;
            }
            if (bitmap == null) {// may cause out of memory issue
                if (imgBitmap == null) {
                    return false;
                }
                bitmap = imgBitmap;
            }
            if (bitmap.isRecycled()) {// mulit click
                return true;
            }
            // int bitmapWidth = bitmap.getWidth();
            // int bitmapHeight = bitmap.getHeight();
            //
            // // 缩放图片的尺寸
            // float scaleWidth = (float) width / bitmapWidth;
            // float scaleHeight = (float) height / bitmapHeight;
            // Matrix matrix = new Matrix();
            // matrix.postScale(scaleWidth, scaleHeight);
            // // 产生缩放后的Bitmap对象
            // Bitmap resizeBitmap = Bitmap.createBitmap(bitmap, 0, 0,
            // bitmapWidth, bitmapHeight, matrix, false);
            Bitmap resizeBitmap = bitmap;
            // save file
            File myCaptureFile = new File(toFile);
            if (myCaptureFile.exists()) {
                myCaptureFile.delete();
            }
            String destParent = myCaptureFile.getParent();
            FileUtils.createFileDirNoMedia(destParent);

            myCaptureFile.createNewFile();
            Log.i("iamge file", toFile);

            FileOutputStream out = new FileOutputStream(myCaptureFile);
            if (resizeBitmap.isRecycled()) {// mulit click
                out.flush();
                out.close();
                return true;
            }
            if (resizeBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) {
                out.flush();
                out.close();
            }
            if (!bitmap.isRecycled()) {
                bitmap.recycle();// 记得释放资源，否则会内存溢出
            }
            if (!resizeBitmap.isRecycled()) {
                resizeBitmap.recycle();
            }
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }



}
