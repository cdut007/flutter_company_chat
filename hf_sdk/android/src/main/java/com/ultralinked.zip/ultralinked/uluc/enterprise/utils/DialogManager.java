package com.ultralinked.uluc.enterprise.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.widget.OptionTitleDialog;
import com.ultralinked.uluc.enterprise.more.ResetPsdActivity;

/**
 * Created by Chenlu on 2016/7/4 0004.
 */
public class DialogManager {



    /**
     *
     * @param context
     * @param titleStr
     * @param hints
     * @param listener
     * @return
     */
    public static Dialog showUnlockDialog(Context context, String titleStr, String[] hints, final OnDialogListener listener) {
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_input_layout, null);
        final Dialog dialog = new Dialog(context, R.style.unlock_dialog);
       // root.findViewById(R.id.cancel_btn).setVisibility(View.GONE);
        dialog.setContentView(root);//必须放在requestWindowFeature后面
        dialog.setCancelable(false);
        final LinearLayout content_layout = (LinearLayout) root.findViewById(R.id.content_container_layout);
        int l = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_lr));
        int t = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_tb));
        int r = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_lr));
        int b = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_tb));
        for (int i = 0; i < hints.length; i++) {
            EditText child = new EditText(context);
            child.setBackgroundResource(R.drawable.edittext_bg_border);
            child.setSingleLine();
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0,10,0,10);

            child.setLayoutParams(params);

            child.setPadding(l, t, r, b);

            child.setHint(hints[i]);
            content_layout.addView(child, i, params);
        }

        TextView title = (TextView) root.findViewById(R.id.dialog_title);
        title.setText(titleStr);
        Button cancel = (Button) root.findViewById(R.id.cancel_btn);
        Button ok = (Button) root.findViewById(R.id.ok_btn);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCancelClick(v);
                dialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence[] items = new  CharSequence[content_layout.getChildCount()];
                for (int i = 0; i < items.length; i++) {
                    items[i] = ((EditText)content_layout.getChildAt(i)).getText().toString();
                }
                listener.onOkClick(v,items,dialog);
//                dialog.dismiss();
            }
        });

        float scale = Float.valueOf(context.getResources().getString(R.string.dialog_width_scale));
        int width = (int) (ScreenUtils.getScreenWidth(context)* scale);

        WindowManager.LayoutParams p = dialog.getWindow().getAttributes();
        p.width = width;
        dialog.getWindow().setAttributes(p);

      //  context.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        dialog.show();
        return dialog;
    }


    public static Dialog showInputDialog(Context context, String titleStr, String[] hints,  final OnDialogListener listener) {

       return showInputDialog(context,titleStr,hints,null,listener);
    }

        /**
         *
         * @param context
         * @param titleStr
         * @param hints
         * @param listener
         * @return
         */
    public static Dialog showInputDialog(Context context, String titleStr, String[] hints, int[]inputTypes, final OnDialogListener listener) {
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_input_layout, null);
        final Dialog dialog = new Dialog(context, R.style.custom_dialog);
        dialog.setContentView(root);//必须放在requestWindowFeature后面

        final LinearLayout content_layout = (LinearLayout) root.findViewById(R.id.content_container_layout);
        int l = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_lr));
        int t = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_tb));
        int r = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_lr));
        int b = ScreenUtils.dp2px(context, context.getResources().getDimensionPixelSize(R.dimen.edittext_padding_tb));
        for (int i = 0; i < hints.length; i++) {
            EditText child = (EditText) View.inflate(context,R.layout.common_password,null);
            child.setBackgroundResource(R.drawable.edittext_bg_border);

            if (inputTypes!=null&&inputTypes.length == hints.length){
                child.setInputType(inputTypes[i]);
            }else{
               // child.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            }

          //  child.setSingleLine();
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ScreenUtils.dp2px(context,50));
            params.setMargins(0,10,0,10);

            child.setLayoutParams(params);

            child.setPadding(l, t, r, b);

            child.setHint(hints[i]);
            content_layout.addView(child, i, params);
        }

        TextView title = (TextView) root.findViewById(R.id.dialog_title);
        title.setText(titleStr);
        Button cancel = (Button) root.findViewById(R.id.cancel_btn);
        Button ok = (Button) root.findViewById(R.id.ok_btn);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCancelClick(v);
                dialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence[] items = new  CharSequence[content_layout.getChildCount()];
                for (int i = 0; i < items.length; i++) {
                    items[i] = ((EditText)content_layout.getChildAt(i)).getText().toString();
                }
                listener.onOkClick(v,items,dialog);
//                dialog.dismiss();
            }
        });

        float scale = Float.valueOf(context.getResources().getString(R.string.dialog_width_scale));
        int width = (int) (ScreenUtils.getScreenWidth(context)* scale);

        WindowManager.LayoutParams p = dialog.getWindow().getAttributes();
        p.width = width;
        dialog.getWindow().setAttributes(p);
        dialog.show();
        return dialog;
    }

    public static AlertDialog showOKCancelDialog(Context context, final String title, String content, final DialogInterface.OnClickListener positiveClickListener, final DialogInterface.OnClickListener negativeClickListener) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title).setMessage(content).setCancelable(false).setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (positiveClickListener != null) {

                    positiveClickListener.onClick(dialog, which);
                }

            }
        }).setNegativeButton(context.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (negativeClickListener != null) {

                    negativeClickListener.onClick(dialog, which);
                }
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        return dialog;


    }

    public static AlertDialog showOKDialog(Context context, final String title, String content, final DialogInterface.OnClickListener positiveClickListener) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title).setMessage(content).setCancelable(false).setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (positiveClickListener != null) {

                    positiveClickListener.onClick(dialog, which);
                }

            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        return dialog;


    }

    public interface OnDialogListener {
        void onCancelClick(View v);

        void onOkClick(View v, CharSequence[] items,Dialog dialog);

    }

    public static Dialog showBalancePayDialog(final Context context,String price, final OnDialogListener listener){
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_balance_pay, null);
        final Dialog dialog = new Dialog(context, R.style.custom_dialog);
        dialog.setCancelable(false);
        dialog.setContentView(root);

        final EditText amount = (EditText) root.findViewById(R.id.edit_payment_pass);

        TextView txtPrice = (TextView) root.findViewById(R.id.txt_payment_amount);
        txtPrice.setText(String.format(context.getString(R.string.recharge_amount),price));

        ImageView cancel = (ImageView) root.findViewById(R.id.img_cancel_payment);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCancelClick(v);
                dialog.dismiss();
            }
        });

        Button confirm = (Button) root.findViewById(R.id.btn_confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence[] items = new CharSequence[1];
                items[0] = amount.getText().toString();
                listener.onOkClick(v,items,dialog);
            }
        });

        if (SPUtil.getLoginModel()==SPUtil.LOGIN_BY_OTP && !SPUtil.getUserHasPsd() || !SPUtil.getUserHasPsd()) {
            TextView setPass = (TextView) root.findViewById(R.id.txt_set_login_pass);
            setPass.setVisibility(View.VISIBLE);
            setPass.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    bundle.putString("lunch_model","login_psd");
                    Intent intent = new Intent(context,ResetPsdActivity.class);
                    intent.putExtras(bundle);
                    context.startActivity(intent);
                }
            });
        }


        float scale = Float.valueOf(context.getResources().getString(R.string.dialog_width_scale));
        int width = (int) (ScreenUtils.getScreenWidth(context)* scale);
        try {
            WindowManager.LayoutParams p = dialog.getWindow().getAttributes();
            p.width = width;
            dialog.getWindow().setAttributes(p);
        }catch (NullPointerException ex){
            Log.e("DialogManager: ",android.util.Log.getStackTraceString(ex));
        }
        dialog.show();
        return dialog;
    }

    /**
     * 显示一个菜单选项的Dialog
     * @param context
     * @param title Dialog的标题
     * @param items 菜单栏的items
     * @param v  触发显示的View
     * @param itemClickListener items的监听
     * @return 创建的 Dialog对象
     */
    public static Dialog showItemsDialog(Context context, String title, String[] items, View v,
                                         final AdapterView.OnItemClickListener itemClickListener) {
        OptionTitleDialog dialog = OptionTitleDialog.Builder(context, title, items, v, itemClickListener);
        dialog.show();
        return dialog;
    }

    /**
     * 显示一个菜单选项的Dialog
     * @param context
     * @param title Dialog的标题
     * @param items 菜单栏的items
     * @param v  触发显示的View
     * @param itemClickListener items的监听
     * @return 创建的 Dialog对象
     */
    public static Dialog showItemsDialog(Context context, String title, String[] items, View v,
                                         final AdapterView.OnItemClickListener itemClickListener, final DialogInterface.OnDismissListener dismissListener) {
        OptionTitleDialog dialog = OptionTitleDialog.Builder(context, title, items, v, itemClickListener,
                dismissListener);
        dialog.show();
        return dialog;
    }
}



