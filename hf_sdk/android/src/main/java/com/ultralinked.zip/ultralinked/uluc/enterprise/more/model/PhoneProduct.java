package com.ultralinked.uluc.enterprise.more.model;

import java.io.Serializable;

/**
 * Created by lly on 2016/12/21.
 */

public class PhoneProduct implements Serializable {
    private String product_id;
    private String saled_at;
    private String created_at;
    private String description;
    private String phone_no;
    private String country_code;
    private String price;
    private String owner_id;
    private String expired_at;
    private String no_with_plus;

    public PhoneProduct(String phone_no,String no_with_plus){
        this.phone_no = phone_no;
        this.no_with_plus = no_with_plus;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getSaled_at() {
        return saled_at;
    }

    public void setSaled_at(String saled_at) {
        this.saled_at = saled_at;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getOwner_id() {
        return owner_id;
    }

    public void setOwner_id(String owner_id) {
        this.owner_id = owner_id;
    }

    public String getEasyNo(){
        return phone_no.substring(country_code.length());
    }

    public String getExpired_at() {
        return expired_at;
    }

    public void setExpired_at(String expired_at) {
        this.expired_at = expired_at;
    }

    public String getNo_with_plus() {
        return no_with_plus;
    }

    public void setNo_with_plus(String no_with_plus) {
        this.no_with_plus = no_with_plus;
    }
}
