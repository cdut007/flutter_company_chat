package com.ultralinked.uluc.enterprise.pay;

import java.io.Serializable;

/**
 * Created by lly on 2016/12/9.
 */

public class RechargeRecordModel implements Serializable{

    private String payment_id;
    private String created_at;
    private String payment_providerid;
    private String payment_success;
    private String payment_value;
    private String product_type;
    private String direction;

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getPayment_providerid() {
        return payment_providerid;
    }

    public void setPayment_providerid(String payment_providerid) {
        this.payment_providerid = payment_providerid;
    }

    public String getPayment_success() {
        return payment_success;
    }

    public void setPayment_success(String payment_success) {
        this.payment_success = payment_success;
    }

    public String getPayment_value() {
        return payment_value;
    }

    public void setPayment_value(String payment_value) {
        this.payment_value = payment_value;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
}
