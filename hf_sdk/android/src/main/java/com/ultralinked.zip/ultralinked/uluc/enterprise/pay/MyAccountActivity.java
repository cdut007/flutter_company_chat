package com.ultralinked.uluc.enterprise.pay;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tendcloud.tenddata.TCAgent;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.baseui.widget.CustomListPopup;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.more.CallRecordsActivity;
import com.ultralinked.uluc.enterprise.more.DedicatedNumberActivity;
import com.ultralinked.uluc.enterprise.more.model.PhoneProduct;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func2;
import rx.schedulers.Schedulers;

/**
 * Created by ulpc1 on 2016/11/2.
 */

public class MyAccountActivity extends BaseActivity implements View.OnClickListener{

    TextView mAccountBalance, mTitleRight;
    RecyclerView mRecycler;
    AccountAdapter adapter;
    CustomListPopup mListPopup;
    PhoneProduct renewProduct;

    List<PhoneProduct> boughtNumbers;
    SparseIntArray quantities;

    Subscription mRechargeSubscription;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_my_account;
    }




    @Override
    public void initView(Bundle savedInstanceState) {

        createRechargeSubscription();
        TCAgent.onPageStart(getActivity(),"我的账户");
//
        mAccountBalance = bind(R.id.txt_account_balance);
        mRecycler = bind(R.id.recycler_my_account);
        ImageUtils.buttonEffect(bind(R.id.linear_recharge_account));
        ImageUtils.buttonEffect(bind(R.id.linear_call_details));
        initListener(this, R.id.linear_recharge_account, R.id.linear_dedicated_number, R.id.linear_balance_transfer, R.id.linear_transaction_records, R.id.linear_call_details);

        quantities = new SparseIntArray(5);
        quantities.put(0, 1);
        quantities.put(1, 2);
        quantities.put(2, 3);
        quantities.put(3, 6);
        quantities.put(4, 12);
//        mRateText = bind(R.id.txt_exchange_rate);

//        getAccountBalance();
        getNetworkInfo();
    }

    @Override
    protected void setTopBar() {
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.my_account);
        bind(R.id.titleRight).setVisibility(View.GONE);
//        mTitleRight = bind(R.id.titleRight);
//        mTitleRight.setText("");
//        Drawable drawable = getResources().getDrawable(R.mipmap.history_icon);
//        int iconSize = getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_20_0_dp);
//        drawable.setBounds(0, 0, iconSize, iconSize); //设置边界
//        mTitleRight.setCompoundDrawables(null, null, drawable, null);//画在右边
//        ImageUtils.buttonEffect(mTitleRight);
//        mTitleRight.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                this.finish();
                break;
            case R.id.linear_transaction_records:
                startActivity(new Intent(this, TransactionRecordsActivity.class));
                break;
            case R.id.linear_recharge_account:
                startActivity(new Intent(this, RechargeActivity.class));
                break;
            case R.id.linear_dedicated_number:
                startActivity(new Intent(this, DedicatedNumberActivity.class));
                break;
            case R.id.linear_balance_transfer:
                startActivity(new Intent(this, BalanceTransferActivity.class));
                break;
            case R.id.linear_call_details:
                startActivity(new Intent(this, CallRecordsActivity.class));
                break;
        }
    }

    @Override
    protected void onDestroy() {
        if (mRechargeSubscription != null && !mRechargeSubscription.isUnsubscribed()) {
            mRechargeSubscription.unsubscribe();
        }
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"我的账户");
    }

    private void createRechargeSubscription() {
        if (mRechargeSubscription == null) {
            mRechargeSubscription = RxBus.getDefault().toObservable(String.class)
                    .subscribe(new Action1<String>() {
                        @Override
                        public void call(String text) {
                            if (text.equals(PaymentActivity.PAYMENT_SUCCESS)) {
                                getNetworkInfo();
                            }
                        }
                    }, new Action1<Throwable>() {
                        @Override
                        public void call(Throwable throwable) {
                            Log.e(TAG, "Recharge subscription error!");
                        }
                    });
        }
    }

    private void getNetworkInfo(){
        showDialog(getString(R.string.loading));
        Observable.zip(ApiManager.getInstance().getAccountBalance(), ApiManager.getInstance().getBoughtPhoneProductList(), new Func2<ResponseBody, ResponseBody, String>() {
            @Override
            public String call(ResponseBody responseBody, ResponseBody responseBody2) {
                String result = "";
                try {
                    String response = responseBody.string();
                    JSONObject object = new JSONObject(response);
                    if (object.optInt("code") == 200) {
                        result = object.optString("result");
                    } else {
                        Log.e(TAG, "errorcode:" + object.optInt("code"));
                    }

                    String response2 = responseBody2.string();
                    Log.e(TAG, response);
                    boughtNumbers = new Gson().fromJson(response2, new TypeToken<List<PhoneProduct>>() {
                    }.getType());
                    if(boughtNumbers!=null&&boughtNumbers.size()>0){
                        for(PhoneProduct product:boughtNumbers){
                            product.setNo_with_plus(PhoneNumberUtils.formatNumber(PhoneNumberUtils.formatMobile(product.getPhone_no())));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, android.util.Log.getStackTraceString(e));
                }
                return result;
            }
        })
                .compose(this.<String>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getNetworkInfo success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getNetworkInfo fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(String response) {
                        mAccountBalance.setText(String.format(getString(R.string.account_balance), response));
                        if(boughtNumbers!=null&&boughtNumbers.size()>0){
                            if(adapter == null){
                                mRecycler.setLayoutManager(new LinearLayoutManager(MyAccountActivity.this));
                                mRecycler.addItemDecoration(new DividerLinearDecoration(MyAccountActivity.this, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_10_0_dp, R.dimen.px_0_0_dp));
                                adapter = new AccountAdapter(MyAccountActivity.this, boughtNumbers);
                                mRecycler.setAdapter(adapter);
                            }else{
                                adapter.updateData(boughtNumbers);
                                adapter.notifyDataSetChanged();
                            }
                        }
                    }
                });
    }

    private void getAccountBalance() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getAccountBalance()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "getAccountBalance success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getAccountBalance fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            JSONObject object = new JSONObject(response);
                            if (object.optInt("code") == 200) {
                                mAccountBalance.setText(String.format(getString(R.string.account_balance), object.optString("result")));
                            } else {
                                Log.e(TAG, "errorcode:" + object.optInt("code"));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    private void showPopup(int type, List<String> list) {
        if (mListPopup == null) {
            mListPopup = new CustomListPopup(this, type, list);
            mListPopup.setOnConfirmListener(new CustomListPopup.OnSingleConfirmListener() {
                @Override
                public void onConfirmClick(int position) {
                    if(renewProduct!=null) {
                        float price = Float.parseFloat(renewProduct.getPrice());
                        int quantity = quantities.get(position);
                        ProductInfo info = new ProductInfo(renewProduct.getProduct_id(), price*quantity+"", "renew", quantity+"");
                        startActivity(new Intent(MyAccountActivity.this, PaymentActivity.class).putExtra("product", info));
                    }
                }
            });
            mListPopup.showAtLocation(mAccountBalance, Gravity.BOTTOM, 0, 0);
        } else {
            mListPopup.setPopup(type, list);
            mListPopup.showAtLocation(mAccountBalance, Gravity.BOTTOM, 0, 0);
        }
    }

    private List<String> getQuantityList(String sPrice) {
        List<String> quantityList = new ArrayList<>();
        float price = Float.parseFloat(sPrice);
        quantityList.add(getString(R.string.one_month) + " —— U.S.$" + price);
        quantityList.add(getString(R.string.two_month) + " —— U.S.$" + price * 2);
        quantityList.add(getString(R.string.three_month) + " —— U.S.$" + price * 3);
        quantityList.add(getString(R.string.six_month) + " —— U.S.$" + price * 6);
        quantityList.add(getString(R.string.one_year) + " —— U.S.$" + price * 12);
        return quantityList;
    }

    class AccountAdapter extends BaseRecyclerAdapter<PhoneProduct,RecyclerViewHolder>{

        public AccountAdapter(Context ctx, List<PhoneProduct> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext,itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_my_account;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, final int position, final PhoneProduct itemData) {
            holder.getTextView(R.id.txt_item_dedicated_number).setText(itemData.getNo_with_plus());
            String expiredTime = itemData.getExpired_at();
            holder.getTextView(R.id.txt_item_expired_time).setText(TextUtils.isEmpty(expiredTime)?"":String.format(getString(R.string.expired_time),expiredTime));
            holder.getTextView(R.id.btn_renew).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    renewProduct = itemData;
                    showPopup(0,getQuantityList(itemData.getPrice()));
                }
            });
        }
    }

}
