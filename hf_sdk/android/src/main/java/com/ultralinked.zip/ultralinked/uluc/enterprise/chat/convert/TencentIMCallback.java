package com.ultralinked.uluc.enterprise.chat.convert;

import com.ultralinked.voip.api.NetRtcXMPPCallbackImpl;

/**
 * Created by mac on 17/1/4.
 */

public class TencentIMCallback extends NetRtcXMPPCallbackImpl {
}
