package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

/**
 * Created by mac on 16/10/19.
 */

public interface RequestFriendListener {
    void callFriendRequest(String action,PeopleEntity peopleEntity);
    void onFriendStatusChanged(PeopleEntity peopleEntity);
}
