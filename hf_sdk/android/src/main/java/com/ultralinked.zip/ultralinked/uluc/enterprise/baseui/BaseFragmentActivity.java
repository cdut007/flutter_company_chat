package com.ultralinked.uluc.enterprise.baseui;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.chatim.BaseChatImFragment;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public abstract class BaseFragmentActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return R.layout.main_fragment_container;
    }



    private BaseFragment mFragment;
    public BaseFragment getFragment() {
        return mFragment;
    }

    public Fragment setFragment(Class<?> className, Bundle bundle) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        mFragment = (BaseFragment) getFragmentByTag(this, bundle, className);
        fragmentTransaction.replace(R.id.main_fragment_container, mFragment,className.getName());
        fragmentTransaction.setCustomAnimations(R.anim.left_in,R.anim.left_out);
        fragmentTransaction.commit();
        return mFragment;
    }
}
