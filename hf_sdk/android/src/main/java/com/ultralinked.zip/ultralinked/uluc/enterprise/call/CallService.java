package com.ultralinked.uluc.enterprise.call;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.IBinder;
import android.support.v7.app.NotificationCompat;
import android.text.TextUtils;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.GlideCircleTransform;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;


public class CallService extends Service {

    private  static String TAG = "CallService";

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }


    Intent startFromCallIntent;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "onStartCommand");

        startFromCallIntent = intent;

        flags = START_STICKY_COMPATIBILITY|START_FLAG_REDELIVERY;

        if (startFromCallIntent == null){
            return super.onStartCommand(intent, flags, startId);
        }

        startFromCallIntent.setClass(this, IncallActivity.class);
        startFromCallIntent.putExtra("from_notification",true);

        String callName = startFromCallIntent.getStringExtra("displayName");

        setNotifationWithLargeBitmap(BitmapFactory.decodeResource(getResources(),ImageUtils.getDefaultContactImageResource(callName)));

        loadImageIcon(startFromCallIntent.getStringExtra("display_icon_url"),callName);

        return super.onStartCommand(intent, flags, startId);

    }

    void setNotifationWithLargeBitmap(Bitmap icon){

        String callName = startFromCallIntent.getStringExtra("displayName");

        PendingIntent pendingintent = PendingIntent.getActivity(this, 0,
                startFromCallIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle(App.getInstance().getString(R.string.call_message))
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(false)
                .setContentIntent(pendingintent)
                .setWhen(System.currentTimeMillis())
                .setLargeIcon(icon)
                .setContentText(App.getInstance().getString(R.string.calling_notification_message,callName))
                .setOngoing(true)
                .setSmallIcon(com.holdingfuture.flutterapp.hfsdk.R.mipmap.logo)
                .setTicker(App.getInstance().getString(R.string.call_message));

        Notification notification = builder.build();
        notification.flags = Notification.FLAG_ONGOING_EVENT
                | Notification.FLAG_NO_CLEAR;
        startForeground(0x111, notification);

    }


    void loadImageIcon(String url,String identify){
        if (!TextUtils.isEmpty(url)) {

            Glide.with(App.getInstance()).load(url).asBitmap().error(ImageUtils.getDefaultContactImageResource(identify)).transform(new GlideCircleTransform(App.getInstance())).into(new SimpleTarget<Bitmap>() {
                @Override
                public void onStart() {
                    super.onStart();
                }

                @Override
                public void onLoadStarted(Drawable placeholder) {
                    super.onLoadStarted(placeholder);
                }

                @Override
                public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                    Log.i(TAG," onResourceReady~~");
                    setNotifationWithLargeBitmap(resource);

                }

                @Override
                public void onLoadFailed(Exception e, Drawable errorDrawable) {
                    super.onLoadFailed(e, errorDrawable);
                    if (e!=null){

                        Log.i(TAG," onLoadFailed~~"+ android.util.Log.getStackTraceString(e));
                    }else{
                        Log.i(TAG," onLoadFailed~~");
                    }

                }

                @Override
                public void onStop() {
                    super.onStop();

                }
            });



        }
    }

    //	Device don't have mac address or wi-fi is disabled
    @Override
    public void onCreate() {

        super.onCreate();
        stopForeground(true);
        Log.i(TAG, "~onCreate~");

    }


    @Override
    public void onDestroy() {

        super.onDestroy();

    }


}
