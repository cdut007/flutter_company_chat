package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.content.ContentValues;
import android.content.Context;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.StrangerContract;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Log;

/**
 * Created by ultralinked on 16/8/12.
 */
public class DetailHelper {


    public static void save_FRIEND_(PeopleEntity item) {

        ContentValues value = DbSQLHelper.assignValues(item);
        if (!PeopleEntityQuery.getInstance().isFriend(item.subuser_id)){
            App.getInstance().getContentResolver().insert(FriendContract.CONTENT_URI, value);
        }

    }


    public static void update_FRIEND_(PeopleEntity item) {

        ContentValues value = DbSQLHelper.assignValues(item);
        String sql = " DELETE  FROM  " + FriendContract.TABLE_NAME + " WHERE " + FriendContract.FriendColumn.SUBUSER_ID
                + " = '" + item.subuser_id + "' ";
        SqliteUtils.getInstance(App.getInstance()).getDb().execSQL(sql);
        App.getInstance().getContentResolver().insert(FriendContract.CONTENT_URI, value);

    }


    public static void del_FRIEND(Context context, PeopleEntity entity) {

        String sql = " DELETE  FROM  " + FriendContract.TABLE_NAME + " WHERE " + FriendContract.FriendColumn.SUBUSER_ID
                + " = '" + entity.subuser_id + "' ";

        SqliteUtils.getInstance(context).getDb().execSQL(sql);

        save_STRANGER_(entity);

        del_PRIVATE(context,entity.subuser_id);

        RequestFriendManager.deletePerson(entity);

    }

    public static void del_STRANGER(Context context, String subuser_id) {

        String sql = " DELETE  FROM  " + StrangerContract.TABLE_NAME + " WHERE " + StrangerContract.StrangerColumn.SUBUSER_ID
                + " = '" + subuser_id + "' ";

        SqliteUtils.getInstance(context).getDb().execSQL(sql);

    }

    public static void save_STRANGER_(PeopleEntity item) {

        ContentValues value = DbSQLHelper.assignValues(item);

        del_STRANGER(App.getInstance(),item.subuser_id);//delete first.
        App.getInstance().getContentResolver().insert(StrangerContract.CONTENT_URI, value);

    }


    public static void save_PRIVATE_(PeopleEntity item) {
        if (TextUtils.isEmpty(item.subuser_id)){
            Log.i("save_PRIVATE_","userId is null");
            return;
        }
        ContentValues value = DbSQLHelper.assignValues(item);
        del_PRIVATE(App.getInstance(),item.subuser_id);//delete first.
        App.getInstance().getContentResolver().insert(PrivateContract.CONTENT_URI,value);
    }


    public static void del_PRIVATE(Context context, String subuser_id) {

        String sql = " DELETE  FROM  " + PrivateContract.TABLE_NAME + " WHERE " + PrivateContract.PrivateColumn.SUBUSER_ID
                + " = '" + subuser_id + "' ";

        SqliteUtils.getInstance(context).getDb().execSQL(sql);

    }


}
