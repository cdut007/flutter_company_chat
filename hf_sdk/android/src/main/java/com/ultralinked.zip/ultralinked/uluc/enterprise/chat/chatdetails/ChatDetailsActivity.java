package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.content.Intent;
import android.os.Bundle;

import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public class ChatDetailsActivity extends BaseFragmentActivity {


    @Override
    public void initView(Bundle savedInstanceState) {

        Bundle bundle = getIntent().getBundleExtra(Constants.DATA_KEY);
        boolean isGroup = bundle.getBoolean("isGroup");
        Class<?> className = isGroup ? GroupChatDetailsFragment.class : SingleChatDetailsFragment.class;
        setFragment(className, bundle);

    }

    /**
     *
     * @param fragment
     * @param conversationId
     * @param userId if is singleChat, groupchat set null.
     * @param isGroup
     * @param requestCode
     */
    public static void launchActivityForResult(BaseFragment fragment, int conversationId, String userId, boolean isGroup, int requestCode) {
        Intent i = new Intent(fragment.getActivity(), ChatDetailsActivity.class);
        Bundle data = new Bundle();
        data.putBoolean("isGroup", isGroup);
        data.putInt("conversation_id",conversationId);
        data.putString("user_id", userId);
        i.putExtra(Constants.DATA_KEY, data);
        fragment.startActivityForResult(i, requestCode, data);
    }

}
