package com.ultralinked.uluc.enterprise.login;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.baseui.widget.OTPButton;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.Locale;

/**
 * Created by ultralinked on 2016/7/1 0001.
 */
public class CreateWithCompanyFragment extends BaseFragment implements View.OnClickListener,LoginView {

    EditText etCompanName;
    EditViewPlus etMobile;
    OTPButton btRequestOTP;
    EditText etOTP;

    LoginPresenter presenter;

    private Button btSignup;
    private LoginActivity activity;
    private int requestCode=1;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (LoginActivity) context;
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.fragment_create_with_company;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        btSignup = bind(R.id.btSignup);
        etOTP=bind(R.id.etOTP);
        etMobile =bind(R.id.customEt);
        etMobile.setHint(activity.getString(R.string.hint_mobile));

        etMobile.setCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
            }
        });


        etCompanName =bind(R.id.company);
        btRequestOTP = bind(R.id.btRequestOTP);
        initListener(this, btSignup, etMobile,btRequestOTP);
        detectMobile();
    }

    private void detectMobile() {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();

        try {

            TelephonyManager mTelephonyMgr;
            mTelephonyMgr = (TelephonyManager)getActivity().getSystemService(Context.TELEPHONY_SERVICE);
            String  number = mTelephonyMgr.getLine1Number();
            Log.i("signup","get mobile number: " + number);
            // phone must begin with '+'
            String currentLanguage = Locale.getDefault().getLanguage();
            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(number,currentLanguage);
            int countryCode = numberProto.getCountryCode();
            if (countryCode>-1){
                etMobile.setCountryCode("+"+countryCode);
            }
            number = numberProto.getNationalNumber()+"";
            etMobile.setMobile(number);

        } catch (Exception e) {
            Log.i("signup","NumberParseException was thrown: " + android.util.Log.getStackTraceString(e));
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        presenter=new LoginPresenter(this,activity);
        Log.i(TAG);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.customEt:
                Intent intent = new Intent(activity, CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
                break;
            case R.id.btRequestOTP:

                requestOTP(SPUtil.getCode() + SPUtil.getMobile());
                break;
            case R.id.btSignup:
                initSignup(SPUtil.getCode() + SPUtil.getMobile(),etOTP.getText().toString(),etCompanName.getText().toString());
                break;
        }
    }

    private void requestOTP(final String mobile){
        if(!NetUtil.isNetworkAvailable(activity)){
            showToast(activity.getString(R.string.check_network));
            return;
        }
        if(!RegexValidateUtils.checkCellphone(mobile)){
            showToast(R.string.error_mobile);
            return;
        }

        btRequestOTP.click(new OTPButton.OnRequestTypeListener() {
            @Override
            public void clickType(String type) {
                currentType = type;
                presenter.otpRequest(mobile,"otp_regist_company",type);
            }
        });
        requestCode=1;

    }

    String currentType;

    private void initSignup(String mobile, String otp,String company) {

        if(!NetUtil.isNetworkAvailable(activity)){
            showToast(activity.getString(R.string.check_network));
            return;
        }
//        if(!RegexValidateUtils.checkCellphone(mobile)){
//            showToast(R.string.error_mobile);
//            return;
//        }



        if (TextUtils.isEmpty(company) || TextUtils.isEmpty(company.trim())){

            showToast(R.string.error_company);
            try {
                bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        if (TextUtils.isEmpty(otp) || TextUtils.isEmpty(otp.trim())){

            showToast(R.string.please_enter_otp);
            try {
                bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            } catch (Exception e) {
                e.printStackTrace();
            }

            return;
        }


        requestCode=2;
        presenter.otpCreateCompany(mobile,company,otp);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG,requestCode+"  "+resultCode);
        if(data!=null)
            etMobile.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void loginSuccess() {
        activity.hideDialog();
        if(requestCode==1){
            if ("voice".equals(currentType)){
                showToast(activity.getString(R.string.voice_sms_code_has_sent_you));

            }else{
                showToast(activity.getString(R.string.message_has_sent_you).substring(0,activity.getString(R.string.message_has_sent_you).indexOf("%s"))+"+"+SPUtil.getCode() +SPUtil.getMobile());

            }

        }else{
//            SPUtil.saveUserHasCompany(true);
            if (MainActivity.instance!=null){
                MainActivity.instance.getDepartment();
            }
            if(activity instanceof SignupActivity){
                ((SignupActivity)activity).setResultAndFinish(Activity.RESULT_OK);
            }
        }

    }

    @Override
    public void loginError(String msg) {
       if (requestCode == 1){
           btRequestOTP.cancelCountDown();
       }else{
           try {
               bind(R.id.btSignup).startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
           } catch (Exception e) {
               e.printStackTrace();
           }
       }
        activity.showToast(msg);
    }

    @Override
    public void showDialog() {
        activity.showDialog();
    }

    @Override
    public void hideDialog() {
        activity.hideDialog();
    }
}
