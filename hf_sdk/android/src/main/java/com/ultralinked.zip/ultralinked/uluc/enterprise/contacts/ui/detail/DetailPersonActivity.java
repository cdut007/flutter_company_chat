package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.moments.activity.UserFeedActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.holdingfuture.flutterapp.hfsdk.R.string.remove_private_contact_ok;


public class DetailPersonActivity extends BaseActivity {
    public static final String TAG = "DetailPerson";
    public static final String KEY_DETAIL_ENTITY = "key2getdataforshow";

    private TextView titleCenter;
    private TextView titleRight;
    private  ImageView sex;
    private PeopleEntity mDetailEntity;


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_detail_person;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.activity_detail_person);

        mDetailEntity = getIntent().getParcelableExtra(KEY_DETAIL_ENTITY);
        if (mDetailEntity == null){
            finish();
            return;
        }else{
            if (mDetailEntity.relation == PeopleEntity.STRANGER && !SPUtil.getFindContactsSetting()){//maybe is need accpeted,later check it?
                //invite again.
                if (!SPUtil.isAssistant(mDetailEntity.subuser_id)){
                    Intent intent = new Intent(this, AddNewFriendActicity.class);
                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY,mDetailEntity);
                    startActivity(intent);
                    finish();
                    return;
                }

            }

        }
        initview();
        initTitleBar();
        initCall();
        LocalBroadcastManager.getInstance(this).registerReceiver(personInfoChangedReceiver, new IntentFilter(RemarkSettingActivity.ACTION_DETAIL_PERSON_INFO_CHANGED));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(personInfoChangedReceiver);
    }

    BroadcastReceiver personInfoChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            PeopleEntity peopleEntity = intent.getParcelableExtra(DetailPersonActivity.KEY_DETAIL_ENTITY);
            if (peopleEntity!=null){
                if (mDetailEntity.subuser_id.equals(peopleEntity.subuser_id)){
                    detailNameInput.setText(PeopleEntityQuery.getDisplayName(peopleEntity));
                }
            }
        }
    };


    Button btnChat, btnCall;

    protected void initCall() {
        btnCall = (Button) findViewById(R.id.btnCall);
        btnChat = (Button) findViewById(R.id.btnChat);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Observable.create(new Observable.OnSubscribe() {
                    @Override
                    public void call(Object o) {
                        String displayName = PeopleEntityQuery.getDisplayName(mDetailEntity);
                        Log.i(TAG, String.format("incall name=%s icon=%s", displayName, mDetailEntity.icon_url));
                       CallDialog callDialog =  CallDialog.getInstance(mDetailEntity.mobile, displayName, mDetailEntity.icon_url);

                        callDialog.setCallUserId(mDetailEntity.subuser_id);
                        callDialog.show(getFragmentManager(), "call_dialog");
                    }
                }).throttleFirst(2, TimeUnit.SECONDS).subscribe();
            }
        });

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Conversation conversation = MessagingApi.getConversation(mDetailEntity.subuser_id);
                if (conversation == null) {
                    Log.i(TAG, "userid:" + mDetailEntity.subuser_id);
                    return;
                }

                SingleChatImActivity.launchToSingleChatIm(DetailPersonActivity.this, mDetailEntity.subuser_id, conversation.conversationFlag);
            }
        });
    }


    private ImageView detailHeadInput;

    private EditText detailNameInput, detailMobileInput, detailCompanyInput, detailDeptInput, detailEmailInput;


    private void initview() {
        detailHeadInput = (ImageView) findViewById(R.id.detailHeadInput);
        detailNameInput = (EditText) findViewById(R.id.detailNameInput);
        detailMobileInput = (EditText) findViewById(R.id.detailMobileInput);

        detailCompanyInput = (EditText) findViewById(R.id.detailCompanyInput);
        detailDeptInput = (EditText) findViewById(R.id.detailDeptInput);
        detailEmailInput = (EditText) findViewById(R.id.detailEmailInput);

        findViewById(R.id.detail_feed_layout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UserFeedActivity.go2FeedPage(DetailPersonActivity.this,mDetailEntity);

            }
        });

        sex = bind(R.id.sex);
        if ("0".equals(mDetailEntity.gender)){
            sex.setImageResource(R.mipmap.female);
        }else {
            sex.setImageResource(R.mipmap.male);
        }

        ImageUtils.loadCircleImage(this, detailHeadInput, mDetailEntity.icon_url, ImageUtils.getDefaultContactImageResource(mDetailEntity.subuser_id));

        detailNameInput.setText(PeopleEntityQuery.getDisplayName(mDetailEntity));
        detailMobileInput.setText(PhoneNumberUtils.formatMobile(mDetailEntity.mobile));
        detailCompanyInput.setText(mDetailEntity.companyName);
        //here show the current department name, not all
        detailDeptInput.setText(mDetailEntity.deparment_name);

        if (mDetailEntity.email == null||mDetailEntity.email.equals("null")){
            detailEmailInput.setText("");
        }else{
            if (!TextUtils.isEmpty(mDetailEntity.email)){
                detailEmailInput.setText(mDetailEntity.email);
            }else{
                detailEmailInput.setText("");
            }

        }


//        String companyId = mDetailEntity.companyid;
//
//        if (TextUtils.isEmpty(companyId)){
//                companyId = CompanySelector.getInstance(this).getCompanyID();
//        }
//        //get all the depart name belongs to
//        String sql = " SELECT * FROM " + RelationContract.TABLE_NAME +
//                " WHERE  " + RelationContract.RelationColumn.USER_ID + " = '" + mDetailEntity.subuser_id
//                + "' " + " AND " + RelationContract.RelationColumn.COMPANY_ID + " = '"+companyId+"'";
//        Cursor curor = SqliteUtils.getInstance(this).getDb().rawQuery(sql, null);
//        if (curor == null || curor.getCount() == 0) {
//            if (curor != null && !curor.isClosed()) {
//
//                curor.close();
//            }
//            return;
//        }
//        StringBuilder companys = new StringBuilder();
//        StringBuilder sb = new StringBuilder();
//        curor.moveToFirst();
//        do {
//
//            sb.append(curor.getString(curor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_NAME)));
//            sb.append(",");
//
//            if (TextUtils.isEmpty(companys)){//only one
//                companys.append(curor.getString(curor.getColumnIndex(RelationContract.RelationColumn.COMPANY_NAME)));
//            }
//
//        } while (curor.moveToNext());
//
//        if (curor != null || !curor.isClosed()) {
//            curor.close();
//        }
//        sb.deleteCharAt(sb.length() - 1);
//        String multiple_departname = sb.toString();
//        detailDeptInput.setText(multiple_departname);
//
//        if (TextUtils.isEmpty(mDetailEntity.companyName) && companys.length()>0){
//            //companys.deleteCharAt(companys.length() - 1);
//            String multiple_companyName = companys.toString();
//            detailCompanyInput.setText(multiple_companyName);
//        }




    }

    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.detail_contact_contacts));


        titleRight = (TextView) findViewById(R.id.titleRight);

        boolean isAssistant = SPUtil.isAssistant(mDetailEntity.subuser_id);
        if (isAssistant){
            titleRight.setVisibility(View.GONE);
        }else{
            titleRight.setVisibility(View.VISIBLE);
        }

        //titleRight.setText(R.string.detail_contact_edit);
        titleRight.setText("");
        ImageUtils.buttonEffect(titleRight);

        titleRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               DetailPersionSettingActivity.gotoSettingDetailPersonActivity(DetailPersonActivity.this,mDetailEntity);

            }
        });
        setDetailImage();
        InputControlEnable(false);
    }

    private void setDetailImage() {

        titleRight.setText("");
        try{
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) titleRight.getLayoutParams();
            layoutParams.rightMargin = ScreenUtils.dp2px(this,0);
            titleRight.setLayoutParams(layoutParams);
        }catch (Exception e){
            e.printStackTrace();
        }
        Drawable drawable = getResources().getDrawable(R.mipmap.details_icon);
        int iconSize = getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_24_0_dp);
        drawable.setBounds(0, 0, iconSize, iconSize); //设置边界
        titleRight.setCompoundDrawables(null, null, drawable, null);//画在右边
        ImageUtils.buttonEffect(titleRight);
    }

    private void InputControlEnable(boolean enable) {

        detailNameInput.setEnabled(enable);
        detailMobileInput.setEnabled(enable);
        detailCompanyInput.setEnabled(enable);
        detailDeptInput.setEnabled(enable);
        detailEmailInput.setEnabled(enable);

        if (enable) {
            //显示虚拟键盘
            InputMethodManager imm = (InputMethodManager) detailNameInput.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

            imm.showSoftInput(detailNameInput, InputMethodManager.SHOW_FORCED);

            detailNameInput.requestFocus();
        } else {
            InputMethodManager imm = (InputMethodManager) detailNameInput.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm.isActive()) {
                imm.hideSoftInputFromWindow(detailNameInput.getApplicationWindowToken(), 0);
            }
        }
    }

    public static void gotoDetailPersonActivity(Context context, PeopleEntity clickedSource) {

        Intent intent = new Intent(context, DetailPersonActivity.class);
        intent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY, clickedSource);
        context.startActivity(intent);
    }




    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
