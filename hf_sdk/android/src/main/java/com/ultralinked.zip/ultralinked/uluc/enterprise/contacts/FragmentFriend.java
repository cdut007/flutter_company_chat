package com.ultralinked.uluc.enterprise.contacts;


import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.ultralinked.uluc.enterprise.baseui.widget.ULListView;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.chat.group.GroupChatListActivity;
import com.ultralinked.uluc.enterprise.common.PasswordLockerHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;

import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.secret.SecretActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class FragmentFriend extends BaseFragment implements View.OnClickListener, ReadFriendContactTask.onContactReadFinishListener {


    private ReadFriendContactTask mReadContactTask;
    private String mSearchWord;

    private static final int LOADER_ID = 0x24;

    private ULListView mFriendListView;

    private static final String TAG = "FragmentFriend";

    private FriendAdapter friendAdapter;

    private ContentObserver contactChangeObserver;

    @Override
    public int getRootLayoutId() {
        return R.layout.contacts_friend_layout;
    }


    View newFriendBtn;
    View groupChatBtn;
  //  TextView secretBtn;

    EditText mSearch_edittext;

    BaseActivity baseActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        baseActivity = (BaseActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadFriendData();
    }


    private void loadFriendData() {


        if (mReadContactTask != null) {

            mReadContactTask.resetLoader(null);

        }
    }

    @Override
    public void initView(Bundle savedInstanceState) {




        mFriendListView = bind(R.id.friend_list_view);


        initListView();


        initListener(this, R.id.searchParent);

        initListener(this,groupChatBtn, newFriendBtn);



        mSearch_edittext = bind(R.id.search_edittext);
        mSearch_edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (mReadContactTask != null) {

                    if (TextUtils.isEmpty(s)) {
                        mSearchWord = "";
                        mReadContactTask.resetLoader(null);
                    } else {
                        mSearchWord = s.toString();
                        mReadContactTask.resetLoader(mSearchWord);
                    }

                }
                //todo:expand the list

            }
        });



    }


    private SideBar indexBar;
    private TextView mDialogText;
    private WindowManager mWindowManager;
    private  TextView contactheaderCatalog;

    private  int mCurrentPosition = -1;

    int mSuspensionHeight;

    private void initListView() {
        mWindowManager = (WindowManager) getActivity()
                .getSystemService(Context.WINDOW_SERVICE);

        mDialogText = (TextView) LayoutInflater.from(getActivity()).inflate(
                R.layout.side_bar_list_position, null);
        mDialogText.setVisibility(View.INVISIBLE);
        indexBar = bind(R.id.sideBar);
        contactheaderCatalog = bind(R.id.contactheader_catalog);

        indexBar.setListView(mFriendListView,true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        try{
            mWindowManager.addView(mDialogText, lp);
            indexBar.setTextView(mDialogText);
        }catch (Exception e){
            e.printStackTrace();
        }

        View layout_head = getActivity().getLayoutInflater().inflate(
                R.layout.contacts_top_header, null);
        mFriendListView.addHeaderView(layout_head);
        goneView(layout_head.findViewById(R.id.organization));

        newFriendBtn = layout_head.findViewById(R.id.new_contact);
        TextView textView = (TextView) newFriendBtn.findViewById(R.id.new_contact_text);
        textView.setText(R.string.new_friend);
        groupChatBtn = layout_head.findViewById(R.id.group_chat);

        //set effect
        ImageUtils.buttonEffect(newFriendBtn);
        ImageUtils.buttonEffect(groupChatBtn);

        friendAdapter = new FriendAdapter(getActivity());
        mFriendListView.setAdapter(friendAdapter);


        mFriendListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PeopleEntity entity = (PeopleEntity) parent.getItemAtPosition(position);
                DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);

            }
        });



        mFriendListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                mSuspensionHeight = contactheaderCatalog.getHeight();
                if (mFriendListView.getChildCount() == 0){
                    mCurrentPosition=-1;
                    contactheaderCatalog.setY(-contactheaderCatalog.getHeight());
                    return;
                }
                View firstView = mFriendListView.getChildAt(0);
                TextView catalogView = (TextView) firstView.findViewById(R.id.contactitem_catalog);
                if (catalogView==null){
                    mCurrentPosition=-1;
                    contactheaderCatalog.setY(-contactheaderCatalog.getHeight());
                    return;
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

                if (mFriendListView.getChildCount() == 0){
                    mCurrentPosition=-1;
                    contactheaderCatalog.setY(-contactheaderCatalog.getHeight());
                    return;
                }

                View firstView = mFriendListView.getChildAt(0);
                TextView catalogView = (TextView) firstView.findViewById(R.id.contactitem_catalog);

                if (catalogView!=null){

                    if (catalogView.getVisibility() == View.GONE){
                        contactheaderCatalog.setY(0);
                        contactheaderCatalog.setText(catalogView.getText());
                        visibleView(contactheaderCatalog);
                    }else{


                        if (firstView.getTop() <= mSuspensionHeight) {

                            contactheaderCatalog.setY(-(mSuspensionHeight - firstView.getTop()));
                        } else {
                            mCurrentPosition = firstVisibleItem;
                            contactheaderCatalog.setY(0);
                        }
                        contactheaderCatalog.setText(catalogView.getText());
                        visibleView(contactheaderCatalog);
                    }
                }


            }
        });

//        mFriendListView.setScrollChangeListener(new ULListView.OnScrollChangeListener() {
//            @Override
//            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
//
//
//            }
//        });




    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mReadContactTask = new ReadFriendContactTask(getActivity(), LOADER_ID);
        mReadContactTask.registerListener(this);
        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, mReadContactTask.getLoader());


        Uri uri = FriendContract.CONTENT_URI;
        contactChangeObserver = new ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri,true,contactChangeObserver);
    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
    }



    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }
        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG,"contact hasChanged..");
            loadFriendData();
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();

      try {
          mWindowManager.removeView(mDialogText);
      }catch (Exception e){
          e.printStackTrace();
      }

        mReadContactTask.unregisterListener(getContext());
        getActivity().getSupportLoaderManager().destroyLoader(LOADER_ID);
        if (contactChangeObserver!=null){
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {


            case R.id.new_contact:

            {
                startActivity(new Intent(getActivity(),NewFriendActicity.class));
            }
                break;
            case R.id.group_chat:
                GroupChatListActivity.launchActivity(getActivity());

                break;


            case R.id.searchParent:
                mSearch_edittext.requestFocus();
                KeyBoardUtils.openKeybord(mSearch_edittext, getActivity());
                break;
        }

    }






    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }




    @Override
    public void onResume() {
        super.onResume();
        Log.i(TAG, " onResume ");
        updateBadge();

    }


    public void updateBadge() {
        if (!isAdded()){
            return;
        }

    }


    @Override
    public void setAdapter(List<PeopleEntity> friend,char[] alphaLetters) {
        Log.i(TAG, "setAdapter");
        if (isDetached() || getActivity() == null || getActivity().isFinishing()){
            return;
        }

        friendAdapter.setData(friend);

        indexBar.resetLetters(alphaLetters);

    }




}
