package com.ultralinked.uluc.enterprise.common;

/**
 * Created by mac on 16/10/29.
 */

public class TimeInfo
{
    private long startTime;
    private long endTime;

    public long getStartTime()
    {
        return startTime;
    }

    public void setStartTime(long paramLong)
    {
        startTime = paramLong;
    }

    public long getEndTime()
    {
        return endTime;
    }

    public void setEndTime(long paramLong)
    {
        endTime = paramLong;
    }
}
