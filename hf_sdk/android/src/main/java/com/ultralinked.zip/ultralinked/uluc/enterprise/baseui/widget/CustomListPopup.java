package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.utils.DividerLinearDecoration;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.List;

/**
 * Created by lly on 2016/12/13.
 */

public class CustomListPopup extends PopupWindow implements View.OnClickListener, BaseRecyclerAdapter.OnItemClickListener {

    private int type;
    public static final int CHOSEN_NUMBER = -1;
    public static final int USE_PERIOD = -2;
    public static final int BOUGHT_NUMBER = -3;

    public interface OnProductChoseListener {
        void onPhoneChanged(int position);

        void onQuantityChanged(int position);

        void onBoughtNumberSelected(int position);
    }
    private OnProductChoseListener listener;
    public void setOnProductChoseListener(OnProductChoseListener listener) {
        this.listener = listener;
    }

    public interface OnSingleConfirmListener {
        void onConfirmClick(int position);
    }
    private OnSingleConfirmListener confirmListener;
    public void setOnConfirmListener(OnSingleConfirmListener confirmListener){
        this.confirmListener = confirmListener;
    }

    TextView mCancel, mConfirm;
    RecyclerView mRecycler;
    RelativeLayout mDismissRelative;
    MyAdapter adapter;

    int selectedPosition = -1;

    public void setSelectedPosition(int selectedPosition) {
        this.selectedPosition = selectedPosition;
    }

    public CustomListPopup(Context context, int type, List<String> list) {

        setFocusable(true);
        setOutsideTouchable(true);
        setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        setAnimationStyle(R.style.PopupAnimationStyle);
        setHeight(ViewGroup.LayoutParams.MATCH_PARENT);

        View view = LayoutInflater.from(context).inflate(R.layout.popup_custom_list, null);
        mCancel = (TextView) view.findViewById(R.id.txt_popup_cancel);
        mCancel.setOnClickListener(this);
        mRecycler = (RecyclerView) view.findViewById(R.id.recycler_custom_popup);
        mDismissRelative = (RelativeLayout) view.findViewById(R.id.relative_popup);
        mConfirm = (TextView) view.findViewById(R.id.txt_popup_confirm);
        mDismissRelative.setOnClickListener(this);
        mConfirm.setOnClickListener(this);

        mRecycler.setLayoutManager(new LinearLayoutManager(context));
        mRecycler.addItemDecoration(new DividerLinearDecoration(context, LinearLayoutManager.VERTICAL, R.drawable.divider_item_line, R.dimen.px_15_0_dp, R.dimen.px_15_0_dp));

        adapter = new MyAdapter(context, list);
        adapter.setOnItemClickListener(this);
        mRecycler.setAdapter(adapter);
        setType(type);
        setContentView(view);
    }

    public void setPopup(int type, List<String> list) {
        adapter.updateData(list);
        setType(type);
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public void onClick(View view) {
        dismiss();
        if(selectedPosition==-1){
            return;
        }
        switch (view.getId()){
            case R.id.txt_popup_confirm:
                if (listener != null)
                    switch (type) {
                        case CHOSEN_NUMBER:
                            listener.onPhoneChanged(selectedPosition);
                            break;
                        case USE_PERIOD:
                            listener.onQuantityChanged(selectedPosition);
                            break;
                        case BOUGHT_NUMBER:
                            listener.onBoughtNumberSelected(selectedPosition);
                            break;
                    }
                if(confirmListener!=null){
                    confirmListener.onConfirmClick(selectedPosition);
                }
                break;
            case R.id.relative_popup:
                break;
            case R.id.txt_popup_cancel:
                break;
        }
    }

    @Override
    public void onItemClick(View itemView, int pos) {
        if(selectedPosition != pos) {
            selectedPosition = pos;
            adapter.notifyDataSetChanged();
        }
    }

    private class MyAdapter extends BaseRecyclerAdapter<String, RecyclerViewHolder> {

        MyAdapter(Context ctx, List<String> list) {
            super(ctx, list);
        }

        @Override
        public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
            return new RecyclerViewHolder(mContext, itemView);
        }

        @Override
        public int getItemLayoutId(int viewType) {
            return R.layout.item_custom_popup;
        }

        @Override
        public void bindData(RecyclerViewHolder holder, int position, String itemData) {
            holder.getTextView(R.id.txt_item_popup).setText(itemData);
            if (selectedPosition == position) {
                holder.getImageView(R.id.img_item_chosen).setImageResource(R.mipmap.number_chose_click_btn);
            } else {
                holder.getImageView(R.id.img_item_chosen).setImageResource(R.mipmap.number_chose_btn);
            }
        }

    }
}


