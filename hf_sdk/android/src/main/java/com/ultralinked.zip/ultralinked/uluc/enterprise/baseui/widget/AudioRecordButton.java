package com.ultralinked.uluc.enterprise.baseui.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.ultralinked.uluc.enterprise.chat.chatim.BaseChatImActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.BaseChatImFragment;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.VoiceRecord;

public class AudioRecordButton extends Button {
    private static final int STATE_NORMAL = 1;
    private static final int STATE_RECORDING = 2;
    private static final int STATE_WANT_CANCEL = 3;
    private static final int STATE_OUTOF_TIME = 4;

    private static final int DISTANCE_CANCEL_Y = 50;

    private int currentState = STATE_NORMAL;
    private boolean isRecording = false;
    private AudioRecordDialog dialogManager;
    private ChatModule chatModule;

    private float mTime;
    // 是否触发LongClick
    private boolean isReady = false;

    private static final String TAG = "AudioRecordButton";
    private String curFilePath;
    private String dir;
    private boolean isPrepared;
    private int maxRecordTime = 60;// 单位：秒
    private Message.Options msgOption;

    public AudioRecordButton(Context context) {
        this(context, null);
    }

    public AudioRecordButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        dialogManager = new AudioRecordDialog(getContext());

        this.setOnLongClickListener(new OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                if (!FileUtils.getSdcardAviable()) {
                    Log.i(TAG, "the SDCard not Aviable");
                    return false;
                }
                isReady = true;
                if (chatModule == null) {
                    return false;
                }
                isPrepared = chatModule.startRecordVoice(useRecognize, new AsistantService.OnSpeechUnderstanderListener() {
                    @Override
                    public void onVolumeChanged(int volume) {
                        dialogManager.updateVolumeLevel(getVoiceLevel(30, volume));
                    }

                    @Override
                    public void onBeginOfSpeech() {

                    }

                    @Override
                    public void onEndOfSpeech(boolean hasError) {
                        if (!hasError) {
                            dialogManager.stateRecogize();
                        } else {
                            resetState();
                        }

                    }

                    @Override
                    public void onResult(String text) {
                        finishRecord();
                        if (text != null) {
                            if (audioRecordFinishListener != null) {
                                audioRecordFinishListener.onRecognizeResult(text);
                            }
                        }
                    }
                });
                if (isPrepared) {
                    mHanlder.sendEmptyMessage(MSG_AUDIO_PREPARED);
                    Log.i(TAG, "prepared is ok.");
                } else {
                    if (audioRecordFinishListener != null) {
                        audioRecordFinishListener.onFinish(mTime,useRecognize, null);
                    }
                    Log.i(TAG, "not prepared");
                }
                return false;
            }
        });
    }

    public int getVoiceLevel(int maxLevel, int volume) {
        try {
            // 振幅范围
            return maxLevel * volume / 30 + 1;
        } catch (Exception e) {
        }
        return 1;
    }

    boolean useRecognize;

    public void setUseRecognize(boolean useRecognize) {
        this.useRecognize = useRecognize;
    }

    /**
     * 录音完成后的回调
     */
    public interface AudioRecordFinishListener {
        Message.Options onPreSendVoice();

        void onRecognizeResult(String content);

        void onFinish(float second, boolean useRecognise,String filePath);
    }

    private AudioRecordFinishListener audioRecordFinishListener;

    public void setAudioRecordFinishListener(AudioRecordFinishListener listener) {
        audioRecordFinishListener = listener;
    }

    private Runnable getVolumeRunnable = new Runnable() {

        @Override
        public void run() {

            while (isRecording) {
                try {
                    Thread.sleep(100);
                    mTime += 0.1f;
                    if (!useRecognize) {
                        mHanlder.sendEmptyMessage(MSG_VOLUME_CHAMGED);
                    }
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }


                if (mTime > maxRecordTime) {
                    isRecording = false;
                    outOfMaxTime = true;

                    ((Activity) getContext()).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            finishRecord();
                            isRecording = false;
                            isReady = false;
                            mTime = 0;
                            changeState(STATE_OUTOF_TIME);
                        }
                    });
                }


            }

        }

    };

    private static final int MSG_AUDIO_PREPARED = 0x110;
    private static final int MSG_VOLUME_CHAMGED = 0x111;
    private static final int MSG_DIALOG_DISMISS = 0x112;

    private Handler mHanlder = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_AUDIO_PREPARED:
                    dialogManager.showDialog();
                    isRecording = true;
                    Log.i(TAG, "  show dialog.........");

                    new Thread(getVolumeRunnable).start();


                    break;
                case MSG_VOLUME_CHAMGED:
                    dialogManager.updateVolumeLevel(chatModule.getVoiceLevel(isPrepared, 7));
                    break;
                case MSG_DIALOG_DISMISS:
                    dialogManager.dismissDialog();

                    break;

                default:
                    break;
            }
        }

    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int action = event.getAction();
        int x = (int) event.getX();
        int y = (int) event.getY();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                if (chatModule == null) {
                    BaseChatImFragment mFragment = ((BaseChatImActivity) getContext()).getmFragment();
                    if (mFragment != null) {
                        chatModule = mFragment.getChatModule();

                    } else {
                        Log.i(TAG, "mFragment is null.");
                    }
                }
                Log.i(TAG, " the chatModule is :" + chatModule);
                if (chatModule == null) {
                    break;
                }
                changeState(STATE_RECORDING);
                break;
            case MotionEvent.ACTION_MOVE:

                // 已经开始录音
                if (isRecording) {
                    // 根据X，Y的坐标判断是否想要取消
                    if (wantCancel(x, y)) {
                        changeState(STATE_WANT_CANCEL);
                        dialogManager.stateWantCancel();
                    } else {
                        changeState(STATE_RECORDING);
                        dialogManager.stateRecording();
                    }
                }

                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // 没有触发longClick
                if (!isReady) {
                    dialogManager.stateLengthShort();
                    resetState();
                    return super.onTouchEvent(event);
                }
                // prepare未完成就up,录音时间过短
                if (!isRecording || mTime < 0.6f) {
                    dialogManager.stateLengthShort();
                    if (chatModule == null) {
                        Log.i(TAG, "chatModule is null.");
                        break;
                    }
                    chatModule.cancelRecordVoice(useRecognize);
                    mHanlder.sendEmptyMessageDelayed(MSG_DIALOG_DISMISS, 1300);
                } else if (currentState == STATE_RECORDING) { // 正常录制结束
                    finishRecord();
                } else if (currentState == STATE_WANT_CANCEL) {
                    dialogManager.dismissDialog();
                    // 用户取消息录制
                    chatModule.cancelRecordVoice(useRecognize);

                }
                resetState();
                break;

            default:
                break;
        }
        return super.onTouchEvent(event);
    }

    private boolean outOfMaxTime;

    private void finishRecord() {
        dialogManager.dismissDialog();
        chatModule.stopRecordVoice(useRecognize);

        if (audioRecordFinishListener != null) {
            msgOption = audioRecordFinishListener.onPreSendVoice();
        }

        if (!useRecognize) {

            chatModule.sendVoice(chatModule.getCurRecordVoiceMsgPath(), (int) mTime, msgOption);
        }
        // callbackToActivity
        if (audioRecordFinishListener != null) {
            audioRecordFinishListener.onFinish(mTime, useRecognize,chatModule.getCurRecordVoiceMsgPath());
        }
    }

    /**
     * 恢复标志位
     */
    private void resetState() {

        isRecording = false;
        isReady = false;
        changeState(STATE_NORMAL);
        mTime = 0;
    }

    private boolean wantCancel(int x, int y) {
        if (x < 0 || x > getWidth()) {
            return true;
        }
        // 零点在左下角？
        return y < -DISTANCE_CANCEL_Y || y > getHeight() + DISTANCE_CANCEL_Y;
    }

    private void changeState(int state) {

        if (currentState != state) {
            currentState = state;
            switch (state) {
                case STATE_OUTOF_TIME:
                    setBackgroundResource(com.holdingfuture.flutterapp.hfsdk.R.drawable.btn_recorder_record);
                    setText(com.holdingfuture.flutterapp.hfsdk.R.string.btn_recorder_recording);
                    break;
                case STATE_NORMAL:
                    setBackgroundResource(com.holdingfuture.flutterapp.hfsdk.R.drawable.btn_recorder_normal);
                    setText(com.holdingfuture.flutterapp.hfsdk.R.string.btn_recorder_normal);

                    break;
                case STATE_RECORDING:
                    setBackgroundResource(com.holdingfuture.flutterapp.hfsdk.R.drawable.btn_recorder_record);
                    setText(com.holdingfuture.flutterapp.hfsdk.R.string.btn_recorder_recording);
                    if (isRecording) {
                        dialogManager.stateRecording();
                    }
                    break;
                case STATE_WANT_CANCEL:
                    setBackgroundResource(com.holdingfuture.flutterapp.hfsdk.R.drawable.btn_recorder_record);
                    setText(com.holdingfuture.flutterapp.hfsdk.R.string.btn_recorder_want_cancel);
                    dialogManager.stateWantCancel();
                    break;

                default:
                    break;
            }
        }
    }
}
