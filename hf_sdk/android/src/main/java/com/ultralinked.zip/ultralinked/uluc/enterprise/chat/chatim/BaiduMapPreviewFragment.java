package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.baidu.location.Address;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.model.LatLng;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.utils.GPSUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MapUtils;

import java.util.List;

/**
 * Created by Chenlu on 2016/8/11 0011.
 */
public class BaiduMapPreviewFragment extends BaseFragment implements BDLocationListener {

    private static final String TAG = "BaiduMapPreviewFragment";
    public LocationClient mLocationClient = null;
    private MapView mMapView;
    private BaiduMap mBaiduMap;

    private ImageView back;
    private TextView title;
    private TextView send;
    private BDLocation mLastLocation;

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_map_baidu;
    }

    private BaseActivity activity;
    @Override
    public void onAttach(Activity activity) {
        this.activity = (BaseActivity) activity;
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);

        return view;
    }



    @Override
    public void initView(Bundle savedInstanceState) {
        back = bind(R.id.left_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
            }
        });
        title = bind(R.id.titleCenter);
        send = bind(R.id.titleRight);
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
            }
        });
        title.setText(com.holdingfuture.flutterapp.hfsdk.R.string.selecte_location);
        send.setText(com.holdingfuture.flutterapp.hfsdk.R.string.send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mLastLocation == null) {
                    Log.e(TAG,"get location failed,mLastLocation is null.");
                    return;
                }

                Intent data = new Intent();
                data.putExtra("location_type", "baidu");
                data.putExtra("lastLocation", mLastLocation);
                activity.setResult(Activity.RESULT_OK, data);
                activity.finish();

            }
        });

        mLocationClient = new LocationClient(activity.getApplicationContext());     //声明LocationClient类
        mLocationClient.registerLocationListener( this );
        mMapView = bind(R.id.bmapView);
        mBaiduMap = mMapView.getMap();
        mBaiduMap.setOnMapStatusChangeListener(new BaiduMap.OnMapStatusChangeListener() {
            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus) {

            }

            @Override
            public void onMapStatusChange(MapStatus mapStatus) {

            }

            @Override
            public void onMapStatusChangeFinish(MapStatus mapStatus) {
//                updateMapState(mapStatus);
            }
        });
//        mMapView.removeViewAt(1);
        mMapView.showScaleControl(true);
        mMapView.showZoomControls(true);
        UiSettings uiSettings = mBaiduMap.getUiSettings();
        uiSettings.setRotateGesturesEnabled(false);
        uiSettings.setZoomGesturesEnabled(true);
        uiSettings.setScrollGesturesEnabled(true);
        initLocation();
        mLocationClient.start();

//        showLocationByGPS();
    }

    private void showLocationByGPS() {
        Bundle bundle = getArguments();
        if (bundle == null) {
            Log.e(TAG,"bundle is null");
            return;
        }
        Location location = bundle.getParcelable("location");

        if (location == null) {
            Log.e(TAG,"location is null");
            return;
        }
        LatLng latLng = MapUtils.convertGpsToBaidu(location.getLatitude(), location.getLongitude());
        location.setLatitude(latLng.latitude);
        location.setLongitude(latLng.longitude);
        mLastLocation = new BDLocation();
        mLastLocation.setLatitude(location.getLatitude());
        mLastLocation.setLongitude(location.getLongitude());

        MyLocationData locationData = new MyLocationData.Builder()
                .accuracy(location.getAccuracy())
                .direction(0).latitude(location.getLatitude())
                .longitude(location.getLongitude()).build();

        if (!mBaiduMap.isMyLocationEnabled()) {
            mBaiduMap.setMyLocationEnabled(true);
        }
        mBaiduMap.setMyLocationData(locationData);
        if(first){
            LatLng ll = new LatLng(location.getLatitude(),
                    location.getLongitude());
            MapStatus.Builder builder = new MapStatus.Builder();
            builder.target(ll).zoom(18.0f);
            mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
            first = false;
        }
    }

    private void updateMapState(MapStatus status) {
        LatLng mCenterLatLng = status.target;
        /**获取经纬度*/
        if (mCenterLatLng != null) {
            Log.i(TAG, "adjust location:" + mLastLocation.getLongitude() + "," + mLastLocation.getLatitude() + "-->" + mCenterLatLng.longitude + "," + mCenterLatLng.latitude);
            mLastLocation.setLatitude(mCenterLatLng.latitude);
            mLastLocation.setLongitude(mCenterLatLng.longitude);
        } else {
            Log.i(TAG, "current mLastLocation is null");
        }

    }


    private void initLocation(){
        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationClientOption.LocationMode.Battery_Saving
        );//可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("bd09ll");//可选，默认gcj02，设置返回的定位结果坐标系
        int span=1000*5;
       // option.setScanSpan(span);//可选，默认0，即仅定位一次，设置发起定位请求的间隔需要大于等于1000ms才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认false,设置是否使用gps
        option.setLocationNotify(false);//可选，默认false，设置是否当gps有效时按照1S1次频率输出GPS结果
        option.setIsNeedLocationDescribe(true);//可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到
        option.setIgnoreKillProcess(false);//可选，默认true，定位SDK内部是一个SERVICE，并放到了独立进程，设置是否在stop的时候杀死这个进程，默认不杀死
        option.SetIgnoreCacheException(true);//可选，默认false，设置是否收集CRASH信息，默认收集
        option.setEnableSimulateGps(false);//可选，默认false，设置是否需要过滤gps仿真结果，默认需要
        option.setNeedDeviceDirect(true);// 返回的定位结果包含手机机头的方向
        option.setTimeOut(10 * 1000); // 超时

        mLocationClient.setLocOption(option);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mLocationClient.stop();
        mBaiduMap.setMyLocationEnabled(false);
        mLocationClient.unRegisterLocationListener(this);
        mMapView.onDestroy();
        mMapView = null;

    }
    @Override
    public void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
        mMapView.setEnabled(false);
    }
    @Override
    public void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }
    private boolean first = true;
    /**
     * 获取到定位信息
     * @param bdLocation
     */
    @Override
    public void onReceiveLocation(final BDLocation bdLocation) {
        if (bdLocation == null || mMapView == null) {
            return;
        }
        MyLocationData locationData = new MyLocationData.Builder()
                .accuracy(bdLocation.getRadius())
                .direction(0).latitude(bdLocation.getLatitude())
                .longitude(bdLocation.getLongitude()).build();
        if (!mBaiduMap.isMyLocationEnabled()) {
            mBaiduMap.setMyLocationEnabled(true);
        }
        mBaiduMap.setMyLocationConfigeration(new MyLocationConfiguration(MyLocationConfiguration.LocationMode.FOLLOWING, true, null)); // 设置为跟随模式,显示手机方向的箭头

        String city = bdLocation.getCity();
        String cityCode = bdLocation.getCityCode();
        String province = bdLocation.getProvince();
        Address address = bdLocation.getAddress();
        String addrStr = bdLocation.getAddrStr();
        String buildingName = bdLocation.getBuildingName();
        String locationDescribe = bdLocation.getLocationDescribe();
        String street = bdLocation.getStreet();
        String streetNumber = bdLocation.getStreetNumber();
        String coorType = bdLocation.getCoorType();
        List poiList = bdLocation.getPoiList();
        String firstPoi = poiList != null && poiList.size() > 0 ? poiList.get(0).toString() : "null";
        String content= new StringBuffer().append("city:" + city + " cityCode:" + cityCode + " province:" + province + " address:" + address + " addrStr:" + addrStr + " buildingName:" + buildingName)
                .append(" locationDescrible:").append(locationDescribe)
                .append(" sreet:").append(street)
                .append(" streetNumber:").append(streetNumber)
                .append("coorType:").append(coorType)
                .append(" firstPoi:").append(firstPoi).toString();

        Log.i(GPSUtils.TAG, "当前定位的位置(经纬度)：" + bdLocation.getLongitude() + "," + bdLocation.getLatitude() + "--->" + content);
        mBaiduMap.setMyLocationData(locationData);
        mLastLocation = bdLocation;

        if(first){
            LatLng ll = new LatLng(bdLocation.getLatitude(),
                    bdLocation.getLongitude());
            MapStatus.Builder builder = new MapStatus.Builder();
            builder.target(ll).zoom(18.0f);
            mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
            first = false;
        }

    }
}
