package com.ultralinked.uluc.enterprise.contacts.contract;

import android.os.Parcel;
import android.os.Parcelable;

import com.github.promeg.pinyinhelper.Pinyin;
import com.google.gson.annotations.SerializedName;
import com.ultralinked.contact.gruc.Gruc;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;

/**
 * Created by ultralinked on 16/7/14.
 */
public class PeopleEntity implements Parcelable ,Comparable<PeopleEntity>{

    public static final int STRANGER = 3;

    public static final int FRIEND = 2;


    public String invite_message;
    public boolean is_friend;

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public boolean enable;
    public String updated_at;
    public boolean active;
    public String deleted_at;
    public String nickname;
    public String remarkname;

    public  int relation=-1;//friend or stanger or company

    public String user_id;//for private bug.

    @SerializedName("id")
    public String subuser_id;



    public String invite_id;

    public String name;
    public String mobile;
    public String icon_url;
    public String created_at;
    public String domain_id;
    public String email;
    public String deparment_id;
    public String deparment_type;

    public String status;

    public String deparment_name;
    public String companyid;
    public String companyName;

    public String gender;

    //extra info not read from database;
    public boolean isSelected = false;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PeopleEntity that = (PeopleEntity) o;

        return subuser_id != null ? subuser_id.equals(that.subuser_id) : that.subuser_id == null;

    }

    @Override
    public int hashCode() {
        return subuser_id != null ? subuser_id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "PeopleEntity{" +
                "enable=" + enable +
                ", updated_at='" + updated_at + '\'' +
                ", status='" + status + '\'' +
                ", active=" + active +
                ", deleted_at='" + deleted_at + '\'' +
                ", nickname='" + nickname + '\'' +
                ", subuser_id='" + subuser_id + '\'' +
                ", name='" + name + '\'' +
                ", mobile='" + mobile + '\'' +
                ", icon_url='" + icon_url + '\'' +
                ", created_at='" + created_at + '\'' +
                ", domain_id='" + domain_id + '\'' +
                ", email='" + email + '\'' +
                ", deparment_id='" + deparment_id + '\'' +
                ", deparment_type='" + deparment_type + '\'' +
                ", deparment_name='" + deparment_name + '\'' +
                ", companyid='" + companyid + '\'' +
                ", isSelected=" + isSelected +
                ", companyName='" + companyName + '\'' +
                ", gender='" + gender + '\'' +
                ", remarkname='" + remarkname + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte(this.enable ? (byte) 1 : (byte) 0);
        dest.writeString(this.updated_at);
        dest.writeByte(this.active ? (byte) 1 : (byte) 0);
        dest.writeString(this.deleted_at);
        dest.writeString(this.nickname);
        dest.writeString(this.subuser_id);
        dest.writeString(this.name);
        dest.writeString(this.mobile);
        dest.writeString(this.icon_url);
        dest.writeString(this.created_at);
        dest.writeString(this.domain_id);
        dest.writeString(this.email);
        dest.writeString(this.deparment_id);
        dest.writeString(this.deparment_type);
        dest.writeString(this.deparment_name);
        dest.writeString(this.companyid);
        dest.writeByte(this.isSelected ? (byte) 1 : (byte) 0);
        dest.writeString(this.companyName);
        dest.writeString(this.status);
        dest.writeString(this.invite_id);
        dest.writeString(this.gender);
        dest.writeInt(this.relation);
        dest.writeByte(this.is_friend ? (byte) 1 : (byte) 0);
        dest.writeString(String.valueOf(letter));
        dest.writeInt(this.letterByNum);
        dest.writeString(this.remarkname);

    }

    public PeopleEntity() {
    }

    protected PeopleEntity(Parcel in) {
        this.enable = in.readByte() != 0;
        this.updated_at = in.readString();
        this.active = in.readByte() != 0;
        this.deleted_at = in.readString();
        this.nickname = in.readString();
        this.subuser_id = in.readString();
        this.name = in.readString();
        this.mobile = in.readString();
        this.icon_url = in.readString();
        this.created_at = in.readString();
        this.domain_id = in.readString();
        this.email = in.readString();
        this.deparment_id = in.readString();
        this.deparment_type = in.readString();
        this.deparment_name = in.readString();
        this.companyid = in.readString();
        this.isSelected = in.readByte() != 0;
        this.companyName = in.readString();
        this.status = in.readString();
        this.invite_id = in.readString();
        this.gender = in.readString();
        this.relation = in.readInt();
        this.is_friend = in.readByte() != 0;
        this.letter = in.readString().charAt(0);
        this.letterByNum = in.readInt();
        this.remarkname = in.readString();
    }

    public static final Parcelable.Creator<PeopleEntity> CREATOR = new Parcelable.Creator<PeopleEntity>() {
        @Override
        public PeopleEntity createFromParcel(Parcel source) {
            return new PeopleEntity(source);
        }

        @Override
        public PeopleEntity[] newArray(int size) {
            return new PeopleEntity[size];
        }
    };


    private char letter;

    public char getLetter() {
        return letter;
    }

    private  int letterByNum;

    public void setLetter(String displayName){
        if (displayName == null || "".equals(displayName)) {
            letter = '#';
            letterByNum = 'Z' - 'A' + 1;
            return;
        }

        char temp = displayName.charAt(0);
        String pinYin;
        char c;
        if (Pinyin.isChinese(temp)){
            pinYin = Pinyin.toPinyin(temp);
            c =pinYin.charAt(0);
        }else {
            c = displayName.charAt(0);
        }
        boolean isLetter = isLetter(c);
        if (isLetter) {
            letter = Character.toUpperCase(c);
            letterByNum = letter - 'A';
        } else {
            letter = '#';
            letterByNum = 'Z' - 'A' + 1;
        }
    }

    /**
     * 如果前面两个字母相同依次比较后面的字母的unicode码
     * @param one
     * @param two
     * @return
     */
    public int stringPlus(String one, String two) {
        int lengthOne = one.length();
        int lengthTwo = two.length();
        if (lengthOne == 0) return -1;
        if (lengthTwo == 0) return 1;
        int first = one.charAt(0);
        int second = two.charAt(0);
        if (first == second) {
            return stringPlus(one.substring(1, lengthOne), two.substring(1, lengthTwo));
        } else {
            return first - second;
        }
    }

    /**
     * 判断是不是字母
     * @param codePoint
     * @return
     */
    public  boolean isLetter(int codePoint) {
        return ('A' <= codePoint && codePoint <= 'Z') || ('a' <= codePoint && codePoint <= 'z');
    }


    @Override
    public int compareTo(PeopleEntity another) {
        if (this.letterByNum != another.letterByNum) {
            return this.letterByNum - another.letterByNum;
        }
        return stringPlus(PeopleEntityQuery.getDisplayName(this), PeopleEntityQuery.getDisplayName(another));
    }
}
