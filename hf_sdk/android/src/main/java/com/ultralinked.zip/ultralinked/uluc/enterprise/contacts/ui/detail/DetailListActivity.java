package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.MyHandler;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;

import java.util.ArrayList;

/**
 * details for internal and external contact
 */
public class DetailListActivity extends AppCompatActivity implements MyHandler.MyHandlerListener {

    public static final String KEY_DETAIL = "elementdetail";

    private static final String TAG = "DetailListActivity";
    public static final String KEY_PAENET_DEPT_NAME = "partentdepmentnamefortitle";

    private DetailAdapter mAdapter;

    private ListView mList;

    private ArrayList<PeopleEntity> myListData;

    private MyHandler mhandler;
    private TextView empty_detailView;
    private DepartUtils.CompanyElement mCompanyElement;

    private TextView titleCenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(com.holdingfuture.flutterapp.hfsdk.R.layout.activity_detail_list);

        mhandler = new MyHandler(DetailListActivity.this);
        mhandler.setListener(this);

        initTitleBar();
        //get data
        mCompanyElement = getIntent().getParcelableExtra(KEY_DETAIL);

        titleCenter.setText(getIntent().getStringExtra(KEY_PAENET_DEPT_NAME));

        mList = (ListView) findViewById(R.id.detailList);
        empty_detailView = (TextView) findViewById(R.id.empty_detail);
        empty_detailView.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.detail_contact_no_contact));
        mList.setEmptyView(empty_detailView);

        mAdapter = new DetailAdapter(this);

        mList.setAdapter(mAdapter);

        mhandler.post(new Runnable() {
            @Override
            public void run() {

                myListData = PeopleEntityQuery.getInstance().getByDeptID(mCompanyElement._id);

                Message msg = Message.obtain();
                msg.what = 11;
                mhandler.sendMessage(msg);
            }
        });


        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PeopleEntity clickedSource = (PeopleEntity) parent.getAdapter().getItem(position);

                Intent intent = new Intent(DetailListActivity.this, DetailPersonActivity.class);
                intent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY, clickedSource);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mhandler.removeCallbacksAndMessages(null);
    }

    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.organization));


        TextView titleRight = (TextView) findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }

    @Override
    public void handleMessage(Message msg) {

        switch (msg.what) {
            case 11:
                mAdapter.setData(myListData);
                break;

            default:
                break;
        }
    }
}
