package com.ultralinked.uluc.enterprise.common;


import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;

import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leo.gesturelibray.crypto.Base64;
import com.leo.gesturelibray.enums.LockMode;
import com.leo.gesturelibray.view.CustomLockView;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class PasswordLockerHelper {

    private static final String TAG = "PasswordLockerHelper";




    public  static  final int RESET_PASSWORD = 1;
    public  static  final int INPUT_PASSWORD = 2;

    public Dialog changelockPasswordDialog(Activity context, final PasswordLockerHelper.OnDialogListener listener){

        return  showUnlockDialog(context,RESET_PASSWORD,listener);
    }


    public Dialog setlockDialog(Activity context, final PasswordLockerHelper.OnDialogListener listener){

        return  showUnlockDialog(context,RESET_PASSWORD,listener);
    }


    public interface OnDialogListener {
        void onCancelClick();

        void onOkClick(String  password);

    }

    /**
     *
     * @param context
     * @param titleStr
     * @param hints
     * @param listener
     * @return
     */
    TextView tvHint ;
    CustomLockView lvLock;
    public Dialog showUnlockDialog(final Activity context,final int type, final PasswordLockerHelper.OnDialogListener listener) {
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_password_lock_layout, null);
        final Dialog dialog = new Dialog(context, R.style.unlock_dialog);
        // root.findViewById(R.id.cancel_btn).setVisibility(View.GONE);
        dialog.setContentView(root);//必须放在requestWindowFeature后面


        tvHint = (TextView) root.findViewById(R.id.tv_hint);
        lvLock = (CustomLockView) root.findViewById(R.id.lv_lock);
        ImageView userIcon = (ImageView) root.findViewById(R.id.user_icon);

        UserInfo userInfo = SPUtil.getUserInfo();
        if (userInfo!=null && !TextUtils.isEmpty(userInfo.getIcon_url())){
            ImageUtils.loadCircleImage(context,userIcon,userInfo.getIcon_url(),R.mipmap.default_head);
        }

        if (type == RESET_PASSWORD){
            dialog.setCancelable(true);
            tvHint.setText(R.string.contact_private_setpassword);
            setLockMode(LockMode.SETTING_PASSWORD,null);
        }else{
            final String oldpsd = SPUtil.getUserPrivatePsd();
            tvHint.setText(R.string.contact_private_inputpassword);
            setLockMode(LockMode.VERIFY_PASSWORD,oldpsd);
            dialog.setCancelable(false);

            DialogInterface.OnKeyListener keylistener = new DialogInterface.OnKeyListener(){
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if (keyCode==KeyEvent.KEYCODE_BACK&&event.getRepeatCount()==0)
                    {
                        //do something...
                        if (!(context instanceof MainActivity)){
                            context.finish();
                        }
                        listener.onCancelClick();
                        dialog.dismiss();
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            } ;

            dialog.setOnKeyListener(keylistener);

        }


        //显示绘制方向
        lvLock.setShow(true);
        //允许最大输入次数
        lvLock.setErrorNumber(5);
        //密码最少位数
        lvLock.setPasswordMinLength(4);
        lvLock.setSavePin(false);

        //编辑密码或设置密码时，是否将密码保存到本地，配合setSaveLockKey使用
       // lvLock.setSavePin(true);

        lvLock.setOnCompleteListener(new CustomLockView.OnCompleteListener() {
            @Override
            public void onComplete(final String password, int[] indexs) {
                String numberPassword = "";
                for (int i = 0; i < indexs.length; i++) {
                    numberPassword+=""+indexs[i];
                }
                Log.i(TAG,"password=="+numberPassword);
                //tvHint.setText(getPassWordHint());
                dialog.dismiss();
                if (type == RESET_PASSWORD) {
                    listener.onOkClick(numberPassword);
                }else{
                    listener.onOkClick(numberPassword);
                }
            }

            @Override
            public void onError(String errorTimes) {
                tvHint.setText(App.getInstance().getString(R.string.input_wrong_password_limit_times,errorTimes));
            }

            @Override
            public void onPasswordIsShort(int passwordMinLength) {
                //tvHint.setText("密码不能少于" + passwordMinLength + "个点");
                //lvLock.reset();
            }

            @Override
            public void onAginInputPassword(LockMode mode, String password, int[] indexs) {
                tvHint.setText(App.getInstance().getString(R.string.please_enter_password_again));
            }


            @Override
            public void onInputNewPassword() {
                tvHint.setText(App.getInstance().getString(R.string.please_enter_new_password));//
            }

            @Override
            public void onEnteredPasswordsDiffer() {
                tvHint.setText(App.getInstance().getString(R.string.check_not_same_password));
            }

            @Override
            public void onErrorNumberMany() {
                //tvHint.setText("密码错误次数超过限制，不能再输入");
                dialog.cancel();
                if (type == RESET_PASSWORD){
                    listener.onCancelClick();
                }else{
                    LoginPresenter.logout(context);
                }
            }

        });



        float scale = 1;
        int width = (int) (ScreenUtils.getScreenWidth(context)* scale);
        int height = (int) (ScreenUtils.getScreenHeight(context)* scale);
        WindowManager.LayoutParams p = dialog.getWindow().getAttributes();
        p.width = width;
        p.height = height;
        dialog.getWindow().setAttributes(p);

        //  context.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        //dialog.setOwnerActivity(context);
        dialog.show();
        return dialog;
    }




    /**
     * 密码输入模式
     */
    private void setLockMode(LockMode mode, String password) {
        lvLock.setMode(mode);
        if (mode != LockMode.SETTING_PASSWORD) {
            int[] indexs = new int[password.length()];
            for (int i = 0; i < indexs.length; i++) {
                try{
                    indexs[i] = Integer.valueOf(password.substring(i,i+1));
                }catch (Exception e){
                    e.printStackTrace();
                }

            }

            lvLock.setOldPassword(Base64.encryptionString(indexs));
        } else {
            lvLock.clearCurrent();
            lvLock.reset();
        }
    }








    public    interface  OnPasswordSetSuccessCallback{
        void onPasswordSetSucc();
    }

    public void setNewPsdForPrivate(final BaseActivity activity, final String psd,final OnPasswordSetSuccessCallback passwordSetSuccess) {

        ApiManager.getInstance().setPrivatePsd(psd)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(activity.<ResponseBody>bindToLifecycle())  //绑定生命周期
                //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"setNewPsdForPrivateComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        android.util.Log.e(TAG, "setNewPsdForPrivate error " + eMsg);
                        activity.showToast(eMsg+"");
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
//                        "code": 200,
//                                I/PasswordLockerHelper(25103):   "result": {
//                            I/PasswordLockerHelper(25103):     "domain": "uc",
//                                    I/PasswordLockerHelper(25103):     "private_contact_password": "0485"
//                            I/PasswordLockerHelper(25103):   }
//                        I/PasswordLockerHelper(25103): }
                        try {
                            rs = responseBody.string();
                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                SPUtil.saveUserPrivatePsd(psd);
                                if (passwordSetSuccess!=null){
                                    passwordSetSuccess.onPasswordSetSucc();
                                }
                                activity.showToast(R.string.private_password_set_success);
                            }else{
                                activity.showToast("errorcode:"+object.optInt("code")+"\n"+object.optString("description"));
                            }


                        } catch (Exception e) {
                            android.util.Log.i(TAG, "setPrivatePsd IOException " + e.getMessage());
                        }


                        android.util.Log.i(TAG, "setPrivatePsd  " + rs);
                    }

                });

    }

    private  static  PasswordLockerHelper sPasswordLockerHelper;
    public static PasswordLockerHelper getInstance() {
        if (sPasswordLockerHelper == null){
            sPasswordLockerHelper = new PasswordLockerHelper();
        }
        return  sPasswordLockerHelper;
    }
}
