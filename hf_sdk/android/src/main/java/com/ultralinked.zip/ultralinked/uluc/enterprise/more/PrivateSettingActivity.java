package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.common.PasswordLockerHelper;
import com.ultralinked.uluc.enterprise.utils.MyCustomDialog;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

public class PrivateSettingActivity extends BaseActivity implements View.OnClickListener{

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_safe_setting;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        initListener(this, R.id.left_back, R.id.privateChangPsd, R.id.privateRecoveryBy, R.id.privateRecoveryPsd);

    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.private_settings);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.privateChangPsd:
                Bundle bundle=new Bundle();
                bundle.putString("lunch_model","private_psd");
                if(TextUtils.isEmpty(SPUtil.getUserPrivatePsd())){
                    //lunchActivity(SetPasswordActivity.class,bundle);
                    setPassword(true);
                }else{
                   // lunchActivity(ResetPsdActivity.class,bundle);
                    setPassword(false);
                }

                break;

            case R.id.privateRecoveryPsd:
                lunchActivity(RecoverySettingActivity.class);
                break;

            case R.id.privateRecoveryBy:
                View dialogView=LayoutInflater.from(PrivateSettingActivity.this).inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.bottom_dialog,null);
                dialogView.findViewById(R.id.dialog_mobile).setOnClickListener(this);
                dialogView.findViewById(R.id.dialog_email).setOnClickListener(this);
                MyCustomDialog.getInstance(this).showBottomContent("Title",dialogView, com.holdingfuture.flutterapp.hfsdk.R.style.CustomDatePickerDialog);
                break;
            case R.id.dialog_email:
                //showToast("email");
                // TODO: 2016/8/4 0004 改密码 通过email
                break;
            case R.id.dialog_mobile:
                //showToast("mobile");
                // TODO: 2016/8/4 0004 改密码 通过mobile
                break;
        }
    }

    private void setPassword(boolean hasOldPassword) {

        PasswordLockerHelper.getInstance().setlockDialog(getActivity(),  new PasswordLockerHelper.OnDialogListener() {

            @Override
            public void onCancelClick() {
                //showToast("Cancel");
            }

            @Override
            public void onOkClick(String password) {


                PasswordLockerHelper.getInstance().setNewPsdForPrivate(PrivateSettingActivity.this, password, new PasswordLockerHelper.OnPasswordSetSuccessCallback() {
                    @Override
                    public void onPasswordSetSucc() {
                    }
                });


            }
        });

    }
}
