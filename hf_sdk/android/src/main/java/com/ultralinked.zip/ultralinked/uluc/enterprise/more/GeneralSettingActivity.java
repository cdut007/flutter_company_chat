package com.ultralinked.uluc.enterprise.more;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatdetails.ChangeChatSkinActivity;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.voip.api.MessagingApi;

/**
 * Created by mac on 16/12/14.
 */

public class GeneralSettingActivity extends BaseActivity implements View.OnClickListener{

    private ImageView leftBack;
    private View tvFontSetting,tvNotificationSetting,tvDownloadMediaSetting,tvBackgroudSetting,tvClear_chat_history;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_setting_general;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        leftBack=bind(R.id.left_back);
        tvFontSetting=bind(R.id.font_size_setting);
        tvNotificationSetting=bind(R.id.notification_setting);
        tvDownloadMediaSetting=bind(R.id.download_media_setting);
        tvBackgroudSetting=bind(R.id.all_chat_backgroud_setting);
        tvClear_chat_history=bind(R.id.clear_chat_history);

        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.general_settings);
        initListener(this, leftBack, tvFontSetting, tvNotificationSetting, tvDownloadMediaSetting,tvBackgroudSetting,tvClear_chat_history);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
//            case R.id.download_media_setting:
//                lunchActivity(AutoDownloadMediaActivity.class);
//                break;
//            case R.id.notification_setting:
//                lunchActivity(NotificationSettingActivity.class);
//                break;
            case R.id.clear_chat_history:
            {
                DialogManager.showOKCancelDialog(GeneralSettingActivity.this, "", getString(R.string.delete_all_message), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MessagingApi.deleteAllConversationsMessages();

                    }
                },null);
            }
                break;
            case R.id.font_size_setting:
                lunchActivity(FontSizeSettingActivity.class);
                break;
            case R.id.all_chat_backgroud_setting:
                Bundle bundle = new Bundle();
                bundle.putBoolean("settingAll",true);
                lunchActivity(ChangeChatSkinActivity.class,bundle);
                break;

            default:
        }
    }


}
