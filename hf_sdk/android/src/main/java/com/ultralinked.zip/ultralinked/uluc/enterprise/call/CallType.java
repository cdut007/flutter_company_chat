package com.ultralinked.uluc.enterprise.call;

import android.graphics.drawable.Drawable;

public class CallType {
	
	private Drawable callTypeDrawable;
	private  String callTypeName;
	
	
	
	
	public Drawable getCallTypeDrawable() {
		return callTypeDrawable;
	}
	public String getCallTypeName() {
		return callTypeName;
	}
	public void setCallTypeDrawable(Drawable callTypeDrawable) {
		this.callTypeDrawable = callTypeDrawable;
	}
	public void setCallTypeName(String callTypeName) {
		this.callTypeName = callTypeName;
	}
	public CallType(Drawable callTypeDrawable, String callTypeName) {
		super();
		this.callTypeDrawable = callTypeDrawable;
		this.callTypeName = callTypeName;
	}
	

}
