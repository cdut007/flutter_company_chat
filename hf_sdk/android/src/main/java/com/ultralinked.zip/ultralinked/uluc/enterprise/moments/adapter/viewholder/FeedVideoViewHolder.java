package com.ultralinked.uluc.enterprise.moments.adapter.viewholder;

import android.view.View;
import android.view.ViewStub;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.widgets.CircleVideoView;


/**
 * Created by suneee on 2016/8/16.
 */
public class FeedVideoViewHolder extends FeedViewHolder {

    public CircleVideoView videoView;

    public FeedVideoViewHolder(View itemView){
        super(itemView, TYPE_VIDEO);
    }

    @Override
    public void initSubView(int viewType, ViewStub viewStub) {
        if(viewStub == null){
            throw new IllegalArgumentException("viewStub is null...");
        }

        viewStub.setLayoutResource(R.layout.comments_viewstub_videobody);
        View subView = viewStub.inflate();

        CircleVideoView videoBody = (CircleVideoView) subView.findViewById(R.id.videoView);
        if(videoBody!=null){
            this.videoView = videoBody;
        }
    }
}
