package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by Chenlu on 2016/7/6 0006.
 */
public class MessageRecyclerView extends RecyclerView {
    private static final String TAG = "MessageRecyclerView";
    public MessageRecyclerView(Context context) {
        super(context);
    }

    public MessageRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MessageRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    private OnElementUIInfoChangeListener mListener;

    public interface OnElementUIInfoChangeListener {
        void OnResize(int w, int h, int oldw, int oldh);
        boolean onTouch(View v, MotionEvent event);
    }

    public void setOnElementUIInfoChangeListener(OnElementUIInfoChangeListener l) {
        mListener = l;
        setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (mListener!=null){
                    return  mListener.onTouch(v,event);
                }else{
                    return  false;
                }


            }
        });

    }



    private void smoothScrollToEnd() {


        int last = ((LinearLayoutManager)getLayoutManager()).findLastVisibleItemPosition();
        int newPosition = getAdapter().getItemCount() - 1;

        if (last < 0 || newPosition < 0) {
            Log.i(TAG, newPosition + "getLastVisiblePosition==" + last);
            return;
        }

        View lastChild = ((LinearLayoutManager)getLayoutManager()).findViewByPosition(last);
        int height = 0;
        if (lastChild != null) {
            height = lastChild.getHeight();
        }

        // Only scroll if the list if we're responding to a newly sent message
        // (force == true) or
        // the list is already scrolled to the end. This code also has to handle
        // the case where
        // the listview has changed size (from the keyboard coming up or down or
        // the message entry
        // field growing/shrinking) and it uses that grow/shrink factor in
        // listSizeChange to
        // compute whether the list was at the end before the resize took place.
        // For example, when the keyboard comes up, listSizeChange will be
        // negative, something
        // like -524. The lastChild listitem's bottom value will be the old
        // value before the
        // keyboard became visible but the size of the list will have changed.
        // The test below
        // add listSizeChange to bottom to figure out if the old position was
        // already scrolled
        // to the bottom. We also scroll the list if the last item is taller
        // than the size of the
        // list. This happens when the keyboard is up and the last item is an
        // mms with an
        // attachment thumbnail, such as picture. In this situation, we want to
        // scroll the list so
        // the bottom of the thumbnail is visible and the top of the item is
        // scroll off the screen.
        int listHeight =getHeight();

        android.util.Log.i(TAG, "newPosition=" + newPosition + ";listHeight="
                + listHeight + ";height=" + height);

        if (height > listHeight) {
            // If the height of the last item is taller than the whole height of
            // the list,
            // we need to scroll that item so that its top is negative or above
            // the top of
            // the list. That way, the bottom of the last item will be exposed
            // above the
            // keyboard.
            ((LinearLayoutManager)getLayoutManager()).scrollToPositionWithOffset(newPosition, listHeight
                    - height);
        } else {

            scrollToPosition(newPosition);
        }

       // mLastSmoothScrollPosition = newPosition;

    }


    private void keybordShow(int keybordHeight) {
        if (keybordHeight <= 0) {
            // add keep
			/*
			 * int len = messageList.size(); if (len == 0) { return; } int last
			 * = messageingListView.getLastVisiblePosition(); if (last >= 0)
			 * {//restore View lastChild = messageingListView.getChildAt(last -
			 * messageingListView.getFirstVisiblePosition()); int childToTop =
			 * lastChild.getTop(); messageingListView.setSelectionFromTop(last,
			 * childToTop-keybordHeight); }
			 */
            return;
        }
        if (getAdapter() == null){
            return;
        }

        int endPos = getAdapter().getItemCount()-1;
        if (endPos < 0) {
            return;
        }

        int last = ((LinearLayoutManager)getLayoutManager()).findLastVisibleItemPosition();
        android.util.Log.i(TAG, "last position=" + last + "; endPos=" + endPos);
        if (last >= 0) {// check is at last view
            // visiable..
            selectFromBottom(endPos);
            // double check
        } else {
            // keep scorll position..
			/*
			 * if (last >= 0) { //add keep View lastChild =
			 * messageingListView.getChildAt(last -
			 * messageingListView.getFirstVisiblePosition()); int childToTop =
			 * lastChild.getTop(); messageingListView.setSelectionFromTop(last,
			 * childToTop - keybordHeight); }
			 */

        }

    }

    private void selectFromBottom(int pos) {
            //软件盘弹出后，调整item的位置
            scrollToPosition(pos);
           // smoothScrollToEnd();


    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Log.i(TAG,oldh + "MessageRecyclerView size changed, h:" + h);
//        android.Log.i(TAG, oldh+"MessageRecyclerView size changed, h:"+h);
        if (getAdapter() == null) {
            return;
        }
        int keybordHeight = oldh - h;
        keybordShow(keybordHeight);


        if (mListener != null) {
            mListener.OnResize(w, h, oldw, oldh);
        }
    }





//    @Override
//    public boolean canScrollVertically(int direction) {
//        // check if scrolling up
//        if (direction < 1) {
//            boolean original = super.canScrollVertically(direction);
//            return !original && getChildAt(0) != null && getChildAt(0).getTop() < 0 || original;
//        }
//        return super.canScrollVertically(direction);
//
//    }


}
