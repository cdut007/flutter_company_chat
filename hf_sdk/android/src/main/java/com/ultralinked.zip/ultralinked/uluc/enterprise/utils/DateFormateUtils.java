package com.ultralinked.uluc.enterprise.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.content.Context;
import android.text.TextUtils;
import android.text.format.DateUtils;

import com.holdingfuture.flutterapp.hfsdk.R;


public class DateFormateUtils {
	private static final String TAG = "DateFormateUtils";
	public static String formateLongToMonthAndDay(Context ctx,Long dateLong){
		Date date = new Date(dateLong);
		SimpleDateFormat formater =
				new SimpleDateFormat(ctx.getString(R.string.date_formate),new Locale("zh"));
		String displayDate = formater.format(date);
		return displayDate;
	}

	public static Locale getCurrentLocale(Context context){
		Locale current = context.getResources().getConfiguration().locale;
		return current;
	}



	public static String getTodayDateFormartString(Context context,long timeInMilliseconds){
		String   date   =  getTodayDateFormartString(context, timeInMilliseconds, DateFormateUtils.is12HoursTimeFormart(context));
		return date;
	}



	static SimpleDateFormat   dateFormat12   =   new   SimpleDateFormat("h:mmaa");
	static SimpleDateFormat   dateFormat24   =   new   SimpleDateFormat("HH:mm");
	static SimpleDateFormat   dateFormat12WithSpace   =   new   SimpleDateFormat("h:mm aa");
	public static String getTodayDateFormartNoSpaceStr(Context context,long timeInMilliseconds,boolean isDateFormat12){
		 Date date = new Date();
		date.setTime(timeInMilliseconds);
		String   dateStr   =  isDateFormat12?dateFormat12.format(date): dateFormat24.format(date);
		return dateStr;
	}



	public static String getTodayDateFormartString(Context context,long timeInMilliseconds,boolean isDateFormat12){

		String   date   =  isDateFormat12?dateFormat12WithSpace.format(new Date(timeInMilliseconds)): dateFormat24.format(new Date(timeInMilliseconds));
		return date;
	}


	public static boolean is12HoursTimeFormart(Context context){

		return !android.text.format.DateFormat.is24HourFormat(context);
	}

	public static String formateLongToMinutes(Context ctx,long dateLong){
		if(dateLong<=0){
			Log.i(TAG, "parameter erro !");
			return "";
		}
		Locale locale = getCurrentLocale(ctx);
		String transformedDate = "";
		long curDateLong = System.currentTimeMillis();

		if(curDateLong<dateLong){ //furture time
			Date dateAgo = new Date(dateLong);
			SimpleDateFormat formater = new SimpleDateFormat("yyyy:MM:dd hh:mm:ss",locale);
			transformedDate = formater.format(dateAgo);
			return transformedDate;
		}else{
			Date dateAgo = new Date(dateLong);
			SimpleDateFormat formater =
					new SimpleDateFormat("HH:mm",locale);//eg:18:00
			String hour_and_minute = formater.format(dateAgo);
			String HourAndM[] = hour_and_minute.split(":");

			long sendHour= Long.parseLong(HourAndM[0]);
			//is today or not.
			int gapDay = (int)(curDateLong/(1000*60*60*24)-dateLong/(1000*60*60*24));
//			switch(gapDay){
//			case 0://today
//				if(sendHour ==0){//midnight
//					transformedDate = ctx.getString(R.string.midnight)+hour_and_minute;
//					break;
//				}
//
//				if(sendHour<12){//morning
//					transformedDate = ctx.getString(R.string.morning)+hour_and_minute;
//				}else if(sendHour>12){
//					if(sendHour<18)//afternoon
//						transformedDate = ctx.getString(R.string.afternoon)+hour_and_minute;
//					else//night
//						transformedDate = ctx.getString(R.string.night)+hour_and_minute;
//				}else if(sendHour==12){//noon
//					transformedDate = ctx.getString(R.string.noon)+hour_and_minute;
//				}
//				break;
//			case 1://yesterday
//				transformedDate = ctx.getString(R.string.yesterday)+hour_and_minute;
//				break;
//			case 2://the day before yesterday
//				transformedDate = ctx.getString(R.string.the_day_before)+hour_and_minute;
//				break;
//			default:
//				Date dateFormated = new Date(dateLong);
//				SimpleDateFormat format = new SimpleDateFormat(ctx.getString(R.string.last_msg_date_formate)+" h:mm a",new Locale("zh"));
//				transformedDate = format.format(dateFormated);
//				break;
//			}
		}

		return transformedDate;
	}
    public static boolean isYesterday(long when){

        long when2=when+(1000*60*60*24);

        return DateUtils.isToday(when2);

       }

	//to seconds
	public static String formateLongToSeconds(String fmt,long dateLong){
		//ctx.getString(R.string.msg_date_formate_to_seconds)
		if(dateLong<=0){
			Log.i(TAG, "parameter erro !");
			return "";
		}
		Date date = new Date(dateLong);
		SimpleDateFormat format = new SimpleDateFormat(fmt,new Locale("zh"));
		String detailDate = format.format(date);
		return detailDate;
	}

	public  static String covertDuration2RightFormat(String duration) {

		String formartedDuration = "";

		if (!TextUtils.isEmpty(duration)) {

			int duratinSecond = Integer.parseInt(duration);

			if (duratinSecond >= 0 && duratinSecond <= 60) {

				formartedDuration = "00:00:" + getFormart(duratinSecond);

			} else if (duratinSecond > 60 && duratinSecond <= 3600) {

				int m = 0;

				int s = 0;

				m = duratinSecond / 60;

				s = duratinSecond % 60;

				formartedDuration = "00:" + getFormart(m) + ":" + getFormart(s);

			} else if (duratinSecond > 3600) {

				int h = 0;

				int m = 0;

				int s = 0;

				h = duratinSecond / 3600;

				int temp = duratinSecond % 3600;

				m = temp / 60;

				s = temp % 60;

				formartedDuration = getFormart(h) + ":" + getFormart(m) + ":"
						+ getFormart(s);

			} else {

				Log.i(TAG, "wrong format");

			}

		} else {

			formartedDuration = "00:00:00";

		}
		return formartedDuration;

	}

	public static String getFormart(long duratinSecond) {

		String s = "";

		if (duratinSecond <= 9) {

			s = "0" + duratinSecond;

		} else {

			s = duratinSecond + "";

		}
		return s;

	}

}
