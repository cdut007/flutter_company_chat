package com.ultralinked.uluc.enterprise.contacts;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

/**
 * Created by ultralinked on 16/7/18.
 */
public class ChoicePopWindow extends PopupWindow {

    // internal contact, external contact, private contact

    public static final int CHOOSE_INTERNAL = 99;
    public static final int CHOOSE_EXTERNAL = 100;

    //the second choice of two type: manually input person name/mobile , or select from address book locally
    public static final int INPUTTYPE_MANNUAL_INPUT = 101;
    public static final int INPUTTYPE_LOCAL_ADDRESS_BOOK = 102;

    public static final int INPUTTYPE_INVITE_EXIST = 103;

    private final View rootView;
    private final Context context;
    private int width;
    private int height;
    private onMenuClickListener mListener;

    public ChoicePopWindow(Context context) {
        this.context = context;
        rootView = LayoutInflater.from(context).inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.layout_choice_plane, null);
        this.setContentView(rootView);
        // 设置弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        // 设置弹出窗体的高

        this.setHeight(getPopupHeight());
        //设置弹出窗体动画效果
        this.setAnimationStyle(com.holdingfuture.flutterapp.hfsdk.R.style.popwin_anim_style);

        //实例化一个ColorDrawable颜色为半透明
        ColorDrawable background = new ColorDrawable(0x4f000000);
        //设置弹出窗体的背景
        this.setBackgroundDrawable(background);

        initView();
    }

    /**
     * 强制绘制popupWindowView，并且初始化popupWindowView的尺寸
     */
    private void mandatoryDraw() {
        this.rootView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        /**
         * 强制刷新后拿到PopupWindow的宽高
         */
        this.width = this.rootView.getMeasuredWidth();
        this.height = this.rootView.getMeasuredHeight();
    }

    private void initView() {

        //init title bar
        rootView.findViewById(R.id.private_public_layout).setVisibility(View.GONE);
        rootView.findViewById(R.id.titleRight).setVisibility(View.GONE);
        rootView.findViewById(R.id.titleCenter).setVisibility(View.VISIBLE);
        ((TextView) rootView.findViewById(R.id.titleCenter)).setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.addcontact_add_contacts));
        ImageUtils.buttonEffect((ImageView)rootView.findViewById(R.id.left_back));

        //init the first view

        // 这里检验popWindow里的button是否可以点击
        Button second = (Button) rootView.findViewById(R.id.second);
        second.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                updatePopWindowView(rootView, CHOOSE_INTERNAL);
            }

        });

        Button third = (Button) rootView.findViewById(R.id.third);
        third.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                updatePopWindowView(rootView, CHOOSE_EXTERNAL);

            }
        });

        Button fourth = (Button) rootView.findViewById(R.id.fourth);
        fourth.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                dismiss();
            }
        });

        ImageView goBackImage = (ImageView) rootView.findViewById(R.id.left_back);
        goBackImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        //by default.
        updatePopWindowView(rootView, CHOOSE_INTERNAL);


    }

    //init the second view
    private void updatePopWindowView(View choicePlane, final int type) {


        final View choiceStep1 = choicePlane.findViewById(R.id.choiceStep1);
        final View choiceStep2 = choicePlane.findViewById(R.id.choiceStep2);
        choiceStep2.setVisibility(View.VISIBLE);

        AlphaAnimation animation = new AlphaAnimation(1.0f, 0.0f);
        animation.setDuration(1000);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                choiceStep1.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        AlphaAnimation animation2 = new AlphaAnimation(0.0f, 1.0f);
        animation.setDuration(1000);

        choiceStep1.setAnimation(animation);
        choiceStep2.setAnimation(animation2);

        animation.start();
        animation2.start();

        if (type == CHOOSE_INTERNAL) {
            ((TextView) choiceStep2.findViewById(R.id.first2))
                    .setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.addcontact_add_contacts));

        } else if (type == CHOOSE_EXTERNAL) {
            ((TextView) choiceStep2
                    .findViewById(R.id.first2)).
                    setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_add_to)
                            + " " + context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_external));
        } else {
            ((TextView) choiceStep2
                    .findViewById(R.id.first2)).
                    setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_add_to)
                            + " " + context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_private_client));

        }


        TextView second2 = (TextView) choiceStep2.findViewById(R.id.second2);
        second2.setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_mannual_input));
        second2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onChoiceSelect(type, INPUTTYPE_MANNUAL_INPUT);
                }
            }
        });

        TextView third2 = (TextView) choiceStep2.findViewById(R.id.third2);
        third2.setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_from_local_address));
        third2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onChoiceSelect(type, INPUTTYPE_LOCAL_ADDRESS_BOOK);
                }

            }
        });

        TextView fourth2 = (TextView) choiceStep2.findViewById(R.id.fourth2);
        fourth2.setText(context.getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_cancle));
        fourth2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public interface onMenuClickListener {

        void onChoiceSelect(int chooseType, int inputType);
    }

    public void setListener(onMenuClickListener listener) {
        mListener = listener;
    }

    @Override
    public void dismiss() {
        super.dismiss();
        mListener = null;

    }

    private int getPopupHeight() {
            Display display = ((Activity)context).getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);

            int statusBarHeight = 0;
            int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                statusBarHeight = context.getResources().getDimensionPixelSize(resourceId);
            }else{
                Rect frame = new Rect();
                ((Activity)context). getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
                 statusBarHeight = frame.top;
            }
            return size.y - statusBarHeight;

    }

}
