package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.CountDownTimer;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Message;

public class BruningView extends LinearLayout {
    //类中的两个私有成员，Text和Icon
    //IconifiedTextView中的两个子View。由TextView和ImageView组合成一个新的View。
    private TextView mText;
    private ImageView mIcon;
    private boolean isSender;

    public BruningView(Context context, AttributeSet attrs) {
        super(context, attrs);

        /* First Icon and the Text to the right (horizontal),
         * not above and below (vertical) */
        //设置IconifiedTextView为水平线性布局
        this.setOrientation(VERTICAL);
        //垂直居中对齐
        this.setGravity(Gravity.CENTER_VERTICAL);

        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs,
                    R.styleable.DisplayViewStyle);
            isSender = a.getBoolean(R.styleable.DisplayViewStyle_isSender, true);
            a.recycle();
        }

        //添加ImageView
        mIcon = new ImageView(context);

        mIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        mIcon.setImageResource(R.mipmap.fire_click_icon);

        // left, top, right, bottom
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);

        layoutParams.gravity = Gravity.CENTER_VERTICAL;

        layoutParams.width = getResources().getDimensionPixelSize(R.dimen.px_21_0_dp);
        layoutParams.height = getResources().getDimensionPixelSize(R.dimen.px_26_0_dp);


        LinearLayout.LayoutParams textlayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);

        textlayoutParams.gravity = Gravity.CENTER_VERTICAL;

        /* At first, add the Icon to ourself
         * (! we are extending LinearLayout) */

        //添加TextView， 由于先添加ImageView后添加TextView，所以 ICON 在前 Text 在后。
        mText = new TextView(context);
        /* Now the text (after the icon) */
        mText.setTextColor(context.getResources().getColor(R.color.light_blue));
        mText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        mText.setGravity(Gravity.CENTER);
        if (isSender) {

            addView(mIcon, layoutParams);
            addView(mText, textlayoutParams);
            // layoutParams.leftMargin = ScreenUtils.dp2px(context,5);


        } else {
            //  layoutParams.rightMargin = ScreenUtils.dp2px(context,5);

            addView(mIcon, layoutParams);
            addView(mText, textlayoutParams);
        }


    }

    //设置TextView的Text内容
    public void setText(String words) {
        //Log.i("test","setText  "+words);
        mText.setText(words);
    }

    Message message;
    private CountDownTimer timer;

    public interface BurningViewListener {
        void burningView(Message itemData);
    }

    BurningViewListener burningViewListener;

    public void setBurnMsg(Message itemData, BurningViewListener burningViewListener) {
        message = itemData;
        if (timer != null) {
            timer.cancel();
            timer = null;
        }

        this.burningViewListener = burningViewListener;

        boolean burningEnd = MessageUtils.checkBruningEnd(message, false);
        if (burningEnd) {
            post(new Runnable() {
                @Override
                public void run() {
                    BruningView.this.burningViewListener.burningView(message);
                }
            });

            return;
        }

        if (MessageUtils.hasStartBurning(message)) {

            mText.setVisibility(VISIBLE);

            long currentTime = System.currentTimeMillis() - message.burningTime;
            int leftTime = (int) (MessageUtils.getBurnTime(message) / 1000 - currentTime / 1000);
            setText(leftTime + "\"");
            Glide.with(getContext()).load(R.drawable.burning_fire).asGif().diskCacheStrategy(DiskCacheStrategy.NONE).error(R.mipmap.fire_click_icon).placeholder(R.mipmap.fire_click_icon).into(mIcon);

            timer = new CountDownTimer(leftTime * 1000, 1000) {

                @Override
                public void onTick(long millisUntilFinished) {
                    setText((millisUntilFinished / 1000) + "\"");

                }

                @Override
                public void onFinish() {
                    //remove.
                    BruningView.this.burningViewListener.burningView(message);
                }
            };
            timer.start();
        } else {

            mText.setVisibility(GONE);
            mIcon.setImageResource(R.mipmap.fire_click_icon);
            setText("");
        }

    }
}
