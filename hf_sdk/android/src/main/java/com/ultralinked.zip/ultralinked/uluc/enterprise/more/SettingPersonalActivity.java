package com.ultralinked.uluc.enterprise.more;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.tendcloud.tenddata.TCAgent;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.common.PasswordLockerHelper;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.ui.secret.SecretActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.BitmapHelp;
import com.ultralinked.voip.api.BitmapUtils;
import com.ultralinked.voip.api.utils.FileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class SettingPersonalActivity extends BaseActivity implements View.OnClickListener {

    private static final int SEX_CHOOSE = 0x22;
    TextView titleRight, titleCenter;
    EditText tvName, tvNickName, tvMobile, tvLocalNumber, tvEmail, tvCompany;
    ImageView ivGender;
    View imgView;
    ImageView ivUserPhoto;
    UserInfo userInfo;

    public static final int FILE_PERMISION_CODE = 0x123;
    public static final int OPEN_CAMERA_CODE = 0x1991;
    public static final int OPEN_GALLY_CODE = 0x1992;
    public static final int CROP_CODE = 0x1993;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_settingpersonal;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initIntent();
        TCAgent.onPageStart(getActivity(),"编辑个人资料");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"编辑个人资料");
    }

    private void initIntent() {
        userInfo = getIntent().getParcelableExtra("user_info");
        if (null != userInfo) {
            ImageUtils.loadCircleImage(this, ivUserPhoto, userInfo.getIcon_url(), ImageUtils.getDefaultContactImageResource(userInfo.getId()));
            tvName.setText(UserInfo.getDisplayName(userInfo));
            tvNickName.setText(userInfo.getNickname());
            tvMobile.setText(PhoneNumberUtils.formatMobile(userInfo.getMobile()));
            tvEmail.setText(userInfo.getEmail());

            int type = userInfo.getGender();
            try {

                if (type == 0){
                    ivGender.setTag("Female");
                    ivGender.setImageResource(R.mipmap.female);
                }else{
                    ivGender.setImageResource(R.mipmap.male);
                    ivGender.setTag("Male");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        } else {
            Log.i(TAG, "user info is null");
        }
    }


    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.left_back).setOnClickListener(this);
        titleRight = bind(R.id.titleRight);
        titleCenter = bind(R.id.titleCenter);
        titleRight.setText(R.string.edit);
        ImageUtils.buttonEffect(titleRight);
        titleCenter.setText(R.string.person_detail);
        imgView = bind(R.id.setImg);
        ivUserPhoto = bind(R.id.ivUserPhoto);
        tvName = bind(R.id.tvName);
        tvNickName = bind(R.id.tvNickname);
        ivGender = bind(R.id.tvGender);
        tvMobile = bind(R.id.tvMobile);
        tvLocalNumber = bind(R.id.tvLocalNumber);
        tvEmail = bind(R.id.tvEmail);
        tvCompany = bind(R.id.tvCompany);

        String companyName = CompanySelector.getInstance(this).getCompanyName();
        tvCompany.setText(TextUtils.isEmpty(companyName) ? "" :
                FragmentContacts.firstLetterToUpper(companyName));
        initListener(this, R.id.setImg, R.id.titleRight,R.id.vcard_code_scan,R.id.setGender);
        InputControlEnable(false);
    }

    private void InputControlEnable(boolean enable) {
        tvName.setEnabled(enable);
        tvNickName.setEnabled(enable);
        tvLocalNumber.setEnabled(enable);
        tvEmail.setEnabled(enable);

        if (enable) {
            //显示虚拟键盘
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(tvName, InputMethodManager.SHOW_FORCED);
            tvName.requestFocus();
        } else {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm.isActive()) {
                imm.hideSoftInputFromWindow(tvName.getApplicationWindowToken(), 0);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.setImg:
                if (checkPermission("file", FILE_PERMISION_CODE)) {
                    DialogManager.showItemsDialog(this, getString(R.string.img_from), new String[]{getString(R.string.take_photo), getString(R.string.gallery)}, imgView, new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            if (position == 0) {
                                GalleryFinal.openCamera(OPEN_CAMERA_CODE, mOnHandlerResultCallback);
                            } else {
                                GalleryFinal.openGallerySingle(OPEN_GALLY_CODE, mOnHandlerResultCallback);
                            }
                        }
                    });
                } else {
                    Log.i(TAG, "has no permission:" + Manifest.permission.WRITE_EXTERNAL_STORAGE);
                }

                break;
            case R.id.left_back:
                if (userInfo == null) {
                    Log.i(TAG, "user info is return null.");
                    finish();
                    return;
                }
                updateUserInfo();
                break;

            case R.id.vcard_code_scan:
                Intent intent = new Intent(this,MyQRCodeActivity.class);
                intent.putExtra("user_info",(Parcelable)userInfo);
                startActivity(intent);
                break;


            case R.id.titleRight:
                Log.i(TAG, "-----------");
                if (titleRight.getText().toString().equals(getString(R.string.save))){
                    updateUserInfo();
                }else{
                    titleRight.setText(R.string.save);
                    InputControlEnable(true);
                }

                break;

            case R.id.setGender:
            {
                if (titleRight.getText().toString().equals(getString(R.string.save))){
                    showChooseSexDialog();
                }else{
                    //do nothing.
                }
            }
                break;

        }
    }




    private void showChooseSexDialog() {
        Intent intent = new Intent();
        intent.setClass(getActivity(), ChooseSexSettingActivity.class);

        try{
            intent.putExtra("sex",ivGender.getTag().toString());
        }catch (Exception e){
            intent.putExtra("sex","Female");
            e.printStackTrace();
        }
        startActivityForResult(intent, SEX_CHOOSE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            if (requestCode == SEX_CHOOSE){
                String sex = data.getStringExtra("sex");
                try{
                    if (!ivGender.getTag().toString().equals(sex)){
                        if ("Female".equals(sex)){
                            ivGender.setImageResource(R.mipmap.female);
                        }else{
                            ivGender.setImageResource(R.mipmap.male);
                        }
                        ivGender.setTag(sex);

                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

    }

    private void updateUserInfo() {
        if (userInfo == null) {
            Log.i(TAG, "user info is return null.");
            return;
        }
        Map<String, String> map = new HashMap<>();
        //       String uName = tvName.getText().toString();
//        if (!TextUtils.isEmpty(uName) && !TextUtils.isEmpty(uName.trim()) && !uName.equals(userInfo.getName())) {
//            map.put("name", uName);
//        }

        String nickName = tvNickName.getText().toString();
        if (!TextUtils.isEmpty(nickName) && !TextUtils.isEmpty(nickName.trim())  && !nickName.equals(userInfo.getNickname())) {
            map.put("nickname", nickName);
        }

        String uEmail = tvEmail.getText().toString();
        if (!TextUtils.isEmpty(uEmail) &&  !TextUtils.isEmpty(uEmail.trim()) && !uEmail.equals(userInfo.getEmail())) {
            map.put("email", uEmail);
        }


        Object sex = ivGender.getTag();

        String uGender;

        if (sex!=null){
            uGender = sex.toString();
            int sexType = 1;//male
            if ("Female".equals(uGender)){
                sexType = 0;
            }
            int type = userInfo.getGender();
            if (type!=sexType){
                //sex is changed.
                map.put("gender", sexType+"");
            }

        }

//        String uLocalNumber = tvLocalNumber.getText().toString();
//        String setting_json = "{\"Gender\": \"" + uGender + "\",\"LocalNumber\":\"" + uLocalNumber + "\" }";
//        if (!setting_json.equals(userInfo.getSetting_json())) {
//            map.put("setting_json", setting_json);
//        }

        if (map.size() == 0) {
            Intent intent = new Intent();
            intent.putExtra("user_info", (Parcelable) userInfo);
            setResult(Activity.RESULT_OK, intent);
            finish();
        }else{
            updateUserSetting(map);
        }

    }

    private void updateUserSetting(Map<String, String> map) {
        ApiManager.getInstance().updateUserInfo(map).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<UserInfo>() {
                    @Override
                    public void call(UserInfo userInfo) {
                        Intent intent = new Intent();
                        intent.putExtra("user_info", (Parcelable) userInfo);
                        setResult(Activity.RESULT_OK, intent);
                        finish();
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        String error = HttpErrorException.handErrorMessage(throwable);
                        showToast(error);
                        finish();
                        Log.e(TAG, error);
                    }
                });
    }


    /**
     * get the thumbnail of the origin bitmap max size is 500KB
     *
     * @param orginBitmap
     * @return
     */
    public static Bitmap getThumbnail(Bitmap orginBitmap) {
        Bitmap bitmap = null;
        if (BitmapHelp.kBSizeOf(orginBitmap) > 500) {

            bitmap = BitmapUtils.compressImage(orginBitmap, 500, 2);
            if (bitmap == null) {
                com.ultralinked.voip.api.Log.i("getThumbnail", "getThumbnail is null from compress");
            } else {
                com.ultralinked.voip.api.Log.i("getThumbnail", "getThumbnail compress image w:" + bitmap.getWidth() + ";image h:" + bitmap.getHeight());

            }
        } else {

            bitmap = orginBitmap;
            if (bitmap == null) {
                com.ultralinked.voip.api.Log.i("getThumbnail", "getThumbnail is null from orginal");
            }
        }

        return bitmap;

    }


    private void uploadImg(final String filePath) {
        Log.i(TAG, filePath);
        File imgFile = new File(filePath);
        if (imgFile.length() > 500 * 1024) {

            Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            com.ultralinked.voip.api.Log.i("uploadImg", "Image file too large!");
            if (bitmap != null) {
                Bitmap compressedBitmap = getThumbnail(bitmap);
                if (compressedBitmap != null) {
                    BitmapUtils.saveBitmap(compressedBitmap, filePath);
                } else {
                    com.ultralinked.voip.api.Log.i("uploadImg", "getThumbnail is null from compress");
                    return;
                }

            } else {
                com.ultralinked.voip.api.Log.i("uploadImg", "getThumbnail is null from corp path");
                return;
            }


        }
        RequestBody body = RequestBody.create(MediaType.parse("image/png"), imgFile);
        Map<String, RequestBody> map = new HashMap<>();
        map.put("file\"; filename=\"" + imgFile.getName() + "", body);

        try {
            ApiManager.getInstance().upImg(map).subscribeOn(Schedulers.io()).compose(this.<ResponseBody>bindToLifecycle())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<ResponseBody>() {
                        @Override
                        public void onNext(ResponseBody responseBody) {
                            userInfo.setIcon_url(filePath);
                            ImageUtils.loadCircleImage(SettingPersonalActivity.this, ivUserPhoto, filePath, ImageUtils.getDefaultContactImageResource(userInfo.getId()));

                        }

                        @Override
                        public void onCompleted() {
                            Log.i(TAG, "uploadImg is compelete ");
                        }

                        @Override
                        public void onError(Throwable e) {
                            String eMsg = HttpErrorException.handErrorMessage(e);
                            Log.i(TAG, "get the error info:" + eMsg);
                            showToast(eMsg+"");
                        }

                    });

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            Log.e(TAG, "update fail");
        }

    }


    /**
     * 图片选择器的回调
     */
    private GalleryFinal.OnHanlderResultCallback mOnHandlerResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int requestCode, List<PhotoInfo> resultList) {
            if (resultList == null) {
                Log.i(TAG, " requestCode:" + requestCode + " resultList is null.");
                return;
            }
            if (requestCode == OPEN_CAMERA_CODE || requestCode == OPEN_GALLY_CODE) {
                for (PhotoInfo photoInfo : resultList) {
                    String filePath = photoInfo.getPhotoPath();
                    if (FileUtils.isFileExist(filePath)) {
                        GalleryFinal.openCrop(CROP_CODE, filePath, new GalleryFinal.OnHanlderResultCallback() {
                            @Override
                            public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
                                if (reqeustCode == CROP_CODE) {
                                    for (PhotoInfo photoInfo : resultList) {
                                        String filePath = photoInfo.getPhotoPath();
                                        if (FileUtils.isFileExist(filePath)) {
                                            uploadImg(filePath);
                                        }
                                    }
                                }
                            }

                            @Override
                            public void onHanlderFailure(int requestCode, String errorMsg) {
                                Log.d(TAG, "the photo file is not exist.. filePath:" + errorMsg);
                            }
                        });

                    } else {
                        Log.d(TAG, "the photo file is not exist.. filePath:" + filePath);
                    }
                }
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            showToast(errorMsg);
            Log.i(TAG, " requestCode:" + requestCode + " errorMsg:" + errorMsg);
        }
    };

    @Override
    public void onBackPressed() {
        //setResult(Activity.RESULT_CANCELED);
        updateUserInfo();
        super.onBackPressed();
    }
}
