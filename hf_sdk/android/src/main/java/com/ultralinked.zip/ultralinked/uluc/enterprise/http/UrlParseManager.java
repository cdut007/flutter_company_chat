package com.ultralinked.uluc.enterprise.http;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.chat.bean.UrlInfo;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.TextMessage;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Completable;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/6/16 0016.
 */

public class UrlParseManager {

    private static UrlParseManager urlParseManager;
    private final String TAG = getClass().getSimpleName();
    private  ApiService apiService;
    Retrofit.Builder retrofit;

    private UrlParseManager() {
    }


    private  static List<String> FetchUrls =new ArrayList<>();



//    public static String doGet(String urlStr) throws CommonException {
//        URL url;
//        String html = "";
//        try {
//            url = new URL(urlStr);
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//            if (urlStr.startsWith("https")){
//                Https
//            }
//
//            connection.setRequestMethod("GET");
//            connection.setConnectTimeout(10000);
//            connection.setDoInput(true);
//            connection.setDoOutput(true);
//            if (connection.getResponseCode() == 200) {
//                InputStream in = connection.getInputStream();
//                html = StreamTool.inToStringByByte(in);
//            } else {
//                throw new CommonException("新闻服务器返回值不为200");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new CommonException("get请求失败");
//        }
//        return html;
//    }

    public  void  requestUrl(final Message itemData, final String url) {
        if (FetchUrls.contains(url)){
            return ;
        }
        FetchUrls.add(url);
        try{


            Observable.create(new Observable.OnSubscribe<String>() {


                @Override
                public void call(Subscriber<? super String> subscriber) {
                    try {
                        String requestUrl = url;
                        if (!url.startsWith("http")){
                            requestUrl = "http://"+url;
                        }
                        Document doc = Jsoup.connect(requestUrl).timeout(10000).get();
                        Log.i(TAG,"html:" +doc.toString());
                        String result = null;

                        FetchUrls.remove(((TextMessage) itemData).getText());
                        String title = doc.title();
                        if (!TextUtils.isEmpty(title)){
                            UrlInfo urlInfo = new UrlInfo();

                            urlInfo.title = title;
                            Element image = doc.select("img").first();
                            if (image!=null){

                                String imgUrl = image.absUrl("src");
                                urlInfo.imgUrl = imgUrl;
                            }
                            String content = doc.head().select("meta[name=description]").attr("content");
                            if (!TextUtils.isEmpty(content)){
                                urlInfo.content = content;
                            }else{
                                String keywords = doc.head().select("meta[name=keywords]").attr("content");
                                if (!TextUtils.isEmpty(keywords)){
                                    urlInfo.content = keywords;
                                }
                            }


                            Message msg = MessagingApi.getMessageById(itemData.getKeyId(),itemData.getChatType() == Conversation.GROUP_CHAT);
                            if (msg == null){
                                Log.i(TAG,"query msg is null");
                                msg = itemData;
                            }else{
                                Log.i(TAG,"query msg info succ."+msg.toString());
                            }

                            msg.tag =urlInfo;
                            Log.i(TAG,"urlInfo:" +urlInfo.toString());
                            MessageUtils.saveUrl(msg);
                            Intent callHandlerIntent = new Intent(MessagingApi.EVENT_MESSAGE_STATUS_CHANGED);
                            callHandlerIntent.putExtra("message", msg);
                            LocalBroadcastManager.getInstance(App.getInstance()).sendBroadcast(callHandlerIntent);

                        }
                        subscriber.onNext(result);
                    } catch (Exception e) {
                        e.printStackTrace();
                        subscriber.onNext(null);
                    }


                }

            })
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Action1<String>() {
                        @Override
                        public void call(String info) {
                            String resultInfo = info;
                            Log.i(TAG,"htmlInfo:"+resultInfo);
                            //

                        }

                    });

        }catch (Exception e){
            e.printStackTrace();
        }

    }


    public static UrlParseManager getInstance() {
        if (urlParseManager == null){
            urlParseManager = new UrlParseManager();
        }
        return urlParseManager;
    }




}
