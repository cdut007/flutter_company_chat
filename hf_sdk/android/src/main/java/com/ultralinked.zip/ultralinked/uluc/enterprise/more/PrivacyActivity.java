package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import com.ultralinked.uluc.enterprise.baseui.widget.SwitchView;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mac on 16/11/23.
 */

public class PrivacyActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_privacy_setting;
    }

    SwitchView firendConfirmPrivacy,findMobileContacts;

    @Override
    public void initView(Bundle savedInstanceState) {
        TextView title = bind(R.id.titleCenter);
        title.setText(R.string.privacy_settings);
        goneView(bind(R.id.titleRight));
        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        findMobileContacts = bind(R.id.find_mobile_contacts_notifications);
        findMobileContacts.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));
        findMobileContacts.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                view.toggleSwitch(true);
                setFindContacts(true);
            }

            @Override
            public void toggleToOff(SwitchView view) {
                view.toggleSwitch(false);
                setFindContacts(false);
            }
        });
       // queryLastestContactsEnableFromServer();
        setFindContactsState(SPUtil.getFindContactsSetting());

        firendConfirmPrivacy = bind(R.id.privacy_firend_confirm_notifications);
        firendConfirmPrivacy.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));

        firendConfirmPrivacy.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                view.toggleSwitch(true);
                setRequestThePrivacy(true);
            }

            @Override
            public void toggleToOff(SwitchView view) {
                view.toggleSwitch(false);
                setRequestThePrivacy(false);
            }
        });


        setFriendConfirmToggleState(SPUtil.getPrivacyFriendConfirmSetting());
        queryLastestPrivacyFromServer();
    }

    private void setFindContacts(boolean enable) {
        SPUtil.saveFindContactsSetting(enable);
        RxBus.getDefault().post("change contacts model");
       // setFindContactsState(enable);
    }


    void setFindContactsState(boolean enable) {
        if (enable) {
            findMobileContacts.toggleSwitch(true);
        } else {
            findMobileContacts.toggleSwitch(false);
        }
    }

    void setFriendConfirmToggleState(boolean enable) {
        if (enable) {
            firendConfirmPrivacy.toggleSwitch(true);
        } else {
            firendConfirmPrivacy.toggleSwitch(false);
        }
    }


    void queryLastestPrivacyFromServer() {

        ApiManager.getInstance().queryFriendConfrrmSetting()
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryLastestPrivacyFromServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                String result = object.optString("result");
                                boolean needAuth = "need_auth".equals(result);
                                if (needAuth) {
                                    boolean enable = false;
                                    SPUtil.savePrivacyFriendConfrimSetting(needAuth);
                                    setFriendConfirmToggleState(needAuth);
                                }

                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse queryLastestPrivacyFromServer error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "queryLastestPrivacyFromServer result:"+rs);
                    }
                });

    }

    void setRequestThePrivacy(boolean enable) {

        ApiManager.getInstance().requestFriendConfirmSetting(enable)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "querySetRequestThePrivacyComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                        showToast(""+eMsg);
                        //if set failed , just reset the status to back
                        resetFriendConfrimByFailed();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                JSONObject result = object.optJSONObject("result");
                                if (result!=null) {
                                    String auth = result.optString("add_friend_setting");
                                    boolean enable = "need_auth".equals(auth);
                                    SPUtil.savePrivacyFriendConfrimSetting(enable);
                                    setFriendConfirmToggleState(enable);
                                }else{
                                    //if set failed , just reset the status to back
                                    resetFriendConfrimByFailed();
                                }

                            }else{
                                //if set failed , just reset the status to back
                                resetFriendConfrimByFailed();
                            }

                        } catch (Exception e) {
                            //if set failed , just reset the status to back
                            resetFriendConfrimByFailed();
                            Log.e(TAG, "parse setRequestThePrivacy error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "setRequestThePrivacy result:"+rs);
                    }
                });



    }

    private void resetFriendConfrimByFailed() {

            setFriendConfirmToggleState(!firendConfirmPrivacy.isOpened());

    }


}
