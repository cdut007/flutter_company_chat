package com.ultralinked.uluc.enterprise.common;

import android.app.Activity;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;

import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by ultralinked on 2016/6/8 0008.
 */
public class AutoGetCode extends ContentObserver {
    private static final String TAG = ">>>AutoGetCode";
    private final Handler handler;
    private Cursor cursor = null;
    private Activity activity;

    private String smsContent = "";

    public AutoGetCode(Activity activity, Handler handler) {
        super(handler);
        this.activity = activity;
        this.handler = handler;
    }

    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        // 读取收件箱中指定号码的短信
        try {
            cursor = activity.managedQuery(Uri.parse("content://sms/inbox"),
                    new String[]{"_id", "address", "read", "body"}, "read=?",
                    new String[]{"0"}, "_id desc");//not check address
            // 按短信id排序，如果按date排序的话，修改手机时间后，读取的短信就不准了
            Log.i(TAG, "onChange");
            if (cursor != null && cursor.getCount() > 0) {
                cursor.moveToFirst();
                if (cursor.moveToFirst()) {

                    String smsbody = cursor.getString(cursor.getColumnIndex("body"));
                    if (smsbody != null && smsbody.contains("code:") ||
                            smsbody.contains("短信验证码")) {
                        Log.i(TAG, "smsbody==" + smsbody);
                        String regEx = "[^0-9]";
                        Pattern p = Pattern.compile(regEx);
                        Matcher m = p.matcher(smsbody);
                        smsContent = m.replaceAll("").trim().toString();//non - number replace "

                        Message msg = new Message();
                        msg.obj = smsContent;
                        handler.sendMessage(msg);
                    }


                } else {
                    Log.i(TAG, "cursor is not move to first");
                }

            } else {
                Log.i(TAG, "cursor is null");
            }

        } catch (Exception e) {
            Log.i(TAG, "parse otp error:" + android.util.Log.getStackTraceString(e));
        }

    }
}
