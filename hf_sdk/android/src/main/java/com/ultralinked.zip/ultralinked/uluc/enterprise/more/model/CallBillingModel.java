package com.ultralinked.uluc.enterprise.more.model;

import com.ultralinked.uluc.enterprise.utils.Log;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by lly on 2017/1/16.
 */

public class CallBillingModel implements Serializable {

    private String destination_number;
    private String charged_amount;
    private String origin_duration;
    private String charged_starttime;

    public String getDestination_number() {
        return destination_number;
    }

    public void setDestination_number(String destination_number) {
        this.destination_number = destination_number;
    }

    public String getCharged_amount() {
        return charged_amount;
    }

    public void setCharged_amount(String charged_amount) {
        this.charged_amount = charged_amount;
    }

    public String getOrigin_duration() {
        return origin_duration;
    }

    public void setOrigin_duration(String origin_duration) {
        this.origin_duration = origin_duration;
    }

    public String getCharged_starttime() {
        return charged_starttime;
    }

    public String getSystem_startTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date = dateFormat.parse(charged_starttime);
            return dateFormat.format(date.getTime() + TimeZone.getDefault().getRawOffset());
        } catch (Exception e) {
            Log.e("CallBillingModel getSystem_startTime error: ",android.util.Log.getStackTraceString(e));
            return charged_starttime;
        }
    }

    public void setCharged_starttime(String charged_starttime) {
        this.charged_starttime = charged_starttime;
    }
}
