package com.ultralinked.uluc.enterprise.contacts.ui.selectmember;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.ultralinked.contact.util.ToastUtil;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.ChatUtils;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadContactTask;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadMembersTask;
import com.ultralinked.uluc.enterprise.contacts.ui.MyHandler;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.EmailType;
import ezvcard.parameter.ImageType;
import ezvcard.parameter.TelephoneType;
import ezvcard.property.Photo;
import ezvcard.property.StructuredName;



//add local registter later.
public class SelectMemberActivity extends BaseActivity implements ReadMembersTask.onContactReadFinishListener {

    public static final String REQUEST_CODE = "requestcode";
    public static final int REQUEST_SEND_VCARD = 92;
    public static final int REQUEST_CREATE_CHAT = 93;
    public static final int REQUEST_INVITE_MEMBERS = 0x10;

    public static final int REQUEST_FORWARD_MESSAGE = 95;


    public static final String CREATE_SIGNLE = "createsinglechat";
    public static final String CREATE_GROUP_MEMBER = "GROUP_MEMber";
    public static final String SEND_VCARD = "sendVcard";

    private static final int ID_LOADER_SELECT = 842;
    private static final String TAG = "SelectMemberActivity";
    private static final int MAKE_VCARD_FINISH = 843;
    private static final int RELOAD_ON_SEARCH = 844;
    private HashMap<String, PeopleEntity> CacheCheckBoxWhenDataChange = new HashMap<>();

    private ReadMembersTask mReadContactTask;


    ListView expandableListView;
    SelectMemberAdapter expandableListAdapter;
    private TextView titleRight;
    private EditText mSearchEdittext;
    private TextView titleCenter;
    private MyHandler mHandler;
    private boolean isSharebyOutside;


    public static void startForResult(Fragment context, int requestCode, Bundle data) {
        Intent intent = new Intent(context.getContext(), SelectMemberActivity.class);
        if (requestCode == REQUEST_CREATE_CHAT) {
            intent.putExtra(REQUEST_CODE, REQUEST_CREATE_CHAT);
        } else if (requestCode == REQUEST_SEND_VCARD) {
            intent.putExtra(REQUEST_CODE, REQUEST_SEND_VCARD);
        } else if (requestCode == REQUEST_FORWARD_MESSAGE) {
            intent.putExtra(REQUEST_CODE, REQUEST_FORWARD_MESSAGE);
        } else if (requestCode == REQUEST_INVITE_MEMBERS) {
            intent.putExtra(REQUEST_CODE, REQUEST_INVITE_MEMBERS);
        } else {
            throw new NullPointerException("SelectMemberActivity has a bad request code");
        }

        if (data != null) {
            intent.putExtra("data", data);
        }

        context.startActivityForResult(intent, requestCode);
    }


    public static void startForResult(Fragment context, int requestCode) {
        startForResult(context, requestCode, null);
    }


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_select_member;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(com.holdingfuture.flutterapp.hfsdk.R.layout.activity_select_member);

        mHandler = new MyHandler(this);

        // must start here ,cause ondestroy may throws unregister error..
        int checkShareAvaliable = ChatUtils.checkAllowedShareIntent(this, getIntent());
        switch (checkShareAvaliable) {
            case 0:// prepare share flag with outside
                isSharebyOutside = true;
                break;
            case 1:// go to provision
                App.getInstance().goToLoginActivity(false);
                finish();
                return;
            case 2:// files > 5 items
                int maxNum = getResources().getInteger(R.integer.max_send_media_num);
                ToastUtil.showToast(this, getString(R.string.chat_share_file_reach_max_limited, maxNum), Toast.LENGTH_LONG);
                finish();
                return;
            case 3:// unkonw errors
                finish();
                return;
            default:// do nothing.
                break;
        }


        mHandler.setListener(new MyHandler.MyHandlerListener() {
            @Override
            public void handleMessage(Message msg) {

                switch (msg.what) {

                    case MAKE_VCARD_FINISH:
                        mProgressBar.setVisibility(View.GONE);
                        expandableListView.setVisibility(View.VISIBLE);

                        ArrayList<String> adrlist = (ArrayList<String>) msg.obj;

                        if (adrlist != null && adrlist.size() > 0) {
                            Log.i(TAG, "MAKE_VCARD_FINISH size " + adrlist.size());
                            int size = adrlist.size();
                            Intent intent = new Intent();
                            String[] strings = adrlist.toArray(new String[size]);
                            intent.putExtra(SEND_VCARD, strings);
                            setResult(RESULT_OK, intent);
                        } else {
                            Log.i(TAG, "MAKE_VCARD_FINISH size null");
                            setResult(RESULT_CANCELED, null);
                        }
                        finish();

                        break;

                    case RELOAD_ON_SEARCH:

                        String s = (String) msg.obj;
                        if (mReadContactTask != null) {

                            if (TextUtils.isEmpty(s)) {
                                mSearchWord = "";
                                mReadContactTask.resetLoader(null);
                            } else {
                                mSearchWord = s.toString();
                                mReadContactTask.resetLoader(mSearchWord);
                            }

                        }

                        break;
                    default:
                        break;
                }
            }
        });

        initTitleBar();
        initExpandableListView();
        initSearchView();
        Bundle data = getIntent().getBundleExtra("data");
        if (data != null) {
            mFilterItems = data.getParcelableArrayList("members");
            if (mFilterItems != null) {
                Log.i(TAG, "get the filter items " + mFilterItems.size());
            }
        }

        mReadContactTask = new ReadMembersTask(this, ID_LOADER_SELECT);
        mReadContactTask.registerListener(this);
        getSupportLoaderManager().initLoader(ID_LOADER_SELECT, null, mReadContactTask.getLoader());
        mReadContactTask.restCompany(" '" + CompanySelector.getInstance(this).getCompanyID() + "' ");

    }

    private List<PeopleEntity> mFilterItems;

    public String mSearchWord;

    private void initSearchView() {
        mSearchEdittext = (EditText) findViewById(R.id.search_edittext);
        mSearchEdittext.addTextChangedListener(new TextWatcher() {


            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                //before search record which data is checked
                freshCheckData();

                Message message = new Message();
                message.what = RELOAD_ON_SEARCH;
                message.obj = "" + s.toString();
                mHandler.sendMessage(message);
            }
        });
    }

    private void freshCheckData() {

        if (mInteralDataList == null) {

            return;
        }

        for (PeopleEntity item : mInteralDataList) {

            if (item.isSelected) {
                item.isSelected = true;
                CacheCheckBoxWhenDataChange.put(item.subuser_id, item);
            } else {
                item.isSelected = false;
                CacheCheckBoxWhenDataChange.put(item.subuser_id, item);
            }
        }

        if (mExteralDataList == null) {

            return;
        }

        for (PeopleEntity item : mExteralDataList) {

            if (item.isSelected) {
                item.isSelected = true;
                CacheCheckBoxWhenDataChange.put(item.subuser_id, item);
            } else {
                item.isSelected = false;
                CacheCheckBoxWhenDataChange.put(item.subuser_id, item);
            }
        }
    }

    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title));


        titleRight = (TextView) findViewById(R.id.titleRight);
        titleRight.setVisibility(View.VISIBLE);
        titleRight.setText(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_done);

        titleRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getIntent().getIntExtra(REQUEST_CODE, -1) == REQUEST_CREATE_CHAT) {// chat之谜之缩进大蜈蚣开始
                    createChatMember();
                } else if (getIntent().getIntExtra(REQUEST_CODE, -1) == REQUEST_SEND_VCARD) {//vcard
                    fanhuiVCardUriAddress();
                } else if (getIntent().getIntExtra(REQUEST_CODE, -1) == REQUEST_FORWARD_MESSAGE) {//forward
                    backToForwardUriAddress();
                } else if (isSharebyOutside) {//share
                    checkIntentBundleSharedDataToSend(getIntent());
                } else if (getIntent().getIntExtra(REQUEST_CODE, -1) == REQUEST_INVITE_MEMBERS) {//chat details 界面邀请联系人入群
                    sendInviteMembers();
                }
            }
        });
    }

    private void sendInviteMembers() {

        ArrayList<PeopleEntity> selecteds = new ArrayList<>();

        for (String key : CacheCheckBoxWhenDataChange.keySet()) {
            PeopleEntity item = CacheCheckBoxWhenDataChange.get(key);
            if (item.isSelected) {
                selecteds.add(item);
            }
        }
        Log.i(TAG, "sendInviteMembers size " + selecteds.size());
        Intent date = new Intent();
        date.putParcelableArrayListExtra("invite_members", selecteds);
        setResult(Activity.RESULT_OK, date);
        finish();
    }

    private void createChatMember() {
        final ArrayList<PeopleEntity> selecteds = new ArrayList<>();

        for (String key : CacheCheckBoxWhenDataChange.keySet()) {
            PeopleEntity item = CacheCheckBoxWhenDataChange.get(key);
            if (item.isSelected) {
                selecteds.add(item);
            }
        }

        int size = selecteds.size();
        Log.i(TAG, "createChatMember size " + size);
        if (size == 1) {//single chat
            Intent intent = new Intent();
            intent.putExtra(CREATE_SIGNLE, selecteds.get(0).subuser_id);
            setResult(Activity.RESULT_OK, intent);
            finish();
        } else if (size > 1) {
            createGroupConversation(selecteds);
        } else {
            setResult(Activity.RESULT_CANCELED, null);
        }
    }

    private void createGroupConversation(final ArrayList<PeopleEntity> selecteds) {
        //group chat
        final EditText editText = new EditText(SelectMemberActivity.this);
        new AlertDialog.Builder(SelectMemberActivity.this).setTitle(getString(R.string.group_chat_create_hint))
                .setIcon(android.R.drawable.ic_dialog_info).setView(editText)
                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ArrayList<String> memberName = new ArrayList<String>();
                        for (PeopleEntity p : selecteds) {
                            memberName.add(p.subuser_id);
                        }
                        Intent intent = new Intent();
                        intent.putStringArrayListExtra(CREATE_GROUP_MEMBER, memberName);
                        String d = editText.getText().toString();
                        Log.i(TAG, d);
                        intent.putExtra("topic_name", d);
                        setResult(Activity.RESULT_OK, intent);
                        finish();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getSupportLoaderManager().destroyLoader(ID_LOADER_SELECT);
        mHandler.removeCallbacks(null);
    }

    ProgressBar mProgressBar;

    private void initExpandableListView() {

        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);

        mProgressBar.setVisibility(View.GONE);

        expandableListView = (ListView) findViewById(R.id.expandablelistview);

        expandableListAdapter = new SelectMemberAdapter(this);

        expandableListView.setAdapter(expandableListAdapter);


        expandableListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PeopleEntity data = (PeopleEntity) parent.getAdapter().getItem(position);
                data.isSelected = !data.isSelected;

                expandableListAdapter.notifyDataSetChanged();

                Log.i(TAG, data.name + " is " + data.isSelected);

                freshCheckData();

                CaculateSelectedNumber();
            }
        });

    }


    ArrayList<PeopleEntity> mInteralDataList;
    ArrayList<PeopleEntity> mExteralDataList;

    @Override
    public void setAdapter(List<PeopleEntity> internal, List<PeopleEntity> external) {

        mInteralDataList = (ArrayList<PeopleEntity>) internal;
        mExteralDataList = (ArrayList<PeopleEntity>) external;

        mInteralDataList = filterItems(mInteralDataList);
        //find out which row are selected before search
        for (PeopleEntity entity : mInteralDataList) {

            if (CacheCheckBoxWhenDataChange.containsKey(entity.subuser_id)) {

                entity.isSelected = CacheCheckBoxWhenDataChange.get(entity.subuser_id).isSelected;
            }
        }
        for (PeopleEntity entity : mExteralDataList) {

            if (CacheCheckBoxWhenDataChange.containsKey(entity.subuser_id)) {
                entity.isSelected = CacheCheckBoxWhenDataChange.get(entity.subuser_id).isSelected;
            }
        }

        expandableListAdapter.updateList(mInteralDataList);

    }

    private ArrayList<PeopleEntity> filterItems(ArrayList<PeopleEntity> mInteralDataList) {
        if (mFilterItems == null) {
            return mInteralDataList;
        }
        ArrayList<PeopleEntity> dataList = new ArrayList<>(mInteralDataList);

        for (int i = dataList.size() - 1; i > -1 && i < dataList.size(); i--) {
            PeopleEntity people = dataList.get(i);
            if (mFilterItems.contains(people)) {
                com.ultralinked.uluc.enterprise.utils.Log.i(TAG, "has the member name is :" + PeopleEntityQuery.getDisplayName(people));
                dataList.remove(people);
            }
        }


        com.ultralinked.uluc.enterprise.utils.Log.i(TAG, "dataList length is :" + dataList.size());
        return dataList;


    }

    /**
     * change title when item checked
     */
    private void CaculateSelectedNumber() {

        int total = 0;
        for (String key : CacheCheckBoxWhenDataChange.keySet()) {
            if (CacheCheckBoxWhenDataChange.get(key).isSelected) {
                total += 1;
            }
        }

        if (0 == total) {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title));
        } else if (1 == total) {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title_count_one));
        } else {
            titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.select_member_title_count, "" + total));
        }

    }


    private void checkIntentBundleSharedDataToSend(final Intent sharedIntent) {

        mProgressBar.setVisibility(View.VISIBLE);
        expandableListView.setVisibility(View.INVISIBLE);

        new Thread(new Runnable() {
            @Override
            public void run() {

                final ArrayList<PeopleEntity> selectedMember = new ArrayList<>();

                ArrayList<Conversation> forwardConvsList = new ArrayList<Conversation>();

                for (String key : CacheCheckBoxWhenDataChange.keySet()) {
                    PeopleEntity item = CacheCheckBoxWhenDataChange.get(key);
                    if (item.isSelected) {
                        selectedMember.add(item);
                        Conversation conversation = MessagingApi.getConversation(item.subuser_id);
                        forwardConvsList.add(conversation);
                        sendSharedMessage(conversation, sharedIntent);
                    }
                }

                if (forwardConvsList.size() > 0) {
                    Conversation conversation = forwardConvsList.get(forwardConvsList.size() - 1);
                    SingleChatImActivity.launchToSingleChatIm(SelectMemberActivity.this, conversation.getContactNumber(), Conversation.CONVERSATION_FLAG_NONE);
                    setResult(RESULT_OK);
                    finish();
                }

            }
        }).start();
    }

    private void sendSharedMessage(Conversation mConversation, Intent sharedIntent) {
        List<Uri> shareUris = new ArrayList<Uri>();
        List<String> shareContents = new ArrayList<String>();

        ChatModule chatModel = new ChatModule(mConversation, SelectMemberActivity.this);

        int sharedMsgType = ChatUtils.getParseSharedTypeWithIntent(
                sharedIntent, shareUris, shareContents);
        if (sharedMsgType == ChatModule.MESSAGE_SHARED_TEXT) {
            for (String content : shareContents) {
                chatModel.sendText(content, null);
            }
            return;
        }

        for (Uri uri : shareUris) {
            com.ultralinked.voip.api.Message message = ChatUtils.createParseSharedMessagewithUri(SelectMemberActivity.this, chatModel, uri, sharedMsgType);// other files message.

        }

    }


    private void backToForwardUriAddress() {


        mProgressBar.setVisibility(View.VISIBLE);
        expandableListView.setVisibility(View.INVISIBLE);

        final ArrayList<PeopleEntity> selectedMember = new ArrayList<>();

        for (String key : CacheCheckBoxWhenDataChange.keySet()) {
            PeopleEntity item = CacheCheckBoxWhenDataChange.get(key);
            if (item.isSelected) {
                selectedMember.add(item);
            }
        }
        Log.i(TAG, "fanhuiVCardUriAddress size " + selectedMember.size());
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                Bundle data = getIntent().getBundleExtra("data");
                if (data != null) {
                    com.ultralinked.voip.api.Message msg = (com.ultralinked.voip.api.Message) data.getSerializable("message");
                    ArrayList<Conversation> forwardConvsList = new ArrayList<Conversation>();
                    try {
                        for (PeopleEntity entity : selectedMember) {

                            String adr = null;
                            Conversation conversation = MessagingApi.forwordMsg(msg, entity.subuser_id, Conversation.SINGLE_CHAT);
                            if (conversation != null) {
                                forwardConvsList.add(conversation);
                            }

                        }
                        if (forwardConvsList.size() > 0) {
                            Conversation conversation = forwardConvsList.get(forwardConvsList.size() - 1);
                            SingleChatImActivity.launchToSingleChatIm(SelectMemberActivity.this, conversation.getContactNumber(), Conversation.CONVERSATION_FLAG_NONE);
                            setResult(RESULT_OK);
                            finish();
                        }


                    } catch (Exception e) {
                        Log.i(TAG, "Exception forward message: " + e.getMessage());
                    }
                } else {
                    Log.i(TAG, "bundle message data is empty ");
                }


            }
        });

    }


    private void fanhuiVCardUriAddress() {

        mProgressBar.setVisibility(View.VISIBLE);
        expandableListView.setVisibility(View.INVISIBLE);

        final ArrayList<PeopleEntity> selectedMember = new ArrayList<>();

        for (String key : CacheCheckBoxWhenDataChange.keySet()) {
            PeopleEntity item = CacheCheckBoxWhenDataChange.get(key);
            if (item.isSelected) {
                selectedMember.add(item);
            }
        }
        Log.i(TAG, "fanhuiVCardUriAddress size " + selectedMember.size());
        mHandler.post(new Runnable() {
            @Override
            public void run() {

                ArrayList<String> addressList = new ArrayList<String>();
                try {
                    for (PeopleEntity entity : selectedMember) {

                        String adr = null;

                        adr = makeVcard(entity);

                        if (!TextUtils.isEmpty(adr)) {

                            addressList.add(adr);
                        }

                    }
                } catch (IOException e) {
                    Log.i(TAG, "IOException " + e.getMessage());
                }
                Message msg = Message.obtain();
                msg.what = MAKE_VCARD_FINISH;
                msg.obj = addressList;
                mHandler.sendMessage(msg);
            }
        });
    }

    public String makeVcard(PeopleEntity entity) throws IOException {


        VCard vcard = new VCard();

        StructuredName n = new StructuredName();
        n.setGiven(PeopleEntityQuery.getDisplayName(entity));
        n.setFamily(PeopleEntityQuery.getDisplayName(entity));
        vcard.setStructuredName(n);

        vcard.setFormattedName(PeopleEntityQuery.getDisplayName(entity));
        vcard.setNickname(PeopleEntityQuery.getDisplayName(entity));
        vcard.addTelephoneNumber(entity.mobile, TelephoneType.CELL);
        vcard.setOrganization(entity.companyName, entity.deparment_name);
        vcard.addEmail(entity.email, EmailType.WORK);
        vcard.addUrl(entity.icon_url);

        Photo photo = new Photo(entity.icon_url, ImageType.JPEG);
        vcard.addPhoto(photo);

        vcard.addTitle(entity.subuser_id);

        String vcardUrl = MessagingApi.getVcardDir() + entity.name + ".vcf";
        File file = new File(vcardUrl);
        Ezvcard.write(vcard).go(file);

        return vcardUrl;

    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
