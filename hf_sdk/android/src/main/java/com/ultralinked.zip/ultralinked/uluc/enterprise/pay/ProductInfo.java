package com.ultralinked.uluc.enterprise.pay;

import java.io.Serializable;

/**
 * Created by ulpc1 on 2016/11/22.
 */

public class ProductInfo implements Serializable{


    private String price;
    private String product_id;
    private String description;
    private String product_type = "charge";
    private String quantity = "1";

    //Custom charge product constructor.
    public ProductInfo(String price){
        this.price = price;
        this.product_id = "custom";
    }

    public ProductInfo(String product_id, String price, String type, String quantity){
        this.product_id = product_id;
        this.price = price;
        this.product_type = type;
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
