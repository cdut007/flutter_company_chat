package com.ultralinked.uluc.enterprise.contacts.ui.secret;

import android.os.Bundle;

import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.contacts.FragmentFriend;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public class AddSecretActivity extends BaseFragmentActivity {


    @Override
    public void initView(Bundle savedInstanceState) {
        Class<?> className = FragmentAddFriend.class;
        exsitPrivates = getIntent().getParcelableArrayListExtra("privates");
        setFragment(className, new Bundle());

    }

    private List<PeopleEntity> exsitPrivates = new ArrayList<>();

    public List<PeopleEntity> filterExsitPrivates(List<PeopleEntity> friendsList){

        if (exsitPrivates!=null && !exsitPrivates.isEmpty()){
            for (PeopleEntity people:exsitPrivates
                 ) {
                if (friendsList.contains(people)){
                    friendsList.remove(people);
                }
            }
        }

        return friendsList;

    }


}
