package com.ultralinked.uluc.enterprise;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CustomEventApi;
import com.ultralinked.voip.api.Log;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

/**
 * Created by Administrator on 2016/5/31.
 */
public class QrScanResponseActivity extends BaseActivity implements View.OnClickListener  {

    private static final String TAG = "QrScanResponseActivity";
    private static final int _PROCESS_QR_RESPONSE = 0x567;
    private static final int TYPE_JOIN_GROUP = 0x568; //join chat group via qrcode
    private static final int TYPE_LOGIN = 0x569;//login  via qrcode
    private static final int TYPE_ADD_FRIEND = 0x570;//add friend  via qrcode
    private static final int TYPE_NONE = 0x571;
    private static final int TYPE_PARSE_WEBSITE = 0x572;
    private String rqcontent;
    private Button mBtnConfirm;
    private MyHandler mHandler;

    //intent feed back a jsonstring {"code":"200","type":"qrlogin"}
    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (CustomEventApi.EVENT_QR_LOGIN_RESPONSE == intent.getAction()) {
                Log.i(TAG, "receiver EVENT_QR_LOGIN_RESPONSE");
                Message message = Message.obtain();
                message.what = _PROCESS_QR_RESPONSE;
                message.obj = intent.getStringExtra("onQrLogInChanged");
                mHandler.sendMessage(message);
            }

        }
    };
    private int mActionType;


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_qr_scan_response;
    }

    private ImageView leftBack;
    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack=bind(R.id.left_back);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.title_scan_result);
        initListener(this, leftBack);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mHandler = new MyHandler(this);

        String scannedcontent = getIntent().getStringExtra(QrScanActivity.QR_CONTENT);

        mActionType = getType(scannedcontent);
        rqcontent = getQrContent(scannedcontent);

        mBtnConfirm = (Button) findViewById(R.id.btn_qr_comfirm);

        if (mActionType == TYPE_JOIN_GROUP) {
            mBtnConfirm.setText(getString(R.string.click_join_group));
        } else if (mActionType == TYPE_LOGIN) {

            mBtnConfirm.setText(getString(R.string.click_login_website));
            finish();
        } else if (mActionType == TYPE_NONE){

        }

        mBtnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (mActionType) {

                    case TYPE_JOIN_GROUP:
                        Log.i(TAG,"join groupId is = "+rqcontent);
                        MessagingApi.JoinGroup(rqcontent);
                        setResult(RESULT_OK, new Intent());
                        finish();
                        break;
                    case TYPE_LOGIN:
                        LoginApi.qrLogin(rqcontent);
                        break;
                    default:
                        break;
                }

                Log.i(TAG, "rqcontent " + rqcontent);
            }
        });
    }

    /**
     * rqcontant is like this "group:private-chat-4a6349aa-6d40-1cec-2575-78e05104181abeb1"
     * split and get type
     *
     * @param scannedcontent
     */
    private String getQrContent(String scannedcontent) {
        if (!TextUtils.isEmpty(scannedcontent)) {
            JSONObject parseInfo = null;
            String groupId = null;
            try {
                parseInfo = new JSONObject(scannedcontent);
                groupId = parseInfo.optString("group");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (!TextUtils.isEmpty(groupId)){

                return groupId;
            }else{
                String[] qrarray = scannedcontent.split(":");
                if (qrarray.length == 2) {
                    return qrarray[1];
                }
            }


        }
        return "" + scannedcontent;
    }

    /**
     * rqcontant is like this "group:private-chat-4a6349aa-6d40-1cec-2575-78e05104181abeb1"
     * split and get type
     *
     * @param rqcontent
     */
    private int getType(String rqcontent) {
        String groupId = null;
        JSONObject parseInfo = null;
        try {
            parseInfo = new JSONObject(rqcontent);
             groupId = parseInfo.optString("group");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (!TextUtils.isEmpty(groupId)){

            return TYPE_JOIN_GROUP;
        }else{
            if (!TextUtils.isEmpty(rqcontent)) {
                String[] qrarray = rqcontent.split(":");
                if ("group".equals(qrarray[0])) {

                    return TYPE_JOIN_GROUP;

                } else if ("login".equals(qrarray[0])) {

                    return TYPE_LOGIN;
                }

            }
        }


        return TYPE_NONE;
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(CustomEventApi.EVENT_QR_LOGIN_RESPONSE);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    class MyHandler extends Handler {
        // WeakReference to the outer class's instance.
        private WeakReference<Activity> mOuter;

        public MyHandler(Activity activity) {
            mOuter = new WeakReference<Activity>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            Activity outer = mOuter.get();
            if (outer != null && msg.what == _PROCESS_QR_RESPONSE) {
                Toast.makeText(getApplicationContext(), (String) msg.obj, Toast.LENGTH_SHORT).show();
                Intent data = new Intent();
                data.putExtra("qr_rep_data", (String) msg.obj);
                setResult(RESULT_OK, data);
                Log.i(TAG, "qr_rep_data :" + msg.obj);
                finish();
            }
        }
    }

    @Override
    public void finish() {
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }

        super.finish();
    }
}
