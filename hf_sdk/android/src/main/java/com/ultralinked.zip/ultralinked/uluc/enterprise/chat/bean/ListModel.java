package com.ultralinked.uluc.enterprise.chat.bean;

import java.util.ArrayList;
import java.util.List;

public class ListModel {
   private String status;
   private List<ResultModel> results=new ArrayList<ResultModel>();
   
   public ListModel() {
	super();
   }
   public ListModel(String status,List<ResultModel> results) {
	super();
	this.status=status;
	this.results=results;
   }
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public List<ResultModel> getResults() {
	return results;
}
public void setResult(List<ResultModel> results) {
	this.results = results;
}
   
   
}
