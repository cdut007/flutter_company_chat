package com.ultralinked.uluc.enterprise.moments.mvp.contract;

/**
 * Created by suneee on 2016/7/15.
 */
public interface BasePresenter {
}
