package com.ultralinked.uluc.enterprise;

import android.*;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Process;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.multidex.BuildConfig;
import android.support.multidex.MultiDex;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.IntentCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.baidu.mapapi.SDKInitializer;
import com.iflytek.cloud.Setting;
import com.iflytek.cloud.SpeechUtility;
import com.tencent.bugly.Bugly;
import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.call.CallModel;
import com.ultralinked.uluc.enterprise.call.IncomingCallActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ImEmotionMap;
import com.ultralinked.uluc.enterprise.chat.chatim.LocationModel;
import com.ultralinked.uluc.enterprise.chat.chatim.MapActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.PaintModel;
import com.ultralinked.uluc.enterprise.chat.chatim.paint.DrawingFragment;
import com.ultralinked.uluc.enterprise.common.PasswordLockerHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.game.chess.ChessGame;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.GuideActivity;
import com.ultralinked.uluc.enterprise.login.LoginActivity;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.login.bean.DeviceInfo;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.GlideImageLoader;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.MsgNotificationUtils;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.ConfigApi;
import com.ultralinked.voip.api.ConnectionChangeReceiver;
import com.ultralinked.voip.api.ContactHelper;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.EventMessage;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.gson.Gson;
import com.tencent.bugly.crashreport.CrashReport;
import com.ultralinked.voip.api.utils.CommonUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import cn.finalteam.galleryfinal.CoreConfig;
import cn.finalteam.galleryfinal.FunctionConfig;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.ImageLoader;
import cn.finalteam.galleryfinal.ThemeConfig;
import me.leolin.shortcutbadger.ShortcutBadger;
import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

//import com.squareup.leakcanary.LeakCanary;
//import com.squareup.leakcanary.RefWatcher;

/**
 * Created by ultralinked on 2016/6/8 0008.
 */


public class App extends Application {
    public static final String TERMS_URL = "http://www.sealedchat.com/?page_id=83";
    private static final String TAG = "Application";
    private static App instance;

    //    private RefWatcher refWatcher;
    public static App getInstance() {
        return instance;
    }

    public static boolean swtichStetho = true;
    public long initTime = System.currentTimeMillis();


    public static boolean isMainPid(Context context) {
        int pid = Process.myPid();
        String processName = "";
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        Iterator packageName = mActivityManager.getRunningAppProcesses().iterator();

        while (packageName.hasNext()) {
            ActivityManager.RunningAppProcessInfo appProcess = (ActivityManager.RunningAppProcessInfo) packageName.next();
            if (appProcess.pid == pid) {
                processName = appProcess.processName;
                break;
            }
        }


        String packageName1 = context.getPackageName();
        if (!TextUtils.isEmpty(packageName1) && !packageName1.contains(":") && !packageName1.contains("push")) {
            if (packageName1.equals(processName)) {
                Log.i("CommonUtils", "is UI process:" + packageName1);
                return true;
            } else {
                Log.i("CommonUtils", "running process name is :" + processName);
                return false;
            }
        } else {
            Log.i("CommonUtils", "is not UI process:" + packageName1);
            return false;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Log.init(this);
        Foreground.init(this);
        instance = this;
        initStrictCheck();
        TCAgent.LOG_ON=false;
        TCAgent.init(this);

        boolean isInitMainPid = isMainPid(this);
        if (isInitMainPid) {
            ImEmotionMap.initEmotionMap(this);
            registerBroadcastReceiver();
            apiInit();
            //country code init.
            CountryCodeStorageHelper.init(this);


            initUpgrade(this);

            initVoiceSpeechRecognizer();

            //图片选择器配置
            initConfigForGallerFinal();

            registerActivityLifecycle();
        }


        initTime = System.currentTimeMillis() - initTime;

    }

    private void initVoiceSpeechRecognizer() {
        // 注意： appid 必须和下载的SDK保持一致，否则会出现10407错误

        SpeechUtility.createUtility(this, "appid=576a889c");

        // 以下语句用于设置日志开关（默认开启），设置成false时关闭语音云SDK日志打印
        Setting.setShowLog(BuildConfig.DEBUG);
    }

    private void initStrictCheck() {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "initStrictCheck");
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().penaltyLog().build());
        }
    }

    private void initConfigForGallerFinal() {
        //配置主题
        ThemeConfig theme = new ThemeConfig.Builder()
                .setTitleBarBgColor(getResources().getColor(com.holdingfuture.flutterapp.hfsdk.R.color.colorPrimary))
                .setTitleBarTextColor(Color.WHITE)
                .setTitleBarIconColor(Color.WHITE)
                .setFabNornalColor(Color.RED)
                .setFabPressedColor(Color.BLUE)
                .setCheckNornalColor(Color.WHITE)
                .setCheckSelectedColor(Color.BLACK)
                .setIconRotate(com.holdingfuture.flutterapp.hfsdk.R.mipmap.ic_action_repeat)
                .setIconCrop(com.holdingfuture.flutterapp.hfsdk.R.mipmap.ic_action_crop)
                .build();

        //配置功能
        FunctionConfig functionConfig = new FunctionConfig.Builder()
                .setEnableCamera(true)
                .setMutiSelectMaxSize(20)
//                .setEnableEdit(true)
                .setEnableCrop(true)
                .setEnableRotate(true)
                .setCropSquare(true)
                .setEnablePreview(true)
                .build();

        //配置imageloader
        ImageLoader imageloader = new GlideImageLoader();
        //设置核心配置信息
        CoreConfig coreConfig = new CoreConfig.Builder(this, imageloader, theme)
                .setDebug(BuildConfig.DEBUG)
                .setFunctionConfig(functionConfig)
                .build();
        GalleryFinal.init(coreConfig);
    }


    /**
     * 初始化APi
     */
    public void apiInit() {
        //init acra

        CallApi.init(this);

        //init the message api
        MessagingApi.init(this);


        //leak init
//        if(swtichCheckLink){
//            refWatcher=LeakCanary.install(instance);
//        }

        //init the call api
//        CallApi.disableLogToFile = BuildConfig.DEBUG;
        //db init.

        SqliteUtils.init(this);
        //set encrypt message
        ConfigApi.setConfig(ConfigApi.IM_CONFIG, ConfigApi.IMConfig.IM_ENCRYPT_TYPE, ConfigApi.IMConfig.IM_ENCRYPT_TYPE_VALUE_ENABLE);
        //set the Image thumb url
        ConfigApi.setConfig(ConfigApi.IM_CONFIG, ConfigApi.IMConfig.IM_THUMB_UPLOAD_URL, ApiManager.getBaseUrl() + "op/upload_thumb/");


//
//        if (BuildConfig.DEBUG) {
//            Stetho.initializeWithDefaults(instance);
//        }
    }




    public boolean baiduSDkInited;

    public void initBaiduSDK() {
        baiduSDkInited = true;
        Log.i(TAG, "init the baidu map sdk");
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        //注意该方法要再setContentView方法之前实现
        SDKInitializer.initialize(this);

    }

    public static void setToken(String token, String bandModel) {
        MessagingApi.sendAppToken(token, bandModel);
    }


    private static String getDeviceModel() {
        String model = android.os.Build.MANUFACTURER;
        Log.i(TAG, "~ android current MANUFACTURER ~" + model);

        String brand = Build.BRAND;
        //for huawei
        if (brand != null && (brand.equalsIgnoreCase("Honor") || brand.toLowerCase().contains("huawei"))) {
            model = "huawei";

        }

        //for xiaomi
        if (model != null && model.equals("Xiaomi")) {
            model = "xiaomi";
        }

        if (model == null) {
            model = "";
        }

        Log.i(TAG, "~ get android current model ~" + model);
        return model.toLowerCase();
    }



    @Override
    public void onTerminate() {
        super.onTerminate();
        if (activityLifecycleCallbacks != null) {
            try {
                unRegisterBroadcastReceiver();
                unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks);
                Foreground.get().unregister(this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    private void unRegisterBroadcastReceiver() {

        // MessagingApi.release();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageBroadcastReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(contactInfoHasChanged);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(sipIncomingCallReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mLoginStatusChangedReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(imMsgIncomingReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(imMsgStatusReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mPushMessageIncomingReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(inviteGroupReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mGroupInfoChangedReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(MsgProgressReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mGroupMemberChangedReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageFromHistoryReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mConvCreatedReceiver);
        this.unregisterReceiver(mScreenOffReceiver);
        unregisterReceiver(connectChangedReceiver);
    }

    private void registerBroadcastReceiver() {


        LocalBroadcastManager.getInstance(this).registerReceiver(sipLoginReceiver, new IntentFilter(LoginApi.EVENT_LOGIN_STATUS_CHANGE));
        LocalBroadcastManager.getInstance(this).registerReceiver(mLoginStatusChangedReceiver, new IntentFilter(MLoginApi.EVENT_LOGIN_STATUS_CHANGE));
        LocalBroadcastManager.getInstance(this).registerReceiver(sipIncomingCallReceiver, new IntentFilter(CallApi.EVENT_CALL_INVITATION));

        LocalBroadcastManager.getInstance(this).registerReceiver(mPushMessageIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_PUSH));
        LocalBroadcastManager.getInstance(this).registerReceiver(imMsgIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_INCOMING));
        LocalBroadcastManager.getInstance(this).registerReceiver(imMsgStatusReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_STATUS_CHANGED));


        LocalBroadcastManager.getInstance(this).registerReceiver(inviteGroupReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_INVITE));

        LocalBroadcastManager.getInstance(this).registerReceiver(mGroupInfoChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_INFO_CHANGED));

        LocalBroadcastManager.getInstance(this).registerReceiver(mGroupMemberChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_MEMBER_CHANGE));

        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageFromHistoryReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_FROM_HISTORY));

        LocalBroadcastManager.getInstance(this).registerReceiver(mConvCreatedReceiver, new IntentFilter(MessagingApi.EVENT_CONV_CREATED));

        LocalBroadcastManager.getInstance(this).registerReceiver(MsgProgressReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_PROGRESS_CHANGED));

        LocalBroadcastManager.getInstance(this).registerReceiver(contactInfoHasChanged, new IntentFilter(ContactHelper.EVENT_FRIEND_INFO_CHANGE));

        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageBroadcastReceiver, new IntentFilter(MessagingApi.EVENT_BROADCAST));


        IntentFilter screenStatusFilter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        screenStatusFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenStatusFilter.addAction(Intent.ACTION_USER_PRESENT);
        this.registerReceiver(mScreenOffReceiver, screenStatusFilter);
        registerReceiver(connectChangedReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    ConnectionChangeReceiverModel connectionChangeReceiverModel;
    BroadcastReceiver connectChangedReceiver = new ConnectionChangeReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            super.onReceive(context, intent);
            if (connectionChangeReceiverModel == null) {
                connectionChangeReceiverModel = new ConnectionChangeReceiverModel();
            }
            connectionChangeReceiverModel.onReceive(context, intent);
        }
    };

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    private boolean isScreenOff;

    public boolean isUnLock;
    private BroadcastReceiver mScreenOffReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null) {
                return;
            }
            if (action.equals(Intent.ACTION_SCREEN_OFF)) {//锁屏
                isScreenOff = true;
                Log.i(TAG, "screen off, isScreenOff:" + isScreenOff);

            } else if (action.equals(Intent.ACTION_SCREEN_ON)) {//开屏，不代表解锁
//                isScreenOff = true;
                isUnLock = true;
                Log.i(TAG, "screen on, isScreenOff:" + isScreenOff);
            } else if (action.equals(Intent.ACTION_USER_PRESENT)) {//解锁
                isScreenOff = false;
                isUnLock = true;
                Log.i(TAG, "screen unlock, isScreenOff:" + isScreenOff);
            }


        }
    };


    int currentTalkChatId = -1;

    public void setCurrentChatId(int currentTalkId) {
        currentTalkChatId = currentTalkId;
    }

    private boolean needPlayVibrator(int convId) {

        //current chatId can be -1
        if (convId != -1 && convId != currentTalkChatId) {//(not in chatlist page,)

            return !(MainActivity.instance != null && MainActivity.instance.currentIsChatListResumed());

        }
        return false;
    }


    Dialog passwordDialog;

    Activity currentResumedActivity;
    private ActivityLifecycleCallbacks activityLifecycleCallbacks = new ActivityLifecycleCallbacks() {

        @Override
        public void onActivityStopped(Activity activity) {

        }

        @Override
        public void onActivityStarted(Activity activity) {
        }

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        }

        @Override
        public void onActivityResumed(final Activity activity) {
            currentResumedActivity = activity;
            //check the private is .
            if (isUnLock) {
                isUnLock = false;
                if (MainActivity.instance != null) {
                    if (MainActivity.instance.currentIsPrivateContact()) {
                        final String oldpsd = SPUtil.getUserPrivatePsd();
                        if (!TextUtils.isEmpty(oldpsd)) {
                            if (passwordDialog != null && passwordDialog.isShowing()) {
                                passwordDialog.dismiss();
                                passwordDialog = null;
                            }
                            passwordDialog = PasswordLockerHelper.getInstance().showUnlockDialog(activity, PasswordLockerHelper.INPUT_PASSWORD,
                                    new PasswordLockerHelper.OnDialogListener() {

                                        @Override
                                        public void onCancelClick() {
                                            Intent mIntent = new Intent(activity, MainActivity.class);
                                            mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                            activity.startActivity(mIntent);
                                        }

                                        @Override
                                        public void onOkClick(String password) {


                                        }
                                    });

                        }
                    }
                }
            }

        }

        @Override
        public void onActivityPaused(Activity activity) {
        }

        @Override
        public void onActivityDestroyed(Activity activity) {

        }

        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

        }
    };

    private void registerActivityLifecycle() {
        this.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);

    }
//    public  RefWatcher getRefWatcher() {
//        return refWatcher;
//    }


    //broadcast receiver

    /**
     * contact load complite
     */
    private BroadcastReceiver contactInfoHasChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (ContactHelper.EVENT_FRIEND_INFO_CHANGE.equals(intent.getAction())) {
                String data = intent.getStringExtra(ContactHelper.PARAM_DATA);
                if (data != null) {
                    Gson gson = new Gson();
                    PeopleEntity peopleEntity = gson.fromJson(data, PeopleEntity.class);
                    if (MainActivity.instance != null) {
                        MainActivity.instance.getContactInfos();
                    }
                    //..
                }
            }
        }
    };


    /**
     * Message Progress Changed Receiver
     */
    private BroadcastReceiver MsgProgressReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);
        }
    };


    private BroadcastReceiver mConvCreatedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
        }
    };

    private BroadcastReceiver mMessageFromHistoryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String chatID = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            int chatType = intent.getIntExtra(MessagingApi.PARAM_CHAT_TYPE, -1);

            Log.i(TAG, "mMessageFromHistoryReceiver~~ " + chatID + ";chatType");
            if (chatType == Conversation.GROUP_CHAT) {

            }
        }
    };


    private BroadcastReceiver mGroupMemberChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            Log.i(TAG, "mGroupMemberChangedReceiver~~ groupId:" + groupId);
        }
    };


    private BroadcastReceiver mGroupInfoChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            Log.i(TAG, "mGroupInfoChangedReceiver~~ groupId:" + groupId);
        }
    };
    /**
     * 监听群聊邀请的广播接收器
     */
    private BroadcastReceiver inviteGroupReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String from = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            String grouptitle = intent.getStringExtra(MessagingApi.PARAM_GROUP_TITLE);
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            Log.i(TAG, "invite Group  " + from + " groupid:" + groupId + " grouptitle:" + grouptitle);
            MessagingApi.JoinGroup(groupId);//必须要出席,必须掉

        }
    };

    /**
     * Incoming call  status moniter
     */
    BroadcastReceiver sipIncomingCallReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // when have a new incoming call the broadcast will be call
            CallSession session = (CallSession) intent.getSerializableExtra(CallApi.PARAM_CALL_SESSION);
//            Log.d(TAG,"sipIncomingCallReceiver" +"call type : " + session.type+  "time  "+ new SimpleDateFormat("yyyy/mm/dd HH:mm:ss").format(new Date()));
            IncomingCallActivity.lunchIncoming(App.this, session.callId);
        }
    };


    BroadcastReceiver mMessageBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String broadcastType = intent.getStringExtra(MessagingApi.PARAM_BROADCAST_TYPE);
            String dataInfo = intent.getStringExtra(MessagingApi.PARAM_BROADCAST_INFO);

            final String chatIdentity = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            Log.i(TAG, "mMessageBroadcastReceiver~~" + dataInfo);
            if (GameModel.TYPE_CHESS.equals(broadcastType)) {
                final GameModel gameModel = new GameModel(dataInfo);
                int action = gameModel.getPlayAction();
                switch (action) {
                    case GameModel.REQUEST: {
//                        PeopleEntity entity = PeopleEntityQuery.getInstance().getByID(chatIdentity);
//                        String userName = chatIdentity;
//                        if (entity != null) {
//                            userName = PeopleEntityQuery.getDisplayName(entity);
//                        }
//                        if (currentResumedActivity == null) {
//                            return;
//                        }
//                        DialogManager.showOKCancelDialog(currentResumedActivity, "", getString(R.string.accept_chess_game_tips, userName), new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                Conversation conversation = MessagingApi.getConversation(chatIdentity);
//                                if (conversation != null) {
//                                    conversation.sendCustomBroadcast(GameModel.TYPE_CHESS, gameModel.accept());//accept
//                                }
//
//                            }
//                        }, null);

                    }
                    break;
                    case GameModel.ACCEPT: {
                        //dismiss request dialog or show game.
                        ChessGame.lunch(chatIdentity, true);
                        Conversation conversation = MessagingApi.getConversation(chatIdentity);
                        if (conversation != null) {
                            conversation.sendCustomBroadcast(GameModel.TYPE_CHESS, gameModel.display());//accept
                        }
                    }
                    break;
                    case GameModel.DISPLAY: {
                        //dismiss request dialog or show gameWindow.
                        ChessGame.lunch(chatIdentity, false);
                    }
                    break;
                    case GameModel.PLAY: {
                        gameModel.setPlayUser(chatIdentity);
                        RxBus.getDefault().post(gameModel);

                    }
                    break;
                }
            }else if(LocationModel.TYPE_LOCATION.equals(broadcastType)){
                final LocationModel locationModel = new LocationModel(dataInfo);
                int action = locationModel.geLocationAction();
                switch (action) {
                    case LocationModel.REQUEST: {
                        PackageManager pm = getPackageManager();
                        String packageName = getPackageName();
                        int checkPm = -1;
                        checkPm = pm.checkPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, packageName);
                        if (checkPm != PackageManager.PERMISSION_GRANTED) {
                            //send reject
                            Conversation conversation = MessagingApi.getConversation(chatIdentity);
                            if (conversation != null) {

                                conversation.sendCustomBroadcast(LocationModel.TYPE_LOCATION, locationModel.reject());//request
                            }
                        }else{
                            locationModel.locate(chatIdentity);
                        }

                    }
                    break;
                    case LocationModel.REJECT: {
                        //do nothing  if reject by location  show a toast ,

                       locationModel.insertSecurityTips(chatIdentity,"对方关闭了定位权限，对方需要在设置里开始对应软件的定位权限才可以进行定位。");


                    }
                    case  LocationModel.ACCEPT:{
                        try{
                            locationModel.insertSecurityTips(chatIdentity,locationModel.getLocationData().optString("content"));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                    break;
                }
            }



        }
    };



    BroadcastReceiver imMsgStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

            MessageUtils.checkMsgStatusChanged(msg);

        }
    };


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.i(TAG, "~~~onLowMemory~~~");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.i(TAG, "~~~onTrimMemory~~~" + level);
    }

    BroadcastReceiver imMsgIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

            MessageUtils.checkIncomingMessage(msg);


            if (isBackground(App.instance) || isScreenOff) {// running in background or screen is on off status
                if (msg != null && !msg.isSender()) {
                    MsgNotificationUtils.sendNotification(msg);
                }
                Log.i(TAG, "send notification for receive msg.");

            } else {
                if (msg != null && !msg.isSender()) {
                    if (needPlayVibrator(msg.getConversationId())) {
                        MessageUtils.playMessageVibratorOneTime();
                    }
                }


                String linkUserName = MessageUtils.linkMyself(msg);
                if (linkUserName != null) {
                    //someone @ you.
                    MessageUtils.playMessageVibrator();


                }
            }

            //if  it is event message.
            if (MessageUtils.isEventMsg(msg)) {//if it is invite case,can be mark the count of friend unread number.
                //refresh friend list.
                MessageUtils.notifyAcceptMsg((EventMessage) msg);
                if (MainActivity.instance != null) {
                    MainActivity.instance.getFriend();
                }
            }

        }
    };


    //if group implent offline message ,remove later..
    public boolean disPlayPushNotifacation(String tag, Message msg) {
        if (msg.getChatType() == Message.CHAT_TYPE_SINGLE) {
            //make sure from single ,must has a sender name ,otherwise it is maybe from a incoming call.
            Log.i(TAG, "msg is single chat");
            return false;
        }


        //handle for group chat  群聊才关注push消息

        if (isBackground(App.instance) || isScreenOff) {// running in background or screen is on off status
            MsgNotificationUtils.sendNotification(msg);
            Log.i(TAG, "receiver " + tag + " push, send notification for receive msg.");

        } else {
            Log.i(TAG, "receiver " + tag + " push, in forground  not display notification for receive msg.");
        }

        return true;
    }


    //from gcm push
    BroadcastReceiver mPushMessageIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i(TAG, "mPushMessageIncomingReceiver~~ ");
            Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

            Bundle pushMsg = intent.getBundleExtra("data");
            String msgFrom = pushMsg.getString("from");
            String message = pushMsg.getString("message");
            Log.d(TAG, "From: " + msgFrom + " ; Message: " + message);
            msg.setBody(message);
            disPlayPushNotifacation("gcm", msg);


        }
    };


/**login--------------------------------------------------------*/
    /**
     * sip login receiver
     */
    private BroadcastReceiver sipLoginReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            int newStatus = intent.getIntExtra(LoginApi.PARAM_LOGIN_STATUS, -1);
            Log.d(TAG, "SIP login status is " + newStatus);
//            Log.d(TAG, "STATUS_USER_LOGOUT = " + intent.getStringExtra(LoginApi.PARAM_KICK_OUT_REASON));
            switch (newStatus) {
                case LoginApi.STATUS_CONNECTING:

                    break;
                case LoginApi.STATUS_REGISTER_ACCOUNT_ERROR:

                    break;

                case LoginApi.STATUS_REGISTER_ACCOUNT_FAILURE:

                    break;

                case LoginApi.STATUS_REGISTER_OK:

                    break;

                case LoginApi.STATUS_REGISTER_TIME_OUT:
                    boolean networkStatus = NetUtil.isNetworkAvailable(instance);
                    Log.i(TAG, " reconnect network status : " + networkStatus);
                    if (networkStatus && retrySipCount < 5) {
                        handler.removeCallbacks(reloginRunable);
                        handler.postDelayed(reloginRunable, 2000);
                    } else {
                        if (retrySipCount >= 5) {
                            retrySipCount = 0;
                        }
                    }
                    break;
                case LoginApi.STATUS_SERVER_FORCE_LOGOUT:
                    if (CallApi.getFgCallSession() != null) {
                        CallApi.getFgCallSession().terminate();
                    }
                    break;

                case LoginApi.STATUS_USER_LOGOUT:

                    break;

                default:

            }
        }
    };

    int retrySipCount = 0;

    Runnable reloginRunable = new Runnable() {
        @Override
        public void run() {
            retrySipCount++;
            Log.i(TAG, " reconnect login.. ");
            grLogin(false);
        }
    };

    /**
     * xmpp server login status moniter
     */
    private BroadcastReceiver mLoginStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int new_status = intent.getIntExtra(MLoginApi.PARAM_LOGIN_STATUS, -1);
            Log.d(TAG, "IM login status is " + new_status);
            switch (new_status) {
                case MLoginApi.STATUS_CONNECTING:

                    break;

                case MLoginApi.STATUS_REGISTER_OK:
                    Log.i(TAG, "xmpp  register successful");
                    MessageUtils.resendAllFailedMsgs();
                    break;

                case MLoginApi.STATUS_REGISTER_ACCOUNT_ERROR:
                    Log.i(TAG, "xmpp username or password is error");
                    break;
                case MLoginApi.STATUS_USER_LOGOUT:
                    cancelAllNotificaiton();

                    break;
                case MLoginApi.STATUS_SERVER_FORCE_LOGOUT:
                    cancelAllNotificaiton();
                    if (CallApi.getFgCallSession() != null) {
                        CallApi.getFgCallSession().terminate();
                    }

                    goToLoginActivity(true);

                    // Toast.makeText(getApplicationContext(),"server force logout",Toast.LENGTH_LONG).show();
                    break;
                case MLoginApi.STATUS_DISCONNECTED:
                    boolean networkStatus = NetUtil.isNetworkAvailable(instance);
                    Log.i(TAG, " reconnect network status : " + networkStatus);
                    if (networkStatus) {
                        LoginPresenter.checkLoginStatus();
                    }
                    break;
            }
        }
    };


    // back to login activity when force logout
    public void goToLoginActivity(boolean forceLogout) {
        if (forceLogout) {
            LoginApi.logout();
            SPUtil.clear();
        }

        Intent i = new Intent(App.this, GuideActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("is_force_logout", forceLogout);
        startActivity(i);
        if (MainActivity.instance != null) {
            MainActivity.instance.finish();
            Log.i(TAG, "finish main activity.");
        }
    }


    public void cancelAllNotificaiton() {
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.cancelAll();
        ShortcutBadger.applyCount(this, 0);
    }

    /**
     * 登录设置config
     * sip 登录使用 id + api返回中的token登录
     * im  登录使用 id + api返回中的token登录
     */
    public static void grLogin(final boolean loginAll) {
        LoginPresenter.checkDeviceStatus(new LoginPresenter.OnDetectDeviceStatusCallback() {
            @Override
            public void onDeviceStatus(int status) {

                final String userID = SPUtil.getUserID();
                final String password = SPUtil.getToken();
                if (TextUtils.isEmpty(userID) || TextUtils.isEmpty(password)) {
                    Log.d(TAG, "login id is null,can't login via sip and xmpp");
                    return;
                } else {
                    Log.d("ULUCApplication", "login..." + userID + "  password:" + password);
                }

                Observable.create(new Observable.OnSubscribe() {
                    @Override
                    public void call(Object o) {


                        if (!LoginApi.isLogin() || !LoginApi.isConnecting()) {
                            LoginApi.login(userID, password);
                        } else {
                            Log.i(TAG, "LoginApi.isLogin()-->true");
                        }

                        if (loginAll) {
                            if (!MLoginApi.isLogin() && !MLoginApi.isConnecting) {
                                MLoginApi.Account account1 = new MLoginApi.Account();
                                account1.password = SPUtil.getToken();
                                account1.userName = SPUtil.getUsername();
                                account1.nickName = SPUtil.getNickname();
                                account1.id = SPUtil.getUserID();

                                Log.i(TAG, "IM grLogin status " + account1.toString());

                                MLoginApi.login(account1);
                            } else {
                                Log.i(TAG, "MLoginApi.isLogin()-->true");
                            }

                        }
                    }
                })
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe();
            }
        });

    }
/**login--------------------------------------------------------*/
    /**
     * 判断当前应用是否处于后台
     *
     * @param context
     * @return
     */
    public static boolean isBackground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }

        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
//            Log.i("后台", ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND+"--~~~--"+appProcess.importance);
            if (appProcess == null) {
                continue;
            }

            if (appProcess.processName.equals(context.getPackageName())) {
                if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                    Log.i("后台", appProcess.processName);
                    return true;
                } else {
//                    if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
//                        for (String d : appProcess.pkgList) {
//
//
//                        }
//                    }
                    PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                    boolean screenOn = pm.isScreenOn();
                    KeyguardManager mKeyguardManager = (KeyguardManager) context.getSystemService(KEYGUARD_SERVICE);
                    boolean screenLock = mKeyguardManager.inKeyguardRestrictedInputMode();
                    Log.i("前台", appProcess.processName + ";screenOn:" + screenOn + ";screenLock:" + screenLock + ";forground=" + Foreground.get().isForeground());
                    return !screenOn || screenLock || !Foreground.get().isForeground();
                }
            }
        }
        return false;
    }

    /**
     * 判断是否锁屏
     *
     * @return
     */
    public boolean isLockScreenOn() {
        KeyguardManager mKeyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return mKeyguardManager.inKeyguardRestrictedInputMode();
    }

    Handler handler = new Handler();

    public void checkIsNeedUnlock() {

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isBackground(App.this)) {
                    isUnLock = true;
                }
            }
        }, 1000);
    }


    private void initUpgrade(App myApplication) {


//        Beta.strToastYourAreTheLatestVersion = getString(R.string.bugly_already_new_ver);
//        Beta.strToastCheckUpgradeError = getString(R.string.bugly_check_new_ver);
//        Beta.strToastCheckingUpgrade = getString(R.string.bugly_checking_new_ver);
//        Beta.strNotificationDownloading = getString(R.string.bugly_download_new_ver);
//        Beta.strNotificationClickToView = getString(R.string.bugly_click_view_new_ver);
//        Beta.strNotificationClickToInstall = getString(R.string.bugly_click_install_ver);
//        Beta.strNotificationClickToRetry = getString(R.string.bugly_click_retry_ver);
//        Beta.strNotificationClickToContinue = getString(R.string.bugly_click_continue_ver);
//        Beta.strNotificationDownloadSucc = getString(R.string.bugly_download_succ);
//        Beta.strNotificationDownloadError = getString(R.string.bugly_download_failed);
//        Beta.strNotificationHaveNewVersion = getString(R.string.bugly_has_new_ver);
//        Beta.strNetworkTipsMessage = getString(R.string.bugly_network_tips);
//        Beta.strNetworkTipsTitle = getString(R.string.bugly_network_title_tips);
//
//        Beta.strNetworkTipsConfirmBtn = getString(R.string.bugly_continue_new_ver);
//        Beta.strNetworkTipsCancelBtn = getString(R.string.cancel);
//        Beta.strUpgradeDialogVersionLabel = getString(R.string.version);
//        Beta.strUpgradeDialogFileSizeLabel = getString(R.string.package_size);
//        Beta.strUpgradeDialogUpdateTimeLabel = getString(R.string.update_time);
//        Beta.strUpgradeDialogFeatureLabel = getString(R.string.update_notice);
//        Beta.strUpgradeDialogUpgradeBtn = getString(R.string.update_now);
//        Beta.strUpgradeDialogInstallBtn = getString(R.string.install);
//        Beta.strUpgradeDialogRetryBtn = getString(R.string.retry);
//        Beta.strUpgradeDialogContinueBtn = getString(R.string.continue_str);
//        Beta.strUpgradeDialogCancelBtn = getString(R.string.next_time);
//
//        /**** Beta高级设置*****/
//        /**
//         * true表示app启动自动初始化升级模块；
//         * false不好自动初始化
//         * 开发者如果担心sdk初始化影响app启动速度，可以设置为false
//         * 在后面某个时刻手动调用
//         */
//        Beta.autoInit = true;
//
//        /**
//         * true表示初始化时自动检查升级
//         * false表示不会自动检查升级，需要手动调用Beta.checkUpgrade()方法
//         */
//        Beta.autoCheckUpgrade = true;
//
//        /**
//         * 设置升级周期为60s（默认检查周期为0s），60s内SDK不重复向后天请求策略
//         */
//        Beta.initDelay = 1 * 1000;
//
//        /**
//         * 设置通知栏大图标，largeIconId为项目中的图片资源；
//         */
//        Beta.largeIconId = R.mipmap.logo;
//
//        /**
//         * 设置状态栏小图标，smallIconId为项目中的图片资源id;
//         */
//        Beta.smallIconId = R.mipmap.logo;
//
//
//        /**
//         * 设置更新弹窗默认展示的banner，defaultBannerId为项目中的图片资源Id;
//         * 当后台配置的banner拉取失败时显示此banner，默认不设置则展示“loading“;
//         */
//        Beta.defaultBannerId = R.mipmap.logo;
//
//        /**
//         * 设置sd卡的Download为更新资源保存目录;
//         *
//         * 后续更新资源会保存在此目录，需要在manifest中添加WRITE_EXTERNAL_STORAGE权限;
//         */
//        Beta.storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
//
//        /**
//         * 点击过确认的弹窗在APP下次启动自动检查更新时会再次显示;
//         */
//        Beta.showInterruptedStrategy = true;
//
//        /**
//         * 只允许在MainActivity上显示更新弹窗，其他activity上不显示弹窗;
//         * 不设置会默认所有activity都可以显示弹窗;
//         */
//        Beta.canShowUpgradeActs.add(MainActivity.class);

        /**
         * 已经接入Bugly用户改用上面的初始化方法,不影响原有的crash上报功能;
         * init方法会自动检测更新，不需要再手动调用Beta.checkUpdate(),如需增加自动检查时机可以使用Beta.checkUpdate(false,false);
         * 参数1： applicationContext
         * 参数2：appId
         * 参数3：是否开启debug
         */

        // 设置是否为上报进程
//        CrashReport.UserStrategy strategy = new CrashReport.UserStrategy(getApplicationContext());
//        strategy.setUploadProcess(true);
        // CrashReport.setIsDevelopmentDevice(this, BuildConfig.DEBUG);

        CrashReport.initCrashReport(myApplication, "8ef95f4dcc", BuildConfig.DEBUG);

        if (!TextUtils.isEmpty(SPUtil.getUserID())) {
            CrashReport.setUserId(SPUtil.getUserID());
        }

    }


}
