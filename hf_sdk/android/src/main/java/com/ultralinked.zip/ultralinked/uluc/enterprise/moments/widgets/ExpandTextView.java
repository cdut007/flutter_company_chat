package com.ultralinked.uluc.enterprise.moments.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.spannable.CircleMovementMethod;


/**
 * Created by yiwei on 16/7/10.
 */
public class ExpandTextView extends LinearLayout {
    public static final int DEFAULT_MAX_LINES = 3;
    private TextView contentText;
    private TextView textPlus;

    private int showLines;

    public ExpandTextView(Context context) {
        super(context);
        initView();
    }

    public ExpandTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initAttrs(attrs);
        initView();
    }

    public ExpandTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initAttrs(attrs);
        initView();
    }

    private void initView() {
        setOrientation(LinearLayout.VERTICAL);
        LayoutInflater.from(getContext()).inflate(R.layout.comments_layout_magic_text, this);
        contentText = (TextView) findViewById(R.id.contentText);

        textPlus = (TextView) findViewById(R.id.textPlus);
        textPlus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String textStr = textPlus.getText().toString().trim();
                String fullActicle = App.getInstance().getString(R.string.full_text);
                if(fullActicle.equals(textStr)){
                    contentText.setMaxLines(Integer.MAX_VALUE);
                    textPlus.setText(App.getInstance().getString(R.string.collapse));
                }else{
                    contentText.setMaxLines(showLines);
                    textPlus.setText(fullActicle);
                }
            }
        });
    }

    private void initAttrs(AttributeSet attrs) {
        TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(attrs, R.styleable.ExpandTextView, 0, 0);
        try {
            showLines = typedArray.getInt(R.styleable.ExpandTextView_showLines, DEFAULT_MAX_LINES);
        }finally {
            typedArray.recycle();
        }
    }

    public void setText(CharSequence content){
        contentText.setText(content);
        contentText.post(new Runnable() {
            @Override
            public void run() {
                int linCount = contentText.getLineCount();
                if(linCount > showLines){
                    contentText.setMaxLines(showLines);
                    textPlus.setVisibility(View.VISIBLE);
                    textPlus.setText(App.getInstance().getString(R.string.full_text));
                }else{
                    textPlus.setVisibility(View.GONE);
                }
            }
        });

        contentText.setMovementMethod(new CircleMovementMethod(getResources().getColor(R.color.name_selector_color)));
    }

}
