package com.ultralinked.uluc.enterprise.game;

import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by ultralinked on 16/10/7.
 */
public class GameModel {
    public static final int REQUEST = 1;
    public static final int ACCEPT = 2;
    public static final int PLAY = 3;
    public static final int DISPLAY = 4;
    public static final int QUIT = 5;
    public static final String TYPE_CHESS = "game_chess";
    private int playAction;

    JSONObject jsonObject = new JSONObject();
    JSONObject playData;

    public GameModel(){

    }

    public GameModel(String pintInfo) {
        try {
            jsonObject = new JSONObject(pintInfo);
            String action = jsonObject.optString("action");
            if ("request".equals(action)){
                playAction = REQUEST;
            }else if("accept".equals(action)){
                playAction = ACCEPT;
            }else if("play".equals(action)){
                playAction = PLAY;
            }else if("display".equals(action)){
                playAction = DISPLAY;
            }else if("quit".equals(action)){
                playAction = QUIT;
            }
             playData = jsonObject.optJSONObject("playData");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public  JSONObject getPlayData(){
        return  playData;
    }

    public int getPlayAction() {

        return playAction;
    }


    public JSONObject quit() {
        try {
            jsonObject.put("action","quit");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }


    public JSONObject accept() {
        try {
            jsonObject.put("action","accept");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    public JSONObject display() {
        try {
            jsonObject.put("action","display");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }


    public JSONObject request() {
        try {
            jsonObject.put("action","request");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    public JSONObject play(JSONObject playdata) {
        try {
            jsonObject.put("action","play");
            jsonObject.put("playData",playdata);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject;
    }

    private  String gameUser;
    public void setPlayUser(String chatIdentity) {
        this.gameUser = chatIdentity;
    }

    public String getGameUser() {
        return gameUser;
    }

    public static boolean isChesse(String content) {
        if (App.getInstance().getString(R.string.playing_chess_game_tips).equals(content)){
            return true;
        }
        return false;
    }
}
