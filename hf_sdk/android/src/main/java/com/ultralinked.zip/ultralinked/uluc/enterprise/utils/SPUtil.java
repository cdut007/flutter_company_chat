package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.login.bean.DeviceInfo;
import com.ultralinked.uluc.enterprise.login.bean.UserConfigs;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.more.FragmentMore;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by ultralinked on 2016/6/8 0008.
 * ULUC Shareprefrence 管理类
 */
public class SPUtil {
    private SPUtil() {
    }

    /**
     * 保存在手机里面的文件名
     */
    private static final String FILE_NAME = "share_data";
    private static final String USERNAME = "username";

    private static final String NICKNAME = "nickname";
    private static String USER_INFO = "user_info";
    private static final String PASSWORD = "password";
    private static final String TOKEN = "access_token";
    private static final String CODE = "country_code";
    private static final String Mobile = "mobile";
    private static final String UserID = "userID";
    private static final String USER_PRIVATE_PSD = "USER_PRIVATE_PSD";

    private static final String USER_HAS_PSD = "USER_HAS_PSD";


    private static final String USER_HAS_COMPANY = "has_company";

    private static final String WEB_MANAGER_URL = "web_manager_url";

    private static final String QRCODE_URL = "web_qrc_url";


    private static final String LAST_USER_CODE = "last_country_code";
    private static final String LAST_USER_Mobile = "last_mobile";


    private static final String TAG = "SharedPreferencesUtil";
    private static SharedPreferences sp = null, lastSp = null;

    public static int LOGIN_BY_PSD = 1;
    public static int LOGIN_BY_OTP = 2;
    private static String LOGIN_MODE = "LOGIN_MODE";

    public static void saveLoginModel(int style) {
       saveLoginModel(style,true);

    }

    public static void saveLoginModel(int style ,boolean hasPassword) {
        getSp().edit().putInt(LOGIN_MODE, style).apply();
        if (hasPassword){
            saveUserHasPsd(true);
        }

    }

    public static int getLoginModel() {
        return getSp().getInt(LOGIN_MODE, -1);
    }

    public static void saveCode(String code) {
        if (code.contains("+")) {
            code = code.substring(1);
        }
        getSp().edit().putString(CODE, code).apply();
        saveLastCode(code);

    }

    private static void saveLastCode(String code) {
        if (code.contains("+")) {
            code = code.substring(1);
        }
        getLastSp().edit().putString(LAST_USER_CODE, code).apply();

    }


    private static String COUNTRY_CODE = "+86";

    public static void initCountryCode(final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //check sim card.
                    TelephonyManager
                            telephonyManager =
                            (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                    String currentLanguage = telephonyManager.getSimCountryIso(); // sim card lanaguage.
                    if (TextUtils.isEmpty(currentLanguage)) {

                        currentLanguage = telephonyManager.getNetworkCountryIso();// network language.

                        Log.i(TAG, "sim card lanaguage null ,get network iso:" + currentLanguage);
                    }

                    if (TextUtils.isEmpty(currentLanguage)) {
                        currentLanguage = Locale.getDefault().getLanguage();// local language.
                        Log.i(TAG, "network language null ,get local language:" + currentLanguage);
                    }


                    //if not found, check language
                    CountryCodeStorage storage = CountryCodeStorageHelper.getInstance().getCountryCodeStorage(context);
                    ArrayList<CountryInfo> countryCodelist = storage.getAllCountryInfo();
                    for (CountryInfo countryInfo : countryCodelist
                            ) {

                        if (currentLanguage != null && currentLanguage.equalsIgnoreCase(countryInfo.getShortName())) {
                            COUNTRY_CODE = countryInfo.getCountryCode();
                            Log.i(TAG, "find current CountryCode :" + COUNTRY_CODE + ";name=" + countryInfo.getFullName());

                            break;
                        }
                    }
                } catch (Exception e) {
                    Log.i(TAG, "initCountryCode error:" + android.util.Log.getStackTraceString(e));
                }


            }
        }).start();
    }


    public static void markCheckedContactsFromServer(boolean checked) {
        if (checked){
            getSp().edit().putString("markCheckedContactsFromSever", "true").apply();
        }else{
            getSp().edit().putString("markCheckedContactsFromSever", "false").apply();
        }

    }

    // time more than one day ,
    public static boolean checkContactsFromServer() {
        String checked = getSp().getString("markCheckedContactsFromSever",null);
        return  "true".equals(checked);
    }

    public static void saveFindContactsSetting(boolean enable) {

        getSp().edit().putBoolean("findContactsSetting", enable).apply();
    }

    public static boolean getFindContactsSetting() {

        useMathPhone = getSp().getBoolean("findContactsSetting", false);
        return useMathPhone;
    }


    public static void saveMiPushToken(String mRegId) {
        getSp().edit().putString("miPushToken", mRegId).apply();
    }

    public static  String getMiPushToken(){
        return  getSp().getString("miPushToken",null);
    }


    public static void saveCurrentOutgoingCallDisplayNumberSetting(String number) {

        getSp().edit().putString("currentOutgoingCallDisplayNumber", number).apply();
    }

    public static String getCurrentOutgoingCallDisplayNumberSetting() {

        return getSp().getString("currentOutgoingCallDisplayNumber", "-1000");
    }



    public static void savePrivacyFriendConfrimSetting(boolean enable) {

        getSp().edit().putBoolean("friendConfirmSetting", enable).apply();
    }

    public static boolean getPrivacyFriendConfirmSetting() {

        return getSp().getBoolean("friendConfirmSetting", false);
    }

    public static String getLastCode() {
        return getLastSp().getString(LAST_USER_CODE, COUNTRY_CODE);
    }

    public static String getCode() {
        return getSp().getString(CODE, COUNTRY_CODE);
    }

    public static void saveMobile(String mobile) {
        getSp().edit().putString(Mobile, mobile).apply();
        saveLastMobile(mobile);
    }


    private static void saveLastMobile(String mobile) {
        getLastSp().edit().putString(LAST_USER_Mobile, mobile).apply();
    }

    public static String getLastMobile() {
        String mobile = getLastSp().getString(LAST_USER_Mobile, "");

        if (!TextUtils.isEmpty(mobile)) {
            String code = getLastCode();
            if (!code.startsWith("+")) {
                code = "+" + code;
            }
            String nationNumber = mobile;
            if (!mobile.startsWith("+")) {
                nationNumber = "+" + mobile;
            }

            if (nationNumber.startsWith(code)) {// replace succ.
                mobile = nationNumber.substring(code.length());
            }


        }


        return mobile;
    }


    /**
     * 获取电话号码
     */
    public static String getNativePhoneNumber() throws Exception {
        String NativePhoneNumber = null;
        TelephonyManager telephonyManager = (TelephonyManager) App.getInstance()
                .getSystemService(Context.TELEPHONY_SERVICE);
        NativePhoneNumber = telephonyManager.getLine1Number();

        return NativePhoneNumber;
    }

    public static String getMobile() {
        return getSp().getString(Mobile, "");
    }

    private static SharedPreferences getSp() {
        if (sp == null) {
            sp = App.getInstance().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        }
        return sp;
    }

    private static SharedPreferences getLastSp() {
        if (lastSp == null) {
            lastSp = App.getInstance().getSharedPreferences("last_user_info", Context.MODE_PRIVATE);
        }
        return lastSp;
    }


    public static void saveNickname(String username) {
        getSp().edit().putString(NICKNAME, username).apply();
    }

    public static String getNickname() {
        return getSp().getString(NICKNAME, "");
    }


    public static void saveUsername(String username) {
        getSp().edit().putString(USERNAME, username).apply();
    }

    public static String getUsername() {
        return getSp().getString(USERNAME, "username");
    }

    public static void saveUserID(String userID) {
        getSp().edit().putString(UserID, userID).apply();
    }


    public static boolean hasAccount() {
        return !TextUtils.isEmpty(getUserID());

    }

    public static String getUserID() {

        sp = getSp();
        if (sp == null) {
            return "";
        }
        return sp.getString(UserID, "");
    }

    public static void savePassword(String password) {
        getSp().edit().putString(PASSWORD, password).apply();
    }

    public static String getPassword() {
        return getSp().getString(PASSWORD, "password");
    }

    private static List<PeopleEntity> mAssistants;


    public static boolean isAssistant(String subUserId) {
        if (TextUtils.isEmpty(subUserId)) {
            return false;
        }
        List<PeopleEntity> assistant = SPUtil.getAssistant();
        if (assistant != null && assistant.size() > 0) {
            for (PeopleEntity custom : assistant
                    ) {
                if (subUserId.equals(custom.subuser_id)) {

                    return true;
                }

            }
        }
        return false;
    }

    public static List<PeopleEntity> getAssistant() {


        if (mAssistants == null) {
            mAssistants = new ArrayList<>();
        }

        if (mAssistants.size() > 0) {
            return mAssistants;
        }

        String info = getSp().getString("assistant", null);
        Log.i(TAG, "assistant List is:" + info);
        if (info == null) {
            return mAssistants;
        }
        Gson gson = new GsonBuilder().serializeNulls().create();
        Type sToken = new TypeToken<List<PeopleEntity>>() {
        }.getType();
        mAssistants = gson.fromJson(info, sToken);
        return mAssistants;
    }



    public static void saveToken(String token) {
        getSp().edit().putString(TOKEN, token).apply();
    }

    public static String getToken() {
        String token = "";
        try {
            token = getSp().getString(TOKEN, "");
            if (!TextUtils.isEmpty(token)) {
                token = "JWT " + token;
            }
            Log.i(TAG, "token:" + token);
        } catch (Exception e) {
            Log.i(TAG, "token with error:" + android.util.Log.getStackTraceString(e));
        }

        return token;
    }

    public static void saveUserPrivatePsd(String userInfo) {
        getSp().edit().putString(USER_PRIVATE_PSD, userInfo).apply();

    }

    public static boolean pushIngoireChina() {
        if (true) {
            Log.i(TAG, "always use gcm if support");
            return true;
        }
        return getSp().getBoolean("ingore_china", true);
    }

    public static void setPushIngoireChina(boolean ignoreChina) {
        getSp().edit().putBoolean("ingore_china", ignoreChina).apply();
    }

    public static void saveUserHasPsd(boolean hasPassword) {
        getSp().edit().putBoolean(USER_HAS_PSD, hasPassword).apply();

    }

    public static void saveUserHasCompany(boolean hasCompany) {
        if (!hasCompany) {
            CompanySelector.getInstance(App.getInstance()).clearCompanyData();
        }
        getSp().edit().putBoolean(USER_HAS_COMPANY, hasCompany).apply();

    }


    public static void saveQRCODE_url(String qrcodeUrl) {
        getSp().edit().putString(QRCODE_URL, qrcodeUrl).apply();

    }

    public static String getQRCODE_url() {
        return getSp().getString(QRCODE_URL, null);
    }

    public static void saveWeb_manager_url(String web_manager_url) {
        getSp().edit().putString(WEB_MANAGER_URL, web_manager_url).apply();

    }

    public static String getWebManagerUrl() {
        return getSp().getString(WEB_MANAGER_URL, null);
    }

    private static void saveTheAssistant(List<PeopleEntity> assistant) {
        if (assistant != null) {
            Gson gson = new Gson();
            String info = gson.toJson(assistant);
            Log.i(TAG, "the assistant info is ." + info);
            getSp().edit().putString("assistant", info).apply();

        } else {
            Log.i(TAG, "the assistant is null.");
        }
    }


    public static String getUserPrivatePsd() {
        return getSp().getString(USER_PRIVATE_PSD, "");
    }


    public static boolean getUserHasPsd() {
        return getSp().getBoolean(USER_HAS_PSD, false);
    }

    public static boolean getUserHasCompany() {

        return getSp().getBoolean(USER_HAS_COMPANY, false);//maybe change later.
    }


    /**
     * refresh配置文件到默认的SharedPreferences
     *
     * @param settingsBean
     */
    public static void refreshSettingConfigs2DefaultSharedPreferences(UserConfigs.SettingsBean settingsBean) {

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(App.getInstance());
        SharedPreferences.Editor editor = sp.edit();


        saveTheAssistant(settingsBean.assistant);
        saveWeb_manager_url(settingsBean.ulweb_manager_url);
        saveQRCODE_url(settingsBean.qrcode_url);

        editor.putString("android_production_push_key", settingsBean.getAndroid_production_push_key());
        editor.putString("android_stage_push_key", settingsBean.getAndroid_stage_push_key());
        editor.putString("api_websocket_addr", settingsBean.getApi_websocket_addr());
        editor.putString("audio_codecs", settingsBean.getAudio_codecs());
        String enable = settingsBean.getAudio_ice_enable();
        Log.i(TAG, "ice enable:" + enable);
        if (enable != null && enable.equalsIgnoreCase("true")) {
            editor.putBoolean("ICE_CONTROL", true);
        } else {
            editor.putBoolean("ICE_CONTROL", false);
        }

        editor.putString("connect_mode", settingsBean.getConnection_mode());
        editor.putString("ddd1", settingsBean.getDdd1());
        editor.putString("domain", settingsBean.getDomain());
        editor.putString("sipdomain", settingsBean.getDomain());
        editor.putString("httpproxyip", settingsBean.getHttp_proxy_ip());

        editor.putString("httpproxyport", settingsBean.getHttp_proxy_port());
        editor.putString("im_domain", settingsBean.getIm_domain());
        editor.putString("imserver", settingsBean.getIm_server_ip());
        editor.putString("import", settingsBean.getIm_server_port());
        editor.putString("im_websocket_ip", settingsBean.getIm_websocket_ip());
        editor.putString("im_websocket_port", settingsBean.getIm_websocket_port());
        editor.putString("ios_production_push_cert", settingsBean.getIos_production_push_cert());
        editor.putString("ios_production_push_key", settingsBean.getIos_production_push_key());
        editor.putString("ios_stage_push_cert", settingsBean.getIos_stage_push_cert());
        editor.putString("ios_stage_push_key", settingsBean.getIos_stage_push_key());
        editor.putString("key5", settingsBean.getKey5());
        editor.putString("sipproxyip", settingsBean.getSip_proxy_ip());
        editor.putString("sipproxyport", settingsBean.getSip_proxy_port());
        editor.putString("sip_websocket_ip", settingsBean.getSip_websocket_ip());
        editor.putString("sip_websocket_port", settingsBean.getSip_websocket_port());
        editor.putString("stage_test_accounts", settingsBean.getStage_test_accounts());
        editor.putString("task1", settingsBean.getTask1());
        editor.putString("teskkey3", settingsBean.getTeskkey3());
        editor.putString("siptunnelip", settingsBean.getTunnel_ip());
        editor.putString("siptunnelport", settingsBean.getTunnel_port());
        editor.putString("ice_server_ip", settingsBean.getTurn_ip());
        editor.putString("turn_password", settingsBean.getTurn_password());
        editor.putString("ice_server_port", settingsBean.getTurn_port());
        editor.putString("turn_username", settingsBean.getTurn_username());

        editor.commit();

    }


    /**
     * 保存配置文件到默认的SharedPreferences
     *
     * @param userConfigs
     */
    public static void saveUserConfigs2DefaultSharedPreferences(UserConfigs userConfigs) {
        saveUsername(userConfigs.getUsername());
        saveNickname(userConfigs.getNickname());
        saveToken(userConfigs.getAccess_token());
        saveUserID(userConfigs.getId());
        saveUserPrivatePsd(userConfigs.getPrivate_contact_password());
        saveUserHasPsd(userConfigs.isHas_password());
        saveUserHasCompany(userConfigs.isHas_company());


        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(App.getInstance());
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("access_token", userConfigs.getAccess_token());
        editor.putString("domain", userConfigs.getDomain());
        editor.putString("id", userConfigs.getId());
        editor.putString("username", userConfigs.getUsername());

        UserConfigs.SettingsBean settingsBean = userConfigs.getSettings();

        saveTheAssistant(settingsBean.assistant);
        saveWeb_manager_url(settingsBean.ulweb_manager_url);
        saveQRCODE_url(settingsBean.qrcode_url);

        editor.putString("android_production_push_key", settingsBean.getAndroid_production_push_key());
        editor.putString("android_stage_push_key", settingsBean.getAndroid_stage_push_key());
        editor.putString("api_websocket_addr", settingsBean.getApi_websocket_addr());
        editor.putString("audio_codecs", settingsBean.getAudio_codecs());
        String enable = settingsBean.getAudio_ice_enable();
        Log.i(TAG, "ice enable:" + enable);
        if (enable != null && enable.equalsIgnoreCase("true")) {
            editor.putBoolean("ICE_CONTROL", true);
        } else {
            editor.putBoolean("ICE_CONTROL", false);
        }

        editor.putString("connect_mode", settingsBean.getConnection_mode());
        editor.putString("ddd1", settingsBean.getDdd1());
        editor.putString("domain", settingsBean.getDomain());
        editor.putString("sipdomain", settingsBean.getDomain());
        editor.putString("httpproxyip", settingsBean.getHttp_proxy_ip());

        editor.putString("httpproxyport", settingsBean.getHttp_proxy_port());
        editor.putString("im_domain", settingsBean.getIm_domain());
        editor.putString("imserver", settingsBean.getIm_server_ip());
        editor.putString("import", settingsBean.getIm_server_port());
        editor.putString("im_websocket_ip", settingsBean.getIm_websocket_ip());
        editor.putString("im_websocket_port", settingsBean.getIm_websocket_port());
        editor.putString("ios_production_push_cert", settingsBean.getIos_production_push_cert());
        editor.putString("ios_production_push_key", settingsBean.getIos_production_push_key());
        editor.putString("ios_stage_push_cert", settingsBean.getIos_stage_push_cert());
        editor.putString("ios_stage_push_key", settingsBean.getIos_stage_push_key());
        editor.putString("key5", settingsBean.getKey5());
        editor.putString("sipproxyip", settingsBean.getSip_proxy_ip());
        editor.putString("sipproxyport", settingsBean.getSip_proxy_port());
        editor.putString("sip_websocket_ip", settingsBean.getSip_websocket_ip());
        editor.putString("sip_websocket_port", settingsBean.getSip_websocket_port());
        editor.putString("stage_test_accounts", settingsBean.getStage_test_accounts());
        editor.putString("task1", settingsBean.getTask1());
        editor.putString("teskkey3", settingsBean.getTeskkey3());
        editor.putString("siptunnelip", settingsBean.getTunnel_ip());
        editor.putString("siptunnelport", settingsBean.getTunnel_port());
        editor.putString("ice_server_ip", settingsBean.getTurn_ip());
        editor.putString("turn_password", settingsBean.getTurn_password());
        editor.putString("ice_server_port", settingsBean.getTurn_port());
        editor.putString("turn_username", settingsBean.getTurn_username());

        editor.commit();

    }


    /**
     * 移除某个key值已经对应的值
     *
     * @param key
     */
    public static void remove(String key) {
        getSp().edit().remove(key).apply();
    }

    /**
     * 清除所有数据
     */
    public static void clear() {
        DepartUtils.clear_cache_DEPARMENT_COMPANY_JSON_STRING();
        RequestFriendManager.registerAccount.clear();
        FragmentMore.newMommetsItems.clear();
        getSp().edit().clear().apply();
    }

    /**
     * 查询某个key是否已经存在
     *
     * @param key
     * @return
     */
    public static boolean contains(String key) {
        return getSp().contains(key);
    }

    /**
     * 返回所有的键值对
     *
     * @return
     */
    public static Map<String, ?> getAll() {
        return getSp().getAll();
    }

    public static void saveUserInfo(UserInfo userInfo) {
        ACache mCache = ACache.get(App.getInstance());
        Gson gson = new Gson();
        mCache.put(SPUtil.getUserID() + "_userInfo", gson.toJson(userInfo), 365 * ACache.TIME_DAY);

    }
    public static UserInfo getUserInfo() {
        ACache mCache = ACache.get(App.getInstance());
        String infoStr = mCache.getAsString(SPUtil.getUserID() + "_userInfo");
        UserInfo info = null;
        if (infoStr != null) {
            Gson gson = new Gson();
            info = gson.fromJson(infoStr, UserInfo.class);
        }

        return info;
    }


    public static User getMomentInfo(String userID) {
        ACache mCache = ACache.get(App.getInstance());
        String infoStr = mCache.getAsString(userID + "_userInfo_moments");
        User info = null;
        if (infoStr != null) {
            Gson gson = new Gson();
            info = gson.fromJson(infoStr, User.class);
        }
        if (info == null){
            info = new User();
            info.setId(userID);
        }
        return info;
    }

    public static void saveMomentInfo(User userInfo) {
        ACache mCache = ACache.get(App.getInstance());
        Gson gson = new Gson();
        mCache.put(userInfo.getId() + "_userInfo_moments", gson.toJson(userInfo), 365 * ACache.TIME_DAY);

    }




    //phone below 8  complete match, >8  only match end
    public static HashMap<String, PeopleEntity> registerAccount = new HashMap<>();

    //enable disable by switch.
    private static boolean useMathPhone = false;

    public static void updateRegisterAccount(PeopleEntity item) {
        if (useMathPhone) {
            String match = RegexValidateUtils.matchPhone(item.mobile);
            if (!TextUtils.isEmpty(match)) {
                registerAccount.put(match, item);
            }

        }
    }



    //************************************for font size *****************************************************************
    private static String fontKey = "fontScale";

    public enum ScaleType {
        SMALL(1),STANDARD(2), MEDIUM(3), LARGE(4),HUGE(5);
        private int numVal;

        ScaleType(int numVal) {
            this.numVal = numVal;
        }

        public int getNumVal() {
            return numVal;
        }

    }

    private static ScaleType fontScaleType = null;// by default
    public static boolean setFontScale(Context context, ScaleType scaleType) {
        if (scaleType != fontScaleType) {
            boolean saveSucc = saveFontScale(context, scaleType);
            if (saveSucc) {
                 fontScaleType = scaleType;
                // context.sendBroadcast(intent);//fontSizeCHanged...
                return true;
            }
        }
        return false;
    }

    private static float getFontScaleByType(ScaleType scaleType) {
        float fontScale = 1.0f;
        if (scaleType == null) {
            return fontScale;
        }
        switch (scaleType) {
            case MEDIUM:
                fontScale = 1.2f;
                break;
            case HUGE:
                fontScale = 1.6f;
                break;
            case STANDARD:
                fontScale = 1.0f;
                break;
            case SMALL:
                fontScale = 0.8f;
                break;
            case LARGE:
                fontScale = 1.4f;
                break;
            default:
                break;
        }
        return fontScale;
    }

    public static ScaleType getFontScaleType(Context context) {
        if (fontScaleType != null) {
            return fontScaleType;
        }

        int type = getSp().getInt(fontKey, ScaleType.STANDARD.getNumVal());

        ScaleType scaleType = ScaleType.SMALL;
        if (type == ScaleType.STANDARD.getNumVal()) {
            scaleType = ScaleType.STANDARD;
        } else if (type == ScaleType.MEDIUM.getNumVal()) {
            scaleType = ScaleType.MEDIUM;
        }else if (type == ScaleType.LARGE.getNumVal()) {
            scaleType = ScaleType.LARGE;
        }else if (type == ScaleType.HUGE.getNumVal()) {
            scaleType = ScaleType.HUGE;
        }
        return scaleType;
    }

    public static float getFontScale(Context context) {
        ScaleType scaleType = getFontScaleType(context);
        float fontScale = getFontScaleByType(scaleType);
        return fontScale;
    }

    private static boolean saveFontScale(Context context, ScaleType fontScale) {
        return getSp().edit().putInt(fontKey, fontScale.getNumVal()).commit();
    }



}
