package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


/**
 * Created by mac on 17/1/12.
 */

public class RemarkSettingActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_detail_person_remark_name_input;
    }

    EditText remarkNameEdit;
    PeopleEntity entity;
    boolean isPrivate;

    public static  final String ACTION_DETAIL_PERSON_INFO_CHANGED= "com.ultralinked.uluc.enterprise.contacts.PERSON_INFO_CHANGED";

    @Override
    public void initView(Bundle savedInstanceState) {


        entity = (PeopleEntity) getIntent().getParcelableExtra(DetailPersonActivity.KEY_DETAIL_ENTITY);
        isPrivate = getIntent().getBooleanExtra("isPrivate", false);
        remarkNameEdit = bind(R.id.edit_remark);

        if (entity != null) {
            if (!TextUtils.isEmpty(entity.remarkname)) {

                remarkNameEdit.setText(entity.remarkname);
                remarkNameEdit.setSelection(entity.remarkname.length());

            }

        } else {
            finish();
        }


        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView signatureText = bind(R.id.titleCenter);
        signatureText.setText(R.string.set_remarks);
        TextView markDone = bind(R.id.titleRight);
        markDone.setText(R.string.select_member_done);
        ImageUtils.buttonEffect(markDone);
        markDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence info = remarkNameEdit.getText();
                if (!TextUtils.isEmpty(info)) {
                    if (!info.toString().equals(entity.remarkname)){
                        setUserRemarkName(entity,info.toString());
                    }else {
                        finish();
                    }

                } else {
                    if (!TextUtils.isEmpty(entity.remarkname)){
                        deleteRemarkName(entity);//clear remark.
                    }else {
                        finish();//nothing has changed.
                    }

                }

            }

        });



}


    private void deleteRemarkName(final PeopleEntity entity) {


        ApiManager.getInstance().deleteRemark(entity.subuser_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {//请求成功
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "deleteRemarkNameComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "deleteRemarkName error " + eMsg);
                        showToast(eMsg + "");
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String rs = "";
                        try {
                            rs = responseBody.string();
                            Log.i(TAG, "deleteRemarkName  " + rs);
                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //showToast(object.optString("description"));
                                //update to friend table,private table,
                                entity.remarkname = null;
                                DetailHelper.update_FRIEND_(entity);
                                if (isPrivate) {
                                    DetailHelper.save_PRIVATE_(entity);
                                }

                                Log.i(TAG, "deleteRemarkName ok");
                                Intent intent = new Intent(ACTION_DETAIL_PERSON_INFO_CHANGED);
                                intent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY,entity);
                                LocalBroadcastManager.getInstance(RemarkSettingActivity.this).sendBroadcast(intent);
                                finish();
                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + android.util.Log.getStackTraceString(e));
                        }
                    }

                });
    }


    //only friend can be set, also can not be null.
    private void setUserRemarkName(final PeopleEntity entity, final String remarkName) {

        if (TextUtils.isEmpty(remarkName)) {
            return;
        }

        ApiManager.getInstance().setRemarkName(entity.subuser_id, remarkName)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {//请求成功
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "setRemarkNameComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "setRemarkName error " + eMsg);
                        showToast(eMsg + "");
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String rs = "";
                        try {
                            rs = responseBody.string();
                            Log.i(TAG, "setRemarkName  " + rs);
                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                showToast(object.optString("description"));
                                //update to friend table,private table,
                                entity.remarkname = remarkName;
                                DetailHelper.update_FRIEND_(entity);
                                if (isPrivate) {
                                    DetailHelper.save_PRIVATE_(entity);
                                }

                                Log.i(TAG, "setRemarkName ok");
                                Intent intent = new Intent(ACTION_DETAIL_PERSON_INFO_CHANGED);
                                intent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY,entity);
                                LocalBroadcastManager.getInstance(RemarkSettingActivity.this).sendBroadcast(intent);
                                finish();
                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + android.util.Log.getStackTraceString(e));
                        }
                    }

                });
    }


}
