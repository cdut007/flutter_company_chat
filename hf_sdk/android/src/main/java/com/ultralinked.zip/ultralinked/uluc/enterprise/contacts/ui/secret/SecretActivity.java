package com.ultralinked.uluc.enterprise.contacts.ui.secret;

import android.content.Intent;
import android.os.Bundle;

import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.chat.chatdetails.GroupChatDetailsFragment;
import com.ultralinked.uluc.enterprise.chat.chatdetails.SingleChatDetailsFragment;

/**
 * Created by Administrator on 2016/7/22 0022.
 */
public class SecretActivity extends BaseFragmentActivity {


    @Override
    public void initView(Bundle savedInstanceState) {
        Class<?> className = FragmentPrivate.class;
        setFragment(className, new Bundle());

    }



}
