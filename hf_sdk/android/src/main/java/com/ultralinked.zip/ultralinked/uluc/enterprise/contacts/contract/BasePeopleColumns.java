package com.ultralinked.uluc.enterprise.contacts.contract;

import android.provider.BaseColumns;

/**
 * Created by mac on 16/10/17.
 */

public interface BasePeopleColumns extends BaseColumns {


    String SUBUSER_ID = "subuser_id";
    String MOBILE = "mobile";
    String ENABLE = "enable";
    String NAME = "name";
    String ACTIVE = "active";
    String ICON = "icon_url";
    String NICKNAME = "nickname";
    String REMARKNAME = "remarkname";
    String DOMAIN_ID = "domain_id";
    String EMAIL = "email";
    String PINYIN = "pinyin";


    String CREATE_DATE = "create_date";
    String DELETE_DATE = "delete_date";
    String LAST_UPDATE = "last_update";
    String LAST_UPDATE_RELATION = "last_update_relation";


    String SEX = "gender";

   // String AGE = "age";






}
