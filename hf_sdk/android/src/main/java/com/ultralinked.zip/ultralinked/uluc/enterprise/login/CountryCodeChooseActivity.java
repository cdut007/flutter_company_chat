package com.ultralinked.uluc.enterprise.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.LetterListView;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorage;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Created by Chenlu on 2016/7/7 0007.
 */
public class CountryCodeChooseActivity extends BaseActivity implements AdapterView.OnItemClickListener{

    public final static int REQUEST_COUNTRY_CODE = 0x10;


    private ListView countryCodeListView;
    private LetterListView letterListView;
    private HashMap<String, Integer> alphaIndexer;
    private boolean is2Bottom;
    private int firstVisible;
    private ArrayList<CountryInfo> countryCodelist,allCountriesList;
    private Intent intent;
    public final static String COUNTRY_CODE_KEY ="country_code_result";

    public final static String COUNTRY_NAME_KEY ="country_name_result";
    private CountryCodeStorage storage;
    private CountryCodeListAdapter adapter;

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_country_code_shoose;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ((TextView) bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.country_code);
        bind(R.id.titleRight).setVisibility(View.INVISIBLE);
        intent = getIntent();
        storage = CountryCodeStorageHelper.getInstance().getCountryCodeStorage(this);

        countryCodeListView = bind(R.id.county_code_list_view);
        letterListView = bind(R.id.litter_list_view);
        countryCodeListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        letterListView.setOnTouchingLetterChangedListener(new LetterListViewListener());
        countryCodelist = storage.getAllCountryInfo();
        countryCodelist.addAll(0,storage.getHotReginsCountryInfo());

        allCountriesList = new ArrayList<>(countryCodelist);

        letterListView.setLetters(getAlphaLetters(countryCodelist));



        EditText searchEditText = bind(R.id.search_edittext);
        searchEditText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                search(s.toString());
            }
        });


        countryCodeListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                firstVisible = firstVisibleItem;
                String str2 = "";

                is2Bottom = visibleItemCount + firstVisibleItem == totalItemCount;

                if (countryCodelist.size() > 0) {

                    setLetter(countryCodelist, firstVisibleItem);

                }
            }

            private void setLetter(List<CountryInfo> countryCodelist, int firstVisibleItem) {
                CountryInfo countryInfo = countryCodelist.get(firstVisibleItem);
                String str1 = countryInfo.getFullName();
                String str2 = countryInfo.getSortLetter().substring(0,1).toUpperCase();

                if (!TextUtils.isEmpty(str1)) {


                    letterListView.refresh(0);


                }

                for (int i = 0; i < letterListView.getLetters().length; i++) {


                    if (letterListView.getLetters()[i].equals(str2))

                    {

                        letterListView.refresh(i);

                        break;
                    }
                }

            }
        });

        adapter = new CountryCodeListAdapter(this, com.holdingfuture.flutterapp.hfsdk.R.layout.country_code_list_item,countryCodelist);

        countryCodeListView.setAdapter(adapter);
        countryCodeListView.setOnItemClickListener(this);

//        if(intent.hasExtra("countryCode")) {
//            String countryCode = intent.getStringExtra("countryCode");
//            if (!countryCode.equals("+")) {
//                for (int i = 0; i < countryCodelist.size(); i++) {
//                    if (countryCodelist.get(i).getCountryCode().equals(countryCode)) {
//                        countryCodeListView.setSelection(i);
//                        break;
//                    }
//                }
//            }
//        }

    }


    private String[] getAlphaLetters(ArrayList<CountryInfo> countryCodelist) {


        if (countryCodelist == null) {

            return new String[]{};

        }

        Set<String> set = new HashSet<String>();

        List<String> newList = new ArrayList<String>();

        for (Iterator<CountryInfo> iter = countryCodelist.iterator(); iter.hasNext();) {

            CountryInfo info = iter.next();
            String letter = info.getSortLetter().substring(0,1).toUpperCase();
            if (set.add(letter)) {

                newList.add(letter);

            }
        }

        Collections.sort(newList);
        String firstLetter = "";
        if (newList.size()>0){
            firstLetter = newList.get(0);
        }
        LinkedList<String> hashLetters = new LinkedList<String>(newList);
        String emptyStr = "";
        while (hashLetters.size()<LetterListView.LETTER_LEN){
            hashLetters.addFirst(emptyStr);
            hashLetters.add(emptyStr);
        }
        int size = hashLetters.size();
        int pos = hashLetters.indexOf(firstLetter);
        Log.i(TAG,"get the current pos:"+pos);
        if (pos>-1){

            letterListView.refresh(pos);
        }
        String[] arr = hashLetters.toArray(new String[size]);
        Log.i(TAG,"getAlphaLetters:"+arr.length);
        return arr;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String code=adapter.getItem(position).getCountryCode();
        intent.putExtra(COUNTRY_CODE_KEY,code);
        intent.putExtra(COUNTRY_NAME_KEY, adapter.getItem(position).getFullName());
        setResult(RESULT_OK, intent);
        finish();

    }

    private class LetterListViewListener implements LetterListView.OnTouchingLetterChangedListener {


        @Override
        public void onTouchingLetterChanged(final String s) {


            if (alphaIndexer.get(s) != null) {

                int position = alphaIndexer.get(s);

                if (!is2Bottom) {

                    countryCodeListView.setSelection(position);

                } else {

                    if (position < firstVisible) {

                        countryCodeListView.setSelection(position);

                    }


                }

            }
        }


    }
    private String getAlpha(String str) {
        if (str == null) {
            return "#";
        }

        if (str.trim().length() == 0) {
            return "#";
        }

        char c = str.trim().substring(0, 1).charAt(0);

        Pattern pattern = Pattern.compile("^[A-Za-z]+$");
        if (pattern.matcher(c + "").matches()) {
            return (c + "").toUpperCase();
        } else {
            return "#";
        }
    }


    private void search(String text) {


        if (TextUtils.isEmpty(text)){
            countryCodelist = new ArrayList<>(allCountriesList);

        }else{

            countryCodelist.clear();
            adapter.updateList(countryCodelist);

            for (CountryInfo country : allCountriesList) {
                if (country.getFullName().toLowerCase(Locale.ENGLISH)
                        .contains(text.toLowerCase())||country.getCountryCode().contains(text)) {
                    countryCodelist.add(country);
                }
            }

        }
        adapter.updateList(countryCodelist);
        letterListView.setLetters(getAlphaLetters(countryCodelist));
    }

    private  class CountryCodeListAdapter extends MyBaseAdapter<CountryInfo> {

        private final String[] sections;
        public LayoutInflater inflater;
        public CountryCodeListAdapter(Context context, int resource, List<CountryInfo> list) {
            super(context, resource, list);
            inflater = LayoutInflater.from(context);

            alphaIndexer = new HashMap<String, Integer>();
            sections = new String[list.size()];

            for (int i = 0; i <list.size(); i++) {

                String currentStr = getAlpha(list.get(i).getSortLetter());

                String previewStr = (i - 1) >= 0 ? getAlpha(list.get(i-1).getSortLetter()): " ";
                if (!previewStr.equals(currentStr)) {
                    String name = getAlpha(list.get(i).getSortLetter());
                    alphaIndexer.put(name, i);
                    sections[i] = name;
                }
            }
            letterListView.refreshKeyList(alphaIndexer);

        }


        public int getResId(String name) {

            try {
                int drawableId = getContext().getResources().getIdentifier("flag_"+name, "raw", getApplicationContext().getPackageName());
                return drawableId;
            } catch (Exception e) {
                Log.e("CountryCodePicker", "Failure to get drawable id."+ android.util.Log.getStackTraceString(e));
            }
            return -1;
        }

        @Override
        public void setHolder(MyHolder viewHolder, CountryInfo countryInfo) {
            viewHolder.setText(R.id.country_code_name,countryInfo.getFullName());
            viewHolder.setText(R.id.country_code_value,countryInfo.getCountryCode());
            ImageView imageView = viewHolder.getView(R.id.row_icon);
            int imageResId = getResId(countryInfo.getShortName());
            if (imageResId == 0){
                imageView.setImageResource(R.mipmap.no_pic);
            }else{
                imageView.setImageResource(imageResId);
            }
            TextView tvCatalog =  viewHolder.getView(R.id.countrycode_catalog);

            char catalog = countryInfo.getSortLetter().toUpperCase().charAt(0);
            if (catalog == '#'){
                //for hot flag
                tvCatalog.setText(R.string.hot_regions);
            }else{
                tvCatalog.setText(String.valueOf(catalog));
            }


            if (viewHolder.getPosition() == 0) {
                tvCatalog.setVisibility(View.VISIBLE);
            } else {
                int index = viewHolder.getPosition() - 1;
                if (index <getList().size() && index >= 0){
                    CountryInfo NextCountry = getList().get(index);
                    char lastCatalog = NextCountry.getSortLetter().toUpperCase().charAt(0);

                    if (catalog == lastCatalog) {
                        tvCatalog.setVisibility(View.GONE);
                    } else {
                        tvCatalog.setVisibility(View.VISIBLE);
                    }
                }else{
                    tvCatalog.setVisibility(View.GONE);
                }

            }
        }
    }

    @Override
    protected void onDestroy() {
        CountryCodeStorageHelper.getInstance().closeCountryCodeStorage();
        super.onDestroy();
    }
}
