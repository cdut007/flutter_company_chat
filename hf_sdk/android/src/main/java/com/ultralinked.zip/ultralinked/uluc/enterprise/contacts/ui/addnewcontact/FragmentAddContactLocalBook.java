package com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Created by ultralinked on 16/7/19.
 */

public class FragmentAddContactLocalBook extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    // Identifier for the permission request
    private static final int READ_CONTACTS_PERMISSIONS_REQUEST = 0x121;
    private static final int LOADERID = 0x12;
    private static final String TAG = "AddContactLocalBook";
    private ListView mListView;
    private LocalBookAdapter mAdapter;
    private boolean mIsSearchResultView;
    private String mSearchTerm;
    private EditText mEditText;
    private OnContactsInteractionListener mOnContactSelectedListener;


    /**
     * This interface must be implemented by any activity that loads this fragment. When an
     * interaction occurs, such as touching an item from the ListView, these callbacks will
     * be invoked to communicate the event back to the activity.
     */
    public interface OnContactsInteractionListener {
        /**
         * Called when a contact is selected from the ListView.
         */
        void onContactSelected(String name, String phone);

        /**
         * Called when the ListView selection is cleared like when
         * a contact search is taking place or is finishing.
         */
        void onSelectionCleared();

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            // Assign callback listener which the holding activity must implement. This is used
            // so that when a contact item is interacted with (selected by the user) the holding
            // activity will be notified and can take further action such as populating the contact
            // detail pane (if in multi-pane layout) or starting a new activity with the contact
            // details (single pane layout).
            mOnContactSelectedListener = (OnContactsInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnContactsInteractionListener");
        }
    }


    private SideBar indexBar;
    private TextView mDialogText;
    private WindowManager mWindowManager;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_add_contact_local, container, false);

        initTitleBar(view);

        mListView = (ListView) view.findViewById(R.id.pickContactList);

        mWindowManager = (WindowManager) getActivity()
                .getSystemService(Context.WINDOW_SERVICE);

        mDialogText = (TextView) LayoutInflater.from(getActivity()).inflate(
                R.layout.side_bar_list_position, null);
        mDialogText.setVisibility(View.INVISIBLE);
        indexBar = (SideBar) view.findViewById(R.id.sideBar);
        indexBar.setListView(mListView,false);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        try{
            mWindowManager.addView(mDialogText, lp);
            indexBar.setTextView(mDialogText);
        }catch (Exception e){
            e.printStackTrace();
        }





        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final PeopleEntity entity = mAdapter.getItem(position);

                mOnContactSelectedListener.onContactSelected(entity.name, entity.mobile);
            }
        });

        mEditText = (EditText) view.findViewById(R.id.search_edittext);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                setSearchQuery(s.toString());
            }
        });

        mEditText.clearFocus();
        mListView.requestFocus();
        return view;
    }

    private void initTitleBar(View view) {

        ImageView left_back = (ImageView) view.findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });


        TextView titleCenter = (TextView) view.findViewById(R.id.titleCenter);
        titleCenter.setText(getString(com.holdingfuture.flutterapp.hfsdk.R.string.add_contact_titel_local_contact));


        TextView titleRight = (TextView) view.findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSIONS_REQUEST);
        } else {
            getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        }

        //getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        mAdapter = new LocalBookAdapter(getContext());
        mListView.setAdapter(mAdapter);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_CONTACTS_PERMISSIONS_REQUEST) {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST ");
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
            } else {
                Toast.makeText(getContext().getApplicationContext(), "Read Contacts permission denied", Toast.LENGTH_SHORT).show();
                getActivity().finish();
            }
        } else {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST no");
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        Uri contentUri;
        if (mSearchTerm == null) {
            // Since there's no search string, use the content URI that searches the entire
            // Contacts table
            contentUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        } else {
            // Since there's a search string, use the special content Uri that searches the
            // Contacts table. The URI consists of a base Uri and the search string.
            contentUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(mSearchTerm));
        }


        return new CursorLoader(getContext(), contentUri,
                null, ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + " > 0", null, "sort_key");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, final Cursor data) {
        //
        new Thread(new Runnable() {
            @Override
            public void run() {
                readContact(data);
            }
        }).start();

    }

    private void readContact(Cursor cursor) {
        if (cursor == null || getActivity().isFinishing()){
            if (cursor == null){
                Log.i(TAG,"contact cursor is null maybe no permission");
            }
            return;
        }

        Log.i(TAG,"contact cursor maybe has permission ");



        if (cursor.getCount() == 0){
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //clear
                        mAdapter.updateList(new ArrayList<PeopleEntity>());
                        mAdapter.notifyDataSetChanged();
                    }
                });

            return;
        }
        Log.i(TAG,"contact cursor move to frist");
        cursor.moveToFirst();
       final  List<PeopleEntity> data = new ArrayList<>();
        do {

            String photoThubnailUri = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI));

            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

            PeopleEntity localContact = new PeopleEntity();
            localContact.name = name;
            localContact.nickname = name;
            localContact.mobile = phone;
            localContact.icon_url = photoThubnailUri;
            localContact.setLetter(localContact.name);
            data.add(localContact);


        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

           try{
               Collections.sort(data);
           }catch (Exception e){
               e.printStackTrace();
           }

        final char[] alphaLetters = ReadFriendContactTask.getAlphaLetters(data);
        if (!getActivity().isFinishing()) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    List<PeopleEntity> localContacts = new ArrayList<PeopleEntity>(data);
                    indexBar.resetLetters(alphaLetters);
                    mAdapter.updateList(localContacts);
                    mAdapter.notifyDataSetChanged();

                }
            });
        }


    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        //clear
        mAdapter.updateList(new ArrayList<PeopleEntity>());
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            mWindowManager.removeView(mDialogText);
        }catch (Exception e){
            e.printStackTrace();
        }
        getActivity().getSupportLoaderManager().destroyLoader(LOADERID);
    }

    public void setSearchQuery(String query) {
        if (TextUtils.isEmpty(query)) {
            mIsSearchResultView = false;
            mSearchTerm = null;
        } else {
            mSearchTerm = query;
            mIsSearchResultView = true;
        }

        getActivity().getSupportLoaderManager().restartLoader(LOADERID, null, this);
    }

}
