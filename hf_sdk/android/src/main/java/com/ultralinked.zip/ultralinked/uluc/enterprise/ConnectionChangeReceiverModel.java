package com.ultralinked.uluc.enterprise;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;

import com.ultralinked.uluc.enterprise.call.CallModel;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

// network type change broadcast
public class ConnectionChangeReceiverModel {
	private final static String TAG = "ConnectionChangeReceiverModel";

	public void onReceive(Context context, Intent intent) {


		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo wifiNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI); //WIFI

		NetworkInfo mobNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);//MOBILE

		boolean hasAccount = SPUtil.hasAccount();
		// network change to wifi
		if (wifiNetInfo != null && wifiNetInfo.isConnected()) {

			if (hasAccount) {
				LoginPresenter.checkDeviceStatus();
			}

			notifyReconnectedToCall();

		}

		//network change to mobile network
		if (mobNetInfo != null && mobNetInfo.isConnected()) {


       // regist to sip server when ip address change
			if (hasAccount) {
				LoginPresenter.checkDeviceStatus();
			}
			notifyReconnectedToCall();


		}

	}

	private void notifyReconnectedToCall() {

		CallModel callModel = new CallModel();
		callModel.networkStatus = "reconnected";
		RxBus.getDefault().post(callModel);
	}
}

