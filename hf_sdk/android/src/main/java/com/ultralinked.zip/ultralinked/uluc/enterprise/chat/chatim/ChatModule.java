package com.ultralinked.uluc.enterprise.chat.chatim;

import android.app.Activity;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.text.style.URLSpan;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.TextView;

import com.google.gson.Gson;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.chat.ChatUtils;
import com.ultralinked.uluc.enterprise.chat.bean.UrlInfo;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.chat.bean.MsgTime;
import com.ultralinked.uluc.enterprise.chat.bean.VCardInfo;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.http.UrlParseManager;
import com.ultralinked.uluc.enterprise.service.AsistantService;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.CommonLinkify;
import com.ultralinked.uluc.enterprise.utils.DateFormateUtils;
import com.ultralinked.uluc.enterprise.utils.FileUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MapUtils;
import com.ultralinked.uluc.enterprise.utils.MediaFile;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.ConfigApi;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.LocationMessage;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.SubscribeMessage;
import com.ultralinked.voip.api.TextMessage;
import com.ultralinked.voip.api.VcardMessage;
import com.ultralinked.voip.api.VoiceMessage;
import com.ultralinked.voip.api.VoiceRecord;
import com.ultralinked.voip.api.VoipCallMessage;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.R.attr.animation;

/**
 * Created by Chenlu on 2016/7/12 0012.
 */
public class ChatModule {
    public static final String imageCachePath = FileUtils.getSDCardRoot() + ConfigApi.appName + "/sendCameraImage/";
    public static final String sendingFileDir = FileUtils.getSDCardRoot() + ConfigApi.appName + "/sendFile/";
    public static final String sendingVideoDir = FileUtils.getSDCardRoot() + ConfigApi.appName + "/sendVideo/";
    public static final String sendingStickerDir = FileUtils.getSDCardRoot() + ConfigApi.appName + "/sendSticker/";


    public static final String imageCompressedPath = FileUtils.getSDCardRoot() + ConfigApi.appName + "/compressedImage/";

    //录制语音文件存放的路径
    public static final String sendingVoiceDir = FileUtils.getSDCardRoot() + "ULUCEnterprise" + File.separator + "upload" + File.separator + "voice" + File.separator;


    public static final int MESSAGE_SHARED_IMAGE = 0x01;
    public static final int MESSAGE_SHARED_VIDEO = 0x02;
    public static final int MESSAGE_SHARED_VIOCE = 0x03;
    public static final int MESSAGE_SHARED_TEXT = 0x04;
    public static final int MESSAGE_SHARED_VCARD = 0x05;
    public static final int UNKONW_SHARED_TYPE = 0x06;

    private Conversation mConversation;
    private BaseActivity activity;
    private int chatType;
    private int conversationId;
    private static final String TAG = "ChatModule";

    public static final int REQUEST_CODE_FOR_SCAN_VIDEO = 18;


    public ChatModule(@NonNull Conversation mConversation, @NonNull BaseActivity activity) {
        this.mConversation = mConversation;
        this.activity = activity;
        this.chatType = mConversation.isGroup() ? Message.CHAT_TYPE_GROUP : Message.CHAT_TYPE_SINGLE;
        this.conversationId = mConversation.getConversationId();
    }

    /**
     * 判断收到的消息是否属于当前会话
     *
     * @param chatIdentity
     * @return
     */
    public boolean checkIsCurrentConversationMsg(@NonNull String chatIdentity) {
        if (TextUtils.isEmpty(chatIdentity)) {
            return false;
        }
        return chatIdentity.equals(mConversation.getContactNumber());
    }

    /**
     * 判断收到的消息是否属于当前会话
     *
     * @param msg
     * @return
     */
    public boolean checkIsCurrentConversationMsg(@NonNull Message msg) {

        if (chatType != msg.getChatType()) {
            Log.i(TAG, "chatType is not equal. msg ChatType:" + msg.getChatType());
            return false;

        }
        if (conversationId != -1 && conversationId == msg.getConversationId()) {
            Log.i(TAG, "conversationId is  equal. current conversationId:" + conversationId + " msg conversationId " + msg.getConversationId());
            return true;
        }
        if (chatType == Message.CHAT_TYPE_SINGLE) {
            String msgIdentity;
            if (msg.isSender()) {
                msgIdentity = msg.getReceiver();
            } else {

                msgIdentity = msg.getSender();
            }
            Log.i(TAG, "isSender:" + msg.isSender() + "  msgIdentity: " + msgIdentity + "  mConversation.getContactNumber():" + mConversation.getContactNumber());
            if (msgIdentity != null && msgIdentity.equals(mConversation.getContactNumber())) {
                return true;
            } else {
                Log.i(TAG, "msgIdentity not equal.");
            }

        } else {
            if (conversationId == msg.getConversationId()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检查收到的消息是否已经加载到界面上显示
     *
     * @param msg
     * @param msgList
     * @return
     */
    public boolean checkMsgHasAdded(@NonNull Message msg, ArrayList<Message> msgList) {
        if ((msgList == null) || (msgList.size() == 0)) {
            return false;
        } else {
            Message lastMsg = msgList.get(msgList.size() - 1);
            if (lastMsg == null) {
                return false;
            }
            if (msg.getKeyId() > lastMsg.getKeyId()) {
                return false;
            }
        }
        return true;
    }


    public Message sendSticker(String stickerDesc, Message.Options options) {
        //return mConversation.sendSticker(stickerDesc,options);
        String stickerPath = CopyStickerToFolder(activity,
                stickerDesc);
        if (stickerPath != null) {
            return mConversation.sendSticker(stickerDesc, stickerPath, options);
        } else {
            Log.i(TAG, "create StickerPath failed");
            return null;
        }
    }

    public static String CopyStickerToFolder(Context context, String stickerName) {

        String stickerGif = stickerName;
        String stickerPath = ChatModule.sendingStickerDir + stickerGif;
        if (!new File(stickerPath).exists()) {
            // copy assert to dir
            try {

                InputStream is = context.getAssets().open(
                        "sticker/" + stickerGif);
                FileUtils
                        .createFileDirNoMedia(ChatModule.sendingStickerDir);

                OutputStream os = new FileOutputStream(stickerPath);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }

                os.flush();
                os.close();
                is.close();
                return stickerPath;
            } catch (Exception e) {
                e.printStackTrace();
                Log.i(TAG, "write to folder error==" + e.getLocalizedMessage());
            }
        } else {
            return stickerPath;
        }

        return null;
    }


    public Message sendTextByAsistant(String sendText, Message.Options options) {
        if (AsistantService.useLocal) {
            AsistantService.getInstance().startUnderStandByText(mConversation.getContactNumber(), sendText);
            return MessagingApi.insertTextMessage(mConversation.getContactNumber(), SPUtil.getUserID(), mConversation.getContactNumber(), sendText, Conversation.SINGLE_CHAT);
        } else {
            return sendText(sendText, options);
        }

    }

    public Message sendText(String sendText, Message.Options options) {
        return mConversation.sendText(sendText, options);
    }


    public Message sendImage(String filePath, Message.Options options) {
        return mConversation.sendImage(filePath, options);
    }

    public Message sendFile(String filePath, Message.Options options) {

        Message msg;
        if (MediaFile.isImageFileType(filePath)) {
            msg = mConversation.sendImage(filePath);
        } else if (MediaFile.isVideoFileType(filePath)) {
            msg = mConversation.sendVideo(filePath);
        } else {
            msg = mConversation.sendFile(filePath);
        }
        return msg;

    }

    public void sendVCard(String[] vCardUrl, Message.Options options) {
        for (int i = 0; i < vCardUrl.length; i++) {
            sendVCard(vCardUrl[i], options);
        }
    }

    public Message sendVCard(String vCardUrl, Message.Options options) {
        return mConversation.sendVcard(vCardUrl, options);
    }


    public Message sendVideo(String filePath, Message.Options options) {
        return mConversation.sendVideo(filePath, options);
    }

    public Message sendVoice(String filePath, int during, Message.Options options) {
        return mConversation.sendVoice(filePath, during, options);
    }

    public Message sendLocation(HashMap<String, String> locationHashMap, Message.Options options) {
        return mConversation.sendLocation(locationHashMap, options);
    }

    public Message sendCustomMessage(JSONObject jsonData, Message.Options options) {
        return mConversation.sendCustomMessage(jsonData, options);
    }

    public void sendComposing() {
        mConversation.sendComposing();
    }

    public static MsgTime getMessageDayTime(Message msg) {

        return new MsgTime(msg);
    }

    public String getCurRecordVoiceMsgPath() {
        return curRecordVoiceMsgPath;
    }

    private String curRecordVoiceMsgPath;

    private String generateVoiceMsgFileName() {
        return FileUtils.getVoiceFileName();
    }

    public boolean startRecordVoice(boolean useRecognize, AsistantService.OnSpeechUnderstanderListener speechUnderstanderListener) {
        curRecordVoiceMsgPath = new StringBuffer().append(sendingVoiceDir).append(generateVoiceMsgFileName()).toString();
        Log.i(TAG, "curRecordVoiceMsgPath is:" + curRecordVoiceMsgPath);
        File dir = new File(curRecordVoiceMsgPath).getParentFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        if (useRecognize) {
            AsistantService.getInstance().startUnderStandByVoice(mConversation.getContactNumber(), speechUnderstanderListener);
            return true;
        } else {
            return VoiceRecord.getInstance(activity).startRecord(curRecordVoiceMsgPath);
        }


    }

    public void stopRecordVoice(boolean useRecognize) {

        if (useRecognize) {
            AsistantService.getInstance().underStandStop();
        } else {
            VoiceRecord.getInstance(activity).stop();
        }

    }

    /**
     * 录制时间太短，释放资源并删除录制的文件
     */
    public void cancelRecordVoice(boolean useRecognize) {
        if (useRecognize) {
            AsistantService.getInstance().underStandCancel();
        } else {
            stopRecordVoice(useRecognize);
            if (FileUtils.isFileExist(curRecordVoiceMsgPath)) {
                File file = new File(curRecordVoiceMsgPath);
                file.delete();
                Log.i(TAG, "delete voice msg:" + curRecordVoiceMsgPath);
            }
        }

    }

    public int getVoiceLevel(boolean isPrepared, int maxLevel) {
        if (isPrepared) {
            try {
                // 振幅范围mediaRecorder.getMaxAmplitude():1-32767
                return maxLevel * VoiceRecord.getInstance(activity).getMaxAmplitude() / 32768 + 1;
            } catch (Exception e) {
            }
        }
        return 1;
    }

    /**
     * 时间转换
     *
     * @param context
     * @param time
     * @return
     */
    public static String convertTimeForChatListItem(Context context, @NonNull String time) {
        try {
            if (TextUtils.isEmpty(time)) {
                return time;
            }
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            Date date = format.parse(time);
            long timeInMilliseconds = date.getTime();

            if (context != null && DateUtils.isToday(timeInMilliseconds)) {

                return DateFormateUtils.getTodayDateFormartString(context, timeInMilliseconds, true/*is12HourFormat*/);
            }

            SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yyyy");
            time = format2.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return time;
    }

    public static String converTiemForMessage(@NonNull String time) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            Date date = format.parse(time);

            SimpleDateFormat format2 = new SimpleDateFormat("h:mm aa");
            time = format2.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return time;
    }

    /**
     * 处理消息的点击事件
     *
     * @param msg
     */
    public void handleMessageClick(View itemView, Message msg) {
        if (msg == null) {
            Log.i(TAG, "the click msg is null.");
            return;
        }
        FileMessage fMsg;
        if (msg instanceof FileMessage) {
            fMsg = (FileMessage) msg;
        } else if (msg instanceof LocationMessage) {
            openLocationMsg(itemView, (LocationMessage) msg);
            Log.i(TAG, "click to open location.");
            return;
        } else if (msg instanceof VoipCallMessage) {

            Log.i(TAG, "click to call voip.");
            return;
        } else if (msg instanceof SubscribeMessage) {
            SubscribeMessage subscribeMessage = (SubscribeMessage) msg;
            Object index = itemView.getTag();
            int indexVal = -1;
            if (index != null && index instanceof String) {
                try {
                    indexVal = Integer.parseInt(index.toString());

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (indexVal == -1) {

                MobileBrowserActivity.actionStart(activity, subscribeMessage.linkUrl, subscribeMessage.title);
            } else {
                try {
                    SubscribeMessage.Subscribe subscribe = subscribeMessage.subscribes.get(indexVal);
                    MobileBrowserActivity.actionStart(activity, subscribe.linkUrl, subscribe.title);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            Log.i(TAG, "click to SubscribeMessage.");
            return;
        } else if (Message.MESSAGE_TYPE_TEXT == msg.getType()) {

            TextMessage textMessage = (TextMessage) msg;
            if (msg.tag != null && (msg.tag instanceof UrlInfo)) {
                UrlInfo urlInfo = (UrlInfo) msg.tag;
                MobileBrowserActivity.actionStart(activity, textMessage.getText(), urlInfo.title);
            }

            return;
        } else {
            Log.i(TAG, "the click not is file message.");
            return;
        }
        String filePath = fMsg.getFilePath();
        boolean isExist = FileUtils.isFileExist(filePath);
        int status = fMsg.getStatus();
        Log.i(TAG, "filePath:" + filePath);
        if (isExist) {
            openMessage(itemView, fMsg);
        } else {
            if (status != Message.STATUS_IN_PROGRESS) {
                fMsg.accept();
                Log.i(TAG, "click to download the file message.");
            } else {
                Log.i(TAG, "the file message is downloading...");
            }
        }
    }

    private void openMessage(@NonNull View itemView, @NonNull FileMessage fMsg) {
        int msgType = fMsg.getType();
        Log.i("file open", "getType=" + msgType);
        String filePath = fMsg.getFilePath();
        boolean isExist = FileUtils.isFileExist(filePath);
        if (!isExist) {
            activity.showToast(com.holdingfuture.flutterapp.hfsdk.R.string.chat_file_select_not_exist);
            return;
        }

        if (msgType == Message.MESSAGE_TYPE_IMAGE) {
            MessageUtils.read(fMsg, true);
//            return;
        } else if (msgType == Message.MESSAGE_TYPE_VIDEO) {

//            return;
        } else if (msgType == Message.MESSAGE_TYPE_VOICE) {
            openVoiceMsg(itemView, (VoiceMessage) fMsg);
            return;
        } else if (msgType == Message.MESSAGE_TYPE_VCARD) {
            openVCardMsg(itemView, (VcardMessage) fMsg);
            return;
        } else if (msgType == Message.MESSAGE_TYPE_LOCATION) {

//            openLocationMsg(itemView,(LocationMessage) fMsg);

        } else if (msgType == Message.MESSAGE_TYPE_TIPS) {

            return;
        }


        MimeTypeMap myMime = MimeTypeMap.getSingleton();

        Log.i("file open", "filePath=" + filePath);
        String extension = MimeTypeMap.getFileExtensionFromUrl(filePath);
        if (TextUtils.isEmpty(extension)) {
            extension = FileUtils.getExtension(filePath);
        }
        Log.i("file open", "extension=" + extension);
        String mimeType = myMime.getMimeTypeFromExtension(extension);
        Log.i("file open", "mime Type=" + mimeType + ";extension=" + extension);
        if (TextUtils.isEmpty(mimeType)) {
            mimeType = "*/*";
        } else {
            if (mimeType.startsWith("video")) {
                mimeType = "video/*";
            } else if (mimeType.startsWith("image")) {
                mimeType = "image/*";
            }
        }
        Uri uri = Uri.fromFile(new File(filePath));

        /*If the file type is picture,then just show it*/
        if (mimeType.equals("image/*")) {
            Intent intent = new Intent(activity, WholeImageActivity.class);
            intent.putExtra("uri", uri);
            activity.startActivity(intent);
            return;
        }

        Intent newIntent = new Intent(android.content.Intent.ACTION_VIEW);
        newIntent.setDataAndType(uri, mimeType);
        newIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        newIntent.addCategory(Intent.CATEGORY_DEFAULT);
        try {
            activity.startActivity(newIntent);
        } catch (android.content.ActivityNotFoundException e) {
            Intent intent = new Intent(android.content.Intent.ACTION_VIEW);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            intent.setData(uri);
            try {
                activity.startActivity(Intent.createChooser(intent, "Choose file"));
            } catch (android.content.ActivityNotFoundException ex) {
                // Potentially direct the user to the Market with a Dialog
                activity.showToast(com.holdingfuture.flutterapp.hfsdk.R.string.chat_open_file_failed);
            }
        }
    }

    private void openVCardMsg(View itemView, VcardMessage vcardMessageg) {
        PeopleEntity peopleEntity = VCardInfo.getInstance(vcardMessageg.getFilePath()).getPeopleEntity();
        if (peopleEntity == null) {
            return;
        }
//        String vcardUserId = peopleEntity.subuser_id;
//        Log.i(TAG, "the vcard userid is" + vcardUserId);
//        if (vcardUserId == null) {
//            return;
//        }
        String userId = peopleEntity.subuser_id;
        Log.i(TAG,"vcardInfo =="+userId+";mobile=="+peopleEntity.mobile);
        PeopleEntity localQueryPeopleEntity;
        if (TextUtils.isEmpty(userId)) {
            localQueryPeopleEntity = PeopleEntityQuery.getInstance().getByID(userId);
        } else {
            localQueryPeopleEntity = PeopleEntityQuery.getInstance().getByMobileSql(peopleEntity.mobile);
        }

        if (PeopleEntityQuery.hasFoundPeople(localQueryPeopleEntity)) {
            Log.i(TAG," localQueryPeopleEntity =="+userId+";relation=="+localQueryPeopleEntity.relation);
            DetailPersonActivity.gotoDetailPersonActivity(activity, localQueryPeopleEntity);
        } else {
            Log.i(TAG,"not found vcardInfo =="+userId+";mobile=="+peopleEntity.mobile);
            DetailPersonActivity.gotoDetailPersonActivity(activity, peopleEntity);
        }


    }


    private void openLocationMsg(View itemView, LocationMessage locationMsg) {
        try {
            MapUtils.goToMapsActivity(activity, locationMsg);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

    }

    private VoiceAnimImageView voiceView;

    private void openVoiceMsg(View itemView, VoiceMessage fMsg) {
        if (voiceView != null) {
            try {
                voiceView.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }

            voiceView = null;
        }
        voiceView = (VoiceAnimImageView) itemView.findViewById(R.id.voiceAnim);
        voiceView.setIsSender(fMsg.isSender());
        voiceView.start(fMsg.getKeyId());
        fMsg.playOrStop(null);
    }

    public static String convertMsgStatus2String(int status) {
        String str = "unknown";
        switch (status) {
            case Message.STATUS_DELIVERY_OK:
                str = "delivery_ok";
                break;
            case Message.STATUS_DRAFT:
                str = "status_draft";
                break;
            case Message.STATUS_FAILURE:
                str = "failure";
                break;
            case Message.STATUS_IN_PROGRESS:
                str = "progress";
                break;
            case Message.STATUS_OK:
                str = "ok";
                break;
            case Message.STATUS_READ:
                str = "read";
                break;

        }
        return str;
    }

    public static String convertMsgStatus2String(@NonNull Message msg) {
        return convertMsgStatus2String(msg.getStatus());
    }


    /**
     * 删除会话
     *
     * @param conversation
     */
    public static void deleteConversation(Conversation conversation) {
        if (conversation == null) {
            return;
        }
        if (conversation.isGroup()) {
            ((GroupConversation) conversation).exitGroup();
        } else {
            conversation.delete();
        }
    }

    public void refresh(Conversation newConversation) {
        this.mConversation = newConversation;
        this.chatType = mConversation.isGroup() ? Message.CHAT_TYPE_GROUP : Message.CHAT_TYPE_SINGLE;
        this.conversationId = mConversation.getConversationId();

    }


    public static final int Add_New_Counts = 1;
    public static final int Increase_New_Counts = 2;
    public static final int Decrease_Message_Counts = 3;


    public static String COPY = "Copy", FORWARD = "Forward", DELETE = "Delete", RESEND = "Resend",
            MORE = "More", SHARE = "Share", ADD_CONTACT = "Add contact", TTS = "TTs";


    public static String[] createOptions(Context context, Message msg, Conversation mConversation) {
        String[] options = null;
        COPY = context.getString(R.string.copy);
        FORWARD = context.getString(R.string.forward);
        DELETE = context.getString(R.string.delete);
        RESEND = context.getString(R.string.resend);
        MORE = context.getString(R.string.edit);
        SHARE = context.getString(R.string.share);
        ADD_CONTACT = context.getString(R.string.add_contact);
        TTS = context.getString(R.string.tts);

        int msgType = msg.getType();

        if (msgType == Message.MESSAGE_TYPE_SUBSCRIBE ||
                msgType == Message.MESSAGE_TYPE_VOIP ||
                msgType == Message.MESSAGE_TYPE_SUBSCRIBE) {

            options = new String[]{DELETE,};
            return options;
        }

        if (msg.getStatus() == Message.STATUS_IN_PROGRESS) {// file is transfer...
            // is revice file end
            String item = COPY;
            if (msg.isSender()) {
                if (msg instanceof FileMessage) {
                    item = RESEND;
                    options = new String[]{item, FORWARD, SHARE, DELETE,};
                } else {

                    options = new String[]{RESEND, item, FORWARD, DELETE,};
                }
            } else {
                if (msg instanceof FileMessage) {
                    item = RESEND;
                    options = new String[]{item, DELETE,};
                } else {

                    options = new String[]{item, DELETE,};
                }
            }


        } else {
            // is revice file end
            String item = COPY;

            if (msg.isSender()) {
                if (msg instanceof FileMessage) {
                    item = RESEND;
                    options = new String[]{item, FORWARD, SHARE, DELETE,};
                } else {


                    if (msg.getType() == Message.MESSAGE_TYPE_LOCATION) {
                        options = new String[]{RESEND, FORWARD, DELETE,};
                    } else if (msg.getType() == Message.MESSAGE_TYPE_TEXT) {
                        options = new String[]{RESEND, FORWARD, DELETE, TTS};
                    } else {
                        options = new String[]{RESEND, item, FORWARD, DELETE,};
                    }


                }

            } else {
                if (msg instanceof FileMessage) {
                    item = RESEND;
                    options = new String[]{item, FORWARD, SHARE, DELETE,};
                } else {
                    if (msg.getType() == Message.MESSAGE_TYPE_LOCATION) {
                        options = new String[]{RESEND, FORWARD, DELETE,};
                    } else if (msg.getType() == Message.MESSAGE_TYPE_TEXT) {
                        options = new String[]{item, FORWARD, DELETE, TTS};
                    } else {
                        options = new String[]{item, FORWARD, DELETE,};
                    }


                }

            }

        }

//            lator.
//            if (isStranger(msg, number) == null) {
//                String[] tempStrings = new String[options.length + 1];
//                for (int i = 0; i < options.length; i++) {
//                    tempStrings[i] = options[i];
//                }
//                tempStrings[options.length] = MULTI_DELETE;
//                options = tempStrings;
//            } else {
//                String[] tempStrings = new String[options.length + 2];
//                for (int i = 0; i < options.length; i++) {
//                    tempStrings[i] = options[i];
//                }
//                tempStrings[options.length] = MULTI_DELETE;
//                tempStrings[options.length + 1] = ADD_CONTACT;
//                options = tempStrings;
//            }

        return options;

    }

    protected void copyMsg(String content) {
        // TODO Auto-generated method stub
        ClipboardManager clipboardManager = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);


        clipboardManager.setText(content);

    }

    public static String formatLinkName(String userName) {
        return "@" + userName + " ";
    }


    public static void clearAllChatBackgroudThemeSkin() {
        ACache mCache = ACache.get(App.getInstance());

        mCache.remove(SPUtil.getUserID() + "_all_chat_skin");
    }

    public static void setAllChatBackgroudThemeSkin(String filePath) {
        ACache mCache = ACache.get(App.getInstance());

        mCache.put(SPUtil.getUserID() + "_all_chat_skin", filePath, 365 * ACache.TIME_DAY);
    }


    public static void clearChatBackgroudThemeSkin(String chatId) {
        ACache mCache = ACache.get(App.getInstance());

        mCache.remove(SPUtil.getUserID() + "_chat_skin" + chatId);
    }

    public static void setChatBackgroudThemeSkin(String chatId, String filePath) {
        ACache mCache = ACache.get(App.getInstance());

        mCache.put(SPUtil.getUserID() + "_chat_skin" + chatId, filePath, 365 * ACache.TIME_DAY);
    }

    public static String getChatBackgroudTheme(Conversation conversation) {
        ACache mCache = ACache.get(App.getInstance());
        String chatId = conversation.getContactNumber();
        if (conversation.isGroup()) {
            chatId = ((GroupConversation) conversation).getGroupID();

        }
        String chatSkin = mCache.getAsString(SPUtil.getUserID() + "_chat_skin" + chatId);

        if (TextUtils.isEmpty(chatSkin)) {
            chatSkin = mCache.getAsString(SPUtil.getUserID() + "_all_chat_skin");
        }
        return chatSkin;
    }

    public static void checkUrlLink(BaseActivity activity, final Message itemData, SpannableStringBuilder content) {
        TextMessage textMessage = (TextMessage) itemData;
        if (RegexValidateUtils.checkUrl(textMessage.getText())) {
            //do http request.

            UrlParseManager.getInstance().requestUrl(itemData, textMessage.getText());

        } else {

        }

    }

}
