package com.ultralinked.uluc.enterprise.contacts.ui.detail;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendAdapter;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import com.ultralinked.uluc.enterprise.baseui.widget.SwitchView;
import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.holdingfuture.flutterapp.hfsdk.R.id.titleRight;
import static com.holdingfuture.flutterapp.hfsdk.R.string.remove_private_contact_ok;


public class DetailPersionSettingActivity extends BaseActivity {
    public static final String TAG = "DetailPersionSettingActivity";

    private TextView titleCenter,remarkName;
    private SwitchView privateSwitch,blockSwitch;
    private Button delete;
    private PeopleEntity mDetailEntity;


    @Override
    public void initView(Bundle savedInstanceState) {

        initTitleBar();

        mDetailEntity = getIntent().getParcelableExtra(DetailPersonActivity.KEY_DETAIL_ENTITY);
        if (mDetailEntity == null) {
            finish();
            return;
        }


        privateSwitch = bind(R.id.add_privacy_firend_notifications);
        privateSwitch.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));
        blockSwitch = bind(R.id.block_notifications);
        blockSwitch.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));

//        if (!ApiManager.IsStage()){
//            goneView(bind(R.id.block_layout));
//        }


        delete = bind(R.id.deleteBtn);
        remarkName = bind(R.id.remarkName);
        remarkName.setText(mDetailEntity.remarkname);
        bind(R.id.remarkName_layout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                go2SetReMarkNameUI();
            }
        });

        if (mDetailEntity.relation != PeopleEntity.FRIEND){
            //query again.
            if (!PeopleEntityQuery.getInstance().isFriend(mDetailEntity.subuser_id)){
                goneView(delete);
                goneView(bind(R.id.remarkName_layout));
            }

        }

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFriend();
            }
        });

        checkPrivateStatus(mDetailEntity.subuser_id);

        LocalBroadcastManager.getInstance(this).registerReceiver(personInfoChangedReceiver, new IntentFilter(RemarkSettingActivity.ACTION_DETAIL_PERSON_INFO_CHANGED));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(personInfoChangedReceiver);
    }

    BroadcastReceiver personInfoChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            PeopleEntity peopleEntity = intent.getParcelableExtra(DetailPersonActivity.KEY_DETAIL_ENTITY);
            if (peopleEntity!=null){
                if (mDetailEntity.subuser_id.equals(peopleEntity.subuser_id)){
                    remarkName.setText(peopleEntity.remarkname);
                }
            }
        }
    };

    private void go2SetReMarkNameUI() {
        Intent mIntent = new Intent(this, RemarkSettingActivity.class);
        mIntent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY,mDetailEntity);
        mIntent.putExtra("isPrivate",isPrivate);
        startActivity(mIntent);
    }

    private void removeFriend() {
        RequestFriendManager.getInstance().removeFriend(this, mDetailEntity, new NewFriendAdapter.OnFriendClickListener() {
            @Override
            public void onItemClickListener(PeopleEntity entity) {

            }

            @Override
            public void callFriendRequest(String action, PeopleEntity peopleEntity) {

            }

            @Override
            public void onFriendStatusChanged(PeopleEntity peopleEntity) {
                DetailHelper.del_FRIEND(DetailPersionSettingActivity.this,mDetailEntity);
                go2MainUI();
            }
        });
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_detail_person_setting;
    }



    void go2MainUI() {
        Intent mIntent = new Intent(this, MainActivity.class);
        mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(mIntent);
        finish();
    }


    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.person_settings));

        goneView(bind(R.id.titleRight));


    }


    public static void gotoSettingDetailPersonActivity(Context context, PeopleEntity clickedSource) {

        Intent intent = new Intent(context, DetailPersionSettingActivity.class);
        intent.putExtra(DetailPersonActivity.KEY_DETAIL_ENTITY, clickedSource);
        context.startActivity(intent);
    }

    private void checkPrivateStatus(String subuser_id) {


        Cursor cursor = SqliteUtils.getInstance(this).getDb()
                .query(PrivateContract.TABLE_NAME, null, PrivateContract.PrivateColumn.SUBUSER_ID + " =  '" + subuser_id + "'",
                        null, null, null, PrivateContract.PrivateColumn.NAME);

        if (cursor == null || cursor.getCount() == 0) {

            setPrivateToggleState(false);

        } else {

            setPrivateToggleState(true);
        }

        if (cursor != null) {
            cursor.close();
        }

        privateSwitch.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                view.toggleSwitch(true);
                setPrivate(mDetailEntity.subuser_id);

            }

            @Override
            public void toggleToOff(SwitchView view) {
                view.toggleSwitch(false);
                unPrivate(mDetailEntity.subuser_id);

            }
        });

        setBlockState(MessagingApi.getConversationIsBlock(mDetailEntity.subuser_id));

        blockSwitch.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                view.toggleSwitch(true);
                MessagingApi.setConversationBlock(mDetailEntity.subuser_id,false,true);

            }

            @Override
            public void toggleToOff(SwitchView view) {
                view.toggleSwitch(false);
                MessagingApi.setConversationBlock(mDetailEntity.subuser_id,false,false);

            }
        });



    }


    void setBlockState(boolean enable) {
        if (enable) {
            blockSwitch.toggleSwitch(true);
        } else {
            blockSwitch.toggleSwitch(false);
        }
    }

    boolean isPrivate;

    void setPrivateToggleState(boolean enable) {
        isPrivate = enable;
        if (enable) {
            privateSwitch.toggleSwitch(true);
        } else {
            privateSwitch.toggleSwitch(false);
        }
    }

    private void unPrivate(final String subuser_id) {


        ApiManager.getInstance().delPrivate(subuser_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {//请求成功
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getunPrivateComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "unPrivate error " + eMsg);
                        showToast(eMsg + "");
                        setLockedFailed();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        String rs = "";
                        try {
                            rs = responseBody.string();
                            Log.i(TAG, "delPrivate  " + rs);
                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                showToast(getString(R.string.remove_private_contact_ok));
                                DetailHelper.del_PRIVATE(getApplicationContext(), subuser_id);
                                Log.i(TAG, "Remove private ok");
                            }

                        } catch (Exception e) {
                            setLockedFailed();
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + android.util.Log.getStackTraceString(e));
                        }
                    }

                });
    }



    private void setLockedFailed() {

        setPrivateToggleState(!privateSwitch.isOpened());

    }

    private void setPrivate(String subuser_id) {

        ApiManager.getInstance().setPrivate(subuser_id)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "setPrivateComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "setPrivate error " + eMsg);
                        setLockedFailed();
                        showToast(eMsg + "");
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {

                                Toast.makeText(getApplicationContext(), R.string.add_contact_add_private_success, Toast.LENGTH_SHORT).show();
                                DetailHelper.save_PRIVATE_(mDetailEntity);
                            }

                        } catch (Exception e) {
                            setLockedFailed();
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "setPrivate  " + rs);
                    }        //请求成功

                });

    }


}
