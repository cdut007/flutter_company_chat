package com.ultralinked.uluc.enterprise.contacts;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.SideBar;
import com.ultralinked.uluc.enterprise.baseui.widget.ULListView;
import com.ultralinked.uluc.enterprise.chat.group.GroupChatListActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.LocalContactContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;

import info.hoang8f.android.segmented.SegmentedGroup;

public class FragmentLocalContacts extends BaseFragment implements View.OnClickListener, LoaderManager.LoaderCallbacks<Cursor> {


    private String mSearchWord;
    // Identifier for the permission request
    private static final int READ_CONTACTS_PERMISSIONS_REQUEST = 0x222;
    private static final int LOADERID = 0x111;
    private ULListView mContactsListView;

    private static final String TAG = "FragmentLocalContacts";

    private LocalContactsAdapter contactsAdapter;

    private ContentObserver contactChangeObserver,localContactChangeObserver;
    boolean showSealChat;

    private List<PeopleEntity> registerPeopleEntitys = new ArrayList<>();
    private List<PeopleEntity> localContacts = new ArrayList<>();

    private char[] alphaLetters = new char[]{}, regiserAlphaLetters = new char[]{};

    @Override
    public int getRootLayoutId() {
        return R.layout.contacts_friend_layout;
    }


    View newFriendBtn;
    View groupChatBtn;
    //  TextView secretBtn;

    EditText mSearch_edittext;

    BaseActivity baseActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        baseActivity = (BaseActivity) context;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSIONS_REQUEST);
        } else {
            getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
        }
    }


    @Override
    public void initView(Bundle savedInstanceState) {


        mContactsListView = bind(R.id.friend_list_view);
        visibleView(tabLayout = bind(R.id.contacts_tab));


        tabLayout.setTintColor(getResources().getColor(R.color.colorPrimary), getResources().getColor(R.color.white));
        RadioButton radioButton = bind(R.id.all_contacts);
        radioButton.toggle();
        initListView();
        tabLayout.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkId) {
                if (R.id.sealchat_contact == checkId) {
                    showSealChat = true;
                } else {
                    showSealChat = false;
                }
                changeTab();
            }
        });

        initListener(this, R.id.searchParent);

        initListener(this, groupChatBtn, newFriendBtn);


        mSearch_edittext = bind(R.id.search_edittext);
        mSearch_edittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {


                if (TextUtils.isEmpty(s)) {
                    mSearchWord = "";
                } else {
                    mSearchWord = s.toString();
                }
                reloadData();

                //todo:expand the list

            }
        });


    }

    public void reloadData() {

        getActivity().getSupportLoaderManager().restartLoader(LOADERID, null, this);
    }


    private SideBar indexBar;
    private TextView mDialogText;
    private WindowManager mWindowManager;
    private TextView contactheaderCatalog;

    private int mCurrentPosition = -1;

    int mSuspensionHeight;

    SegmentedGroup tabLayout;

    private void initListView() {
        mWindowManager = (WindowManager) getActivity()
                .getSystemService(Context.WINDOW_SERVICE);

        mDialogText = (TextView) LayoutInflater.from(getActivity()).inflate(
                R.layout.side_bar_list_position, null);
        mDialogText.setVisibility(View.INVISIBLE);
        indexBar = bind(R.id.sideBar);
        contactheaderCatalog = bind(R.id.contactheader_catalog);

        indexBar.setListView(mContactsListView, true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        try {
            mWindowManager.addView(mDialogText, lp);
            indexBar.setTextView(mDialogText);
        } catch (Exception e) {
            e.printStackTrace();
        }

        View layout_head = getActivity().getLayoutInflater().inflate(
                R.layout.contacts_top_header, null);
        mContactsListView.addHeaderView(layout_head);
        goneView(layout_head.findViewById(R.id.organization));

        newFriendBtn = layout_head.findViewById(R.id.new_contact);
        TextView textView = (TextView) newFriendBtn.findViewById(R.id.new_contact_text);
        textView.setText(R.string.new_friend);
        groupChatBtn = layout_head.findViewById(R.id.group_chat);

        //set effect
        ImageUtils.buttonEffect(newFriendBtn);
        ImageUtils.buttonEffect(groupChatBtn);

        contactsAdapter = new LocalContactsAdapter(getActivity());
        mContactsListView.setAdapter(contactsAdapter);

        mContactsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PeopleEntity entity = (PeopleEntity) parent.getItemAtPosition(position);

                if (!TextUtils.isEmpty(entity.subuser_id)) {//our register user
                    DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
                } else {
                    //go to normal detail page , maybe need reload when query succ.
                    //invite
                    Intent intent = new Intent(mContext, AddNewFriendActicity.class);
                    intent.putExtra(AddNewFriendActicity.KEY_DETAIL_ENTITY, entity);
                    intent.putExtra(AddNewFriendActicity.KEY_QUERY_DETAIL_ENTITY, true);
                    mContext.startActivity(intent);
                }


            }
        });


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = super.onCreateView(inflater, container, savedInstanceState);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        Uri uri = LocalContactContract.CONTENT_URI;
        contactChangeObserver = new ContactChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri, true, contactChangeObserver);

        try{
            localContactChangeObserver = new LocalContactChangeObserver(new Handler());
            getActivity().getContentResolver().registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, localContactChangeObserver);
        }catch (Exception e){
            e.printStackTrace();//maybe not has permission
        }

    }

    @Override
    protected void settingConfigHasChanged() {
        super.settingConfigHasChanged();
    }



    private class LocalContactChangeObserver extends ContentObserver {
        public LocalContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "LocalContactChangeObserver hasChanged..");
            SPUtil.markCheckedContactsFromServer(false);
        }
    }

    private class ContactChangeObserver extends ContentObserver {
        public ContactChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG, "contact hasChanged..");
            reloadData();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_CONTACTS_PERMISSIONS_REQUEST) {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST ");
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getActivity().getSupportLoaderManager().initLoader(LOADERID, null, this);
            } else {
                Toast.makeText(getContext().getApplicationContext(), "Read Contacts permission denied", Toast.LENGTH_SHORT).show();
                getActivity().finish();
            }
        } else {
            Log.i(TAG, "READ_CONTACTS_PERMISSIONS_REQUEST no");
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        Uri contentUri;
        if (TextUtils.isEmpty(mSearchWord)) {
            // Since there's no search string, use the content URI that searches the entire
            // Contacts table
            contentUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        } else {
            // Since there's a search string, use the special content Uri that searches the
            // Contacts table. The URI consists of a base Uri and the search string.
            contentUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(mSearchWord));
        }


        return new CursorLoader(getContext(), contentUri,
                null, ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + " > 0", null, "sort_key");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, final Cursor data) {
        //
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    readContact(data);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }


    void changeTab() {
        if (showSealChat) {
            indexBar.resetLetters(regiserAlphaLetters);
            contactsAdapter.updateList(registerPeopleEntitys);
            contactsAdapter.notifyDataSetChanged();
        } else {
            indexBar.resetLetters(alphaLetters);
            contactsAdapter.updateList(localContacts);
            contactsAdapter.notifyDataSetChanged();
        }
    }


    private void readContact(Cursor cursor) throws  Exception{
        if (cursor == null || getActivity().isFinishing()) {
            if (cursor == null) {
                Log.i(TAG, "contact cursor is null maybe no permission");
            }
            return;
        }

        Log.i(TAG, "contact cursor maybe has permission ");


        if (cursor.getCount() == 0) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //clear
                    registerPeopleEntitys.clear();
                    localContacts.clear();
                    alphaLetters = new char[]{};
                    regiserAlphaLetters = new char[]{};
                    changeTab();
                }
            });

            return;
        }
        Log.i(TAG, "contact cursor move to frist");
        cursor.moveToFirst();
        final List<PeopleEntity> data = new ArrayList<>();
        final List<PeopleEntity> dataRegisers = new ArrayList<>();
        List<String> userMoblies = new ArrayList<>();

        String CountryCode = SPUtil.getCode();
        do {

            String photoThubnailUri = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI));

            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            if (TextUtils.isEmpty(phone)){
                Log.i(TAG,"phone number is empty ,user contact name:"+name);
                continue;
            }
            PeopleEntity localContact = new PeopleEntity();
            localContact.name = name;
            localContact.nickname = name;
            localContact.mobile = phone;

            String numberPrfex = CountryCode;

            String matchPhone = PhoneNumberUtils.normalizeMatchNumber(numberPrfex,phone);


            PeopleEntity matchPhoneEntity = SPUtil.registerAccount.get(matchPhone);
            if (PeopleEntityQuery.hasFoundPeople(matchPhoneEntity)) {
                localContact = matchPhoneEntity;
                localContact.name = name;
                localContact.nickname = name;
                dataRegisers.add(localContact);
            } else {
                localContact.icon_url = photoThubnailUri;
                userMoblies.add(matchPhone);
            }

            localContact.setLetter(localContact.name);
            data.add(localContact);


        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

        try {
            Collections.sort(data);
            Collections.sort(dataRegisers);
        } catch (Exception e) {
            e.printStackTrace();
        }

        final char[] alphaLettersTemp = ReadFriendContactTask.getAlphaLetters(data);
        final char[] registerAlphaLettersTemp = ReadFriendContactTask.getAlphaLetters(dataRegisers);
        if (!getActivity().isFinishing()) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    localContacts = new ArrayList<PeopleEntity>(data);
                    registerPeopleEntitys = new ArrayList<PeopleEntity>(dataRegisers);
                    alphaLetters = alphaLettersTemp;
                    regiserAlphaLetters = registerAlphaLettersTemp;
                    changeTab();

                }
            });
        }


        if (!SPUtil.checkContactsFromServer()) {
            Log.i(TAG,"check userList from server");

            checkContactsFromServer(userMoblies);
        }else {
            checkContactsFromServer(new ArrayList<String>());
            Log.i(TAG,"no need to check userList from server");
        }


    }

    private void checkContactsFromServer(final List<String> userMoblies) {
        Log.i(TAG,"checkContactsFromServer start");
        RequestFriendManager.getInstance().queryPeoplesByMoblie(userMoblies, new QueryFriendListener() {
            @Override
            public void onResultFriendList(List<PeopleEntity> entities) {
                //in threads
                if (userMoblies.size()>0){
                    SPUtil.markCheckedContactsFromServer(true);
                }

                if (entities != null && !entities.isEmpty()) {
                    if (!getActivity().isFinishing()){
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                reloadData();
                            }
                        });
                    }
                    //save to contact local table later.
                }
            }

            @Override
            public void onQueryFailed(List<String> requestUserIds) {
                    //sub thread.
            }
        });
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        //clear
        contactsAdapter.updateList(new ArrayList<PeopleEntity>());
        contactsAdapter.notifyDataSetChanged();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        try {
            mWindowManager.removeView(mDialogText);
        } catch (Exception e) {
            e.printStackTrace();
        }

        getActivity().getSupportLoaderManager().destroyLoader(LOADERID);
        if (contactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(contactChangeObserver);
        }

        if (localContactChangeObserver != null) {
            getActivity().getContentResolver().unregisterContentObserver(localContactChangeObserver);
        }

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {


            case R.id.new_contact:

            {
                startActivity(new Intent(getActivity(), NewFriendActicity.class));
            }
            break;
            case R.id.group_chat:
                GroupChatListActivity.launchActivity(getActivity());

                break;


            case R.id.searchParent:
                mSearch_edittext.requestFocus();
                KeyBoardUtils.openKeybord(mSearch_edittext, getActivity());
                break;
        }

    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        Log.i(TAG, " isVisibleToUser " + isVisibleToUser);
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.i(TAG, " onResume ");
        updateBadge();

    }


    public void updateBadge() {
        if (!isAdded()) {
            return;
        }

    }


}
