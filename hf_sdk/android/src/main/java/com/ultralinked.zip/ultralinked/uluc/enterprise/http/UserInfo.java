package com.ultralinked.uluc.enterprise.http;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 2016/7/15 0015.
 */
public class UserInfo implements Parcelable,Serializable {
    @Override
    public String toString() {
        return "UserInfo{" +
                "active=" + active +
                ", created_at='" + created_at + '\'' +
                ", deleted_at='" + deleted_at + '\'' +
                ", domain_id='" + domain_id + '\'' +
                ", email='" + email + '\'' +
                ", enable=" + enable +
                ", icon_url='" + icon_url + '\'' +
                ", id='" + id + '\'' +
                ", mobile='" + mobile + '\'' +
                ", name='" + name + '\'' +
                ", nickname='" + nickname + '\'' +
                ", owner=" + owner +
                ", setting_json='" + setting_json + '\'' +
                ", updated_at='" + updated_at + '\'' +
                ", url='" + url + '\'' +
                ", department=" + department +
                ", roles=" + roles +
                '}';
    }

    /**
     * active : true
     * created_at : 2016-07-15T06:01:35
     * deleted_at : null
     * department : [{"id":"DEPART31873dc8-4a5a-11e6-8b80-22000aae16d4","name":"??"}]
     * domain_id : DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed
     * email : hjjj@ffg
     * enable : true
     * icon_url : null
     * id : SUBUSR3178a268-4a5a-11e6-8b80-22000aae16d4
     * mobile : 8618011485532
     * name : ??
     * nickname : null
     * owner : {"developer_id":"DEVELOc2a60578-f73f-11e5-870a-fa163e17f4ed","domain_name":"uc","id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed"}
     * roles : [{"description":null,"id":1,"name":"admin"}]
     * setting_json : null
     * updated_at : null
     * url : null
     */

    private boolean active;
    private String created_at;
    private String deleted_at;
    private String domain_id;
    private String email;
    private boolean enable;
    private String icon_url;
    private String id;
    private String mobile;
    private String name;
    private String nickname;
    private  int gender=-1;
    /**
     * developer_id : DEVELOc2a60578-f73f-11e5-870a-fa163e17f4ed
     * domain_name : uc
     * id : DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed
     */

    private OwnerBean owner;
    private String setting_json;
    private String updated_at;
    private String url;
    /**
     * id : DEPART31873dc8-4a5a-11e6-8b80-22000aae16d4
     * name : ??
     */

    private List<DepartmentBean> department;
    /**
     * description : null
     * id : 1
     * name : admin
     */

    private List<RolesBean> roles;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getDeleted_at() {
        return deleted_at;
    }

    public void setDeleted_at(String deleted_at) {
        this.deleted_at = deleted_at;
    }

    public String getDomain_id() {
        return domain_id;
    }

    public void setDomain_id(String domain_id) {
        this.domain_id = domain_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public OwnerBean getOwner() {
        return owner;
    }

    public void setOwner(OwnerBean owner) {
        this.owner = owner;
    }

    public String getSetting_json() {
        return setting_json;
    }

    public void setSetting_json(String setting_json) {
        this.setting_json = setting_json;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<DepartmentBean> getDepartment() {
        return department;
    }

    public void setDepartment(List<DepartmentBean> department) {
        this.department = department;
    }

    public List<RolesBean> getRoles() {
        return roles;
    }

    public void setRoles(List<RolesBean> roles) {
        this.roles = roles;
    }

    public static String getDisplayName(UserInfo userInfo) {


        String nickName = userInfo.nickname;

        if (TextUtils.isEmpty(nickName)){

            String name = userInfo.name;

            if (TextUtils.isEmpty(name)){
                name = "";
            }
            return name;
        }

        return  nickName;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public static class OwnerBean implements Parcelable {
        private String developer_id;
        private String domain_name;
        private String id;

        public String getDeveloper_id() {
            return developer_id;
        }

        public void setDeveloper_id(String developer_id) {
            this.developer_id = developer_id;
        }

        public String getDomain_name() {
            return domain_name;
        }

        public void setDomain_name(String domain_name) {
            this.domain_name = domain_name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.developer_id);
            dest.writeString(this.domain_name);
            dest.writeString(this.id);
        }

        public OwnerBean() {
        }

        protected OwnerBean(Parcel in) {
            this.developer_id = in.readString();
            this.domain_name = in.readString();
            this.id = in.readString();
        }

        public static final Creator<OwnerBean> CREATOR = new Creator<OwnerBean>() {
            @Override
            public OwnerBean createFromParcel(Parcel source) {
                return new OwnerBean(source);
            }

            @Override
            public OwnerBean[] newArray(int size) {
                return new OwnerBean[size];
            }
        };
    }

    public static class DepartmentBean implements Parcelable {
        private String id;
        private String name;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.id);
            dest.writeString(this.name);
        }

        public DepartmentBean() {
        }

        protected DepartmentBean(Parcel in) {
            this.id = in.readString();
            this.name = in.readString();
        }

        public static final Creator<DepartmentBean> CREATOR = new Creator<DepartmentBean>() {
            @Override
            public DepartmentBean createFromParcel(Parcel source) {
                return new DepartmentBean(source);
            }

            @Override
            public DepartmentBean[] newArray(int size) {
                return new DepartmentBean[size];
            }
        };
    }

    public static class RolesBean implements Parcelable {
        private Object description;
        private int id;
        private String name;

        public Object getDescription() {
            return description;
        }

        public void setDescription(Object description) {
            this.description = description;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeParcelable((Parcelable) this.description, flags);
            dest.writeInt(this.id);
            dest.writeString(this.name);
        }

        public RolesBean() {
        }

        protected RolesBean(Parcel in) {
            this.description = in.readParcelable(Object.class.getClassLoader());
            this.id = in.readInt();
            this.name = in.readString();
        }

        public static final Creator<RolesBean> CREATOR = new Creator<RolesBean>() {
            @Override
            public RolesBean createFromParcel(Parcel source) {
                return new RolesBean(source);
            }

            @Override
            public RolesBean[] newArray(int size) {
                return new RolesBean[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte(this.active ? (byte) 1 : (byte) 0);
        dest.writeString(this.created_at);
        dest.writeString(this.deleted_at);
        dest.writeString(this.domain_id);
        dest.writeString(this.email);
        dest.writeByte(this.enable ? (byte) 1 : (byte) 0);
        dest.writeString(this.icon_url);
        dest.writeString(this.id);
        dest.writeString(this.mobile);
        dest.writeString(this.name);
        dest.writeString(this.nickname);
        dest.writeParcelable(this.owner, flags);
        dest.writeString(this.setting_json);
        dest.writeString(this.updated_at);
        dest.writeString(this.url);
        dest.writeInt(this.gender);
        dest.writeList(this.department);
        dest.writeList(this.roles);
    }

    public UserInfo() {
    }

    protected UserInfo(Parcel in) {
        this.active = in.readByte() != 0;
        this.created_at = in.readString();
        this.deleted_at = in.readString();
        this.domain_id = in.readString();
        this.email = in.readString();
        this.enable = in.readByte() != 0;
        this.icon_url = in.readString();
        this.id = in.readString();
        this.mobile = in.readString();
        this.name = in.readString();
        this.nickname = in.readString();
        this.owner = in.readParcelable(OwnerBean.class.getClassLoader());
        this.setting_json = in.readString();
        this.updated_at = in.readString();
        this.url = in.readString();
        this.gender = in.readInt();
        this.department = new ArrayList<DepartmentBean>();
        in.readList(this.department, DepartmentBean.class.getClassLoader());
        this.roles = new ArrayList<RolesBean>();
        in.readList(this.roles, RolesBean.class.getClassLoader());
    }

    public static final Parcelable.Creator<UserInfo> CREATOR = new Parcelable.Creator<UserInfo>() {
        @Override
        public UserInfo createFromParcel(Parcel source) {
            return new UserInfo(source);
        }

        @Override
        public UserInfo[] newArray(int size) {
            return new UserInfo[size];
        }
    };
}
