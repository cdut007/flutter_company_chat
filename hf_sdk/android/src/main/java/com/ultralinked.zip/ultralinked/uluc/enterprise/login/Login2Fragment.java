package com.ultralinked.uluc.enterprise.login;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.OTPButton;
import com.ultralinked.uluc.enterprise.common.AutoGetCode;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by ultralinked on 2016/7/1 0001.
 */
public class Login2Fragment extends BaseFragment implements EasyPermissions.PermissionCallbacks {

    private Button btVerify;
    private OTPButton btRequest;
    private EditViewPlus etInput;
    private LoginActivity activity;
    private LoginPresenter presenter;
    private EditText etOtp;
    private boolean defaultRequest = true;


    private AutoGetCode autoGetCode;
    private Handler smsHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String otp = (String) msg.obj;

            String lastMobile = SPUtil.getLastMobile();
            if (lastMobile != null && etInput.getText() != null && !lastMobile.equals(etInput.getText().toString())) {
                Log.i(TAG, "user change the mobile , let user input otp by themself");
                return;
            }

            etOtp.setText(otp);
            //  showToast(mContext, getString(R.string.toast_otp_auto_fillin, otp), Style.ALERT);
            btVerify.performClick();
        }
    };


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (LoginActivity) context;
    }

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_login2;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        btVerify = bind(R.id.btVerify);
        etOtp = bind(R.id.etOTP);
        btRequest = bind(R.id.btRequest);
        etInput = bind(R.id.customEt);
        etInput.setHint(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.hint_mobile));

        etInput.setCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, CountryCodeChooseActivity.class);
                startActivityForResult(intent, CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
            }
        });

        btVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetUtil.isNetworkAvailable(activity)) {
                    showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
                    return;
                }

                if (!RegexValidateUtils.checkCellphone(etInput.getTextAll())) {
                    showToast(com.holdingfuture.flutterapp.hfsdk.R.string.error_mobile);
                    try {
                        btVerify.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }


                if (TextUtils.isEmpty(etOtp.getText().toString())) {
                    showToast(R.string.please_enter_otp);
                    try {
                        etOtp.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }

                defaultRequest = false;
                presenter.otpLogin(etInput.getTextAll(), etOtp.getText().toString());
            }
        });

        btRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String account = etInput.getTextAll();
                if (!NetUtil.isNetworkAvailable(activity)) {
                    showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
                    return;
                }

                if (!RegexValidateUtils.checkCellphone(etInput.getTextAll())) {
                    showToast(com.holdingfuture.flutterapp.hfsdk.R.string.error_mobile);

                    return;
                }
                btRequest.click(new OTPButton.OnRequestTypeListener() {
                    @Override
                    public void clickType(String type) {
                        currentType = type;
                        presenter.otpRequest(account, "otp_login", type);
                    }
                });
                defaultRequest = true;

            }
        });

        initData();
    }

    String currentType;

    private void initData() {
        String lastMobile = SPUtil.getLastMobile();
        if (!TextUtils.isEmpty(lastMobile)) {
            etInput.setText(SPUtil.getLastCode(), lastMobile);
        } else {
            etInput.setCountryCode(SPUtil.getCode());
        }


        String[] perms = {Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS};
        if (EasyPermissions.hasPermissions(getActivity(), perms)) {
            autoGetCode = new AutoGetCode(mContext, smsHandler);//
            getActivity().getContentResolver().registerContentObserver(Uri.parse("content://sms/"), true, autoGetCode); //...
        } else {
            //...
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (autoGetCode != null) {
            getActivity().getContentResolver().unregisterContentObserver(autoGetCode);
        }

        smsHandler.removeCallbacksAndMessages(null);


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG, requestCode + "  " + resultCode);
        if (data != null)
            etInput.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.i(TAG);

        presenter = new LoginPresenter(loginView, activity);
    }

    LoginView loginView = new LoginView() {
        @Override
        public void loginSuccess() {
            if (defaultRequest) {
                if ("voice".equals(currentType)) {
                    showToast(activity.getString(R.string.voice_sms_code_has_sent_you));

                } else {
                    showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).substring(0, activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.message_has_sent_you).indexOf("%s")) + etInput.getTextAll());
                }
                return;
            }
            SPUtil.saveCode(etInput.getCountryCode());
            SPUtil.saveMobile(etInput.getText());
            SPUtil.saveLoginModel(SPUtil.LOGIN_BY_OTP);
            Log.i(TAG, "login success from the ui login page, we need to init the DB manager for contact or other things.");
            SqliteUtils.getInstance(getActivity());//init the db manager ,
            Bundle bundle = new Bundle();
            bundle.putBoolean("login", true);
            lunchActivity(MainActivity.class, bundle);
            activity.finish();
        }

        @Override
        public void loginError(String msg) {
            if (defaultRequest) {
                btRequest.cancelCountDown();
            } else {
                try {
                    btVerify.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            activity.showToast(msg);
            activity.hideDialog();
        }

        @Override
        public void showDialog() {
            activity.showDialog();
        }

        @Override
        public void hideDialog() {
            activity.hideDialog();
        }
    };

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
}
