package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

public class AccountSecurity extends BaseActivity implements View.OnClickListener{




    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_account_security;
    }


    @Override
    public void initView(Bundle savedInstanceState) {
        initListener(this, R.id.securityChangMobile, R.id.securityChangePassword, R.id.remote_destrcut, R.id.left_back);
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView)bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.account_security);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.securityChangMobile:
                lunchActivity(ChangeMobileActivity.class);
                break;
            case R.id.securityChangePassword:

                Bundle bundle=new Bundle();
                bundle.putString("lunch_model","login_psd");

                lunchActivity(ResetPsdActivity.class,bundle);

                break;

            case R.id.remote_destrcut:

                lunchActivity(SettingRemoteDestrcutActivity.class);

                break;

            case R.id.left_back:
                finish();
                break;
        }
    }
}
