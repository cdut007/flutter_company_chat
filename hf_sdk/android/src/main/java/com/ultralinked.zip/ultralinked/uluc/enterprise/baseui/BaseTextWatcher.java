package com.ultralinked.uluc.enterprise.baseui;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * Created by lly on 2016/9/20.
 */
public class BaseTextWatcher implements TextWatcher {

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }

}
