package com.ultralinked.uluc.enterprise.contacts;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.ReadFriendContactTask;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Created by ultralinked.
 */
public class CompanyAdapter extends FriendAdapter  {

     protected String TAG = "CompanyAdapter";


    public CompanyAdapter(Context context) {
        super(context);
    }

    @Override
    public void setHolder(MyHolder holder, PeopleEntity peopleEntity) {
        super.setHolder(holder, peopleEntity);
       // TextView tvCatalog =  holder.getView( R.id.contactitem_catalog);
       // tvCatalog.setVisibility(View.GONE);
    }
}
