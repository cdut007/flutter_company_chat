package com.ultralinked.uluc.enterprise.http;


import com.ultralinked.uluc.enterprise.pay.RechargeRecordModel;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;
import rx.Observable;

/**
 * Created by ultralinked on 2016/6/16 0016.
 */

interface ApiService {
    /**----------------------------------login-----------------------------------------*/
    /**
     * 用户注册
     *
     * @param map
     * @return
     */
    @POST("op/create_user")
    Observable<ResponseBody> createUser(@Body Map<String, String> map);



    /**
     * 用户登录old
     *
     * @param map
     * @return
     */
    @POST("authuser")
    Observable<ResponseBody> login(@Body Map<String, Object> map);


    /**
     * otp 注册
     *
     * @param map
     * @return
     */
    @POST("op/otp_regist")
    Observable<ResponseBody> otpRegist(@Body Map<String, String> map);



    /**
     * otp 注册
     *
     * @param map
     * @return
     */
    @POST("op/otp_regist_company")
    Observable<ResponseBody> otpRegistCompany(@Header("Authorization") String token,@Body Map<String, String> map);





    /**
     * otp 验证 old
     *
     * @param map
     * @return
     */
    @POST("op/otp_login")
    Observable<ResponseBody> otpVerify(@Body Map<String, Object> map);


    /**---------------------user info-------------------------*/



    /**
     * 设置用户备注名
     *
     * @param map
     * @return
     */
    @POST("v1/remarkname")
    Observable<ResponseBody> setRemarkName(@Header("Authorization") String token,@Body Map<String, String> map);


    /**
     * 删除用户备注名
     *
     * @param
     * @return
     */
    @DELETE("v1/remarkname")
    Observable<ResponseBody> deleteRemarkName(@Header("Authorization") String token,@Query("user_id") String userid);

    /**
     * 获取用户信息
     *
     * @param token
     * @param userid
     * @return
     */
    @GET("v1/user/{user_id}")
    Observable<UserInfo> getUserInfo(@Header("Authorization") String token, @Path("user_id") String userid);



    @POST("v1/usersetting")
    Observable<ResponseBody> changePrivatePsd(@Header("Authorization") String token,@Body Map<String,String> map);



    @POST("v1/usersetting")
    Observable<ResponseBody> requestSetSignture(@Header("Authorization") String token,@Body Map<String,String> map);


    @POST("v1/usersetting")
    Observable<ResponseBody> requestSetMomentBackgroud(@Header("Authorization") String token,@Body Map<String,String> map);


    @POST("v1/usersetting")
    Observable<ResponseBody> requestFriendConfirmSetting(@Header("Authorization") String token,@Body Map<String,String> map);

    @GET("v1/usersetting")
    Observable<ResponseBody> querySettingConfirmByType(@Header("Authorization") String token,@Query("keyname") String info);


    @GET("v1/usersetting")
    Observable<ResponseBody> queryUserMomentsProfile(@Header("Authorization") String token,@Query("user_id") String user_id,@Query("keyname") String keys);



    @POST("v1/balance_transfer")
    Observable<ResponseBody> requestBalanceTransfer(@Header("Authorization") String token,@Body Map<String,String> map);


    @GET("v1/moments_event")
    Observable<ResponseBody> getUnreadMomentsList(@Header("Authorization") String token);

    @DELETE("v1/moments_event")
    Observable<ResponseBody> deleteUnreadMomentsList(@Header("Authorization") String token,@Query("moments_event_ids") String event_ids);


    @POST("v1/moments_post")
    Observable<ResponseBody> shareMoments(@Header("Authorization") String token,@Body Map<String,Object> map);


    @POST("v1/post_comment")
    Observable<ResponseBody> commentMoments(@Header("Authorization") String token,@Body Map<String,String> map);


    @DELETE("v1/moments_post")
    Observable<ResponseBody> deleteMoments(@Header("Authorization") String token,@Query("post_id") String post_id);



    @DELETE("v1/post_comment")
    Observable<ResponseBody> deleteMomentsComment(@Header("Authorization") String token,@Query("post_id") String post_id,@Query("comment_id") String comment_id);



    @POST("v1/post_like")
    Observable<ResponseBody> likeMoments(@Header("Authorization") String token,@Body Map<String,String> map);




    @GET("v1/moments_post")
    Observable<ResponseBody> queryMoments(@Header("Authorization") String token,@Query("post_id") String page);



    @GET("v1/moments_post")
    Observable<ResponseBody> queryUserPostedMoments(@Header("Authorization") String token,@Query("post_id") String page ,@Query("user_id") String userId);


    @POST("v1/balance_pay")
    Observable<ResponseBody> requestSealedChatPay(@Header("Authorization") String token,@Body Map<String,String> map);



    @POST("v1/usersetting")
    Observable<ResponseBody> requestCurrentOutgoingCallDisplayNumberSetting(@Header("Authorization") String token,@Body Map<String,String> map);

    @GET("v1/usersetting")
    Observable<ResponseBody> queryCurrentOutgoingCallDisplayNumberSetting(@Header("Authorization") String token,@Query("keyname") String number);




    @GET("v1/department?root=false")
    Observable<ResponseBody> getDepartment(@Header("Authorization") String token);



    @GET("op/invitation_status")
    Observable<ResponseBody> getPendingList(@Header("Authorization") String token);

    /**
     * 同意好友,拒绝好友
     * @param token
     * @return
     */
    @PUT("op/invitation_status")
    Observable<ResponseBody> invitationCommand(@Header("Authorization") String token, @Body Map<String, String> map);

    /**
     * 查询好友邀请你的列表
     * @param token
     * @return
     */
    @GET("op/invitation_status")
    Observable<ResponseBody> getFriendPendingList(@Header("Authorization") String token,@Query("action") String action);


    /**
     * 生成qrcode url
     * @param token
     * @return
     */
    @POST("v1/qrcode_string")
    Observable<ResponseBody> getQrcodeUrl(@Header("Authorization") String token, @Body Map<String, String> map);


    @POST("v1/get_users")
    Observable<ResponseBody> getUsers(@Header("Authorization") String token, @Body Map<String, String> map);

    /**
     * ---------------------user info-------------------------
     */




    @POST("op/uploadfile/image")
    Observable<ResponseBody> uploadImagesToMoments(@Header("Authorization") String token, @Body MultipartBody multipartBody);
    /**-------------------invite to be internal/ externa -------------*/


    @Multipart
    @POST("op/uploadicon/")
    Observable<ResponseBody> uploadImg(@Header("Authorization") String token, @PartMap Map<String, RequestBody> params);
    /**-------------------invite to be internal/ externa -------------*/






    /**
     * 查询用户
     *
     * @param token
     * @param map
     * @return
     */
    @POST("op/search_user")
    Observable<ResponseBody> searchUserIds(@Header("Authorization") String token, @Body Map<String, Object> map);



    /**
     * 查询用户mobliles
     *
     * @param token
     * @param map
     * @return
     */
    @POST("v1/mobile_contact")
    Observable<ResponseBody> searchUsersByMobile(@Header("Authorization") String token, @Body Map<String, Object> map);



    /**
     * 查询用户
     *
     * @param token
     * @param map
     * @return
     */
    @POST("op/search_user")
    Observable<ResponseBody> searchUser(@Header("Authorization") String token, @Body Map<String, String> map);

    /**
     * 邀请用户
     *
     * @param token
     * @param map
     * @return
     */
    @POST("op/invitation")
    Observable<ResponseBody> invite(@Header("Authorization") String token, @Body Map<String, String> map);

    /***
     * -------------------invite to be internal/ externa -------------
     */

    /*-------------------- get, set, delete- private contact-------------*/
    @GET("v1/private_contact")
    Observable<ResponseBody> getprivate(@Header("Authorization") String token);


    @POST("v1/private_contact")
    Observable<ResponseBody> setprivate(@Header("Authorization") String token, @Body Map<String, String> map);


    @HTTP(method = "DELETE", path = "v1/private_contact", hasBody = true)
    Observable<ResponseBody> deleprivate(@Header("Authorization") String token, @Body Map<String, String> map);

   /*-------------------- get, set, delete- private contact-------------*/


    /*-------------------- get, set, delete- friend-------------*/
    @GET("v1/friend")
    Observable<ResponseBody> getFriend(@Header("Authorization") String token);

    @HTTP(method = "DELETE", path = "v1/friend", hasBody = true)
    Observable<ResponseBody> deleteFriend(@Header("Authorization") String token,@Body Map<String, String> map);



    /**
     * 修改密码
     * @param token
     * @param userid
     * @param map
     * @return
     */
    @PUT("v1/personalsetting/{user_id}")
    Observable<ResponseBody> changeUserPassword(@Header("Authorization") String token, @Path("user_id") String userid, @Body Map<String, String> map);


    /**
     * 个人详情
     * @param token
     * @param userid
     * @param map
     * @return
     */
    @PUT("v1/user/{user_id}")
    Observable<UserInfo> updateUserInfo(@Header("Authorization") String token, @Path("user_id") String userid, @Body Map<String, String> map);

    /**
     * 个人详情设置
     * @param token
     * @param map
     * @return
     */
    @POST("v1/usersetting")
        //set password for private contact if no password exists
    Observable<ResponseBody> setPrivatePsd(@Header("Authorization") String token, @Body Map<String, String> map);



    /**
     * 获取登录设备列表
     * @param token
     * @param
     * @return
     */
    @GET("v1/user_device")
    Observable<ResponseBody> getTheUserDevices(@Header("Authorization") String token);



    /**
     * 查询当前设备是否摧毁
     * @param token
     * @return
     */
    @GET("v1/destroyed_device")
    Observable<ResponseBody> getDestroyDevice(@Header("Authorization") String token,@Query("device_id") String device_id,@Query("device_name") String device_name,@Query("device_type") String device_type);


    /**
     * 一键远程摧毁
     * @param token
     * @param map
     * @return
     */
    @POST("v1/destroyed_device")
    Observable<ResponseBody> setDestroyDevice(@Header("Authorization") String token, @Body Map<String, String> map);


    /**
     * 解除某个设备一键远程摧毁
     * @param token
     * @return
     */
    @HTTP(method = "DELETE", path = "v1/destroyed_device")
    Observable<ResponseBody> recoveryDestroyDevice(@Header("Authorization") String token, @Query("password") String password,@Query("device_id") String device_id);


    /**
     * refresh token config
     * @param token
     * @return
     */
    @GET("v1/usersetting")
    Observable<ResponseBody> refreshConfig(@Header("Authorization") String token);


    /**
     * 请求OTP
     * @param token
     * @param map
     * @return
     */
    @POST("op/request_otp")
    Observable<ResponseBody> request_otp(@Header("Authorization") String token, @Body Map<String, String> map);

    /**
     * 改手机号码
     * @param token
     * @param map
     * @return
     */
    @POST("op/change_mobile_otp")
    Observable<ResponseBody> changeMobile(@Header("Authorization") String token, @Body Map<String, String> map);


    @POST("op/callback_rabbitmq")
    Observable<ResponseBody> callback(@Header("Authorization") String token, @Body Map<String, String> map);


    @GET("http://api.map.baidu.com/geoconv/v1/?from=1&to=5&ak=FtGWsTC5zD2A3zX4fOzsrxztIyuAiINO&mcode=72:CB:A3:EE:13:C4:39:24:E7:2B:81:6E:F1:D6:F9:D5:D0:47:74:09;com.ultralinked.uluc.enterprise")
    Observable<ResponseBody> getMap( @Query("coords") String coords);

    @GET
    Observable<ResponseBody> parseQrCodeUrl(@Header("Authorization") String token, @Url String url);

    @GET("v1/product")
    Observable<ResponseBody> getProduct(@Header("Authorization")String token,@Query("type")String type);




    @POST("v1/user_payment_change_provider")
    Observable<ResponseBody> changePaymentProviderSignedData(@Header("Authorization")String token, @Body Map<String,String> map);


    @POST("v1/user_payment")
    Observable<ResponseBody> getPaymentSignedData(@Header("Authorization")String token, @Body Map<String,String> map);

    Observable<ResponseBody> getHtml();

    @GET("http://www.tuling123.com/openapi/api?key=00a859243614e178d52d52c44b9db891")
    Observable<ResponseBody> queryAsisantInfo( @Query("info") String content);

    @PUT("v1/user_payment/{payment_id}")
    Observable<ResponseBody> submitPayPalId(@Header("Authorization")String token, @Path("payment_id")String payment_id, @Body Map<String, String> map);

    @GET("v1/balance")
    Observable<ResponseBody> getAccountBalance(@Header("Authorization")String token);

    @GET("v1/exchange_rate")
    Observable<ResponseBody> getCurrencyRate(@Header("Authorization") String token);

    @GET("v1/invitation_code")
    Observable<ResponseBody> getInvitationUrl(@Header("Authorization") String token);

    @GET("v1/user_payment")
    Observable<ResponseBody> getRechargeRecord(@Header("Authorization") String token);

    @POST("v1/payment_status")
    Observable<ResponseBody> submitPaymentStatus(@Header("Authorization") String token, @Body Map<String,String> map);

    @GET("v1/download_url")
    Observable<ResponseBody> getShareUrl(@Header("Authorization") String token);

    @POST("op/query_order")
    Observable<ResponseBody> queryOrder(@Header("Authorization") String token, @Body RechargeRecordModel model);

    @GET("v1/sub_cdr")
    Observable<ResponseBody> queryCallRecords(@Header("Authorization") String token, @QueryMap Map<String,Integer> map);
}
