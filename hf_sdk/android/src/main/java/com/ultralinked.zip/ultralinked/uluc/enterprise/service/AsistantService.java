package com.ultralinked.uluc.enterprise.service;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.content.IntentCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.Gson;
import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechUnderstander;
import com.iflytek.cloud.SpeechUnderstanderListener;
import com.iflytek.cloud.TextUnderstander;
import com.iflytek.cloud.TextUnderstanderListener;
import com.iflytek.cloud.UnderstanderResult;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.call.IncallActivity;
import com.ultralinked.uluc.enterprise.chat.bean.UrlInfo;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.game.chess.ChessGame;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.GuideActivity;
import com.ultralinked.uluc.enterprise.utils.ACache;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.SubscribeMessage;
import com.ultralinked.voip.api.TextMessage;
import com.ultralinked.voip.api.VoiceMessage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by mac on 16/11/11.
 */
public class AsistantService {
    private static AsistantService ourInstance = new AsistantService();
    public static boolean useLocal=true;

    static String TAG = "AsistantService";


    // 语义理解对象（语音到语义）。
    private SpeechUnderstander mSpeechUnderstander;
    // 语义理解对象（文本到语义）。
    private TextUnderstander mTextUnderstander;


    /**
     * 参数设置
     * @param
     * @return
     */
    public void setSpeechParam(){
        String lang = "zh_cn";

        String currentLanguage = Locale.getDefault().getLanguage();
        if (currentLanguage!=null&& currentLanguage.startsWith("en")){
            lang = "en_us";
        }
        if (lang.equals("en_us")) {
            // 设置语言
            mSpeechUnderstander.setParameter(SpeechConstant.LANGUAGE, "en_us");
        }else {
            // 设置语言
            mSpeechUnderstander.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
            // 设置语言区域
            mSpeechUnderstander.setParameter(SpeechConstant.ACCENT, lang);
        }
        // 设置语音前端点:静音超时时间，即用户多长时间不说话则当做超时处理
        mSpeechUnderstander.setParameter(SpeechConstant.VAD_BOS, "4000");

        // 设置语音后端点:后端点静音检测时间，即用户停止说话多长时间内即认为不再输入， 自动停止录音
        mSpeechUnderstander.setParameter(SpeechConstant.VAD_EOS, "1000");

        // 设置标点符号，默认：1（有标点）
        mSpeechUnderstander.setParameter(SpeechConstant.ASR_PTT, "1");

        // 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
        // 注：AUDIO_FORMAT参数语记需要更新版本才能生效
        mSpeechUnderstander.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
        mSpeechUnderstander.setParameter(SpeechConstant.ASR_AUDIO_PATH, Environment.getExternalStorageDirectory()+"/msc/sud.wav");
    }




    private  boolean inited;
    public  void initSpeech(){
        // 初始化对象
        if (!inited){
            inited = true;
            mSpeechUnderstander = SpeechUnderstander.createUnderstander(App.getInstance(), mSpeechUdrInitListener);
            mTextUnderstander = TextUnderstander.createTextUnderstander(App.getInstance(), mTextUdrInitListener);
        }

    }

    public  void releaseSpeech(){
        // 退出时释放连接
        inited = false;
        if (mSpeechUnderstander!=null){
            mSpeechUnderstander.cancel();
            mSpeechUnderstander.destroy();
            if(mTextUnderstander.isUnderstanding())
                mTextUnderstander.cancel();
            mTextUnderstander.destroy();
        }

    }

    /**
     * 初始化监听器（语音到语义）。
     */
    private InitListener mSpeechUdrInitListener = new InitListener() {

        @Override
        public void onInit(int code) {
            Log.d(TAG, "speechUnderstanderListener init() code = " + code);
            if (code != ErrorCode.SUCCESS) {
                Log.d(TAG, "mSpeechUdrInitListener 初始化失败,错误码 = " + code);
            }
        }
    };

    /**
     * 初始化监听器（文本到语义）。
     */
    private InitListener mTextUdrInitListener = new InitListener() {

        @Override
        public void onInit(int code) {
            Log.d(TAG, "textUnderstanderListener init() code = " + code);
            if (code != ErrorCode.SUCCESS) {
                Log.d(TAG, "mTextUdrInitListener 初始化失败,错误码 = " + code);
            }
        }
    };



    private TextUnderstanderListener mTextUnderstanderListener = new TextUnderstanderListener() {

        @Override
        public void onResult(final UnderstanderResult result) {
            if (null != result) {
                // 显示
                String text = result.getResultString();
                if (!TextUtils.isEmpty(text)) {
                    Log.i(TAG, "understander result:"+text);
                    parseUnderstanderResult(text);
                }
            } else {
                Log.i(TAG, "understander result:null");
            }
        }

        @Override
        public void onError(SpeechError error) {
            // 文本语义不能使用回调错误码14002，请确认您下载sdk时是否勾选语义场景和私有语义的发布
            Log.d(TAG, "onError Code："+ error.getErrorCode());


        }
    };


    /**
     * 语义理解回调。
     */
    private SpeechUnderstanderListener mSpeechUnderstanderListener = new SpeechUnderstanderListener() {

        @Override
        public void onResult(final UnderstanderResult result) {
            if (null != result) {
                Log.i(TAG, "result:"+result.getResultString());

                // 显示
                String text = result.getResultString();
                if (!TextUtils.isEmpty(text)) {
                    Log.i(TAG,"识别结果: "+text);
                    parseUnderstanderResult(text);
                    if (sSpeechUnderstanderListener!=null){
                       try{
                           JSONObject jsonObject = new JSONObject(text);
                          int code =  jsonObject.optInt("rc");
                           if (code == 0){
                               String content = jsonObject.optString("text");
                               sSpeechUnderstanderListener.onResult(content);
                           }

                       }catch (Exception e){
                           e.printStackTrace();
                       }
                    }
                }
            } else {
                Log.i(TAG,"识别结果不正确。");
                if (sSpeechUnderstanderListener!=null){
                    sSpeechUnderstanderListener.onResult(null);
                }
            }


        }

        @Override
        public void onVolumeChanged(int volume, byte[] data) {
            Log.i(TAG,"当前正在说话，音量大小：" + volume);
            if (sSpeechUnderstanderListener!=null){
                sSpeechUnderstanderListener.onVolumeChanged(volume);
            }
            Log.i(TAG, data.length+"");
        }

        @Override
        public void onEndOfSpeech() {
            // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
            Log.i(TAG,"结束说话");
            if (sSpeechUnderstanderListener!=null){
                sSpeechUnderstanderListener.onEndOfSpeech(false);
            }
        }

        @Override
        public void onBeginOfSpeech() {
            // 此回调表示：sdk内部录音机已经准备好了，用户可以开始语音输入
            Log.i(TAG,"开始说话");
            if (sSpeechUnderstanderListener!=null){
                sSpeechUnderstanderListener.onBeginOfSpeech();
            }
        }

        @Override
        public void onError(SpeechError error) {
           Log.i(TAG,"speech_error:"+error.getPlainDescription(true));
            if (sSpeechUnderstanderListener!=null){
                sSpeechUnderstanderListener.onEndOfSpeech(true);
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
            // 以下代码用于获取与云端的会话id，当业务出错时将会话id提供给技术支持人员，可用于查询会话日志，定位出错原因
            //	if (SpeechEvent.EVENT_SESSION_ID == eventType) {
            //		String sid = obj.getString(SpeechEvent.KEY_EVENT_SESSION_ID);
            //		Log.d(TAG, "session id =" + sid);
            //	}
        }
    };



    public  void underStandStop(){
        if (mSpeechUnderstander!=null)
        mSpeechUnderstander.stopUnderstanding();


    }
   public void underStandCancel(){
       if (mSpeechUnderstander!=null)
        mSpeechUnderstander.cancel();

    }







    //end speech. .........................................................................






    public static AsistantService getInstance() {
        return ourInstance;
    }

    private AsistantService() {

    }


    String currentChatId;

   public void startUnderStandByText(String chatID,String text){
        if (mTextUnderstander == null){
            return;
        }
        currentChatId = chatID;
        if(mTextUnderstander.isUnderstanding()){
            mTextUnderstander.cancel();
        }

        int  ret = mTextUnderstander.understandText(text, mTextUnderstanderListener);
        if(ret != 0)
        {
            Log.i(TAG,"语义理解失败,错误码:"	+ ret);
        }

    }

    public interface OnSpeechUnderstanderListener {
        void onVolumeChanged(int volume);

        void onBeginOfSpeech();

        void onEndOfSpeech(boolean hasError);

        void onResult(String text);
    }

    OnSpeechUnderstanderListener sSpeechUnderstanderListener;

    public void startUnderStandByVoice(String chatId,OnSpeechUnderstanderListener sSpeechUnderstanderListener){
        if (mSpeechUnderstander == null){
            return;
        }
        currentChatId = chatId;
        // 设置参数
        setSpeechParam();

        if(mSpeechUnderstander.isUnderstanding()){// 开始前检查状态
            mSpeechUnderstander.stopUnderstanding();

        }
     this. sSpeechUnderstanderListener = sSpeechUnderstanderListener;
        int ret = mSpeechUnderstander.startUnderstanding(mSpeechUnderstanderListener);
        if(ret != 0){
           Log.i(TAG,"语义理解失败,错误码:"	+ ret);
        }else {
          //  showTip(getString(R.string.text_begin));
        }

    }



    public void checkPushAsistantMsg() {

        {
            try{

                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        ACache aCache = ACache.get(App.getInstance());
                        String time = aCache.getAsString("lastCheckTime");
                        if (time!=null){
                            try{
                                long systemTime = Long.parseLong(time);
                                long currentTime = System.currentTimeMillis();
                                if (currentTime - systemTime > 1000* 3600 *4){//4 hours
                                    aCache.put("lastCheckTime",""+currentTime,ACache.TIME_DAY*365);
                                    Random random = new Random();
                                    // int index= random.nextInt();
                                    List<PeopleEntity> peopleEntities = SPUtil.getAssistant();
                                    if (peopleEntities!=null && peopleEntities.size()>0){
                                        dealContent(peopleEntities.get(0).subuser_id,"新闻");
                                    }
                                }
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }else{
                            long currentTime = System.currentTimeMillis();
                            aCache.put("lastCheckTime",""+currentTime,ACache.TIME_DAY*365);
                            List<PeopleEntity> peopleEntities = SPUtil.getAssistant();
                            if (peopleEntities!=null && peopleEntities.size()>0){
                                dealContent(peopleEntities.get(0).subuser_id,"新闻");
                            }
                        }

                    }
                }, 1000);


            }catch (Exception e){
                e.printStackTrace();
            }
        }



    }


//
//    private void install(String name){
//        Intent intent = new Intent();
//        intent.setAction(Intent.ACTION_VIEW);
//
//        File file = new File(Environment.getExternalStorageDirectory(),"HtmlUI1.apk");
//        intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
//
//        startActivity(intent);
//    }

    private void uninstall(String name){
        if (TextUtils.isEmpty(name)){
            return;
        }

        PackageManager packageManager = App.getInstance().getPackageManager();

        // 获取手机里的应用列表

        List<PackageInfo> pInfo = packageManager.getInstalledPackages(0);

        for (int i = 0; i < pInfo.size(); i++)

        {

            PackageInfo p = pInfo.get(i);

            // 获取相关包的<application>中的label信息，也就是-->应用程序的名字

            String label = packageManager.getApplicationLabel(p.applicationInfo).toString();

            System.out.println(label);

            if (label.contains(name)||name.contains(label)){ //比较label

                String pName = p.packageName; //获取包名

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_DELETE);
                intent.setData(Uri.parse("package:"+pName));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                App.getInstance().startActivity(intent);

            }

        }

    }

    private  void openAppByName(String name){
        if (TextUtils.isEmpty(name)){
            return;
        }

        PackageManager packageManager = App.getInstance().getPackageManager();

        // 获取手机里的应用列表

        List<PackageInfo> pInfo = packageManager.getInstalledPackages(0);

        for (int i = 0; i < pInfo.size(); i++)

        {

            PackageInfo p = pInfo.get(i);

            // 获取相关包的<application>中的label信息，也就是-->应用程序的名字

            String label = packageManager.getApplicationLabel(p.applicationInfo).toString();

            System.out.println(label);

            if (label.contains(name)||name.contains(label)){ //比较label

                String pName = p.packageName; //获取包名

                Intent intent = new Intent();
                //获取intent
                intent =packageManager.getLaunchIntentForPackage(pName);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                App.getInstance().startActivity(intent);

            }

        }
    }

    private void parseUnderstanderResult(final String text) {
        try{


            Observable.create(new Observable.OnSubscribe<String>() {


                @Override
                public void call(Subscriber<? super String> subscriber) {
                    try {

                        JSONObject parseInfo = new JSONObject(text);

                        int code = parseInfo.optInt("rc");
                        if (code == 0){
                            if ("music".equals(parseInfo.optString("service"))){
                                if ("PLAY".equals(parseInfo.optString("operation"))){
                                   JSONObject musicJsonData = parseMusicMessage(parseInfo);
                                    if (musicJsonData!=null){
                                        Message musicMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), musicJsonData, Conversation.SINGLE_CHAT,null);
                                        if (musicMessage!=null){
                                            musicMessage =  parseSubscribeMessageInfo((SubscribeMessage) musicMessage);
                                            List<SubscribeMessage.Subscribe> subscribes = ((SubscribeMessage) musicMessage).subscribes;
                                            if (subscribes!=null && subscribes.size()>0){
                                                String playAddress = subscribes.get((int) (Math.random() * subscribes.size())).linkUrl;
                                                PlayMusicService.getInstance().playOrStop(playAddress);
                                            }
                                        }

                                    }
                                }

                            } else if ("weather".equals(parseInfo.optString("service"))){
                                if ("QUERY".equals(parseInfo.optString("operation"))){
                                    JSONObject weatherJsonData = parseWeatherMessage(parseInfo);
                                    if (weatherJsonData!=null){
                                        Message weatherMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), weatherJsonData, Conversation.SINGLE_CHAT,null);
                                        if (weatherMessage!=null){
                                            weatherMessage =  parseSubscribeMessageInfo((SubscribeMessage) weatherMessage);
                                            List<SubscribeMessage.Subscribe> subscribes = ((SubscribeMessage) weatherMessage).subscribes;

                                        }

                                    }
                                }

                            }else if ("cookbook".equals(parseInfo.optString("service"))){
                                if ("QUERY".equals(parseInfo.optString("operation"))){
                                    JSONObject cookJsonData = parseCookMessage(parseInfo);
                                    if (cookJsonData!=null){
                                        Message cookMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), cookJsonData, Conversation.SINGLE_CHAT,null);
                                        if (cookMessage!=null){
                                            cookMessage =  parseSubscribeMessageInfo((SubscribeMessage) cookMessage);
                                            List<SubscribeMessage.Subscribe> subscribes = ((SubscribeMessage) cookMessage).subscribes;

                                        }

                                    }
                                }

                            }else if ("stock".equals(parseInfo.optString("service"))){
                                if ("QUERY".equals(parseInfo.optString("operation"))){
                                    JSONObject stockJsonData = parseStockMessage(parseInfo);
                                    if (stockJsonData!=null){
                                        Message stockMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), stockJsonData, Conversation.SINGLE_CHAT,null);
                                        if (stockMessage!=null){
                                            stockMessage =  parseSubscribeMessageInfo((SubscribeMessage) stockMessage);
                                            List<SubscribeMessage.Subscribe> subscribes = ((SubscribeMessage) stockMessage).subscribes;

                                        }

                                    }
                                }

                            }else if ("video".equals(parseInfo.optString("service"))){
                                if ("QUERY".equals(parseInfo.optString("operation"))||"PLAY".equals(parseInfo.optString("operation"))){
                                    JSONObject videoJsonData = parseVideoMessage(parseInfo);
                                    if (videoJsonData!=null){
                                        Message videoMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), videoJsonData, Conversation.SINGLE_CHAT,null);
                                        if (videoMessage!=null){
                                            videoMessage =  parseSubscribeMessageInfo((SubscribeMessage) videoMessage);
                                            List<SubscribeMessage.Subscribe> subscribes = ((SubscribeMessage) videoMessage).subscribes;

                                        }

                                    }
                                }

                            }else if ("app".equals(parseInfo.optString("service"))){
                                if ("LAUNCH".equals(parseInfo.optString("operation"))){
                                    String name = parseAppName(parseInfo);
                                    openAppByName(name);
                                }else if ("UNINSTALL".equals(parseInfo.optString("operation"))){
                                    String name = parseAppName(parseInfo);
                                    uninstall(name);
                                }

                            }else if ("website".equals(parseInfo.optString("service"))){

                                JSONObject websiteJsonData = parseWebsiteMessage(parseInfo);
                                if (websiteJsonData!=null){
                                    Message websiteMessage = MessagingApi.insertSubscribeMessage(currentChatId,currentChatId, SPUtil.getUserID(), websiteJsonData, Conversation.SINGLE_CHAT,null);
                                    if (websiteMessage!=null){
                                        websiteMessage =  parseSubscribeMessageInfo((SubscribeMessage) websiteMessage);

                                    }

                                }

                                if ("OPEN".equals(parseInfo.optString("operation"))){

                                }


                            }else if ("telephone".equals(parseInfo.optString("service"))){



                                if ("CALL".equals(parseInfo.optString("operation"))){
                                    String callName = parseSenderNameMessage(parseInfo);
                                    if (callName!=null){

                                        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByNameSql(callName);
                                        if (peopleEntity==null){
                                            Log.i(TAG,"can not find the people info.");
                                            return;
                                        }
                                        String displayName = PeopleEntityQuery.getDisplayName(peopleEntity);

                                        Log.i("callfromChat", "call mobile:===" + peopleEntity.mobile+";call name="+displayName);
                                        IncallActivity.lunch(App.getInstance(), peopleEntity.mobile, displayName, peopleEntity.icon_url, false, IncallActivity.IP2IP);         }
                                }


                            }else if ("message".equals(parseInfo.optString("service"))){


                                if ("SEND".equals(parseInfo.optString("operation"))){
                                    String chatName = parseSenderNameMessage(parseInfo);


                                    if (chatName!=null){

                                        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByNameSql(chatName);
                                        if (peopleEntity==null){
                                            Log.i(TAG,"can not find the people info.");
                                            return;
                                        }
                                        String chatId = peopleEntity.subuser_id;

                                            //go to SinglePage.
                                        SingleChatImActivity.launchToSingleChatImWithIntentFlags(App.getInstance(),chatId,Conversation.CONVERSATION_FLAG_NONE,Intent.FLAG_ACTIVITY_NEW_TASK);



                                    }
                                }


                            }else{
                                JSONObject answer = parseInfo.optJSONObject("answer");
                                String text= answer.optString("text");
                                MessagingApi.insertTextMessage(currentChatId,currentChatId, SPUtil.getUserID(), text, Conversation.SINGLE_CHAT);

                            }
                        }else if (code == 4){
                            String askStr =  parseInfo.optString("text");
                            dealContent(currentChatId,askStr);
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    //test game.
                    if (text!=null && text.contains("象棋")){
                        ChessGame.lunch(SPUtil.getAssistant().get(0).subuser_id,false);

                    }

                    subscriber.onNext("parse_result.."+text);

                }

            })
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Action1<String>() {
                        @Override
                        public void call(String info) {
                            String resultInfo = info;
                            Log.i(TAG,"parse_result:"+resultInfo);
                            //

                        }

                    });

        }catch (Exception e){
            e.printStackTrace();
        }
    }



    private  JSONObject parseVideoMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        JSONObject webPagejsonObj = parseInfo.optJSONObject("webPage");
        subscribeMessage.linkUrl ="http://www.youku.com/";
        subscribeMessage.title = "优酷(Youku)";
        subscribeMessage.content = subscribeMessage.title;

        subscribeMessage.imgUrl = "http://pic2.ooopic.com/11/01/53/32b1OOOPIC14.jpg";
        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }



    private  String parseAppName(JSONObject parseInfo) throws  JSONException{


        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                return  slotsObj.optString("name");

            }
        }

        return null;
    }



    private  String parseSenderNameMessage(JSONObject parseInfo) throws  JSONException{

        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                return  slotsObj.optString("name");
            }
        }

        return null;
    }


    private  JSONObject parseWebsiteMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();

        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                subscribeMessage.title = slotsObj.optString("name");
                subscribeMessage.content = subscribeMessage.title;
                subscribeMessage.linkUrl = slotsObj.optString("url");
            }
        }

        subscribeMessage.imgUrl = "http://img02.tooopen.com/images/20151110/tooopen_sy_148255028389.jpg";

        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }


    private  JSONObject parseStockMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        JSONObject webPagejsonObj = parseInfo.optJSONObject("webPage");
        if (webPagejsonObj!=null){
            subscribeMessage.linkUrl = webPagejsonObj.optString("url");
        }

        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                subscribeMessage.title = slotsObj.optString("name");
                subscribeMessage.content = subscribeMessage.title+"("+slotsObj.optString("code")+")";
            }
        }

        subscribeMessage.imgUrl = "http://www.wm178.com/uploads/20161114/ivpnsormlzv51.jpg";

        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }

    private  JSONObject parseCookMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        JSONObject webPagejsonObj = parseInfo.optJSONObject("webPage");
        if (webPagejsonObj!=null){
            subscribeMessage.linkUrl = webPagejsonObj.optString("url");
        }

        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                subscribeMessage.title = slotsObj.optString("dishName");
                subscribeMessage.content = slotsObj.optString("dishName");
            }
        }

        subscribeMessage.imgUrl = "http://pic.90sjimg.com/back_pic/qk/back_origin_pic/00/03/79/dbbeafa2d1fd0da34b9c19e8afd49508.jpg";
        JSONObject data = parseInfo.optJSONObject("data");

        if (data == null){
            return  null;
        }

        JSONArray listArray = data.optJSONArray("result");
        subscribeMessage.subscribes = new ArrayList<>();
//        "accessory": "盐:1克;糖:15克;醋:5克;水:半碗;生粉:适量;酱油:1克;豆瓣酱:适量;香菇:3朵;大葱:适量;青椒:半个;红椒:半个;茭白:半个;胡萝卜:适量;姜:适量;蒜:适量",
//                "source": "豆果网",
//                "imgUrl": "http:\/\/imgs.douguo.com\/upload\/caiku\/a\/d\/5\/ad27633167be872ca870ecb99fbff085.jpg",
//                "ingredient": "里脊肉丝:半斤",
//                "url": "http:\/\/m.douguo.com\/cookbook\/86823.html?f=xunfei",
//                "cuisine": "川菜"
        for (int i = 0; i <listArray.length() ; i++) {
            JSONObject jsonObject= listArray.getJSONObject(i);
            SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
            subscribe.title = jsonObject.optString("ingredient");
            subscribe.imgUrl =  jsonObject.optString("imgUrl");
            subscribe.linkUrl = jsonObject.optString("url");
            subscribe.content =  jsonObject.optString("accessory");
            subscribeMessage.subscribes.add(subscribe);
         if (!TextUtils.isEmpty(subscribe.imgUrl)){
             subscribeMessage.imgUrl =  subscribe.imgUrl;
         }

        }
        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }


    private JSONObject parseWeatherMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        JSONObject webPagejsonObj = parseInfo.optJSONObject("webPage");
        if (webPagejsonObj!=null){
            subscribeMessage.linkUrl = webPagejsonObj.optString("url");
        }


        subscribeMessage.imgUrl = "http://sc.jb51.net/uploads/allimg/140309/10-14030916252IW.jpg";
        JSONObject data = parseInfo.optJSONObject("data");

        if (data == null){
            return  null;
        }

        JSONArray listArray = data.optJSONArray("result");
        subscribeMessage.subscribes = new ArrayList<>();
        //       "airQuality": "中度污染",
//                "sourceName": "中国天气网",
//                "date": "2016-11-15",
//                "lastUpdateTime": "2016-11-15 18:31:01",
//                "dateLong": 1479139200,
//                "pm25": "190",
//                "city": "成都",
//                "humidity": "37%",
//                "windLevel": 0,
//                "weather": "多云",
//                "tempRange": "11℃",
//                "wind": "南风微风"
        for (int i = 0; i <listArray.length() ; i++) {
            JSONObject jsonObject= listArray.getJSONObject(i);
            SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
            subscribe.title = jsonObject.optString("city");
            subscribe.imgUrl = "http://www.sucaitianxia.com/png/UploadFiles_6130/200803/20080320234151914.png";
            subscribe.linkUrl = subscribeMessage.linkUrl;
            subscribe.content =  jsonObject.optString("city")+" "+jsonObject.optString("airQuality")+" "+jsonObject.getString("tempRange");

            subscribeMessage.subscribes.add(subscribe);
            if (i == 0){
                subscribeMessage.content =  jsonObject.optString("date")+" "+ jsonObject.optString("city")+" "+jsonObject.optString("airQuality")+" "+jsonObject.getString("tempRange");
                subscribeMessage.title =  jsonObject.optString("sourceName");
            }

        }
        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }

    private JSONObject parseMusicMessage(JSONObject parseInfo) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        JSONObject webPagejsonObj = parseInfo.optJSONObject("webPage");
        if (webPagejsonObj!=null){
            subscribeMessage.linkUrl = webPagejsonObj.optString("url");
        }
        JSONObject semanticjsonObj = parseInfo.optJSONObject("semantic");
        if (semanticjsonObj!=null){
            JSONObject slotsObj = semanticjsonObj.optJSONObject("slots");
            if (slotsObj!=null){
                subscribeMessage.title = slotsObj.optString("artist");
                subscribeMessage.content = slotsObj.optString("artist");
            }
        }


        subscribeMessage.imgUrl = "http://pic.58pic.com/58pic/17/32/59/63758PICfhF_1024.jpg";
        JSONObject data = parseInfo.optJSONObject("data");

        if (data == null){
            return  null;
        }

        JSONArray listArray = data.optJSONArray("result");
        subscribeMessage.subscribes = new ArrayList<>();
//        "singer": "刘德华",
//                "sourceName": "自产音乐",
//                "name": "你会看见我的爱",
//                "downloadUrl": "http://file.kuyinyun.com/group1/M00/45/D9/rBBGdVPXmRqAJP2VABePVqkLvm0889.mp3"
        for (int i = 0; i <listArray.length() ; i++) {
            JSONObject jsonObject= listArray.getJSONObject(i);
            SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
            subscribe.title = jsonObject.optString("singer");
            subscribe.imgUrl = "http://pic37.nipic.com/20140109/13340678_144948124115_2.jpg";
            subscribe.linkUrl = jsonObject.optString("downloadUrl");
            subscribe.content = jsonObject.optString("name");
            subscribeMessage.subscribes.add(subscribe);

        }
        Gson gson = new Gson();
        JSONObject result = new JSONObject(gson.toJson(subscribeMessage));
        return result;
    }




























    public void dealContent(final String chatId,final String sendText) {

        //1 check local keyword match first.
        queryByThridPatry(chatId,sendText);



    }


   void  queryByThridPatry(final String chatId,String sendText){
        ApiManager.getInstance().queryAsisantInfo(sendText)
                .subscribeOn(Schedulers.io())                   //子线程
                .observeOn(Schedulers.io())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"dealContentComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "dealContent error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            int code = object.optInt("code");
                            if (100000 == code || 40002==code ) {
                                String content = object.optString("text");
                                MessagingApi.insertTextMessage(chatId,chatId, SPUtil.getUserID(), content, Conversation.SINGLE_CHAT);
                            }else if(302000 == code ){
                                JSONObject data = parseNewsMessage(object);
                                MessagingApi.insertSubscribeMessage(chatId,chatId, SPUtil.getUserID(), data, Conversation.SINGLE_CHAT,null);
                            }else if(308000 == code ){
                                JSONObject data = parseCookingMessage(object);
                                MessagingApi.insertSubscribeMessage(chatId,chatId, SPUtil.getUserID(), data, Conversation.SINGLE_CHAT,null);
                            }else if (200000 ==code ){
                                JSONObject data = parseLinkMessage(object);
                                MessagingApi.insertSubscribeMessage(chatId,chatId, SPUtil.getUserID(), data, Conversation.SINGLE_CHAT,null);

                            }

                        } catch (IOException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        } catch (JSONException e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        }

                        Log.i(TAG, "dealContent:  " + rs);
                    }

                });
    }

//
//    {
//
//
//        "code": 200000,
//
//
//            "text": "亲，已帮你找到图片",
//
//
//            "url": "http://m.image.so.com/i?q=%E5%B0%8F%E7%8B%97"
//
//
//    }
    private JSONObject parseLinkMessage(JSONObject linkObject) throws  JSONException{
        SubscribeMessage subscribeMessage =new SubscribeMessage();
        subscribeMessage.title = linkObject.optString("text");
        subscribeMessage.content = linkObject.optString("text");
        subscribeMessage.linkUrl =  linkObject.optString("url");
        subscribeMessage.imgUrl = "http://tiejp.com/static/uploads/items/1376/preview.jpg";
        Gson gson = new Gson();
        JSONObject data = new JSONObject(gson.toJson(subscribeMessage));
        return  data;
    }



//    {
//
//
//        "code": 308000,
//
//
//            "text": "亲，已帮您找到菜谱信息",
//
//
//            "list": [{
//
//
//        "name": "鱼香肉丝",
//
//
//                "icon": "http://i4.xiachufang.com/image/280/cb1cb7c49ee011e38844b8ca3aeed2d7.jpg",
//
//
//                "info": "猪肉、鱼香肉丝调料 | 香菇、木耳、红萝卜、黄酒、玉米淀粉、盐",
//
//
//                "detailurl": "http://m.xiachufang.com/recipe/264781/"
//
//
//    }]
//
//
//    }


    public static  boolean hasMoreItemsInfo(SubscribeMessage subscribeMessage){
        if (subscribeMessage!=null && subscribeMessage.subscribes!=null&& subscribeMessage.subscribes.size()>0){
            return true;
        }

        SubscribeMessage parseMsg = parseSubscribeMessageInfo(subscribeMessage);
        return parseMsg != null && parseMsg.subscribes != null && parseMsg.subscribes.size() > 0;
    }




   public static  SubscribeMessage parseSubscribeMessageInfo(SubscribeMessage subscribeMessage){
      try{

          JSONObject newsObject = new JSONObject(subscribeMessage.dataStr);
          subscribeMessage.title = newsObject.optString("title");
          subscribeMessage.content = newsObject.optString("content");
          subscribeMessage.imgUrl = newsObject.optString("imgUrl");
          subscribeMessage.linkUrl = newsObject.optString("linkUrl");
          JSONArray listArray = newsObject.optJSONArray("subscribes");
          subscribeMessage.subscribes = new ArrayList<>();
          for (int i = 0; i <listArray.length() ; i++) {
              JSONObject jsonObject= listArray.getJSONObject(i);
              SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
              subscribe.title = jsonObject.optString("title");
              subscribe.imgUrl = jsonObject.optString("imgUrl");
              subscribe.linkUrl = jsonObject.optString("linkUrl");
              subscribe.content = jsonObject.optString("content");
              subscribeMessage.subscribes.add(subscribe);
          }

      }catch (Exception e){
          e.printStackTrace();
      }

       return  subscribeMessage;
   }

    private JSONObject parseCookingMessage(JSONObject newsObject) throws  JSONException{
        SubscribeMessage subscribeMessage =new SubscribeMessage();
        subscribeMessage.title = newsObject.optString("text");
        subscribeMessage.content = newsObject.optString("text");
        subscribeMessage.imgUrl = "http://tiejp.com/static/uploads/items/1376/preview.jpg";
        JSONArray listArray = newsObject.optJSONArray("list");
        subscribeMessage.subscribes = new ArrayList<>();
        for (int i = 0; i <listArray.length() ; i++) {
            JSONObject jsonObject= listArray.getJSONObject(i);
            SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
            subscribe.title = jsonObject.optString("name");
            subscribe.imgUrl = jsonObject.optString("icon");
            subscribe.linkUrl = jsonObject.optString("detailurl");
            subscribe.content = jsonObject.optString("info");
            subscribeMessage.subscribes.add(subscribe);
            if (i==0){
                subscribeMessage.linkUrl = jsonObject.optString("detailurl");
            }
        }
        Gson gson = new Gson();
        JSONObject data = new JSONObject(gson.toJson(subscribeMessage));
        return data;
    }



    //    {
//
//
//        "code": 302000,
//
//
//            "text": "亲，已帮您找到相关新闻",
//
//
//            "list": [
//
//
//        {
//
//
//            "article": "工信部:今年将大幅提网速降手机流量费",
//
//
//                "source": "网易新闻",
//
//
//                "icon": "",
//
//
//                "detailurl": "http://news.163.com/15/0416/03/AN9SORGH0001124J.html"
//
//
//        },


    private JSONObject parseNewsMessage(JSONObject newsObject) throws  JSONException{

        SubscribeMessage subscribeMessage =new SubscribeMessage();
        subscribeMessage.title = newsObject.optString("text");
        subscribeMessage.content = newsObject.optString("text");
        subscribeMessage.imgUrl = "http://tiejp.com/static/uploads/items/1376/preview.jpg";
        JSONArray listArray = newsObject.optJSONArray("list");
        subscribeMessage.subscribes = new ArrayList<>();
        for (int i = 0; i <listArray.length() ; i++) {
           JSONObject jsonObject= listArray.getJSONObject(i);
            SubscribeMessage.Subscribe subscribe = new SubscribeMessage.Subscribe();
            subscribe.title = jsonObject.optString("source");
            subscribe.imgUrl = jsonObject.optString("icon");
            subscribe.linkUrl = jsonObject.optString("detailurl");
            subscribe.content = jsonObject.optString("article");
            subscribeMessage.subscribes.add(subscribe);
            if (i==0){
                subscribeMessage.linkUrl = jsonObject.optString("detailurl");
            }
        }
        Gson gson = new Gson();
        JSONObject data = new JSONObject(gson.toJson(subscribeMessage));
        return data;
    }

}
