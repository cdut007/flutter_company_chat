package com.ultralinked.uluc.enterprise.pay;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.paypal.android.sdk.payments.PayPalAuthorization;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalFuturePaymentActivity;
import com.paypal.android.sdk.payments.PayPalItem;
import com.paypal.android.sdk.payments.PayPalOAuthScopes;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalPaymentDetails;
import com.paypal.android.sdk.payments.PayPalProfileSharingActivity;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentConfirmation;
import com.paypal.android.sdk.payments.ShippingAddress;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.pay.alipay.Alipay;
import com.ultralinked.uluc.enterprise.pay.weixin.WXPay;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RxBus;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by mac on 16/10/27.
 */

public class PaymentActivity extends BaseActivity implements View.OnClickListener {

    public static final String PAYMENT_SUCCESS = "payment success";

    //    public static final int ALI_PAY = 1;
    public static final int WX_PAY = 2;
    public static final int PAY_PAL = 3;
    public static final int REWARD = 4;
    public static final int SEALCHAT_PAY = 5;

    public static final int CANCEL = -2;
    public static final int WAITING_CONFIRM = -3;
    public static final int UNCOMPLETED = 0;
    public static final int COMPLETED = 1;

    //Current payment method that user choose.
    private int currentPaymentMethod = WX_PAY;
    private int cancelledMethod = 0;
    private String payment_id;
    private ProductInfo mInfo;

    //    ImageView mAliPay;
    ImageView mWxPay;
    ImageView mPayPal;
    ImageView mSealChatPay;
    TextView mRechargeAmount, mDescription, mBalancePay, mCurrentRate;

    double balance;//user current amount balance

    private boolean isCanSealChatPay = false;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_payment;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Init PayPal service.
        Intent intent = new Intent(this, PayPalService.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);
        startService(intent);
    }


    private void getAccountBalanceAndSetBalancePay() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getAccountBalance()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "getAccountBalance success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, "getAccountBalance fail： " + eMsg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            JSONObject object = new JSONObject(response);
                            if (object.optInt("code") == 200) {
                                balance = object.optDouble("result");
                                if (Double.parseDouble(mInfo.getPrice()) > balance) {
                                    isCanSealChatPay = false;
                                    mBalancePay.setTextColor(getResources().getColor(R.color.color_c0c0c0));
                                    mSealChatPay.setImageResource(R.mipmap.not_choose);
                                    ((ImageView) bind(R.id.img_balance)).setImageResource(R.mipmap.not_sufficient_funds_icon);
                                } else {
                                    isCanSealChatPay = true;
                                    choosePaymentMethod(SEALCHAT_PAY);
                                }
                            } else {
                                Log.e(TAG, "errorcode:" + object.optInt("code"));
                            }
                        } catch (Exception ex) {
                            Log.e(TAG, android.util.Log.getStackTraceString(ex));
                        }
                    }
                });
    }

    @Override
    public void initView(Bundle savedInstanceState) {

//        mAliPay = bind(R.id.iv_aliPay);
        mWxPay = bind(R.id.iv_wxPay);
        mPayPal = bind(R.id.iv_payPal);
        mSealChatPay = bind(R.id.iv_sealChatPay);
        mRechargeAmount = bind(R.id.txt_recharge_amount);
        mDescription = bind(R.id.txt_payment_description);
        mBalancePay = bind(R.id.txt_balance_pay);
        mCurrentRate = bind(R.id.txt_current_rate);
        //R.id.relative_aliPay
        initListener(this, R.id.left_back, R.id.relative_balancePay, R.id.relative_wxPay, R.id.relative_payPal, R.id.btn_pay_confirm);

        Intent extra = getIntent();
        mInfo = (ProductInfo) extra.getSerializableExtra("product");
        mRechargeAmount.setText(String.format(getString(R.string.recharge_amount), mInfo.getPrice()));

        if (mInfo.getProduct_type().equals("phone_no")) {
            mDescription.setText(R.string.purchase_exclusive_number);
            getAccountBalanceAndSetBalancePay();
        } else if (mInfo.getProduct_type().equals("renew")) {
            mDescription.setText(R.string.renew_exclusive_number);
            getAccountBalanceAndSetBalancePay();
        } else {
            goneView(bind(R.id.relative_balancePay));
        }

        getNetworkInfo();
    }

    void getNetworkInfo() {
        showDialog(getString(R.string.loading));
        ApiManager.getInstance().getCurrencyRate()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "getNetworkInfo success");
                        closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, "getNetworkInfo fail: " + HttpErrorException.handErrorMessage(e));
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            JSONObject object = new JSONObject(response);
                            if (object.has("code") && object.getInt("code") == 200) {
                                JSONObject result = object.optJSONObject("result");
                                String rate = result.optString("CNY");
                                if (!TextUtils.isEmpty(rate))
                                    mCurrentRate.setText(String.format(getString(R.string.dollar_exchange_rate), rate));
                            }
                        } catch (Exception ex) {
                            Log.e(TAG, android.util.Log.getStackTraceString(ex));
                        }

                    }
                });
    }

    @Override
    protected void setTopBar() {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.pay);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (!TextUtils.isEmpty(payment_id) && cancelledMethod != 0) {
            showToast(R.string.payment_cancelled);
            submitPaymentStatus(cancelledMethod + "", CANCEL + "");
        }
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                onBackPressed();
                break;
//            case R.id.relative_aliPay:
//                choosePaymentMethod(ALI_PAY);
//                break;
            case R.id.relative_payPal:
                choosePaymentMethod(PAY_PAL);
                break;
            case R.id.relative_wxPay:
                choosePaymentMethod(WX_PAY);
                break;
            case R.id.relative_balancePay:
                if (isCanSealChatPay) {
                    choosePaymentMethod(SEALCHAT_PAY);
                } else {
                    showToast(R.string.balance_not_enough);
                }
                break;
            case R.id.btn_pay_confirm:
                pay();
                break;
        }
    }


    private void doSealChatPay() {


        DialogManager.showBalancePayDialog(getActivity(), mInfo.getPrice(), new DialogManager.OnDialogListener() {

            @Override
            public void onCancelClick(View v) {
                cancelledMethod = SEALCHAT_PAY;
            }

            @Override
            public void onOkClick(View v, CharSequence[] items, Dialog dialog) {
                requestSealChatPayToServer(items[0].toString());
                dialog.dismiss();
            }
        });
    }

    private void requestSealChatPayToServer(String password) {

        if (TextUtils.isEmpty(password)) {
            showToast(getString(R.string.check_password));
            cancelledMethod = SEALCHAT_PAY;
            return;
        }

        if (!NetUtil.isNetworkAvailable(this)) {
            showToast(getString(R.string.check_network));
            cancelledMethod = SEALCHAT_PAY;
            return;
        }

        showDialog(getString(R.string.loading));


        ApiManager.getInstance().requestSealedChatPay(password, payment_id)
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "requestSealChatPayToServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        closeDialog();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        showToast(" " + eMsg);

                        cancelledMethod = SEALCHAT_PAY;
                        Log.e(TAG, "requestSealChatPayToServer  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        closeDialog();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                cancelledMethod = 0;
                                showToast(R.string.payment_success);
                                sendRechargeSuccessMessage();
                            } else {
                                showToast("errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                                cancelledMethod = SEALCHAT_PAY;
                                Log.i(TAG, "requestSealChatPayToServer error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                            }


                        } catch (JsonSyntaxException e) {
                            cancelledMethod = SEALCHAT_PAY;
                            showToast(R.string.payment_failed);
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            cancelledMethod = SEALCHAT_PAY;
                            showToast(R.string.payment_failed);
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            cancelledMethod = SEALCHAT_PAY;
                            showToast(R.string.payment_failed);
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        Log.i(TAG, "get requestSealChatPayToServer:  " + rs);
                    }         //请求成功

                });
    }


    private void pay() {

        showDialog(getString(R.string.loading));
        Map<String, String> map = new HashMap<>();
        String product_id = mInfo.getProduct_id();
        map.put("product_id", product_id);
        if (product_id.equals("custom")) {
            map.put("price", mInfo.getPrice());
        }
        map.put("product_type", mInfo.getProduct_type());
        map.put("quantity", mInfo.getQuantity());
        map.put("payment_providerid", currentPaymentMethod + "");

        if (!TextUtils.isEmpty(payment_id)) {

            map.put("payment_id", payment_id);
            ApiManager.getInstance().changePaymentProviderSignedData(map)
                    .compose(this.<ResponseBody>bindToLifecycle())
                    .throttleFirst(3, TimeUnit.SECONDS)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<ResponseBody>() {
                        @Override
                        public void onCompleted() {
                            closeDialog();
                        }

                        @Override
                        public void onError(Throwable e) {
                            String eMsg = HttpErrorException.handErrorMessage(e);
                            showToast("" + eMsg);
                            closeDialog();
                        }

                        @Override
                        public void onNext(ResponseBody responseBody) {
                            parseCreateOrderPayResponse(responseBody);
                        }
                    });

        } else {
            ApiManager.getInstance().getPaymentSignedData(map)
                    .compose(this.<ResponseBody>bindToLifecycle())
                    .throttleFirst(3, TimeUnit.SECONDS)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<ResponseBody>() {
                        @Override
                        public void onCompleted() {
                            closeDialog();
                        }

                        @Override
                        public void onError(Throwable e) {
                            String eMsg = HttpErrorException.handErrorMessage(e);
                            showToast("" + eMsg);
                            closeDialog();
                        }

                        @Override
                        public void onNext(ResponseBody responseBody) {
                            parseCreateOrderPayResponse(responseBody);
                        }
                    });
        }


    }

    private void parseCreateOrderPayResponse(ResponseBody responseBody) {
        try {
            String response = responseBody.string();
            Map<String, Object> map = new Gson().fromJson(response, new TypeToken<Map<String, Object>>() {
            }.getType());
            switch (currentPaymentMethod) {
//                                case ALI_PAY:
//                                payment_id = (String) map.get("payment_id");
//                                    doAlipay((String) map.get("pay_reqinfo"));
//                                    break;
                case WX_PAY:
                    payment_id = (String) map.get("payment_id");
                    String wxParams = null;
                    try {
                        wxParams = new JSONObject(response).getJSONObject("pay_reqinfo").toString();
                        Log.e(TAG, wxParams);
                        doWXPay(wxParams);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case PAY_PAL:
                    payment_id = (String) map.get("payment_id");
                    doPayPal();
                    break;


                case SEALCHAT_PAY:
                    payment_id = (String) map.get("payment_id");
                    doSealChatPay();
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, android.util.Log.getStackTraceString(e));
        }
    }

    private void sendRechargeSuccessMessage() {
        RxBus.getDefault().post(PAYMENT_SUCCESS);
        startActivity(new Intent(this, MyAccountActivity.class));
    }

    @Override
    protected void onDestroy() {
        // Stop PayPal service when done
        stopService(new Intent(this, PayPalService.class));
        super.onDestroy();
    }

    private void choosePaymentMethod(int method) {
        switch (method) {
//            case ALI_PAY:
//                mAliPay.setImageResource(R.mipmap.choose_click);
//                mWxPay.setImageResource(R.mipmap.choose);
//                mPayPal.setImageResource(R.mipmap.choose);
//            if(isCanSealChatPay) {
//                mSealChatPay.setImageResource(R.mipmap.choose);
//            }else{
//                mSealChatPay.setImageResource(R.mipmap.not_choose);
//            }
//                currentPaymentMethod = ALI_PAY;
//                break;
            case WX_PAY:
                mWxPay.setImageResource(R.mipmap.choose_click);
                mPayPal.setImageResource(R.mipmap.choose);
                if(isCanSealChatPay) {
                    mSealChatPay.setImageResource(R.mipmap.choose);
                }else{
                    mSealChatPay.setImageResource(R.mipmap.not_choose);
                }
//                mAliPay.setImageResource(R.mipmap.choose);
                currentPaymentMethod = WX_PAY;
                break;
            case PAY_PAL:
                mPayPal.setImageResource(R.mipmap.choose_click);
//                mAliPay.setImageResource(R.mipmap.choose);
                mWxPay.setImageResource(R.mipmap.choose);
                if(isCanSealChatPay) {
                    mSealChatPay.setImageResource(R.mipmap.choose);
                }else{
                    mSealChatPay.setImageResource(R.mipmap.not_choose);
                }
                currentPaymentMethod = PAY_PAL;
                break;
            case SEALCHAT_PAY: {
                mWxPay.setImageResource(R.mipmap.choose);
                mPayPal.setImageResource(R.mipmap.choose);
//                mAliPay.setImageResource(R.mipmap.choose);
                mSealChatPay.setImageResource(R.mipmap.choose_click);
                currentPaymentMethod = SEALCHAT_PAY;
            }
            break;
        }
    }

    private void submitPayPalId(String payPalId) {
        showDialog(getString(R.string.loading));
        Map<String, String> map = new HashMap<>();
        map.put("paypal_id", payPalId);
        ApiManager.getInstance().submitPayPalId(payment_id, map)
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "submit PayPal id successfully");
                        closeDialog();
                        sendRechargeSuccessMessage();
                    }

                    @Override
                    public void onError(Throwable e) {
                        String msg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, msg);
                        closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                    }
                });
    }

    private void submitPaymentStatus(String payment_providerid, String payment_status) {
        Map<String, String> map = new HashMap<>();
        map.put("payment_id", payment_id);
        map.put("payment_providerid", payment_providerid);
        map.put("payment_status", payment_status);
        ApiManager.getInstance().submitPaymentStatus(map)
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "Submit payment status id successfully");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String msg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, msg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            String response = responseBody.string();
                            Log.i(TAG, response);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }

    /**
     * 支付宝支付
     *
     * @param pay_param 支付服务生成的支付参数
     */
    private void doAlipay(String pay_param) {
        new Alipay(this, pay_param, new Alipay.AlipayResultCallBack() {
            @Override
            public void onSuccess() {
                cancelledMethod = 0;
                showToast(R.string.payment_success);
                submitPaymentStatus(payment_id, WAITING_CONFIRM + "");
                sendRechargeSuccessMessage();
            }

            @Override
            public void onDealing() {
                showToast(R.string.loading);
            }

            @Override
            public void onError(int error_code) {
                switch (error_code) {
                    case Alipay.ERROR_RESULT:
                        showToast(R.string.payment_failed);
                        break;

                    case Alipay.ERROR_NETWORK:
                        showToast(getString(R.string.check_network));
                        break;

                    case Alipay.ERROR_PAY:
                        showToast(R.string.payment_failed);
                        break;

                    default:
                        showToast(R.string.payment_failed);
                        break;
                }

            }

            @Override
            public void onCancel() {
//                cancelledMethod = ALI_PAY;
            }
        }).doPay();
    }

    /**
     * 微信支付
     *
     * @param pay_param 支付服务生成的支付参数
     */
    private void doWXPay(String pay_param) {
        //wxd2dda8db651af40c //old version
        String wx_appid = "wxa03328ec130df79f";     //替换为自己的appid
        WXPay.init(getApplicationContext(), wx_appid);      //要在支付前调用
        WXPay.getInstance().doPay(pay_param, new WXPay.WXPayResultCallBack() {
            @Override
            public void onSuccess() {
                cancelledMethod = 0;
                showToast(R.string.payment_success);
                submitPaymentStatus(payment_id, WAITING_CONFIRM + "");
                sendRechargeSuccessMessage();
            }

            @Override
            public void onError(int error_code) {
                switch (error_code) {
                    case WXPay.NO_OR_LOW_WX:
                        showToast(R.string.no_wx_prompt);
                        break;

                    case WXPay.ERROR_PAY_PARAM:
                        showToast(R.string.payment_failed);
                        break;

                    case WXPay.ERROR_PAY:
                        showToast(R.string.payment_failed);
                        break;
                }
            }

            @Override
            public void onCancel() {
                cancelledMethod = WX_PAY;
            }
        });
    }


    /**
     * - Set to PayPalConfiguration.ENVIRONMENT_PRODUCTION to move real money.
     * <p>
     * - Set to PayPalConfiguration.ENVIRONMENT_SANDBOX to use your test credentials
     * from https://developer.paypal.com
     * <p>
     * - Set to PayPalConfiguration.ENVIRONMENT_NO_NETWORK to kick the tires
     * without communicating to PayPal's servers.
     */
//    private static final String PAYPAL_CONFIG_ENVIRONMENT = PayPalConfiguration.ENVIRONMENT_SANDBOX;
    private static final String PAYPAL_CONFIG_ENVIRONMENT = PayPalConfiguration.ENVIRONMENT_PRODUCTION;

    // note that these credentials will differ between live & sandbox environments.
//    private static final String PAYPAL_CONFIG_CLIENT_ID = "AZnIYLqcSQrijWT63yeSMqXZyNkq1wT68F2rUJ-AN1hgU6oZk7tWb3pM1Iqsl2aV42sSI5XUFe12HwhB"; //sandbox
    private static final String PAYPAL_CONFIG_CLIENT_ID = "ASKP18S4_d45b2Mlk0wtm27hrplrSfqrjyBoA55QLS7poMhtAcOtmq-SxEdEDpzkrYgGwpyCqUV6rSXu";   //production


    private static final int PAYPAL_REQUEST_CODE_PAYMENT = 1;
    private static final int PAYPAL_REQUEST_CODE_FUTURE_PAYMENT = 2;
    private static final int PAYPAL_REQUEST_CODE_PROFILE_SHARING = 3;

    private static PayPalConfiguration config = new PayPalConfiguration()
            .environment(PAYPAL_CONFIG_ENVIRONMENT)
            .clientId(PAYPAL_CONFIG_CLIENT_ID)
            // The following are only used in PayPalFuturePaymentActivity.
            .merchantName("Sealchat Merchant")
            .merchantPrivacyPolicyUri(Uri.parse("https://www.example.com/privacy"))
            .merchantUserAgreementUri(Uri.parse("https://www.example.com/legal"));


    public void doPayPal() {
        /*
         * PAYMENT_INTENT_SALE will cause the payment to complete immediately.
         * Change PAYMENT_INTENT_SALE to
         *   - PAYMENT_INTENT_AUTHORIZE to only authorize payment and capture funds later.
         *   - PAYMENT_INTENT_ORDER to create a payment for authorization and capture
         *     later via calls from your server.
         *
         * Also, to include additional payment details and an item list, see getStuffToBuy() below.
         */
        PayPalPayment thingToBuy = paypalGetThingToBuy(PayPalPayment.PAYMENT_INTENT_SALE);

        /*
         * See getStuffToBuy(..) for examples of some available payment options.
         */

        Intent intent = new Intent(this, com.paypal.android.sdk.payments.PaymentActivity.class);

        // send the same configuration for restart resiliency
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);

        intent.putExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_PAYMENT, thingToBuy);

        startActivityForResult(intent, PAYPAL_REQUEST_CODE_PAYMENT);
    }

    private PayPalPayment paypalGetThingToBuy(String paymentIntent) {
        PayPalPayment payPalPayment = new PayPalPayment(new BigDecimal(mInfo.getPrice()), "USD", mDescription.getText().toString(), paymentIntent);
        payPalPayment.custom(payment_id);
        return payPalPayment;
    }

    /*
     * This method shows use of optional payment details and item list.
     */
    private PayPalPayment paypayGetStuffToBuy(String paymentIntent) {
        //--- include an item list, payment amount details
        PayPalItem[] items =
                {
                        new PayPalItem("sample item #1", 2, new BigDecimal("87.50"), "USD",
                                "sku-12345678"),
                        new PayPalItem("free sample item #2", 1, new BigDecimal("0.00"),
                                "USD", "sku-zero-price"),
                        new PayPalItem("sample item #3 with a longer name", 6, new BigDecimal("37.99"),
                                "USD", "sku-33333")
                };
        BigDecimal subtotal = PayPalItem.getItemTotal(items);
        BigDecimal shipping = new BigDecimal("7.21");
        BigDecimal tax = new BigDecimal("4.67");
        PayPalPaymentDetails paymentDetails = new PayPalPaymentDetails(shipping, subtotal, tax);
        BigDecimal amount = subtotal.add(shipping).add(tax);
        PayPalPayment payment = new PayPalPayment(amount, "USD", "sample item", paymentIntent);
        payment.items(items).paymentDetails(paymentDetails);

        //--- set other optional fields like invoice_number, custom field, and soft_descriptor
        payment.custom("This is text that will be associated with the payment that the app can use.");

        return payment;
    }

    /*
     * Add app-provided shipping address to payment
     */
    private void paypalAddAppProvidedShippingAddress(PayPalPayment paypalPayment) {
        ShippingAddress shippingAddress =
                new ShippingAddress().recipientName("Mom Parker").line1("52 North Main St.")
                        .city("Austin").state("TX").postalCode("78729").countryCode("US");
        paypalPayment.providedShippingAddress(shippingAddress);
    }

    /*
     * Enable retrieval of shipping addresses from buyer's PayPal account
     */
    private void paypalEnableShippingAddressRetrieval(PayPalPayment paypalPayment, boolean enable) {
        paypalPayment.enablePayPalShippingAddressesRetrieval(enable);
    }

    public void paypalOnFuturePaymentPressed(View pressed) {
        Intent intent = new Intent(this, PayPalFuturePaymentActivity.class);

        // send the same configuration for restart resiliency
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);

        startActivityForResult(intent, PAYPAL_REQUEST_CODE_FUTURE_PAYMENT);
    }

    public void paypalOnProfileSharingPressed(View pressed) {
        Intent intent = new Intent(this, PayPalProfileSharingActivity.class);

        // send the same configuration for restart resiliency
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);

        intent.putExtra(PayPalProfileSharingActivity.EXTRA_REQUESTED_SCOPES, paypalGetOauthScopes());

        startActivityForResult(intent, PAYPAL_REQUEST_CODE_PROFILE_SHARING);
    }

    private PayPalOAuthScopes paypalGetOauthScopes() {
        /* create the set of required scopes
         * Note: see https://developer.paypal.com/docs/integration/direct/identity/attributes/ for mapping between the
         * attributes you select for this app in the PayPal developer portal and the scopes required here.
         */
        Set<String> scopes = new HashSet<String>(
                Arrays.asList(PayPalOAuthScopes.PAYPAL_SCOPE_EMAIL, PayPalOAuthScopes.PAYPAL_SCOPE_ADDRESS));
        return new PayPalOAuthScopes(scopes);
    }

    protected void paypalDisplayResultText(String result) {

        Toast.makeText(
                getApplicationContext(),
                result, Toast.LENGTH_LONG)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PAYPAL_REQUEST_CODE_PAYMENT) {
            if (resultCode == Activity.RESULT_OK) {
                PaymentConfirmation confirm =
                        data.getParcelableExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_RESULT_CONFIRMATION);
                if (confirm != null) {
                    try {
                        Log.e(TAG, confirm.toJSONObject().getJSONObject("response").getString("id"));
                        Log.e(TAG, confirm.toJSONObject().toString(4));
                        Log.e(TAG, confirm.getPayment().toJSONObject().toString(4));
                        Log.e(TAG, confirm.getProofOfPayment().toJSONObject().toString(4));
                        showToast(R.string.payment_success);
                        cancelledMethod = 0;
                        submitPayPalId(confirm.getProofOfPayment().getPaymentId());
                        /**
                         *  TODO: send 'confirm' (and possibly confirm.getPayment() to your server for verification
                         * or consent completion.
                         * See https://developer.paypal.com/webapps/developer/docs/integration/mobile/verify-mobile-payment/
                         * for more details.
                         *
                         * For sample mobile backend interactions, see
                         * https://github.com/paypal/rest-api-sdk-python/tree/master/samples/mobile_backend
                         */
//                        paypalDisplayResultText("PaymentConfirmation info received from PayPal");


                    } catch (JSONException e) {
                        Log.e(TAG, "an extremely unlikely failure occurred: " + android.util.Log.getStackTraceString(e));
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.e(TAG, "The user canceled.");
                cancelledMethod = PAY_PAL;
            } else if (resultCode == com.paypal.android.sdk.payments.PaymentActivity.RESULT_EXTRAS_INVALID) {
                Log.e(
                        TAG,
                        "An invalid Payment or PayPalConfiguration was submitted. Please see the docs.");
            }
        } else if (requestCode == PAYPAL_REQUEST_CODE_FUTURE_PAYMENT) {
            if (resultCode == Activity.RESULT_OK) {
                PayPalAuthorization auth =
                        data.getParcelableExtra(PayPalFuturePaymentActivity.EXTRA_RESULT_AUTHORIZATION);
                if (auth != null) {
                    try {
                        Log.i("FuturePaymentExample", auth.toJSONObject().toString(4));

                        String authorization_code = auth.getAuthorizationCode();
                        Log.i("FuturePaymentExample", authorization_code);

                        paypalSendAuthorizationToServer(auth);
                        paypalDisplayResultText("Future Payment code received from PayPal");

                    } catch (JSONException e) {
                        Log.e("FuturePaymentExample", "an extremely unlikely failure occurred: " + android.util.Log.getStackTraceString(e));
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.i("FuturePaymentExample", "The user canceled.");
            } else if (resultCode == PayPalFuturePaymentActivity.RESULT_EXTRAS_INVALID) {
                Log.i(
                        "FuturePaymentExample",
                        "Probably the attempt to previously start the PayPalService had an invalid PayPalConfiguration. Please see the docs.");
            }
        } else if (requestCode == PAYPAL_REQUEST_CODE_PROFILE_SHARING) {
            if (resultCode == Activity.RESULT_OK) {
                PayPalAuthorization auth =
                        data.getParcelableExtra(PayPalProfileSharingActivity.EXTRA_RESULT_AUTHORIZATION);
                if (auth != null) {
                    try {
                        Log.i("ProfileSharingExample", auth.toJSONObject().toString(4));

                        String authorization_code = auth.getAuthorizationCode();
                        Log.i("ProfileSharingExample", authorization_code);

                        paypalSendAuthorizationToServer(auth);
                        paypalDisplayResultText("Profile Sharing code received from PayPal");

                    } catch (JSONException e) {
                        Log.e("ProfileSharingExample", "an extremely unlikely failure occurred: " + android.util.Log.getStackTraceString(e));
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.i("ProfileSharingExample", "The user canceled.");
            } else if (resultCode == PayPalFuturePaymentActivity.RESULT_EXTRAS_INVALID) {
                Log.i(
                        "ProfileSharingExample",
                        "Probably the attempt to previously start the PayPalService had an invalid PayPalConfiguration. Please see the docs.");
            }
        }
    }

    private void paypalSendAuthorizationToServer(PayPalAuthorization authorization) {

        /**
         * TODO: Send the authorization response to your server, where it can
         * exchange the authorization code for OAuth access and refresh tokens.
         *
         * Your server must then store these tokens, so that your server code
         * can execute payments for this user in the future.
         *
         * A more complete example that includes the required app-server to
         * PayPal-server integration is available from
         * https://github.com/paypal/rest-api-sdk-python/tree/master/samples/mobile_backend
         */

    }

    public void paypalOnFuturePaymentPurchasePressed(View pressed) {
        // Get the Client Metadata ID from the SDK
        String metadataId = PayPalConfiguration.getClientMetadataId(this);

        Log.i("FuturePaymentExample", "Client Metadata ID: " + metadataId);

        // TODO: Send metadataId and transaction details to your server for processing with
        // PayPal...
        paypalDisplayResultText("Client Metadata Id received from SDK");
    }


}
