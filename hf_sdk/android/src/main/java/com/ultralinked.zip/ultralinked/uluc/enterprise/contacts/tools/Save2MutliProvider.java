package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.ContentValues;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.contacts.contract.BasePeopleColumns;
import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailHelper;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.google.gson.JsonSyntaxException;
import com.ultralinked.uluc.enterprise.contacts.contract.StrangerContract;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by ultralinked on 16/7/1.
 */
public class Save2MutliProvider {

    private static final String TAG = "Save2";

    private static ExecutorService exec = Executors.newCachedThreadPool();

    /**
     * save  personnel table and relation table
     *
     * @param string
     * @throws JSONException
     */
    public static void save_Personnel_Relation(final String string) throws JsonSyntaxException, JSONException {

        final RawPerson rawPerson = GsonUtil.fromJson(string, RawPerson.class);

        Log.i(TAG, "save_Personnel_Relation result.body start --> " + rawPerson.code);

        Callable callable = new Callable<String>() {
            @Override
            public String call() {

                ArrayList<ContentValues> valueslist_personnel = new ArrayList<>();

                ArrayList<ContentValues> valueslist_relation = new ArrayList<>();

                for (RawPerson.ResultBean resultBean : rawPerson.result) {
                    // String companyname ="222";
                    DepartUtils.CompanyElement element = null;

                    if (!TextUtils.isEmpty(resultBean.company)) {
                        element = DepartUtils.getInstance().getFromSearchCache(resultBean.company);
                    }

                    String companyname = "34";

                    if (element != null) {
                        companyname = element.name;
                    }


                    Log.i(TAG, "searchbyId --> " + companyname);

                    for (PeopleEntity item : resultBean.data) {

                        ContentValues value = DbSQLHelper.assignValues(item);

                        valueslist_personnel.add(value);

                        ContentValues value2 = new ContentValues();
                        value2.put(RelationContract.RelationColumn.USER_ID, "" + item.subuser_id);
                        value2.put(RelationContract.RelationColumn.DEPART_ID, "" + resultBean.department_id);
                        value2.put(RelationContract.RelationColumn.DEPARTMENT_TYPE, "" + resultBean.type);
                        value2.put(RelationContract.RelationColumn.COMPANY_ID, "" + resultBean.company);

                        value2.put(RelationContract.RelationColumn.DEPARTMENT_NAME, "" + resultBean.name);

                        value2.put(RelationContract.RelationColumn.COMPANY_NAME, companyname);
                        valueslist_relation.add(value2);

                    }

                }
                Log.i(TAG, "size1  " + valueslist_personnel.size());
                Log.i(TAG, "size2 " + valueslist_relation.size());
                if (valueslist_personnel.size() > 0) {

                    bulkInsert_PERSON(valueslist_personnel);
                }else {
                    if (rawPerson.code == 200){
                        Log.i(TAG, "bulkInsert_PERSON empty size ");
                        bulkInsert_PERSON(valueslist_personnel);
                    }
                }

                if (valueslist_relation.size() > 0) {
                    update_relation(valueslist_relation);
                }else{
                    if (rawPerson.code == 200){
                        Log.i(TAG, "update_relation empty size ");
                        update_relation(valueslist_personnel);
                    }
                }


                return null;
            }
        };

        exec.submit(callable);
    }

    private static int bulkInsert_PERSON(ArrayList<ContentValues> valueslist) {

        return App.getInstance().getContentResolver().bulkInsert(PersonnelContract.CONTENT_URI, valueslist.toArray(new ContentValues[valueslist.size()]));
    }


    private static int update_relation(ArrayList<ContentValues> valueslist) {

        return App.getInstance().getContentResolver().bulkInsert(RelationContract.CONTENT_URI, valueslist.toArray(new ContentValues[valueslist.size()]));
    }

    /**
     * save  personnel table and relation table
     *
     * @param string
     * @throws JSONException
     */
    public static void save_PRIVATE(final String string) throws JSONException {

        final RawPrivatePerson rawPrivatePerson = GsonUtil.fromJson(string, RawPrivatePerson.class);

        Log.i(TAG, "save_PRIVATE result.body start --> " + rawPrivatePerson.code);

        Callable callable = new Callable<String>() {
            @Override
            public String call() {

                ArrayList<ContentValues> valueslist_private = new ArrayList<>();

                for (PeopleEntity item : rawPrivatePerson.result) {

                    ContentValues value = DbSQLHelper.assignValues(item);
                    value.put(BasePeopleColumns.SUBUSER_ID, "" + item.user_id);//bug for private.
                    valueslist_private.add(value);
                }


                Log.i(TAG, "size3  " + valueslist_private.size());

                if (valueslist_private.size() > 0) {

                    bulkInsert_PRIVATE(valueslist_private);
                }else{
                    if (rawPrivatePerson.code == 200){
                        Log.i(TAG, "bulkInsert_PRIVATE empty size ");
                        bulkInsert_PRIVATE(valueslist_private);
                    }
                }

                return null;
            }
        };

        exec.submit(callable);
    }



    /**
     * save  stranger table
     *
     * @throws JSONException
     */
    public static void save_Stranger(final List<PeopleEntity> strangers) throws JSONException {

        Log.i(TAG, "save_Stranger result.body start --> ");

        Callable callable = new Callable<String>() {
            @Override
            public String call() {

                ArrayList<ContentValues> valueslist_stranger = new ArrayList<>();

                for (PeopleEntity item : strangers) {

                    ContentValues value = new ContentValues();

                    value.put(StrangerContract.StrangerColumn.SUBUSER_ID, "" + item.subuser_id);
                    value.put(StrangerContract.StrangerColumn.MOBILE, "" + item.mobile);
                    value.put(StrangerContract.StrangerColumn.ENABLE, "" + item.enable);
                    value.put(StrangerContract.StrangerColumn.NAME, "" + item.name);
                    value.put(StrangerContract.StrangerColumn.ACTIVE, "" + item.active);
                    value.put(StrangerContract.StrangerColumn.ICON, "" + item.icon_url);
                    value.put(StrangerContract.StrangerColumn.NICKNAME, "" + item.nickname);
                    value.put(StrangerContract.StrangerColumn.DOMAIN_ID, "" + item.domain_id);
                    value.put(StrangerContract.StrangerColumn.EMAIL, "" + item.email);
                    value.put(StrangerContract.StrangerColumn.PINYIN, "" + item.name);

                    value.put(StrangerContract.StrangerColumn.CREATE_DATE, "" + item.created_at);
                    value.put(StrangerContract.StrangerColumn.DELETE_DATE, "" + item.deleted_at);
                    value.put(StrangerContract.StrangerColumn.LAST_UPDATE, "" + item.updated_at);
                    value.put(StrangerContract.StrangerColumn.LAST_UPDATE_RELATION, "");

                    valueslist_stranger.add(value);
                }


                Log.i(TAG, "size friends: " + valueslist_stranger.size());

                if (valueslist_stranger.size() > 0) {

                    bulkInsert_Stranger(valueslist_stranger);
                }else{

                }

                return null;
            }
        };

        exec.submit(callable);
    }

    private static int bulkInsert_Stranger(ArrayList<ContentValues> valueslist_stranger) {

        return App.getInstance().getContentResolver().bulkInsert(StrangerContract.CONTENT_URI, valueslist_stranger.toArray(new ContentValues[valueslist_stranger.size()]));

    }



    /**
     * save  friend table
     *
     * @param string
     * @throws JSONException
     */
    public static void save_FRIEND(final String string) throws Exception {

        final RawFriendPerson rawFriendPerson = GsonUtil.fromJson(string, RawFriendPerson.class);

        Log.i(TAG, "save_FRIEND result.body start --> " + rawFriendPerson.code);

        Callable callable = new Callable<String>() {
            @Override
            public String call() {

                ArrayList<ContentValues> valueslist_friend = new ArrayList<>();

                for (PeopleEntity item : rawFriendPerson.result) {

                    ContentValues value = DbSQLHelper.assignValues(item);

                    valueslist_friend.add(value);
                }


                Log.i(TAG, "size friends: " + valueslist_friend.size());

                if (valueslist_friend.size() > 0) {

                    bulkInsert_FRIEND(valueslist_friend);
                }else{
                    if (rawFriendPerson.code == 200){
                        Log.i(TAG, "bulkInsert_FRIEND empty size ");
                        bulkInsert_FRIEND(valueslist_friend);
                    }
                }

                return null;
            }
        };

        exec.submit(callable);
    }

    private static int bulkInsert_FRIEND(ArrayList<ContentValues> valueslist_friend) {

        return App.getInstance().getContentResolver().bulkInsert(FriendContract.CONTENT_URI, valueslist_friend.toArray(new ContentValues[valueslist_friend.size()]));

    }


    private static int bulkInsert_PRIVATE(ArrayList<ContentValues> valueslist_private) {

        return App.getInstance().getContentResolver().bulkInsert(PrivateContract.CONTENT_URI, valueslist_private.toArray(new ContentValues[valueslist_private.size()]));

    }
}
