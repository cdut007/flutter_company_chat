package com.ultralinked.uluc.enterprise.moments.mvp.presenter;

import android.view.View;


import com.google.gson.JsonSyntaxException;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.moments.bean.CircleItem;
import com.ultralinked.uluc.enterprise.moments.bean.CommentConfig;
import com.ultralinked.uluc.enterprise.moments.bean.CommentItem;
import com.ultralinked.uluc.enterprise.moments.bean.FavortItem;
import com.ultralinked.uluc.enterprise.moments.listener.IDataRequestListener;
import com.ultralinked.uluc.enterprise.moments.mvp.contract.CircleContract;
import com.ultralinked.uluc.enterprise.moments.mvp.modle.CircleModel;
import com.ultralinked.uluc.enterprise.moments.utils.DatasUtil;
import com.ultralinked.uluc.enterprise.moments.utils.MomentUrlParseManager;
import com.ultralinked.uluc.enterprise.utils.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * @author yiw
 * @ClassName: CirclePresenter
 * @Description: 通知model请求服务器和通知view更新
 * @date 2015-12-28 下午4:06:03
 */
public class CirclePresenter implements CircleContract.Presenter {
    private CircleModel circleModel;
    private CircleContract.View view;
    private static final String TAG = "SNSPresenter";


    public CirclePresenter(CircleContract.View view) {
        circleModel = new CircleModel();
        this.view = view;
    }




    public void loadData(final String pageIndex,final int loadType) {
//
//        DatasUtil.requestMomentUrl(0, new MomentUrlParseManager.IFetchMomentLister() {
//            @Override
//            public void momentListResult(int pageNum, List<CircleItem> fetchMomentList) {
//                if (view != null) {
//                    view.update2loadData(loadType, fetchMomentList);
//                }
//            }
//        });


        ApiManager.getInstance().queryMoments("10", pageIndex)
                .subscribeOn(Schedulers.io())        //子线程

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryMomentsComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        if (view != null) {
                            view.update2loadData(pageIndex,loadType, new ArrayList<CircleItem>());
                        }

                        Log.e(TAG, "queryMoments  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                JSONArray result = object.optJSONArray("result");
                                List<CircleItem> datas = DatasUtil.createCircleDatas(result);
                                if (view != null) {
                                    view.update2loadData(pageIndex,loadType, datas);
                                }
                            } else {
                                Log.i(TAG, "queryMoments error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));


                            }


                        } catch (JsonSyntaxException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        Log.i(TAG, "get queryMoments:  " + rs);
                    }         //请求成功

                });


//        List<CircleItem> datas = DatasUtil.createCircleDatas();
//        if(view!=null){
//            view.update2loadData(loadType, datas);
//        }
    }


    /**
     * @param circleId
     * @return void    返回类型
     * @throws
     * @Title: deleteCircle
     * @Description: 删除动态
     */
    public void deleteCircle(final String circleId) {
        circleModel.deleteCircle(new IDataRequestListener() {

            @Override
            public void loadSuccess(Object object) {
                if (view != null) {
                    view.update2DeleteCircle(circleId);
                }
            }
        });
    }


    public  void chooseImageBackgroud(){

                if (view!=null){
                    view.chooseImageBackgroud();
                }

    }

    /**
     * @param circlePosition
     * @return void    返回类型
     * @throws
     * @Title: addFavort
     * @Description: 点赞
     */
    public void addFavort(final int circlePosition,final CircleItem circleItem) {
        circleModel.addFavort(new IDataRequestListener() {

            @Override
            public void loadSuccess(Object object) {
                if (view != null) {
                    view.update2AddFavorite(circlePosition, circleItem);
                }

            }
        });
    }

    /**
     * @param @param circlePosition
     * @param @param favortId
     * @return void    返回类型
     * @throws
     * @Title: deleteFavort
     * @Description: 取消点赞
     */
    public void deleteFavort(final int circlePosition, final String favortId) {
        circleModel.deleteFavort(new IDataRequestListener() {

            @Override
            public void loadSuccess(Object object) {
                if (view != null) {
                    view.update2DeleteFavort(circlePosition, favortId);
                }
            }
        });
    }

    /**
     * @param content
     * @param config  CommentConfig
     * @return void    返回类型
     * @throws
     * @Title: addComment
     * @Description: 增加评论
     */
    public void addComment(final String content, final CommentConfig config) {
        if (config == null) {
            return;
        }
        circleModel.addComment(new IDataRequestListener() {

            @Override
            public void loadSuccess(Object object) {
                CommentItem newItem = null;
                if (config.commentType == CommentConfig.Type.PUBLIC) {
                    newItem = DatasUtil.createPublicComment(content);
                } else if (config.commentType == CommentConfig.Type.REPLY) {
                    newItem = DatasUtil.createReplyComment(config.replyUser, content);
                }
                if (view != null) {
                    view.update2AddComment(config.circlePosition, newItem);
                }
            }

        });
    }

    /**
     * @param @param circlePosition
     * @param @param commentId
     * @return void    返回类型
     * @throws
     * @Title: deleteComment
     * @Description: 删除评论
     */
    public void deleteComment(final int circlePosition, final String commentId) {
        circleModel.deleteComment(new IDataRequestListener() {

            @Override
            public void loadSuccess(Object object) {
                if (view != null) {
                    view.update2DeleteComment(circlePosition, commentId);
                }
            }

        });
    }

    /**
     * @param commentConfig
     */
    public void showEditTextBody(CommentConfig commentConfig) {
        if (view != null) {
            view.updateEditTextBodyVisible(View.VISIBLE, commentConfig);
        }
    }


    /**
     * 清除对外部对象的引用，反正内存泄露。
     */
    public void recycle() {
        this.view = null;
    }
}
