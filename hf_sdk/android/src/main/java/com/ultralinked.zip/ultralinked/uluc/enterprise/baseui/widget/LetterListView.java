package com.ultralinked.uluc.enterprise.baseui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class LetterListView extends View {

	OnTouchingLetterChangedListener onTouchingLetterChangedListener;
	String[] letters = {"#","A","B","C","D","E","F","G","H","I","J","K","L"
			,"M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
	int choose = 0;
	Paint paint = new Paint();
	Paint p = new Paint();
	boolean showBkg = false;
	private static final String TAG="LetterListView";

	private float mChildWidth;

	private Map<String,Integer> canShowList=new HashMap<String,Integer>();
	private float paddinTop = 0;

	public LetterListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public void setLetters(String[] letters) {
		this.letters = letters;
		Log.i(TAG,"default index=="+choose);
		if(onTouchingLetterChangedListener != null){
			if(choose >-1 && choose< letters.length&&isIndexCanShow(choose)){
				onTouchingLetterChangedListener.onTouchingLetterChanged(letters[choose]);

				invalidate();
			}
		}
	}


	public LetterListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	private float singleHeight;
	private  int defaultColor = 0x3b5998;
	private void init(Context context) {
		defaultColor = getResources().getColor(R.color.colorPrimary);
		// TODO Auto-generated method stub
		getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {



			@Override
			public void onGlobalLayout() {
				// TODO Auto-generated method stub
				 if (letters==null) {
						Log.i(TAG, "maybe need insave instace...="+getWidth());
						return;
					}
						int width = getWidth();

						singleHeight = getHeight() /letters.length;
						mChildWidth = singleHeight;

						float offset = ScreenUtils.dp2px(getContext(),
								3);

						float textSize = (float) (singleHeight * 0.75);
						if (textSize > (width - 2 * offset)) {
							ViewGroup.LayoutParams params = getLayoutParams();
							params.width = (int) (textSize + 0.5f + 2 * offset);
							setLayoutParams(params);
						}
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
					getViewTreeObserver().removeOnGlobalLayoutListener(this);
				}
			}
		});
	}

	public LetterListView(Context context) {
		super(context);
		init(context);
	}

	public String[] getLetters() {

      return letters;

	}
	@Override
	protected void onAttachedToWindow() {
		// TODO Auto-generated method stub
		super.onAttachedToWindow();

	}

	public  final static int LETTER_LEN = 27;

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		    canvas.drawColor(0x00000000);
	    for(int i=0;i<letters.length;i++){

			paint.setColor(defaultColor);

	        paint.setAntiAlias(true);
	        float textSize = (float)(mChildWidth*0.75);

	        paint.setTextSize(textSize);

			if (i == choose) {

				this.p.setColor(defaultColor);
				this.p.setAntiAlias(true);// 抗锯齿
				float radius = 16f;

				float left = (getWidth() - mChildWidth) / 2;
				float top = paddinTop + singleHeight * i;
				float right = left + mChildWidth;
				float bottom = top + singleHeight;
				RectF rectF = new RectF(left, top, right, bottom);
				canvas.drawRoundRect(rectF, radius, radius, this.p);
				this.paint.setColor(-1);

				this.paint.setFakeBoldText(true);
			}

			String info = "";
			if (i<letters.length){
				info = letters[i];
			}
	       float xPos = getWidth()/2  - paint.measureText(info)/2;
	       Paint.FontMetrics fm = paint.getFontMetrics();
	       float textHeight = Math.abs(fm.descent + fm.ascent);

	       float yPos = singleHeight * i + singleHeight -(singleHeight-textHeight)/2-1;

	       canvas.drawText(info, xPos, yPos, paint);

	       paint.reset();
	    }
	}

	  public void refresh(int position)
	  {
	    this.choose = position;

	    invalidate();

	  }
	  public void refreshKeyList(Map<String, Integer> alphaIndexer)

	  {
		  this.canShowList=alphaIndexer;
	  }

	private boolean isIndexCanShow(int index){
    	boolean result=false;
    	if(canShowList.size()==letters.length){
    		return true;
    	}
    	Iterator<String> iter = canShowList.keySet().iterator();
    	while (iter.hasNext()) {
    	String key = iter.next();
    	   if(key.equalsIgnoreCase(letters[index])){
			 result=true;
		   }
    	}
		return result;
    }

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		final int action = event.getAction();
	    final float y = event.getY();
	    final int oldChoose = choose;
	    final OnTouchingLetterChangedListener listener = onTouchingLetterChangedListener;
	    final int c = (int) (y/getHeight()*letters.length);
	    Log.i(TAG, "c == "+c);
		switch (action) {
			case MotionEvent.ACTION_DOWN:
				showBkg = true;
				if(oldChoose != c && listener != null){
					if(c >-1 && c< letters.length&&isIndexCanShow(c)){
						listener.onTouchingLetterChanged(letters[c]);
						choose = c;
						invalidate();
					}
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if(oldChoose != c && listener != null){
					if(c > -1&& c< letters.length&&isIndexCanShow(c)){
					    listener.onTouchingLetterChanged(letters[c]);
						choose = c;
						invalidate();
					}
				}
				break;
			case MotionEvent.ACTION_UP:

				break;
		}
		return true;
	}

	public void setOnTouchingLetterChangedListener(
			OnTouchingLetterChangedListener onTouchingLetterChangedListener) {
		    this.onTouchingLetterChangedListener = onTouchingLetterChangedListener;
	}

	public interface OnTouchingLetterChangedListener{
		void onTouchingLetterChanged(String s);
	}

}
