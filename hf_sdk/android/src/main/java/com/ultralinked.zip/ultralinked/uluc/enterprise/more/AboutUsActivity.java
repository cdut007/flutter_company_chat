package com.ultralinked.uluc.enterprise.more;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.common.ZipUtils;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.LogUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.ultralinked.uluc.enterprise.baseui.widget.SwitchView;
import com.ultralinked.voip.rtcapi.rtcapij;

/**
 * Created by lly on 2016/9/14.
 */
public class AboutUsActivity extends BaseActivity implements View.OnClickListener {

    ImageView mLeftBack;
    View mTitleCenter, mCurrentVersion, mReportBug;
    private long downTime;
    private int clickTime;

    SwitchView gcmPush;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_about_us;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.txt_terms).setOnClickListener(this);
        mLeftBack = bind(R.id.left_back);
        mTitleCenter = bind(R.id.titleCenter);
        mCurrentVersion = bind(R.id.text_version);
        mReportBug = bind(R.id.setReportBug);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView) mTitleCenter).setText(getString(R.string.about_us));
        goneView(bind(R.id.gcm_push_layout));
        gcmPush = bind(R.id.gcm_push);
        gcmPush.setColor(getResources().getColor(R.color.colorPrimary),getResources().getColor(R.color.colorPrimaryDark));

        if (SPUtil.pushIngoireChina()) {
            gcmPush.toggleSwitch(true);
        } else {
            gcmPush.toggleSwitch(false);
        }

        gcmPush.setOnStateChangedListener(new SwitchView.OnStateChangedListener() {
            @Override
            public void toggleToOn(SwitchView view) {
                view.toggleSwitch(true);
               // rtcapij.grrtc_set_config("crash_dmp","112");
               // SPUtil.setPushIngoireChina(true);
            }

            @Override
            public void toggleToOff(SwitchView view) {
                view.toggleSwitch(false);
             //   SPUtil.setPushIngoireChina(false);
            }
        });


        /*获取当前版本号并显示*/
        try {
            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageInfo(this.getPackageName(), 0);
            ((TextView) mCurrentVersion).setText(String.format(getString(R.string.current_version),info.versionName));
        } catch (Exception ex) {
            ((TextView) mCurrentVersion).setText(getString(R.string.current_version_not_found));
        }
        initListener(this, mLeftBack, mReportBug,mTitleCenter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;
            case R.id.setReportBug:
                LogUtils.reportBug(this,getString(R.string.choose_a_email));
                break;
            case R.id.titleCenter:
            {
                if (System.currentTimeMillis() - downTime > 500) {
                    clickTime = 0;
                    downTime = System.currentTimeMillis();
                    return;
                }
                clickTime++;
                android.util.Log.i(TAG, "is record log " + clickTime);
                if (clickTime == 7) {
                    visibleView(bind(R.id.gcm_push_layout));
                    clickTime = 0;
                    String path = "/data/data/" + getActivity().getPackageName()+"/databases";// database
                    File f = new File(path);
                    File of= Environment.getExternalStorageDirectory();
                    File outFile = new File(of, "sealchatDB");
                    if(outFile.exists()){
                        deleteFile(outFile);
                    }
                    outFile.mkdir();
                    try {
                        copyDB(f, outFile);
                        ZipUtils.zipFolder(outFile.getAbsolutePath(), outFile.getAbsolutePath()+".zip", true);
                        showToast("zip the file path:"+ outFile.getAbsolutePath()+".zip");
                    } catch (Exception e1) {
                        showToast("failed copy db ");
                        e1.printStackTrace();
                    }

                }
                downTime = System.currentTimeMillis();
            }
                break;
            case R.id.txt_terms:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.TERMS_URL)));
                break;
        }
    }

    public void deleteFile(File file){
        if(!file.exists()) return;
        if(file.isFile()){
            file.delete();
        }
        if(file.isDirectory()){
            File [] listFiles = file.listFiles();
            if(listFiles.length == 0) return;
            for(File f:listFiles){
                deleteFile(f);
            }
            file.delete();
        }

    }

    public void copyDB(File inFile, File outFile) throws Exception {
        if(!outFile.exists() || outFile.isFile()){
            return;
        }
        if (!inFile.exists()) {
            return;
        }
        if (inFile.isFile()) {
            String name = inFile.getName();
            File file = new File(outFile, name);
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            FileInputStream fis = new FileInputStream(inFile);
            FileOutputStream fos = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int count = -1;
            while ((count = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, count);
            }
            fis.close();
            fos.close();
        }
        if (inFile.isDirectory()) {
            String name = inFile.getName();
            File file = new File(outFile, name);
            if (file.exists()) {
                file.exists();
            }
            file.mkdirs();
            File[] listFile = inFile.listFiles();
            if (listFile.length == 0)	return;

            for (File f : listFile) {
//				String subName = f.getName();
                copyDB(f,file);
            }
        }
    }

}
