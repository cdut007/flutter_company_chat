package com.ultralinked.uluc.enterprise.contacts.ui.orgnization;

import android.content.Context;
import android.graphics.Color;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.widget.BadgeView;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.DataWrapper;
import com.ultralinked.uluc.enterprise.contacts.ui.pendinglist.FragmentPendingInviteList;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 16/7/22. only show organization, not show external
 */
public class OrganizationAdapter extends BaseAdapter {

    private static final String TAG = "OrganizationAdapter";
    private static final int TYPE1 = 0;
    private static final int TYPE2 = 1;
    ArrayList<DataWrapper> elements = new ArrayList<>();
    LayoutInflater mInflater;

    public void setData(List<DataWrapper> data) {

        elements = new ArrayList<>();

        elements.addAll(data);
    }

    public OrganizationAdapter(Context context) {

        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getViewTypeCount() {
        return 2;

    }

    @Override
    public int getItemViewType(int position) {

        if (getItem(position) == null) {
            return 0;
        }
        return getItem(position).type == 0 ? TYPE1 : TYPE2;
    }

    @Override
    public int getCount() {
        return elements == null ? 0 : elements.size();
    }

    @Override
    public DataWrapper getItem(int position) {
        return elements == null ? null : elements.get(position);
    }

    @Override
    public long getItemId(int position) {
        return elements == null ? 0 : position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        int type = getItemViewType(position);

        System.out.println("getView " + position + " " + convertView + " type = " + type);

        ViewHolder_T1 holder1 = null;

        ViewHolder_T2 holder2 = null;

        if (convertView != null) {

            switch (type) {
                case TYPE1:
                    holder1 = (ViewHolder_T1) convertView.getTag();//取出ViewHolder对象
                    break;
                case TYPE2:
                    holder2 = (ViewHolder_T2) convertView.getTag();//取出ViewHolder对象
                    break;
            }


        } else {

            switch (type) {
                case TYPE1:
                    convertView = mInflater.inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.depart_list_item, null);
                    holder1 = new ViewHolder_T1();
                    holder1.bind(convertView);
                    convertView.setTag(holder1);//绑定ViewHolder对象
                    break;
                case TYPE2:
                    convertView = mInflater.inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.depart_list_item, null);
                    holder2 = new ViewHolder_T2();
                    holder2.bind(convertView);
                    convertView.setTag(holder2);//绑定ViewHolder对象
                    break;
            }

        }

        //loade datas
        switch (type) {
            case TYPE1:
                DepartUtils.CompanyElement source = elements.get(position).element;
                //
                holder1.title.setText(source.name);
                holder1._Id = source._id;
                BadgeView badgeView = (BadgeView) holder1.title.getTag();
                if (DepartUtils.INVITE_ORG_FLAG.equals(source._id)){
                    //set the count.
                    if (badgeView == null){
                        badgeView = new BadgeView(holder1.title.getContext(), holder1.title);
                        badgeView.setBadgeBackgroundColor(Color.RED);
                        badgeView.setTextColor(Color.WHITE);
                    }
                    holder1.title.setTag(badgeView);
                    if (FragmentPendingInviteList.mInviteList.size() > 0){
                        badgeView.show();
                        badgeView.setText(""+ FragmentPendingInviteList.mInviteList.size());
                    }else{
                        badgeView.hide();
                    }
                }else{
                    if (badgeView!=null){
                        badgeView.hide();
                    }
                }
                int defaultId = -1;

                switch (position % 4) {

                    case 1:
                        defaultId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.orgnanization_1;
                        break;
                    case 2:
                        defaultId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.orgnanization_2;
                        break;
                    case 3:
                        defaultId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.orgnanization_3;
                        break;
                    default:
                        defaultId = com.holdingfuture.flutterapp.hfsdk.R.mipmap.orgnanization_4;
                        break;
                }


                holder1.head.setImageResource(defaultId);
                holder1.detail.setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.more);
                break;
            case TYPE2:

                PeopleEntity entity = elements.get(position).peopleEntity;

                holder2.title.setText(PeopleEntityQuery.getDisplayName(entity));

                holder2.detail.setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.detail);


                int defaultHead =  ImageUtils.getDefaultContactImageResource(entity.subuser_id);

                ImageUtils.loadCircleImage(convertView.getContext(), holder2.head,entity.icon_url, defaultHead);

                break;

            default:

                break;
        }


        return convertView;
    }

    public final class ViewHolder_T1 {
        public TextView title;
        public ImageView head;
        public ImageView detail;
        public String _Id;

        public void bind(View view) {

            this.title = (TextView) view.findViewById(R.id.Orgtitle);
            this.head = (ImageView) view.findViewById(R.id.Orgimage);
            this.detail = (ImageView) view.findViewById(R.id.OrgDetail);
        }
    }

    public final class ViewHolder_T2 {
        public TextView title;
        public ImageView head;
        public ImageView detail;
        public String _Id;

        public void bind(View view) {

            this.title = (TextView) view.findViewById(R.id.Orgtitle);
            this.head = (ImageView) view.findViewById(R.id.Orgimage);
            this.detail = (ImageView) view.findViewById(R.id.OrgDetail);
        }
    }

}
