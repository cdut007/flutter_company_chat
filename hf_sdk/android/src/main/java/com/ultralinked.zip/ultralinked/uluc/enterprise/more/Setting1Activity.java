package com.ultralinked.uluc.enterprise.more;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.login.LoginActivity;
import com.ultralinked.uluc.enterprise.login.LoginPresenter;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.LogUtils;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MLoginApi;

public class Setting1Activity extends BaseActivity implements View.OnClickListener{

    private ImageView leftBack;
    private View tvAccountS,tvPasswordR,tvLogout,aboutUs,privacy,general,mCallSetting;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_setting1;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        leftBack=bind(R.id.left_back);
        tvAccountS=bind(R.id.setAccount);
        tvPasswordR=bind(R.id.setPassword);
        tvLogout=bind(R.id.setLogout);
        privacy = bind(R.id.privacy);
        general = bind(R.id.general);
        mCallSetting = bind(R.id.frame_call_set);

        aboutUs=bind(R.id.setAbout);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView)bind(R.id.titleCenter)).setText(R.string.settings);
        initListener(this, leftBack, tvAccountS, tvPasswordR, tvLogout,aboutUs,privacy,general,mCallSetting);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.setAccount:
                lunchActivity(AccountSecurity.class);
                break;
            case R.id.privacy:
                lunchActivity(PrivacyActivity.class);
                break;
            case R.id.general:
                lunchActivity(GeneralSettingActivity.class);
                break;
            case R.id.setPassword:
                lunchActivity(PrivateSettingActivity.class);
                break;
            case R.id.setLogout:
            {
                clickLogout();
            }
                break;
            case R.id.setAbout:
                startActivity(new Intent(this,AboutUsActivity.class));
                break;
            case R.id.frame_call_set:
                startActivity(new Intent(this,CallSettingActivity.class));
                break;
            default:
        }
    }

    private void clickLogout() {

        DialogManager.showOKCancelDialog(this, "",getString(R.string.logout_tips), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.i(TAG, "click logout button");

                LoginPresenter.logout(Setting1Activity.this);
            }
        }, null);
    }


}
