package com.ultralinked.uluc.enterprise.chat.chatim;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.Constants;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.voip.api.Conversation;

/**
 * Created by Chenlu on 2016/7/6 0006.
 */
public class BaseChatImActivity extends BaseActivity {


    protected BaseChatImFragment mFragment;
    public BaseChatImFragment getmFragment() {
        return mFragment;
    }

    private Fragment setFragment(Class<?> className, Bundle bundle) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        BaseFragment fragment = (BaseFragment) getFragmentByTag(this, bundle, className);
        fragmentTransaction.replace(R.id.main_fragment_container, fragment,className.getName());
        fragmentTransaction.commit();
        return fragment;
    }

    /**
     * 启动到单聊界面
     * @param context
     * @param number
     */
//    public static void launchToSingleChatIm(@NonNull Context context, @NonNull String number,int chatFlag){
//        Bundle data = new Bundle();
//        data.putString(Constants.PHONE_NUMBER_KEY,number);
//        data.putInt(Constants.CHAT_TYPE_KEY, Conversation.SINGLE_CHAT);
//        data.putInt(Constants.CHAT_FLAG,chatFlag);
//
//        Intent intent = new Intent(context, BaseChatImActivity.class);
//        intent.putExtra(Constants.DATA_KEY, data);
//        context.startActivity(intent);
//        Log.i("BaseChatImActivity","number:"+number);
//    }

    /**
     * 启动到群聊界面
     * @param context
     * @param groupId
     */
//    public static void launchToGroupChatIm(@NonNull Context context, @NonNull String groupId, int chatFlag) {
//        Bundle data = new Bundle();
//        data.putString(Constants.GROUPKD_KEY,groupId);
//        data.putInt(Constants.CHAT_TYPE_KEY, Conversation.GROUP_CHAT);
//        data.putInt(Constants.CHAT_FLAG,chatFlag);
//
//        Intent intent = new Intent(context, BaseChatImActivity.class);
//        intent.putExtra(Constants.DATA_KEY, data);
//        context.startActivity(intent);
//    }

    /**
     * 将Back键的点击事件交给Fragment处理
     */
    @Override
    public void onBackPressed() {
        if (mFragment!=null) {

            mFragment.onBackPressed();

        }else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (mFragment != null) {
            mFragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
        } else {

        }

    }



    @Override
    public int getRootLayoutId() {
        return R.layout.main_fragment_container;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        Bundle  data = null;
        if (savedInstanceState != null) {
            data = savedInstanceState.getBundle("save_bundle");
            Log.i(TAG, "get data form savedInstanceState");
        }
        if (data == null) {
            data = getIntent().getExtras();
            Log.i(TAG, "get data form Intent");
        }
        if (data == null) {
            Log.e(TAG, " the data is null,please check!");
//            showToast("the data is null,please check!");
            finish();
            return;
        }

        int chatType = data.getInt(Constants.CHAT_TYPE_KEY);
        Class<?> className = null;
        if (chatType == Conversation.SINGLE_CHAT) {
            className = SingleChatImFragment.class;
        } else {
            className = GroupChatImFragment.class;
        }
        mFragment = (BaseChatImFragment) setFragment(className, data);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        swipeUI = false;
        super.onCreate(savedInstanceState);
        Log.i(TAG,"onCreate~~~");
      //  SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
    }

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);

        Log.i(TAG,"onCreate~~~~~~~~~");
    }

    @Override
    public View onCreateView(String name, Context context, AttributeSet attrs) {
        return super.onCreateView(name, context, attrs);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mFragment != null) {
            mFragment.onActivityResult(requestCode, resultCode, data);

        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        fixInputMethodManagerLeak(this);

    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putBundle("save_bundle",getIntent().getExtras());
        Log.i(TAG,"onSaveInstanceState~~~");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG,"onRestart~~~");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onResume~~~");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (mFragment != null) {
            // from notification
            Bundle data = intent.getExtras();
            if (data == null) {
                Log.i(TAG, "data is null");

            }
            mFragment.onNewIntent(data);
        }

    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN||event.getAction() == MotionEvent.ACTION_MOVE){
            rawX = event.getX();
            rawY = event.getRawY();
        }
        return super.dispatchTouchEvent(event);
    }

    float rawX,rawY;
    public float getRawY(){
        Log.i("message_bubble","get click rawY:"+rawY);
        return  rawX;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mFragment!=null) {
            boolean onKeyDown = mFragment.onKeyDown(keyCode,event);
            if (onKeyDown) {
                return true;
            }
        }

        return super.onKeyDown(keyCode, event);
    }

}
