package com.ultralinked.uluc.enterprise.contacts.tools;

import com.google.gson.annotations.SerializedName;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

import java.util.List;

/**
 * Created by Created by ultralinked.
 */
public class RawFriendPerson {

    /**
     * code : 200
     * result : [{"mobile":"8618200394453","name":"chenlu","id":"subusr1468983506007"}]
     */

    public int code;
    /**
     * mobile : 8618200394453
     * name : chenlu
     * id : subusr1468983506007
     */

    public List<PeopleEntity> result;


}
