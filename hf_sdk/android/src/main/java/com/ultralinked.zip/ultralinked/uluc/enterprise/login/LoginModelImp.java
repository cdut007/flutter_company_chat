package com.ultralinked.uluc.enterprise.login;


import android.content.Context;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.Log;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/6/24 0024.
 */

public class LoginModelImp implements LoginModel {

    private LoginModelFab listener;
    private BaseActivity activity;
    public LoginModelImp(LoginModelFab modelFab, Context context){
        this.listener=modelFab;
        this.activity= (BaseActivity) context;
    }

    private static final String TAG = "LoginModelImp";

    @Override
    public void login(String userName,String password) {
        if(checkParams(userName,password)){
            listener.error("Input can't be null");
            return;
        }

        ApiManager.getInstance().login(userName,password)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });
    }

    @Override
    public void refreshTokenConfig() {
        ApiManager.getInstance().refreshToken()
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });
    }

    @Override
    public void createUser(HashMap<String,String> map) {
        ApiManager.getInstance().createUser(map)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"createUser onCompleted ");
                    }

                    @Override
                    public void onError(Throwable e) {
                       try{
                           Log.e(TAG,e.getMessage());
                           listener.error(HttpErrorException.handErrorMessage(e));
                       }catch (Exception ex){
                           Log.e(TAG,"create error:"+ android.util.Log.getStackTraceString(ex));
                       }
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG,"createUser onNext");
                        listener.success(responseBody);
                    }
                });
    }

    @Override
    public void otpRequest(String mobile,String action ,String type) {
        if(checkParams(mobile)){
            listener.error("Input can't be null");
            return;
        }

        ApiManager.getInstance().request_otp(mobile,action,type)
                .throttleFirst(3, TimeUnit.SECONDS)
                .compose(activity.<ResponseBody>bindToLifecycle())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i("otpRequest", "onCompleted" );
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.i("otpRequest", "onError" );
                        if (e!=null){
                            listener.error(HttpErrorException.handErrorMessage(e));
                        }else{
                            Log.i("otpRequest", "onError unknown");
                            listener.error("unknown error");
                        }

                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG,"otpRequest onNext");
                        listener.success(responseBody);
                    }
                });
    }

    @Override
    public void otpLogin(String mobile, String otp) {
        if(checkParams(mobile,otp)){
            listener.error("Input can't be null");
            return;
        }

        ApiManager.getInstance().otpVerify(mobile,otp)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i("otpLogin", "onCompleted" );
                    }

                    @Override
                    public void onError(Throwable e) {
                        if (e == null){
                            Log.i("otpLogin", "error -----" );
                            return;
                        }
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });
    }



    @Override
    public void otpRegist(String mobile, String username,String otp) {
        if(!TextUtils.isEmpty(otp) && checkParams(mobile,username)){
            listener.error(activity.getString(R.string.input_empty_info_tips));
            return;
        }

        ApiManager.getInstance().otpRegist(mobile,username,otp)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3,TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i("otpRegist", "onCompleted" );
                    }

                    @Override
                    public void onError(Throwable e) {
                        if (e == null){
                            Log.i("otpRegist", "error------" );
                            return;
                        }
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });
    }


    @Override
    public void otpRegistCompany(String mobile, String company, String email, String username,String otp) {
        if(!TextUtils.isEmpty(otp) && checkParams(mobile,company,email,username)){
            listener.error(activity.getString(R.string.input_empty_info_tips));
            return;
        }

        ApiManager.getInstance().otpRegistWithCompany(mobile,company,email,username,otp)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3,TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });
    }

    @Override
    public void otpCreateCompany(String mobile, String company, String otp) {
        if(!TextUtils.isEmpty(otp) && checkParams(mobile,company,otp)){
            listener.error(activity.getString(R.string.input_empty_info_tips));
            return;
        }

        ApiManager.getInstance().otpCreateWithCompany(mobile,company,otp)
                .subscribeOn(Schedulers.io())
                .compose(activity.<ResponseBody>bindToLifecycle())
                .throttleFirst(3,TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        listener.error(HttpErrorException.handErrorMessage(e));
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        listener.success(responseBody);
                    }
                });

    }

    private boolean checkParams(String ...params){
        for(String param:params){
            if(TextUtils.isEmpty(param)){
                return true;
            }
        }
        return false;
    }
}
