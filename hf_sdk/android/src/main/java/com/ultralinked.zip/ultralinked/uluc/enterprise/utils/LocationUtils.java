package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.chat.bean.AddressComponent;
import com.ultralinked.uluc.enterprise.chat.bean.ListModel;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Locale;




public class LocationUtils {
	private Context mContext;

     public final static  String CN="zh";
	 public final static  String  EN="en";
	private final static String  TAG="LocationUtils";

	public LocationUtils(Context mContext){
		this.mContext = mContext;
	}

	//copy from chatManager (lines:1913)
	public String getPlaceNameString(String locationInfo) {
		String result = "";
		double[] nautica = new double[2];
		String nauticaStr = locationInfo.replace("http://maps.google.com/?q=",
				"");
		try {
			String[] str = nauticaStr.split(",");
			nautica[0] = Double.parseDouble(str[0]);
			nautica[1] = Double.parseDouble(str[1]);
		} catch (Exception e) {
			e.printStackTrace();
			nautica[0] = 0.0D;
			nautica[1] = 0.0D;
		}

		nautica[1] = (nautica[1] < -90.0D ? -90.0D : nautica[0]);
		nautica[1] = (nautica[1] > 90.0D ? 90.0D : nautica[0]);
		nautica[0] = (nautica[0] < -180.0D ? -180.0D : nautica[1]);
		nautica[0] = (nautica[0] > 180.0D ? 180.0D : nautica[1]);

		Geocoder geocoder = new Geocoder(this.mContext, Locale.getDefault());
		List addressList = null;
		try {
			addressList = geocoder.getFromLocation(nautica[0], nautica[1], 1);
			if ((addressList != null) && (!addressList.isEmpty())) {
				Address tempAddress = (Address) addressList.get(0);
				String country = tempAddress.getCountryName();
				String city = tempAddress.getLocality();
				String subCity = tempAddress.getSubLocality();
				String thoroughfare = tempAddress.getThoroughfare();
				String subThoroughfare = tempAddress.getSubThoroughfare();
				result = country + city + subCity + thoroughfare
						+ subThoroughfare;

				if ((result != null) && (result.length() == 0)) {
					result = "";
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}



	 private static String[] geoCodeBySDK(Context mContext, double lat, double lnt){
			String title = "";
			String address = "";
			String route = "";
			 Log.i(TAG, "geoCodeBySDK");

		 if (!Geocoder.isPresent()) {
			 Log.i(TAG, "not support location by android sdk!");
			 return new String[]{title,address,route};
		}
		  Geocoder geocoder = new Geocoder(mContext,Locale.getDefault());
	        List<Address> addresses = null;

	        try{

	            // Call the synchronous getFromLocation() method by passing in the lat/long values.

	            addresses = geocoder.getFromLocation(lat,lnt,1);

	        } catch(IOException e) {
	        	Log.i(TAG, "catch IOException geoCodeBySDK~lat="+lat+";lnt="+lnt);
	            e.printStackTrace();

	            // Update UI field with the exception.
	            return new String[]{title,address,route};

	        }

	        if(addresses !=null && addresses.size()>0) {

	            Address addressInfo = addresses.get(0);

	            // Format the first line of address (if available), city, and country name.
	            address = addressInfo.getMaxAddressLineIndex()>0 ? addressInfo.getAddressLine(0) : "";

            	String countryName = addressInfo.getCountryName();
            	String postCode = addressInfo.getPostalCode();
            	if (countryName==null) {
            		countryName="";
				}
            	if (postCode==null) {
            		postCode="";
				}


            	StringBuilder addreBuilder = new StringBuilder();
            	if (!TextUtils.isEmpty(address)) {
            		//addressInfo.getSubLocality();//Wuhou
                	//addressInfo.getLocality();Chengdu
                	//addressInfo.getAdminArea();//Sichuan
                	  /*{
                          "long_name" : "Wuhou",
                          "short_name" : "Wuhou",
                          "types" : [ "sublocality_level_1", "sublocality", "political" ]
                       },
                       {
                          "long_name" : "Chengdu",
                          "short_name" : "Chengdu",
                          "types" : [ "locality", "political" ]
                       },
                       {
                          "long_name" : "Sichuan",
                          "short_name" : "Sichuan",
                          "types" : [ "administrative_area_level_1", "political" ]
                       },
                       {
                          "long_name" : "China",
                          "short_name" : "CN",
                          "types" : [ "country", "political" ]
                       },*/
            		address = address+", ";
            		String area="";
            		if (!"Singapore".equals(addressInfo.getCountryName())) {
            			String subLocality = addressInfo.getSubLocality();
                    	String locality = addressInfo.getLocality();
                    	String adminArea = addressInfo.getAdminArea();
                    	if (subLocality==null) {
                    		subLocality="";
        				}else {
        					subLocality=subLocality+", ";
						}
                    	if (locality==null) {
                    		locality="";
        				}else {
        					locality=locality+", ";
						}
                    	if (adminArea==null) {
                    		adminArea="";
        				}else {
        					adminArea=adminArea+", ";
						}
                    	area=subLocality+locality+adminArea;
                    	address=address+area;
					}

	            	String currentLanguage=Locale.getDefault().getLanguage();
	        		if(EN.equalsIgnoreCase(currentLanguage)){
	        			//add counry  post code
	        			addreBuilder.append(address).append(countryName).append(" ").append(postCode);
	        		}else {

						String subLocality = addressInfo.getSubLocality();
						String locality = addressInfo.getLocality();
						String adminArea = addressInfo.getAdminArea();

						String thoroughfare = addressInfo.getThoroughfare();
						String featureName = addressInfo.getFeatureName();
						if (thoroughfare==null) {
							thoroughfare="";
						}else {
							thoroughfare=thoroughfare+"";
						}
						if (thoroughfare==null) {
							thoroughfare="";
						}else {
							thoroughfare=thoroughfare+"";
						}

						if (subLocality==null) {
							subLocality="";
						}else {
							subLocality=subLocality+"";
						}
						if (locality==null) {
							locality="";
						}else {
							locality=locality+"";
						}
						if (adminArea==null) {
							adminArea="";
						}else {
							adminArea=adminArea+"";
						}
						area=adminArea + locality + subLocality+thoroughfare+featureName;
						address=area;

	        			addreBuilder.append(countryName).append(address).append(" ").append(postCode);

					}
				}

	            route = addressInfo.getThoroughfare();

	            if (route==null) {
	            	route="";
				}
	            String addressText = String.format("%s, %s, %s",addreBuilder.toString(), addressInfo.getLocality(),countryName);
	            Log.i(TAG, "address ="+addressText);
	            // Update the UI via a message handler.
	            Log.i(TAG, "getFeatureName ="+addressInfo.getFeatureName()
	            		+"getThoroughfare ="+addressInfo.getThoroughfare()
	            		+"getPostalCode ="+addressInfo.getPostalCode()
	            		+"getSubLocality ="+addressInfo.getSubLocality()
	            		+"getSubThoroughfare ="+addressInfo.getSubThoroughfare()
	            	     +"getPremises ="+addressInfo.getPremises()
	            	       +"getAdminArea ="+addressInfo.getAdminArea()
	            		  +"getSubAdminArea ="+addressInfo.getSubAdminArea()
	            		);

	            return new String[]{title,addreBuilder.toString(),route};
	         }else {
	        	  Log.i(TAG, "no address found");
			}
	        return new String[]{title,address,route};
	 }

	public static String[] geocodeAddr(Context context,double latitude, double longitude){
		String geocodeAddr[] =geoCodeBySDK(context, latitude, longitude);
		if (!TextUtils.isEmpty(geocodeAddr[1])) {
			return geocodeAddr;
		}

		String title = "";
		String address = "";
		String route = "";
		BufferedReader in= null;

		String latLng=latitude+","+longitude;
		String lang="en";
		String currentLanguage=Locale.getDefault().getLanguage();
		Log.i(TAG, "currentLanguage = "+currentLanguage);

		if(CN.equalsIgnoreCase(currentLanguage)){
			lang="zh-CN";

		}else if(EN.equalsIgnoreCase(currentLanguage)){

			lang="en";
		}else{

			lang="en";

		}
		String latef=latitude+lang+longitude;
		String geoUrl ="http://maps.google.com/maps/api/geocode/json?latlng="+latLng+"&language="+lang+"&sensor=true";
		 String addressDecoder=getGeoUrlFromNativeCache(context,latef);
		 boolean saveCache =false;
		if (TextUtils.isEmpty(addressDecoder)) {
			saveCache=true;
		}
		HttpURLConnection httpConn = null ;
		try {
			   String result="";
			if (saveCache) {
				URL url = new URL(geoUrl);
				 Log.i(TAG, "geocodeAddr is "+url.toString());
				 httpConn = (HttpURLConnection) url.openConnection();
				httpConn.setConnectTimeout(15000);
				in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
			    String line;

			    while ((line = in.readLine()) != null) {
			        result += line;
			    }

			    in.close();
			}else {
				 Log.i(TAG, "read from native ");
				result=addressDecoder;//
			}

		     Gson gson=new Gson();
		     ListModel list = null;
		     Log.i("location struct", "result="+result);
		  try {
			   list=gson.fromJson(result, ListModel.class);

		} catch (Exception e) {
			e.printStackTrace();
			//reach limited?
			if (!saveCache) {
				deleteByfileName(latef,context);
			}
			return geoCodeBySDK(context, latitude, longitude);

		}

			if (list.getResults().size() > 0) {
				Log.i(TAG, "status is " + list.getStatus());
				address = list.getResults().get(0).getFormatted_address();
				Log.i(TAG, "Formatted address is "+address);
				List<AddressComponent> titles = list.getResults().get(0).getAddress_components();
				if (titles.size()>0) {
					title =  titles.get(titles.size()-1).getLong_name();
					for (int i = 0; i < titles.size(); i++) {
						List<String> types = titles.get(i).getTypes();
						if (types.size()>0&&types.get(0).equals("route")) {
							route= titles.get(i).getShort_name();
							break;
						}
					}

					Log.i(TAG, "title is " +title);
				}

				if (TextUtils.isEmpty(address)) {
					address=title;
				}

				if (!TextUtils.isEmpty(address)&&saveCache) {//save restlt to native ,reach max

					 saveAddressToCache(context,latef,result);
				}


			} else {
				address = "";
				Log.i(TAG, "location getResults is null");
				 return geoCodeBySDK(context, latitude, longitude);

			}

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		} catch (IOException e) {
			if (!saveCache) {
				deleteByfileName(latef,context);
			}
			e.printStackTrace();
			if (TextUtils.isEmpty(address)) {
				return geoCodeBySDK(context, latitude, longitude);
			}
		}
		finally{
			if (httpConn!=null) {
				httpConn.disconnect();
			}
		}

		if (TextUtils.isEmpty(address)) {
			return geoCodeBySDK(context, latitude, longitude);
		}

		return new String[]{title,address,route};
	}




	private static void deleteByfileName(String geoUrl, Context context) {
		java.io.File cacheFile = context.getCacheDir();
		java.io.File locationFile = new java.io.File(cacheFile.getAbsolutePath()+java.io.File.separator+"locationDir"
				+java.io.File.separator+geoUrl);
		if(locationFile.exists()) {
			locationFile.delete();
		}

	}

	private static String getGeoUrlFromNativeCache(Context context, String geoUrl) {
		java.io.File cacheFile = context.getCacheDir();
		String pathStr = cacheFile.getAbsolutePath()+java.io.File.separator+"locationDir"
				+java.io.File.separator+geoUrl;
		java.io.File locationFile = new java.io.File(pathStr);
		if (!locationFile.exists()) {
			return null;
		}else {//has  this file
			return readFileSdcard(pathStr);
		}

	}

	private static String readFileSdcard(String fileName ){

	       try{

	       FileInputStream fin = new FileInputStream(fileName);
	       BufferedReader in = new BufferedReader(new InputStreamReader(fin));
	       String line;
	       String result = "";
		    while ((line = in.readLine()) != null) {
		        result += line;
		    }

		    in.close();
		    return result;
	       }
	       catch(Exception e){

	        e.printStackTrace();

	       }
	       return null;
	   }





	private static void saveAddressToCache(Context context, String key,String result) {
		java.io.File cacheFile = context.getCacheDir();
		java.io.File  locaFileDir = new java.io.File(cacheFile.getAbsolutePath()+java.io.File.separator+"locationDir");
		if (!locaFileDir.exists()) {
			locaFileDir.mkdirs();
			FileUtils.writeFileSdcard(locaFileDir.getAbsolutePath()+java.io.File.separator+key, result);
			return;
		}else {//check the location len >= max? ,reomve the first time.
			String fileNames[] = locaFileDir.list();
			//always replace
			if (fileNames!=null&&fileNames.length>=50) {
				//delete early
				java.io.File  locations[]=locaFileDir.listFiles();
				java.io.File eariyFile=locations[0];
				for (int i = 0; i < locations.length-1; i++) {
					if(locations[i+1].lastModified()<eariyFile.lastModified()){
						eariyFile=locations[i+1];
						}
					}
				eariyFile.delete();
			}
			//save
			FileUtils.writeFileSdcard(locaFileDir.getAbsolutePath()+java.io.File.separator+key, result);
		}

	}

	public static Bitmap getBitmapByLocation(String latitude, String longitude){
		Bitmap map = null;
		BufferedReader in= null;

		String latLng=latitude+","+longitude;
		try {


			String urlString="http://maps.googleapis.com/maps/api/staticmap?center="+latLng+"&zoom=14&size=200x200&sensor=true";

			URL url = new URL(urlString);

			Log.i(TAG, "get bitmap url is "+urlString);

			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setConnectTimeout(15000);
			httpConn.setDoInput(true);

			map=BitmapFactory.decodeStream(httpConn.getInputStream());


		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		return map;
	}


}
