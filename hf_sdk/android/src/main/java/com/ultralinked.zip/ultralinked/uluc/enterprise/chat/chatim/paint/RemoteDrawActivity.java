package com.ultralinked.uluc.enterprise.chat.chatim.paint;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;

public class RemoteDrawActivity extends BaseActivity {
    private final RemoteDrawActivity self = this;

    private DrawingFragment drawingFragment;

    @Override
    public int getRootLayoutId() {
        return R.layout.remote_draw_activity_main;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DrawResource.context = this;
        getFragmentManager().beginTransaction()
                .replace(R.id.drawingFragmentLayout, getDrawingFragment(), "drawingFragment")
                .commit();
    }




    public DrawingFragment getDrawingFragment() {
        if (drawingFragment == null) {
            drawingFragment = (DrawingFragment) getFragmentManager().findFragmentByTag("drawingFragment");
            if (drawingFragment == null) {
                drawingFragment = new DrawingFragment();
            }
        }
        return drawingFragment;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
