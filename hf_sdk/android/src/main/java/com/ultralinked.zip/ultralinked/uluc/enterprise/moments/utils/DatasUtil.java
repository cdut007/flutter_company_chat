package com.ultralinked.uluc.enterprise.moments.utils;


import android.text.TextUtils;
import android.text.format.DateUtils;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.bean.CircleItem;
import com.ultralinked.uluc.enterprise.moments.bean.CommentItem;
import com.ultralinked.uluc.enterprise.moments.bean.FavortItem;
import com.ultralinked.uluc.enterprise.moments.bean.FeedUserLineItem;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author yiw
 * @ClassName: DatasUtil
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @date 2015-12-28 下午4:16:21
 */
public class DatasUtil {
    public static final String[] CONTENTS = {"",
            "哈哈，18123456789,ChinaAr  http://www.ChinaAr.com;一个不错的VR网站。哈哈，ChinaAr  http://www.ChinaAr.com;一个不错的VR网站。哈哈，ChinaAr  http://www.ChinaAr.com;一个不错的VR网站。哈哈，ChinaAr  http://www.ChinaAr.com;一个不错的VR网站。",
            "今天是个好日子，http://www.ChinaAr.com;一个不错的VR网站,18123456789,",
            "呵呵，http://www.ChinaAr.com;一个不错的VR网站,18123456789,",
            "只有http|https|ftp|svn://开头的网址才能识别为网址,如果你又更好的正则表达式请评论告诉我，谢谢！",
            "VR（Virtual Reality，即虚拟现实，简称VR），是由美国VPL公司创建人拉尼尔（Jaron Lanier）在20世纪80年代初提出的。其具体内涵是：综合利用计算机图形系统和各种现实及控制等接口设备，在计算机上生成的、可交互的三维环境中提供沉浸感觉的技术。其中，计算机生成的、可交互的三维环境称为虚拟环境（即Virtual Environment，简称VE）。虚拟现实技术是一种可以创建和体验虚拟世界的计算机仿真系统的技术。它利用计算机生成一种模拟环境，利用多源信息融合的交互式三维动态视景和实体行为的系统仿真使用户沉浸到该环境中。",
            "哈哈哈哈",
            "图不错",
            "我勒个去"};
    public static final String[] PHOTOS = {
            "http://f.hiphotos.baidu.com/image/pic/item/faf2b2119313b07e97f760d908d7912396dd8c9c.jpg",
            "http://g.hiphotos.baidu.com/image/pic/item/4b90f603738da977c76ab6fab451f8198718e39e.jpg",
            "http://e.hiphotos.baidu.com/image/pic/item/902397dda144ad343de8b756d4a20cf430ad858f.jpg",
            "http://a.hiphotos.baidu.com/image/pic/item/a6efce1b9d16fdfa0fbc1ebfb68f8c5495ee7b8b.jpg",
            "http://b.hiphotos.baidu.com/image/pic/item/a71ea8d3fd1f4134e61e0f90211f95cad1c85e36.jpg",
            "http://c.hiphotos.baidu.com/image/pic/item/7dd98d1001e939011b9c86d07fec54e737d19645.jpg",
            "http://f.hiphotos.baidu.com/image/pic/item/f11f3a292df5e0fecc3e83ef586034a85edf723d.jpg",
            "http://cdn.duitang.com/uploads/item/201309/17/20130917111400_CNmTr.thumb.224_0.png",
            "http://pica.nipic.com/2007-10-17/20071017111345564_2.jpg",
            "http://pic4.nipic.com/20091101/3672704_160309066949_2.jpg",
            "http://pic4.nipic.com/20091203/1295091_123813163959_2.jpg",
            "http://pic31.nipic.com/20130624/8821914_104949466000_2.jpg",
            "http://pic6.nipic.com/20100330/4592428_113348099353_2.jpg",
            "http://pic9.nipic.com/20100917/5653289_174356436608_2.jpg",
            "http://img10.3lian.com/sc6/show02/38/65/386515.jpg",
            "http://pic1.nipic.com/2008-12-09/200812910493588_2.jpg",
            "http://pic2.ooopic.com/11/79/98/31bOOOPICb1_1024.jpg"};
    public static final String[] HEADIMG = {
            "https://uc.ultralinked.com/icons/70587cc7b24c13fc9630a9f3345270f3.jpeg",
            "https://uc.ultralinked.com/icons/acf689642e2b9cd7ef4ba091e188f505.jpeg",
            "https://uc.ultralinked.com/icons/3a648982457d776cf53c2af013f902df.jpg",
            "https://uc.ultralinked.com/icons/1aed8d576071986093ca8612de459fc1.jpeg",
            "https://uc.ultralinked.com/icons/3ea8fe6d888b0412f67269aeb67c680b.jpeg",
            "https://uc.ultralinked.com/icons/4652e66b52fea0cb56f7475092cc9732.jpg",
            "https://uc.ultralinked.com/icons/88291821ddde5d858b98df2366c6f299.jpeg"};

    public static List<User> users = new ArrayList<User>();
    /**
     * 动态id自增长
     */
    private static int circleId = 0;
    /**
     * 点赞id自增长
     */
    private static int favortId = 0;
    /**
     * 评论id自增长
     */
    private static int commentId = 0;
    public static  User curUser = new User(SPUtil.getUserID(), SPUtil.getNickname(), HEADIMG[0]);

    static {
        User user1 = new User("1", "fafu", HEADIMG[0]);
        User user2 = new User("2", "の龙猫", HEADIMG[1]);
        User user3 = new User("3", "寒江钓客", HEADIMG[2]);
        User user4 = new User("4", "安琪教练", HEADIMG[3]);
        User user5 = new User("5", "jinsong", HEADIMG[4]);
        User user6 = new User("6", "樱木花道", HEADIMG[5]);
        User user7 = new User("7", "wenning", HEADIMG[6]);

        users.add(curUser);
        users.add(user1);
        users.add(user2);
        users.add(user3);
        users.add(user4);
        users.add(user5);
        users.add(user6);
        users.add(user7);
    }



    public static  void changeCurrentUser(){
        curUser = new User(SPUtil.getUserID(), SPUtil.getNickname(), HEADIMG[0]);
    }

    public static List<FeedUserLineItem> createFeedUserLineItem(User circleItem) {

        List<FeedUserLineItem> feedUserLineDatas = new ArrayList<FeedUserLineItem>();
        FeedUserLineItem item = new FeedUserLineItem();

        if (circleItem != null) {
            item.setHeadUrl(circleItem.getHeadUrl());
            item.setName(circleItem.getName());
        }

        if (true) {
            item.itemId = 1111;
            item.ts = 1444902955586L;
            item.cover = "http://static.zuidaima.com/images/70156/201511/20151102151228765.jpg";
            item.photoCount = 1;
            item.type = FeedUserLineItem.TYPE_GAME;
            item.text = App.getInstance().getString(R.string.playing_chess_game_tips);
            feedUserLineDatas.add(item);
            return feedUserLineDatas;
        }

        item.itemId = 1111;
        item.ts = 1444902955586L;
        item.cover = "http://b.hiphotos.baidu.com/image/pic/item/a71ea8d3fd1f4134e61e0f90211f95cad1c85e36.jpg";
        item.text = App.getInstance().getString(R.string.playing_chess_game_tips);
        feedUserLineDatas.add(item);


        FeedUserLineItem item2 = new FeedUserLineItem();
        item2.itemId = 11222;
        item2.ts = 1444902951586L;
        item2.text = "阿里巴巴（1688.com）是全球企业间电子商务的著名品牌，为数千万网商提供海量商机信息和便捷安全的在线交易市场，也是商人们以商会友、真实互动的社区平台 ...";
        feedUserLineDatas.add(item2);


        FeedUserLineItem item3 = new FeedUserLineItem();
        item3.itemId = 22221111;
        item3.ts = 1444102855586L;
        item3.cover = "http://cdn.duitang.com/uploads/item/201408/13/20140813122725_8h8Yu.jpeg";
        item3.photoCount = 8;
        feedUserLineDatas.add(item3);


        FeedUserLineItem item4 = new FeedUserLineItem();
        item4.itemId = 7771111;
        item4.ts = 1442912955586L;
        item4.cover = "http://b.hiphotos.baidu.com/image/pic/item/a71ea8d3fd1f4134e61e0f90211f95cad1c85e36.jpg";
        item4.photoCount = 6;
        feedUserLineDatas.add(item4);


        FeedUserLineItem item5 = new FeedUserLineItem();
        item5.itemId = 9991111;
        item5.ts = 1442912945586L;
        item5.cover = "http://cdn.duitang.com/uploads/item/201408/13/20140813122725_8h8Yu.jpeg";
        item5.photoCount = 2;
        item5.text = "京东JD.COM-专业的综合网上购物商城，销售超数万品牌、4020万种商品，http://jd.com 囊括家电、手机、电脑、服装、图书、母婴、个护、食品、旅游等13大品类。秉承客户为先的理念，京东所售商品为正品行货、全国联保、机打发票。@刘强东";
        feedUserLineDatas.add(item5);

        return feedUserLineDatas;
    }


    public static List<FeedUserLineItem> createFeedUserLineItem(JSONArray result) {
        if (result == null) {
            return new ArrayList<>();
        }
        List<FeedUserLineItem> feedUserDatas = new ArrayList<FeedUserLineItem>();
        int size = result.length();
        for (int i = 0; i < size; i++) {
            FeedUserLineItem item = new FeedUserLineItem();
            JSONObject jsonObject = result.optJSONObject(i);



            item.post_id = jsonObject.optString("post_id");
            item.itemId = item.post_id.hashCode();
            item.ts = jsonObject.optLong("created_at") * 1000;
            Date date = new Date(item.ts);
            item.day =date.getDate();
            item.month =DateUtils.formatDateTime(App.getInstance(),item.ts, DateUtils.FORMAT_NO_MONTH_DAY|DateUtils.FORMAT_ABBREV_MONTH);
            item.text = jsonObject.optString("message");
            item.type = jsonObject.optString("type");
            if("image".equals(item.type)){
                JSONArray image_urls = jsonObject.optJSONArray("image_urls");

                List<String> img_urls = new ArrayList<>();

                for (int j = 0; j < image_urls.length(); j++) {
                    img_urls.add(image_urls.optString(j));
                }
                item.cover = img_urls.get(0);
                item.photos = img_urls;
                item.photoCount = img_urls.size();
                // add thumb_urls
//
//                JSONArray thumb_urls = jsonObject.optJSONArray("thumb_urls");
//                List<String> img_thumb_urls = new ArrayList<>();
//                for (int j = 0; j < thumb_urls.length(); j++) {
//                    img_thumb_urls.add(thumb_urls.optString(j));
//                }
//
//                item.setThumbImages(img_thumb_urls);

            }

            feedUserDatas.add(item);
        }

        return feedUserDatas;
    }


    public static void requestMomentUrl(int pageNum, MomentUrlParseManager.IFetchMomentLister fetchMomentLister) {
        MomentUrlParseManager.getInstance().requestMoment(pageNum, fetchMomentLister);
    }


    public static List<CircleItem> createCircleDatas(JSONArray result) {
        if (result == null) {
            return new ArrayList<>();
        }
        List<CircleItem> circleDatas = new ArrayList<CircleItem>();
        int size = result.length();
        for (int i = 0; i < size; i++) {
            CircleItem item = new CircleItem();
            JSONObject jsonObject = result.optJSONObject(i);
            User user = new User();
            user.setName(jsonObject.optString("nickname"));
            user.setHeadUrl(jsonObject.optString("icon_url"));
            user.setId(jsonObject.optString("user_id"));

            item.setId(jsonObject.optString("post_id"));//post_id
            item.setUser(user);
            item.setContent(jsonObject.optString("message"));
            long timeStamp = jsonObject.optLong("created_at");
            item.setCreateTime(DateUtils.formatDateTime(App.getInstance(), timeStamp * 1000, DateUtils.FORMAT_24HOUR | DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_TIME
                    | DateUtils.FORMAT_SHOW_YEAR | DateUtils.LENGTH_LONG | DateUtils.FORMAT_ABBREV_MONTH));

            item.setFavorters(createFavortItemList(jsonObject.optJSONArray("like")));
            item.setComments(createCommentItemList(jsonObject.optJSONArray("comment")));
            String type = jsonObject.optString("type");
            if ("text".equals(type)) {
                item.setType(type);// 链接
//				item.setLinkImg("http://pics.sc.chinaz.com/Files/pic/icons128/2264/%E8%85%BE%E8%AE%AFQQ%E5%9B%BE%E6%A0%87%E4%B8%8B%E8%BD%BD1.png");
//				item.setLinkTitle("百度一下，你就知道");
//				item.setLinkUrl("http://www.baidu.com");
            }
			else if("image".equals(type)){
				item.setType(type);// 图片
                JSONArray image_urls = jsonObject.optJSONArray("image_urls");

                List<String> img_urls = new ArrayList<>();

                for (int j = 0; j < image_urls.length(); j++) {
                    img_urls.add(image_urls.optString(j));
                }

                item.setPhotos(img_urls);
                // add thumb_urls

                JSONArray thumb_urls = jsonObject.optJSONArray("thumb_urls");
                List<String> img_thumb_urls = new ArrayList<>();
                for (int j = 0; j < thumb_urls.length(); j++) {
                    img_thumb_urls.add(thumb_urls.optString(j));
                }

                item.setThumbImages(img_thumb_urls);

			}
//
// else if(type == 4){
//				item.setType("4");// 文字
//				item.setPhotos(createPhotos());
//			}else {
//				item.setType("3");// 视频
//				String videoUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.mp4";
//				String videoImgUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.jpg";
//				item.setVideoUrl(videoUrl);
//				item.setVideoImgUrl(videoImgUrl);
//			}
            circleDatas.add(item);
        }

        return circleDatas;
    }


    public static List<CircleItem> createCircleDatas() {
        List<CircleItem> circleDatas = new ArrayList<CircleItem>();
        for (int i = 0; i < 15; i++) {
            CircleItem item = new CircleItem();
            User user = getUser();
            item.setId(String.valueOf(circleId++));
            item.setUser(user);
            item.setContent(getContent());
            item.setCreateTime(App.getInstance().getString(R.string.date_info));
            int type = getRandomNum(10) % 2;
            if (type == 0) {
                item.setType("1");// 链接
                item.setLinkImg("http://pics.sc.chinaz.com/Files/pic/icons128/2264/%E8%85%BE%E8%AE%AFQQ%E5%9B%BE%E6%A0%87%E4%B8%8B%E8%BD%BD1.png");
                item.setLinkTitle("百度一下，你就知道");
                item.setLinkUrl("http://www.baidu.com");
            } else if (type == 1) {
                item.setType("2");// 图片
                item.setPhotos(createPhotos());
            } else {
                item.setType("3");// 视频
                String videoUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.mp4";
                String videoImgUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.jpg";
                item.setVideoUrl(videoUrl);
                item.setVideoImgUrl(videoImgUrl);
            }
            circleDatas.add(item);
        }

        return circleDatas;
    }

    public static User getUser() {
        return users.get(getRandomNum(users.size()));
    }

    public static String getContent() {
        return CONTENTS[getRandomNum(CONTENTS.length)];
    }

    public static int getRandomNum(int max) {
        Random random = new Random();
        int result = random.nextInt(max);
        return result;
    }


    public static String createPhoto() {
        List<String> photos = new ArrayList<String>();
        String photo = PHOTOS[getRandomNum(PHOTOS.length)];
        return photo;
    }

    public static List<String> createPhotos() {
        List<String> photos = new ArrayList<String>();
        int size = getRandomNum(PHOTOS.length);
        if (size > 0) {
            if (size > 9) {
                size = 9;
            }
            for (int i = 0; i < size; i++) {
                String photo = PHOTOS[getRandomNum(PHOTOS.length)];
                if (!photos.contains(photo)) {
                    photos.add(photo);
                } else {
                    i--;
                }
            }
        }
        return photos;
    }

    public static List<String> createPhotos(String url) {
        List<String> photos = new ArrayList<String>();
        photos.add(url);
        return photos;
    }


    public static List<FavortItem> createFavortItemList(JSONArray likeList) {

        List<FavortItem> items = new ArrayList<FavortItem>();
        List<String> history = new ArrayList<String>();
        if (likeList != null && likeList.length() > 0) {
            int size = likeList.length();
            for (int i = 0; i < size; i++) {
                try {
                    FavortItem newItem = createFavortItem(likeList.getJSONObject(i));
                    items.add(newItem);

//                    String userid = newItem.getUser().getId();
//                    if (!history.contains(userid)) {
//                        items.add(newItem);
//                        history.add(userid);
//                    } else {
//                        i--;
//                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        return items;
    }

    public static FavortItem createFavortItem(JSONObject likeUser) {
        FavortItem item = new FavortItem();
        item.setId("sss="+likeUser.toString());
        User user = new User();
        user.setId(likeUser.optString("user_id"));
        user.setName(likeUser.optString("nickname"));
        item.setUser(user);
        return item;
    }

    public static FavortItem createCurUserFavortItem() {
        FavortItem item = new FavortItem();
        item.setId(String.valueOf(favortId++));
        item.setUser(curUser);
        return item;
    }


    //	"comment": [
//	I/SNSPresenter(13382):         {
//		I/SNSPresenter(13382):           "content": "Hhhhhhhhhhhhhhh",
//				I/SNSPresenter(13382):           "comment_time": 1483950695,
//				I/SNSPresenter(13382):           "nickname": "yongjun",
//				I/SNSPresenter(13382):           "user_id": "subusr1474982458000"
//		I/SNSPresenter(13382):         }
//	I/SNSPresenter(13382):       ]
    public static List<CommentItem> createCommentItemList(JSONArray commentList) {
        List<CommentItem> items = new ArrayList<CommentItem>();
        if (commentList != null && commentList.length() > 0) {
            int size = commentList.length();
            for (int i = 0; i < size; i++) {
                try {
                    items.add(createComment(commentList.getJSONObject(i)));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }


        return items;
    }

    public static CommentItem createComment(JSONObject comment) {
        CommentItem item = new CommentItem();
        item.setId(comment.optString("comment_id"));
        item.setContent(comment.optString("content"));
        User user = new User();
        user.setId(comment.optString("user_id"));
        user.setName(comment.optString("nickname"));
        item.setUser(user);

        String replyUserId = comment.optString("reply_user_id");
        if (!TextUtils.isEmpty(replyUserId)) {
            User replyUser = new User();
            replyUser.setId(replyUserId);
            replyUser.setName(comment.optString("reply_nickname"));
            item.setToReplyUser(replyUser);
        }
        return item;
    }

    /**
     * 创建发布评论
     *
     * @return
     */
    public static CommentItem createPublicComment(String content) {
        CommentItem item = new CommentItem();
        item.setId(String.valueOf(commentId++));
        item.setContent(content);
        item.setUser(curUser);
        return item;
    }

    /**
     * 创建回复评论
     *
     * @return
     */
    public static CommentItem createReplyComment(User replyUser, String content) {
        CommentItem item = new CommentItem();
        item.setId(String.valueOf(commentId++));
        item.setContent(content);
        item.setUser(curUser);
        item.setToReplyUser(replyUser);
        return item;
    }


    public static CircleItem createVideoItem(String videoUrl, String imgUrl) {
        CircleItem item = new CircleItem();
        item.setId(String.valueOf(circleId++));
        item.setUser(curUser);
        //item.setContent(getContent());
        item.setCreateTime(App.getInstance().getString(R.string.date_info));

        //item.setFavorters(createFavortItemList());
        //item.setComments(createCommentItemList());
        item.setType("3");// 图片
        item.setVideoUrl(videoUrl);
        item.setVideoImgUrl(imgUrl);
        return item;
    }
}
