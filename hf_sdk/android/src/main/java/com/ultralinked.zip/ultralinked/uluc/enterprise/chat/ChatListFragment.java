package com.ultralinked.uluc.enterprise.chat;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.GuideViewHelper;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.QrScanActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.widget.TitleActionMenu.ActionItem;
import com.ultralinked.uluc.enterprise.baseui.widget.TitleActionMenu.TitlePopup;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.GroupChatImActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.NewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.selectmember.SelectMemberActivity;
import com.ultralinked.uluc.enterprise.http.netstatus.NetChangeCallBack;
import com.ultralinked.uluc.enterprise.http.netstatus.NetStatusReceiver;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import java.util.ArrayList;
import java.util.List;

import rx.Subscription;
import rx.functions.Action1;


public class ChatListFragment extends BaseFragment implements ChatViewFab, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener, TextWatcher {

    ListView listView;
    EditText etSearch;
    TextView titleCenter;
    TextView emptyWords;

    View loadingView;

    ChatAdapter chatAdapter;
    ChatPresenter presenter;

    private int clickCount;
    private long lastClickTime = -1;
    private String no_conversations;
    private EditText editText;
    private TextView add;
    private ArrayList<String> inviteMembers;
    private LinearLayout noNetWorkLayout;
    private boolean isPrivate;
    private boolean isGroupChatList;
    private static final String TAG = "ChatListFragment";
    private boolean isSearch;
    private Subscription rxSubscription;


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if(rxSubscription!=null&&!rxSubscription.isUnsubscribed()) {
            rxSubscription.unsubscribe();
        }

        NetStatusReceiver.unRegisterNetworkStateReceiver(getActivity());
        NetStatusReceiver.removeRegisterNetChangeCallBack(netChangeCallBack);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MLoginStatusChangedReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MsgIncomingReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mGroupInfoChangedReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mGroupMemberChangedReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mMessageFromHistoryReceiver);
        TCAgent.onPageEnd(getActivity(),"聊天列表");
    }
  boolean firstLoad = false;
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        TCAgent.onPageStart(getActivity(),"聊天列表");
        registerReceiver();
        Bundle bundle = getArguments();
        if (bundle != null) {// when start from group chat in contacts user interface
            isGroupChatList = bundle.getBoolean("group_chats", false);
            isPrivate = bundle.getBoolean("isPrivate", false);
            if (isGroupChatList) {//for group chats view
                titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.group_chats);
            } else {//for chat view
                titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.chat);
            }
        } else {
            Log.i(TAG, "bundle is null.");
        }
        bind(R.id.left_back).setVisibility(isGroupChatList ? View.VISIBLE : View.GONE);

        // rxSubscription是一个Subscription的全局变量，这段代码可以在onCreate/onStart等生命周期内
        rxSubscription = RxBus.getDefault().toObservable(Conversation.class)
                .subscribe(new Action1<Conversation>() {
                               @Override
                               public void call(Conversation conversation) {
                                   Log.i(TAG,"update the conversation~~~~");
                                   chatAdapter.updateItem(conversation);

                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG,"update the subscribe error:"+ android.util.Log.getStackTraceString(throwable));
                            }
                        });

        firstLoad = true;
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshConversationList();
            }
        }, 600);
        initPopWindow();
        return view;
    }


    TitlePopup titlePopup;
    private void initPopWindow() {
        // 实例化标题栏弹窗
        titlePopup = new TitlePopup(getActivity(), ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        titlePopup.setItemOnClickListener(onitemClick);
        // 给标题栏弹窗添加子类
        titlePopup.addAction(new ActionItem(getActivity(), R.string.create_group,
                R.mipmap.create_group_chat_btn));
        titlePopup.addAction(new ActionItem(getActivity(), R.string.add_friend,
                R.mipmap.add_friend_btn));
        titlePopup.addAction(new ActionItem(getActivity(), R.string.scan_barcode,
                R.mipmap.scan_bar_code_btn));
//        titlePopup.addAction(new ActionItem(this, R.string.menu_money,
//                R.drawable.abv));
    }


    private TitlePopup.OnItemOnClickListener onitemClick = new TitlePopup.OnItemOnClickListener() {

        @Override
        public void onItemClick(ActionItem item, int position) {
            // mLoadingDialog.show();
            switch (position) {
                case 0:// 发起群聊
                    SelectMemberActivity.startForResult(ChatListFragment.this, SelectMemberActivity.REQUEST_CREATE_CHAT);
                    break;
                case 1:// 添加朋友
                    startActivity(new Intent(getActivity(),NewFriendActicity.class));
                    break;
                case 2:// 扫一扫
                {
                    PackageManager pm = getActivity().getPackageManager();
                    String packageName= getActivity().getPackageName();
                    int checkPm = pm.checkPermission(Manifest.permission.CAMERA, packageName);


                    int checkPm2 = pm.checkPermission(Manifest.permission.RECORD_AUDIO, packageName);


                    if(checkPm!= PackageManager.PERMISSION_GRANTED||checkPm2!= PackageManager.PERMISSION_GRANTED){
                        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},0x9999);

                    }else{
                        startActivity(new Intent(getActivity(), QrScanActivity.class));
                    }

                }

                    break;
//                case 3:// 收钱
//                    Utils.start_Activity(MainActivity.this, GetMoneyActivity.class);
//                    break;
                default:
                    break;
            }
        }
    };


    @Override
    public void onPause() {
        super.onPause();
        KeyBoardUtils.closeInputMethod(getActivity());

    }

    private void registerReceiver() {
        NetStatusReceiver.registerNetworkStateReceiver(getActivity());
        NetStatusReceiver.registerNetChangeCallBack(netChangeCallBack);

        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MLoginStatusChangedReceiver, new IntentFilter(MLoginApi.EVENT_LOGIN_STATUS_CHANGE));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MsgIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_INCOMING));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mGroupInfoChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_INFO_CHANGED));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mGroupMemberChangedReceiver, new IntentFilter(MessagingApi.EVENT_GROUP_MEMBER_CHANGE));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mMessageFromHistoryReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_FROM_HISTORY));

    }

    private NetChangeCallBack netChangeCallBack = new NetChangeCallBack() {
        @Override
        public void onNetConnected(NetUtil.NetType type) {
            Log.d(TAG,"onNetConnected");
            goneView(noNetWorkLayout);

        }

        @Override
        public void onNetDisConnected() {
            Log.d(TAG,"onNetDisConnected");
            visibleView(noNetWorkLayout);
        }
    };
    private BroadcastReceiver MLoginStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                visibleView(titleCenter);
                goneView(loadingView);

                int loginStatus = intent.getIntExtra(MLoginApi.PARAM_LOGIN_STATUS, -1);
                String status = "";
                switch (loginStatus) {
                    case MLoginApi.STATUS_CONNECTING:
                        visibleView(loadingView);
                        goneView(titleCenter);
                        status = "status_connecting";
                        break;
                    case MLoginApi.STATUS_DISCONNECTED:
                        status = "status_disconnected";
                        visibleView(noNetWorkLayout);
                        break;
                    case MLoginApi.STATUS_RECONNECT:
                        status = "status_reconnect";
                        break;
                    case MLoginApi.STATUS_REGISTER_ACCOUNT_ERROR:
                        status = "status_register_account_error";
                        break;
                    case MLoginApi.STATUS_REGISTER_OK:
                        status = "status_register_ok";
                        break;
                    case MLoginApi.STATUS_SERVER_FORCE_LOGOUT:
                        status = "status_server_force_logout";
                        break;
                    case MLoginApi.STATUS_USER_LOGOUT:
                        status = "status_user_logout";
                        break;
                    default:
                        status = "unknown";

                }

                Log.i(TAG, "MLoginStatusChangedReceiver~~  status:" + status);
            }
        }
    };
    private BroadcastReceiver mGroupInfoChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i(TAG,"mGroupInfoChangedReceiver~~ ");
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);

            checkIsCreateGroup(intent, status);

            if (isResumed()) {
                refreshConversationList();
            }
        }
    };

    /**
     *
     * @param intent
     * @param status
     * @return
     */
    private boolean checkIsCreateGroup(Intent intent, int status) {
        String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
        //create group
        if (MessagingApi.JOIN_GROUP_SUCCESS == status) {
            // need invite all member here
            GroupConversation groupConversation = GroupConversation.getConversationByGroupId(groupId);
            if (groupConversation==null){
                Log.i(TAG,"get conversation is null");
                return true;
            }
            if (inviteMembers != null && inviteMembers.size() > 0) {
                groupConversation.invitesToGroup(inviteMembers);
                Log.i(TAG, " GroupCreateBroadCastReceiver  topicName:" + groupConversation.getGroupTopic());
                inviteMembers.clear();
            }


        } else  {//create group failure
            Log.i(TAG,"get conversation is failed");
        }
        return false;
    }



    Runnable historyRunnable = new Runnable() {
        @Override
        public void run() {
            refreshConversationList();
        }
    };

  private BroadcastReceiver mMessageFromHistoryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String chatID = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
            int chatType = intent.getIntExtra(MessagingApi.PARAM_CHAT_TYPE,-1);
            if (chatType == Conversation.GROUP_CHAT){

                if (isResumed()) {
                    mHandler.removeCallbacks(historyRunnable);
                    mHandler.postDelayed(historyRunnable,100);

                }
            }
        }
    };

    private BroadcastReceiver mGroupMemberChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(MessagingApi.PARAM_STATUS, -1);
            Log.i(TAG,"mGroupMemberChangedReceiver~~ ");
            String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
            if (isResumed()) {
                refreshConversationList();
            }
        }
    };

    private BroadcastReceiver MsgIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

                if (msg == null) {
                    Log.i(TAG, "incoming msg is null ");
                    return;
                }
                Log.i(TAG, "MsgIncomingReceiver~~ msgKeyId:" + msg.getKeyId() + " conversationId:" + msg.getConversationId());
//                final Conversation recevieConversation = MessagingApi.getConversationById(msg.getConversationId());
//                if (recevieConversation == null) {
//                    Log.i(TAG, "conversation is null, the conversationId:" + msg.getConversationId());
//                    return;
//                }

                if (isResumed()) {//界面可见时才刷新，减少资源消耗
                    refreshConversationList();
                }


            }

        }
    };


    private void refreshConversationList() {
        if (isSearch) {
            Log.i(TAG,"current is serach mode, return refresh conversation~~~");
            return;
        }

        presenter.initData(isGroupChatList,isPrivate);

    }

    Handler mHandler = new Handler();
    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.fragment_chat;
    }

    @Override
    public void onResume() {
        super.onResume();

        etSearch.getText().clear();
        etSearch.setCursorVisible(false);

        isSearch = false;

        if (firstLoad){
            firstLoad = false;
        }else{
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    refreshConversationList();
                }
            }, 300);
        }

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

    }

    @Override
    public void initView(Bundle savedInstanceState) {

        noNetWorkLayout = bind(R.id.no_network_layout);
        goneView(noNetWorkLayout);
        boolean available = NetUtil.isNetworkAvailable(getActivity());
        if (!available) {
            visibleView(noNetWorkLayout);
        }
        noNetWorkLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (noNetWorkLayout.isShown()) {
                    NetUtil.goToSystemSettingsActivity(getActivity());
                }
                if (NetUtil.isNetworkAvailable(getActivity())&&!MLoginApi.isLogin() && !MLoginApi.isConnecting) {
                    App.grLogin(false);
                }
            }
        });

        loadingView = bind(R.id.loading_view);
        goneView(loadingView);
        listView = bind(R.id.lv_chat);
        emptyWords = bind(R.id.empty_conversation);
        etSearch = bind(R.id.search_edittext);
        titleCenter = bind(R.id.titleCenter);

        initListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                KeyBoardUtils.openKeybord(etSearch,getActivity());

            }
        }, R.id.searchParent);

        titleCenter.setText(com.holdingfuture.flutterapp.hfsdk.R.string.chat);
        add = bind(R.id.titleRight);
        add.setText("");
        try{
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) add.getLayoutParams();
            layoutParams.rightMargin = ScreenUtils.dp2px(getActivity(),0);
            add.setLayoutParams(layoutParams);
        }catch (Exception e){
            e.printStackTrace();
        }
        Drawable drawable = getResources().getDrawable(com.holdingfuture.flutterapp.hfsdk.R.mipmap.add);
        int iconSize = getResources().getDimensionPixelSize(com.holdingfuture.flutterapp.hfsdk.R.dimen.px_20_0_dp);
        drawable.setBounds(0, 0, iconSize, iconSize); //设置边界
        add.setCompoundDrawables(null, null, drawable, null);//画在右边
        ImageUtils.buttonEffect(add);

        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                showToast("ddd");
                //  SelectMemberActivity.startForResult(ChatListFragment.this, SelectMemberActivity.REQUEST_CREATE_GROUPCHAT);

                titlePopup.show(bind(R.id.top_bar));

            }
        });


        titleCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long curentTime = System.currentTimeMillis();
                if (lastClickTime == -1) {
                    lastClickTime = curentTime;
                }
                if (curentTime - lastClickTime < 2000) {
                    clickCount++;
                } else {
                    clickCount = 0;
                    lastClickTime = -1;
                }
                if (clickCount == 5) {
                    //do somethiing.
                }
                Log.i(TAG, " clickCount:" + clickCount);

            }
        });
        editText = bind(R.id.input_edit_text);

        presenter = new ChatPresenter(this);

        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_FLING|| scrollState == SCROLL_STATE_TOUCH_SCROLL){
                    if (chatAdapter!=null){
                        chatAdapter.closeCurrentSwipeView();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });


        etSearch.addTextChangedListener(this);



        //checkuserGuide.
        GuideViewHelper.checkNeedDisPlayUserGuideInfo(getActivity(),add,"addfriend",getString(R.string.add_friend),getString(R.string.create_friend_msg_tips),null);

        // GuideViewHelper.checkNeedDisPlayUserGuideInfo(getActivity(),add,"createGroup",getString(R.string.create_group),getString(R.string.create_group_msg_tips),null);
    }

    @Override
    public void updateConversation(List<Conversation> conversations) {

        if (!isAdded()){
            return;
        }
        if (conversations != null) {
            Log.i(TAG, "conversations size:" + conversations.size());
            if (chatAdapter == null) {
                chatAdapter = new ChatAdapter((BaseActivity) getActivity(), com.holdingfuture.flutterapp.hfsdk.R.layout.item_chat, conversations);
                chatAdapter.setConversationItemListener(new ChatAdapter.OnConversationItemListener() {
                    @Override
                    public void removeUnread(int unreadMsgCount, Conversation conversation) {
                        updateUnreadMessageCount(unreadMsgCount,ChatModule.Decrease_Message_Counts);
                    }
                });
                listView.setAdapter(chatAdapter);
            } else {
                chatAdapter.updateList(conversations);
            }
        } else {
            Log.d(TAG,"no data find");
        }
        try {

            no_conversations = getString(R.string.no_conversations,getString(R.string.app_name));
            emptyWords.setText(no_conversations);
            listView.setEmptyView(bind(R.id.conversation_relative));
        }catch (Exception except){
            Log.d(TAG,"updateConversation occurs error :"+ android.util.Log.getStackTraceString(except));
        }
    }

    @Override
    public void updateUnreadMessageCount(final int count,final int flags) {
        //warning not in ui thread.
        if (isActivityDestryed()){
            return;
        }
        if (getActivity() instanceof  MainActivity){
           final MainActivity activity  = (MainActivity) getActivity();
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    activity.updateUnreadMessageCount(count,flags);
                }
            });
        }

    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        if (chatAdapter.closeCurrentSwipeView()){
            return;
        }

        Conversation conversation = (Conversation) parent.getAdapter().getItem(position);
        String chatIdentity;
        if (conversation.isGroup()) {
            chatIdentity = ((GroupConversation) conversation).getGroupID();
            GroupChatImActivity.launchToGroupChatIm(mContext, chatIdentity, conversation.conversationFlag);
        } else {
            chatIdentity = conversation.getContactNumber();
            SingleChatImActivity.launchToSingleChatIm(mContext, chatIdentity, conversation.conversationFlag);
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//        showToast("long click position:" + position);


        if (chatAdapter.closeCurrentSwipeView()){
            return true;
        }

        final Conversation conversation = (Conversation) parent.getAdapter().getItem(position);
        String title = (String) conversation.getTag();

        String aboutMute = conversation.isMute() ? "Unmute chat" : "Mute chat";
        final String topUpStr = conversation.isTopUp ? mContext.getString(com.holdingfuture.flutterapp.hfsdk.R.string.cancel_stick_on_top) : mContext.getString(com.holdingfuture.flutterapp.hfsdk.R.string.stick_on_top);

        final String finalTitle = title;

        DialogManager.showItemsDialog(mContext, title, new String[]{topUpStr, mContext.getString(com.holdingfuture.flutterapp.hfsdk.R.string.delete_conversation)}, view, new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                switch (position) {
                    case 0:
//                        conversation.setMute(!conversation.isMute());
//                        Log.i(TAG, "set conversation mute:" + conversation.isMute() + " conversation name:" + finalTitle);
                        conversation.topUp(!conversation.isTopUp);
                        refreshConversationList();
                        break;
                    case 1:
                        String content = getActivity().getString(com.holdingfuture.flutterapp.hfsdk.R.string.delete_conversation_tips);
                        String replaceMent = finalTitle;
                        if (replaceMent == null) {
                            Log.i(TAG, "replaceMent is null.");
                            replaceMent = "";
                        }
                        content = content.replace("xxx", replaceMent);
                        DialogManager.showOKCancelDialog(mContext, "",content, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                ChatModule.deleteConversation(conversation);
                                chatAdapter.removeItem(conversation);
                                Log.i(TAG, "delete conversation, conversationId:" + conversation.getConversationId() + " conversation name:" + finalTitle);
                                refreshConversationList();
                            }
                        }, null);
                        break;

                }
            }
        });

        // 必须返回true,否则还会再回调onItemClick事件
        return true;
    }

    //文字输入的监听
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {


    }

    @Override
    public void afterTextChanged(Editable s) {
        if (s == null || s.length() == 0) {
            isSearch = false;
            emptyWords.setText(no_conversations);
        } else {
            isSearch = true;
            emptyWords.setText(R.string.no_search_result);
        }
        if (chatAdapter!=null) {
            chatAdapter.getFilter().filter(s);
        }


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i(TAG, "onActivityResult  requestCode"+requestCode+"  resultCode="+requestCode);
        if (resultCode == Activity.RESULT_OK) {
            if(data==null){
                Log.i(TAG,"data is null ");
                return;
            }

            if(requestCode==SelectMemberActivity.REQUEST_CREATE_CHAT){
                String ids = data.getStringExtra(SelectMemberActivity.CREATE_SIGNLE);
                Log.i(TAG, "ids is " + ids);

                if(TextUtils.isEmpty(ids)){
                    String topicName=data.getStringExtra("topic_name");
                    inviteMembers = data.getStringArrayListExtra(SelectMemberActivity.CREATE_GROUP_MEMBER);

                    if(inviteMembers ==null|| inviteMembers.size()==0){
                        Log.i(TAG,"members is null");
                        return;
                    }
                    MessagingApi.createGroup(topicName);
                }else {
                    Conversation conversation = MessagingApi.getConversation(ids);
                    SingleChatImActivity.launchToSingleChatIm(mContext, conversation.getContactNumber(),conversation.conversationFlag);
                }
            }
        }
    }



}
