package com.ultralinked.uluc.enterprise.more;


import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.tendcloud.tenddata.TCAgent;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.ultralinked.uluc.enterprise.QrScanActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.common.PasswordLockerHelper;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.ui.secret.SecretActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.uluc.enterprise.moments.activity.MomentsActivity;
import com.ultralinked.uluc.enterprise.moments.bean.NewMomentItem;
import com.ultralinked.uluc.enterprise.pay.MyAccountActivity;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.bingoogolapple.badgeview.BGABadgeView;
import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class FragmentMore extends BaseFragment implements View.OnClickListener {

    private ImageView ivUserPhoto;
    private TextView tvUsername;
    private View company, setting, scanQrCode, moments;
    private MainActivity activity;

    public static int DETAIL_CODE = 1111;
    public static int Setting1_CODE = 2222;
    public static int Setting2_CODE = 3333;
    public static int Setting_COMPANY_CODE = 4444;
    public static int Scan_Qr_Code_CODE = 5555;

    public static int Scan_Qr_Code_permission_CODE = 6666;

    private UserInfo info;
    public static List<NewMomentItem> newMommetsItems = new ArrayList<>();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (MainActivity) context;
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.fragment_more;
    }

    @Override
    public void onOptionsMenuClosed(Menu menu) {
        super.onOptionsMenuClosed(menu);
    }

    private void showMomentsDot(boolean showMomentsDot) {
        hasMoments = showMomentsDot;
        try {
            if (showMomentsDot) {
                momentsBadge.getBadgeViewHelper().setDragable(false);
                momentsBadge.showCirclePointBadge();
            } else {
                momentsBadge.hiddenBadge();
            }
            updateMeDot();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMeDot() {
        try {
            MainActivity mainActivity = (MainActivity) getActivity();
            mainActivity.updateMeBadge(hasMoments || hasPrivateUnreadMsg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    BGABadgeView momentsBadge, privateContactBadge;

    @Override
    public void initView(Bundle savedInstanceState) {
        bind(R.id.left_back).setVisibility(View.GONE);
        bind(R.id.titleRight).setVisibility(View.GONE);
        ((TextView) bind(R.id.titleCenter)).setText(R.string.me);
        ivUserPhoto = bind(R.id.ivUserPhoto);
        tvUsername = bind(R.id.tvUsername);
        momentsBadge = bind(R.id.moments_badge);
        privateContactBadge = bind(R.id.txt_private_contact_badge);
        company = bind(R.id.company);
        setting = bind(R.id.setting);
        moments = bind(R.id.moments);
        scanQrCode = bind(R.id.scan_qr_code);
        goneView(scanQrCode);
//        if (!ApiManager.IsStage()) {
//            goneView(moments);
//            goneView(bind(R.id.momnets_line));
//        }
        initListener(this, company, setting, scanQrCode, moments, bind(R.id.private_contact)
                , bind(R.id.payment), bind(R.id.user_info_container), bind(R.id.share));
        getUserInfo();
        queryLastestMomentsFromServer();
        queryUneadMomentsFromServer();
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(MsgIncomingReceiver, new IntentFilter(MessagingApi.EVENT_MESSAGE_INCOMING));

    }

    boolean hasPrivateUnreadMsg, hasMoments;

    private void getUserInfo() {
        start();
        info = SPUtil.getUserInfo();
        Log.i(TAG, "user profile getUserInfo.");
        if (info != null) {
            Log.i(TAG, " succ getUserInfo info." + info.toString());
            updateUserInfo(info);
        } else {
            Log.i(TAG, " getUserInfo info error.");
        }

        ApiManager.getInstance().getUserInfo()
                .subscribeOn(Schedulers.io())
                .compose(this.<UserInfo>bindToLifecycle())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<UserInfo>() {
                    @Override
                    public void call(UserInfo userInfo) {
                        if (userInfo != null && userInfo.getId() != null) {
                            getUserInfoSuccess(userInfo);
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {

                        Log.i(TAG, "get user info fail. error info:" + android.util.Log.getStackTraceString(throwable));
                        if (info == null) {
                            info = new UserInfo();
                        }

                    }
                });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.user_info_container:
                Intent intent = new Intent(activity, SettingPersonalActivity.class);
                intent.putExtra("user_info", (Parcelable) info);
                startActivityForResult(intent, DETAIL_CODE);
                break;
            case R.id.company:

                if (!SPUtil.getUserHasCompany()) {
                    intent = new Intent(getActivity(), CreateCompanyActivity.class);
                    startActivity(intent);
                } else {

                    startActivityForResult(new Intent(activity, SettingCompanyActivity.class), Setting_COMPANY_CODE);
                }

                break;
            case R.id.setting:
                startActivityForResult(new Intent(activity, Setting1Activity.class), Setting1_CODE);
                break;
            case R.id.scan_qr_code:
                PackageManager pm = getActivity().getPackageManager();
                String packageName = getActivity().getPackageName();
                int checkPm = pm.checkPermission(Manifest.permission.CAMERA, packageName);

                int checkPm2 = pm.checkPermission(Manifest.permission.RECORD_AUDIO, packageName);


                if (checkPm != PackageManager.PERMISSION_GRANTED || checkPm2 != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO},
                            Scan_Qr_Code_permission_CODE);
                } else {
                    startActivityForResult(new Intent(activity, QrScanActivity.class), Scan_Qr_Code_CODE);
                }
                break;
            case R.id.moments:
                Intent momentsIntent = new Intent(activity, MomentsActivity.class);

                startActivity(momentsIntent);

                break;
            case R.id.vcard_code_scan:
                intent = new Intent(getActivity(), MyQRCodeActivity.class);
                intent.putExtra("user_info", (Parcelable) info);
                startActivity(intent);
                break;
            case R.id.private_contact:
                go2SecretChat();
                break;
            case R.id.payment:
                startActivity(new Intent(activity, MyAccountActivity.class));
                break;
            case R.id.share:
//                startActivity(new Intent(activity, ShareActivity.class));
                getShareUrl();
                break;
        }
    }

    private void getShareUrl() {
        if (!NetUtil.isNetworkAvailable(activity)) {
            showToast(activity.getString(com.holdingfuture.flutterapp.hfsdk.R.string.check_network));
            return;
        }
        activity.showDialog(getString(R.string.loading));
        ApiManager.getInstance().getShareUrl()
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(3, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.e(TAG, "get share url success: ");
                        activity.closeDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        activity.showToast(R.string.share_fail);
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                        activity.closeDialog();
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        try {
                            JSONObject response = new JSONObject(responseBody.string());
                            if (response.optInt("code") == 202) {
                                String invitation_url = response.optString("description");
                                if (!TextUtils.isEmpty(invitation_url)) {
                                    ShareUtils.tellFriend(activity, invitation_url);
                                }
                            }
                        } catch (Exception e) {
                            Log.e(TAG, android.util.Log.getStackTraceString(e));
                        }
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == DETAIL_CODE) {
                info = data.getParcelableExtra("user_info");
                if (info == null || info.getIcon_url() == null) {
                    Log.i(TAG, "info is null");
                    return;
                }
                getUserInfoSuccess(info);

            } else if (requestCode == Setting1_CODE) {
                getUserInfo();

            } else if (requestCode == Setting2_CODE) {

            } else if (requestCode == Setting_COMPANY_CODE) {

            } else if (requestCode == Scan_Qr_Code_CODE) {

            }
        }

        Log.i(TAG, "requestCode=" + requestCode);
    }

    void updateUserInfo(UserInfo userInfo) {
        tvUsername.setText(UserInfo.getDisplayName(userInfo));
        ImageUtils.loadCircleImage(activity, ivUserPhoto, userInfo.getIcon_url(), ImageUtils.getDefaultContactImageResource(info.getId()));

    }

    public void getUserInfoSuccess(UserInfo userInfo) {
        Log.i(TAG, "getUserInfoSuccess name is " + userInfo.toString());
        SPUtil.saveUserInfo(userInfo);
        info = userInfo;
        Log.i(TAG, userInfo.getName());
        updateUserInfo(userInfo);
    }

    public void start() {
        Log.i(TAG);
    }


    private boolean priviteModelChecked;
    private boolean isPrivateModel = false;

    public boolean isPrivateModel() {
        return isPrivateModel;
    }

    @Override
    public void onResume() {
        super.onResume();
        showMomentsDot(false);
        isPrivateModel = false;
        showPrivateDot();
    }


    @Override
    public void onHidden(boolean isHidden) {
        super.onHidden(isHidden);
        if (!isHidden) {
            queryLastestMomentsFromServer();
            queryUneadMomentsFromServer();
        }
        showPrivateDot();
    }

    private void showPrivateDot() {
        try {
            final MainActivity mainActivity = (MainActivity) getActivity();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if (mainActivity == null){
                        return;
                    }

                    int unreadCount = mainActivity.getPrivateUnreadMessageCount();
                    if (unreadCount > 0) {
                        hasPrivateUnreadMsg = true;
                        privateContactBadge.post(new Runnable() {
                            @Override
                            public void run() {
                                privateContactBadge.showCirclePointBadge();
                                updateMeDot();
                            }
                        });
                    } else {
                        hasPrivateUnreadMsg = false;
                        privateContactBadge.post(new Runnable() {
                            @Override
                            public void run() {
                                privateContactBadge.hiddenBadge();
                                updateMeDot();
                            }
                        });
                    }

                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void lunchSecretChat() {
        isPrivateModel = true;
        startActivity(new Intent(getActivity(), SecretActivity.class));
    }

    private void go2SecretChat() {


//        if (priviteModelChecked){
//            lunchSecretChat();
//            return;
//        }

        //first detect password exist or not?
        final String oldpsd = SPUtil.getUserPrivatePsd();
        if (!TextUtils.isEmpty(oldpsd) /*&& !priviteModelChecked*/) {

            PasswordLockerHelper.getInstance().showUnlockDialog(getActivity(), PasswordLockerHelper.INPUT_PASSWORD,
                    new PasswordLockerHelper.OnDialogListener() {

                        @Override
                        public void onCancelClick() {

                        }

                        @Override
                        public void onOkClick(String password) {

                            // priviteModelChecked = true;
                            lunchSecretChat();

                        }
                    });

        } else {

            PasswordLockerHelper.getInstance().setlockDialog(getActivity(), new PasswordLockerHelper.OnDialogListener() {

                @Override
                public void onCancelClick() {
                    //showToast("Cancel");
                }

                @Override
                public void onOkClick(String password) {


                    PasswordLockerHelper.getInstance().setNewPsdForPrivate((BaseActivity) getActivity(), password, new PasswordLockerHelper.OnPasswordSetSuccessCallback() {
                        @Override
                        public void onPasswordSetSucc() {
                            lunchSecretChat();
                        }
                    });


                }
            });
        }

    }


    private BroadcastReceiver MsgIncomingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isAdded()) {
                final Message msg = (Message) intent.getSerializableExtra(MessagingApi.PARAM_MESSAGE);

                if (msg == null) {
                    Log.i(TAG, "incoming msg is null ");
                    return;
                }
                Log.i(TAG, "MsgIncomingReceiver~~ msgKeyId:" + msg.getKeyId() + " conversationId:" + msg.getConversationId());
                showPrivateDot();

            }

        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(MsgIncomingReceiver);
    }


    void queryUneadMomentsFromServer() {

        ApiManager.getInstance().queryHasUnreadMomentsItems()
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryUneadMomentsFromServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                String result = object.optString("result");
                                Type sToken = new TypeToken<List<NewMomentItem>>() {
                                }.getType();
                                Gson gson = new GsonBuilder().serializeNulls().create();
                                List<NewMomentItem> pendingList = gson.fromJson(result, sToken);
                                if (pendingList != null) {

                                    if (pendingList.size() > 0) {
                                        newMommetsItems = pendingList;
                                        showMomentsDot(true);
                                    }
                                }

                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse queryUneadMomentsFromServer error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "queryUneadMomentsFromServer result:" + rs);
                    }
                });

    }


    void queryLastestMomentsFromServer() {

        ApiManager.getInstance().queryMomentsStatus()
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryLastestMomentsFromServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                boolean hasNewMoments = object.optBoolean("result");
                                if (hasNewMoments) {
                                    showMomentsDot(true);
                                }

                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse queryLastestMomentsFromServer error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "queryLastestMomentsFromServer result:" + rs);
                    }
                });

    }


}
