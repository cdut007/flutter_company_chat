package com.ultralinked.uluc.enterprise.service;


import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.Log;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.VoiceRecord;
import com.ultralinked.voip.api.utils.FileUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;


public class PlayMusicService {

    public static final  String TAG="PlayMusicService";


    public  boolean isPlayed;



    private  int during;//sec

    public int getDuration() {
        return during;
    }


    public boolean seek(int currentPositon,String path) {
        Log.i(TAG, "playStop():");
        if (null == mPlayVoice) {
            mPlayVoice = new PlayVoice();
        }
        boolean flag = true;
        if (isPlaying()) {//
            mPlayVoice.seek(currentPositon);
            return flag;
        }

        if (isCurrentPlaying()) {
            // not allow move
            return false;
        }

        mPlayVoice.stop();

        if (!FileUtils.isFileExist(path))
            flag = false;
        else {

            mPlayVoice.start(path, currentPositon, 1,
                    false);
            mPlayVoice.setDuration(getDuration() * 1000);
        }
//        if (!msg.isRead()) {
//            msg.read();
//        }
        return flag;
    }

    public interface OnEndPlay{

        void finish(int msgId, int reason);
    }



    public boolean playOrStop(String path) {

        Log.i(TAG, "playStop() keyid:");
        if (null == mPlayVoice) {
            mPlayVoice = new PlayVoice();
        }
        boolean flag = true;
        if (isPlaying()) {
            mPlayVoice.stop();

        } else {
            if (HasCurrentPlayingID()) {
                mPlayVoice.stop();
            }

            if (TextUtils.isEmpty(path))
                flag = false;
            else {

                mPlayVoice.start(path, 0,
                        1, true);
                mPlayVoice.setDuration(getDuration() * 1000);


            }
        }
//        if (!msg.isRead()) {
//            msg.read();
//        }
        return flag;
    }

    public boolean isPlaying() {
        return mPlayingId == 1;
    }




    public int getDuring() {
        return during;
    }

    public void setDuring(int during) {
        this.during = during;
    }




    public static final int PLAY_STATUS_START = 1;
    public static final int PLAY_STATUS_STOP = 2;
    public static final int PLAY_STATUS_COMPLETION = 3;

    private transient static PlayVoice mPlayVoice = null;
    private static long mPlayingId = -1L;


    public interface RefreshListener {
        void refresh(int pos);
    }






    private static boolean HasCurrentPlayingID() {
        return (null != mPlayVoice) && (mPlayingId != -1L);
    }

    public static boolean isCurrentPlaying() {
        if ((null != mPlayVoice) && (mPlayingId != -1L)) {
            try {
                return mPlayVoice.isPlaying();
            } catch (IllegalStateException e) {
                // TODO: handle exception
                e.printStackTrace();
            }

        }
        return false;
    }



    public static long getCurrentPlayingId() {
        // TODO Auto-generated method stub
        return mPlayingId;
    }

    public static long getCurrentPlayingDuring() {
        if ((null != mPlayVoice) && (mPlayingId != -1L)) {
            return mPlayVoice.getCurrentPlayingDuring();
        }
        return 0;
    }



    public static void stopCurrentVoice() {
        if ((null != mPlayVoice) && (mPlayingId != -1L))
            mPlayVoice.stop();
    }

    public static boolean pauseOrResume(int pos) {
        if ((null != mPlayVoice) && (mPlayingId != -1L))
            return mPlayVoice.pauseOrResume(pos);
        return true;
    }

    public static void pause() {
        if ((null != mPlayVoice) && (mPlayingId != -1L))
            mPlayVoice.pause();
    }

    public static void resume() {
        if ((null != mPlayVoice) && (mPlayingId != -1L))
            mPlayVoice.goOn(-1);
    }

    public long refreshNow() {
        // if ((null != mPlayVoice) && (mPlayingId != -1L)) {
        // mPlayVoice.refreshNow();
        // }
        return 20;// fix
    }

    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public int hashCode() {
        return super.hashCode();
    }

    public void queueNextRefresh(long delay, Handler handler, int whatMsg) {
        if ((null != mPlayVoice) && (mPlayingId != -1L))
            mPlayVoice.queueNextRefresh(delay, handler, whatMsg);
    }

    private class PlayVoice {
        private MediaPlayer mediaPlayer = null;
        boolean mIsRequestAudioFocus = false;
        boolean mIsPause = false;
        final int delayAbandonTime = 500;
        final int WHAT_ABANDON_AUDIO_FOCUS = 1;

        private long mDuration;

        public void setDuration(long mDuration) {
            this.mDuration = mDuration;
        }

        public boolean isPlaying() throws IllegalStateException {
            if (mediaPlayer == null)
                return false;
            return mediaPlayer.isPlaying();
        }

        public long getDuring() {
            if (mediaPlayer == null)
                return mDuration;
            return mediaPlayer.getDuration();
        }

        public long getCurrentPlayingDuring() {
            if (mediaPlayer == null)
                return 0;
            return mediaPlayer.getCurrentPosition();
        }

        public void queueNextRefresh(long delay, Handler handler, int whatMsg) {
            android.os.Message msg = handler.obtainMessage(whatMsg);
            handler.removeMessages(whatMsg);
            handler.sendMessageDelayed(msg, delay);

        }

        private long refreshNow() {
            if (mediaPlayer == null)
                return 500;

            long pos = mediaPlayer.getCurrentPosition();
            long remaining = 1000 - (pos % 1000);
            if ((pos >= 0 && pos <= mDuration) && (mDuration > 0)) {

                if (!mediaPlayer.isPlaying()) {
                    remaining = 500;
                }

            } else {
                pos = 0;

            }

            // return the number of milliseconds until the next full second, so
            // the counter can be updated at just the right time
            return remaining;
        }

        private PlayVoice() {
        }

        public void pause() {
            if ((this.mediaPlayer != null) && (this.mediaPlayer.isPlaying())) {
                this.mediaPlayer.pause();
                this.mIsPause = true;
            }
        }

        public void seek(int pos) {
            if ((this.mediaPlayer != null)) {
                if (pos > -1) {
                    mediaPlayer.seekTo(pos);
                }
            }
        }

        public boolean pauseOrResume(int pos) {
            if ((this.mediaPlayer != null) && (this.mIsPause)) {
                goOn(pos);
                return false;
            } else {
                pause();
                return true;
            }

        }

        public void goOn(int msec) {
            if ((this.mediaPlayer != null) && (this.mIsPause)) {
                if (msec > -1) {
                    mediaPlayer.seekTo(msec);
                }
                this.mediaPlayer.start();
                this.mIsPause = false;
                Log.d(TAG, "resume() mPlayingId:" );
            }
        }

        public void stop() {
            if (null == this.mediaPlayer) {
                return;
            }

            Log.d(TAG, "PlayVoice.stop()");
            this.mediaPlayer.stop();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
            setPlayingId(-1L);
        }

        public boolean start(String pcFileName, int currentposition,
                             long keyId, boolean play) {
            Log.d(TAG, "PlayVoice.start()");
            if (null == pcFileName) {
                return false;
            }

            if (null != this.mediaPlayer) {
                return false;
            }

            Log.d(TAG, "PlayVoice.start() pcFileName:" + pcFileName
                    + ", currentposition:" + currentposition
                    + ",mIsRequestAudioFocus:" + this.mIsRequestAudioFocus);

            this.mediaPlayer = new MediaPlayer();
            this.mediaPlayer
                    .setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {

                        @Override
                        public void onSeekComplete(MediaPlayer mp) {
                            // TODO Auto-generated method stub

                        }
                    });

            this.mediaPlayer
                    .setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        public void onCompletion(MediaPlayer mp) {

                            Log.d(TAG, "PlayVoice  MediaPlayer onCompletion()");
                            if (null != PlayVoice.this.mediaPlayer) {
                                PlayVoice.this.mediaPlayer
                                        .release();
                                PlayVoice.this.mediaPlayer = null;
                            }

                            VoiceRecord.abandonAudioFocus(MessagingApi.mContext);
                            mIsRequestAudioFocus = false;
                            setPlayingId(-1L);
                        }
                    });
            this.mediaPlayer
                    .setOnErrorListener(new MediaPlayer.OnErrorListener() {
                        public boolean onError(MediaPlayer mp, int what,
                                               int extra) {
                            Log.d(TAG, "PlayVoice  MediaPlayer onError()");

                            PlayVoice.this.mediaPlayer = null;
                            VoiceRecord.abandonAudioFocus(MessagingApi.mContext);
                            mIsRequestAudioFocus = false;
                            setPlayingId(-1L);
                            return false;
                        }
                    });
            try {
                this.mediaPlayer.setDataSource(pcFileName);
                this.mediaPlayer.prepare();
                this.mediaPlayer.seekTo(currentposition);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                this.mediaPlayer.release();
                this.mediaPlayer = null;
                setPlayingId(-1L);
                VoiceRecord.abandonAudioFocus(MessagingApi.mContext);
                mIsRequestAudioFocus = false;
                return false;
            } catch (IllegalStateException e) {
                this.mediaPlayer.release();
                this.mediaPlayer = null;
                e.printStackTrace();
                setPlayingId(-1L);
                VoiceRecord.abandonAudioFocus(MessagingApi.mContext);
                mIsRequestAudioFocus = false;
                return false;
            } catch (IOException e) {
                this.mediaPlayer.release();
                this.mediaPlayer = null;
                e.printStackTrace();
                Log.i(TAG, "io error msgId =" + keyId);
                setPlayingId(-1L);
                VoiceRecord.abandonAudioFocus(MessagingApi.mContext);
                mIsRequestAudioFocus = false;
                return false;
            }

            if (play) {
                this.mIsPause = false;
                this.mediaPlayer.start();

            } else {
                this.mIsPause = true;
            }

            setPlayingId(keyId);
            Log.d(TAG, "start() mPlayingId:");


            if (!this.mIsRequestAudioFocus) {
                VoiceRecord.requestAudioFocus(MessagingApi.mContext);
                this.mIsRequestAudioFocus = true;
            }
            return true;
        }


    }

    public static void setPlayingId(long keyId) {
        mPlayingId = keyId;

    }

    public  int getRetainPlayingTime() {
        int retainInMsec =  (int) (getDuring() - com.ultralinked.voip.api.VoiceMessage
                .getCurrentPlayingDuring()) ;
        if (retainInMsec < 1000 && retainInMsec > 500) {//not reach 1 sec ,we set to 1 sec
            retainInMsec = 1000;
        }
        int retainTime =retainInMsec / 1000;
        if (retainTime < 0) {
            retainTime = 0;
        }

        return retainTime;
    }

    /**
     * @param secs
     *            makeTimeString(pos / 1000)
     * @return
     */
    public static String makeTimeString(long secs) {

        long minute = secs / 60;
        long sec = (secs) % 60;
        String secString = sec < 10 ? "0" + sec : sec + "";
        String minString = minute < 10 ? "0" + minute : minute + "";
        return minString + ":" + secString;

    }

    int playPosition;

    private static PlayMusicService ourInstance = new PlayMusicService();

    public static PlayMusicService getInstance() {
        return ourInstance;
    }

    private PlayMusicService() {
    }





}
