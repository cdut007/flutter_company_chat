package com.ultralinked.uluc.enterprise.contacts.contract;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by ultralinked on 16/6/30.
 */
public interface RelationContract extends BaseContract {


    String TABLE_NAME = "relation";

    String PATH_RELATION = "relation";

    Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_RELATION).build();

    // DIR 代表 返回的Cursor中包含0或多条记录
    String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_RELATION;

    //ITEM 代表 返回的Cursor中为特定ID的一条记录
    String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_RELATION;

    interface RelationColumn extends BaseColumns {


        String USER_ID = "user_id";

        String DEPART_ID = "depart_id";

        String DEPARTMENT_TYPE = "department_type";

        String COMPANY_ID = "company_id";

        String DEPARTMENT_NAME = "depart_name";

        String COMPANY_NAME = "company_name";
    }
}
