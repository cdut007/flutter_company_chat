package com.ultralinked.uluc.enterprise.contacts.ui;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;

/**
 * Created by ultralinked on 16/7/29. uesed in organization and external
 */
public class DataWrapper {

    // 0:department; 1: people
    public int type;

    public PeopleEntity peopleEntity;

    public DepartUtils.CompanyElement element;

    public DataWrapper(DepartUtils.CompanyElement element, PeopleEntity peopleEntity) {

        this.element = element;
        this.peopleEntity = peopleEntity;
        if (element != null) {
            type = 0;
        } else if (peopleEntity != null) {
            type = 1;
        } else {
            type = 2;
        }
    }
}
