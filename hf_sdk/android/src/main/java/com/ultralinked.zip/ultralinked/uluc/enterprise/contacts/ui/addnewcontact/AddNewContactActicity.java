package com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.tendcloud.tenddata.TCAgent;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;

public class AddNewContactActicity extends BaseActivity implements FragmentAddContactLocalBook.OnContactsInteractionListener {

    private static final String CHOICE1 = "CHOICE1";
    private static final String CHOICE2 = "CHOICE2";
    private int chooseType;



    @Override
    protected void onDestroy() {
        super.onDestroy();
        TCAgent.onPageEnd(getActivity(),"添加好友");
    }

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_add_new_contact_acticity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TCAgent.onPageStart(getActivity(),"添加好友");
        //Internal or external
        chooseType = getIntent().getIntExtra("chooseType", -1);
        //mannul or local phone book
        int inputType = getIntent().getIntExtra("inputType", -1);

        if (savedInstanceState != null) {

        } else {

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();


            if (inputType == ChoicePopWindow.INPUTTYPE_MANNUAL_INPUT) {

                transaction.replace(R.id.container, FragmentAddContactMannual.newInstance(null,"", "", chooseType), "mannual").commit();

            } else if (inputType == ChoicePopWindow.INPUTTYPE_LOCAL_ADDRESS_BOOK) {

                transaction.replace(R.id.container, new FragmentAddContactLocalBook(), "local").commit();
            } else if(inputType == ChoicePopWindow.INPUTTYPE_INVITE_EXIST){
                PeopleEntity peopleEntity = getIntent().getParcelableExtra(FragmentAddContactMannual.ARG_ENTITY);
                transaction.replace(R.id.container, FragmentAddContactMannual.newInstance(peopleEntity, PeopleEntityQuery.getDisplayName(peopleEntity), peopleEntity.mobile, chooseType), "exist").commit();
            }
        }
    }

    @Override
    public void onContactSelected(String name, String phone) {

        getSupportFragmentManager().beginTransaction().replace(R.id.container,
                FragmentAddContactMannual.newInstance(null,name, phone, chooseType), "local2").commit();
    }

    @Override
    public void onSelectionCleared() {

    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
