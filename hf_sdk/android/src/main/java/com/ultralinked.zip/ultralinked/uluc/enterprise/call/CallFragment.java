package com.ultralinked.uluc.enterprise.call;

import android.animation.LayoutTransition;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.nineoldandroids.animation.AnimatorInflater;
import com.tendcloud.tenddata.TCAgent;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragment;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.CCPhoneView;
import com.ultralinked.uluc.enterprise.baseui.widget.NumberKeyboard;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatBottomMenuPagerAdapter;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.ScreenUtils;
import com.ultralinked.uluc.enterprise.utils.StringUtils;
import com.ultralinked.voip.api.Conversation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static android.animation.LayoutTransition.APPEARING;
import static android.animation.LayoutTransition.CHANGE_APPEARING;
import static android.animation.LayoutTransition.CHANGE_DISAPPEARING;
import static android.animation.LayoutTransition.DISAPPEARING;
import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.COUNTRY_CODE_KEY;
import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.COUNTRY_NAME_KEY;
import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.REQUEST_COUNTRY_CODE;


public class CallFragment extends BaseFragment implements View.OnClickListener, CCPhoneView.OnEventListener {
    CallAdapter adapter;
    ImageView leftBack;
    TextView titleCenter, titleRight;
    ListView callLog;
    NumberKeyboard keypad;
    ImageView bottomLeft;
    ImageView bottomCenter;
    ImageView bottomRight;
    ImageView showKeypad;
    View content;
    CallLog clickItem;
   // PopupWindow popupWindow;

    CCPhoneView mCCPhoneView;
    List<CountryInfo> countryInfos;


    private Subscription rxKeypadDisplaySubscription;


    public final static int REQUEST_CONTACT_CODE = 0x11;
    private boolean clearCallNumber;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_call_dialer;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        TCAgent.onPageStart(getActivity(),"拨号页");
        return super.onCreateView(inflater, container, savedInstanceState);

    }

    public boolean onBackPressed() {
        if (keypad != null && keypad.isShowing()) {
            keypad.dismiss();
            return true;
        } else {
           return  false;
        }
    }


    protected void setTopBar() {

        leftBack = bind(R.id.left_back);
        titleCenter = bind(R.id.titleCenter);
        titleRight = bind(R.id.titleRight);

        goneView(leftBack);
        titleCenter.setText(getString(R.string.detail_contact_call));
        goneView(titleRight);

    }

    View dialer_container,call_log_container;
    TextView callRate,callFromContact;

    @Override
    public void initView(Bundle savedInstanceState) {
        setTopBar();
        getActivity().registerReceiver(notifyDataChanged, new IntentFilter("update_call_log"));
        updateData();

        callLog = bind(R.id.callLog);
        content = bind(R.id.content);
        mCCPhoneView = bind(R.id.cc_phone_view);
        dialer_container = bind(R.id.dialer_container);
        call_log_container = bind(R.id.call_log);
        callRate = bind(R.id.call_rate);
        callFromContact = bind(R.id.call_from_contact);
        ImageUtils.buttonEffect(callRate,false);
        ImageUtils.buttonEffect(callFromContact,false);
        if (adapter == null) {
            adapter = new CallAdapter(getActivity(), R.layout.item_call_log, null);
            callLog.setAdapter(adapter);
        }



        initKeypad();

        keypad.setDialer(dialer_container);

        keypad.dismiss(false);


        initListener(this, leftBack, bottomLeft, bottomCenter, bottomRight, showKeypad,callRate,callFromContact);


        rxKeypadDisplaySubscription = RxBus.getDefault().toObservable(Boolean.class)
                .subscribe(new Action1<Boolean>() {
                               @Override
                               public void call(Boolean forceShow) {
                                   Log.i(TAG,"display keypad~~~~"+forceShow);
                                   if (forceShow!=null){
                                       if (keypad == null && isAdded() && isResumed() ){
                                           initKeypad();
                                       }

                                       if (keypad!=null){
                                           toggleKeypad(forceShow.booleanValue());

                                       }else{
                                           Log.i(TAG,"keypad is null");

                                       }
                                   }

                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG,"update the subscribe error:"+ android.util.Log.getStackTraceString(throwable));
                            }
                        });

        callLog.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState != SCROLL_STATE_IDLE){
                    if (keypad.isShowing()) {
                        keypad.dismiss(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        callLog.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                clickItem = adapter.getItem(position);

//                if (keypad!=null&&keypad.isShowing()){
//                    keypad.dismiss();
//                }

         new Thread(new Runnable() {
             @Override
             public void run() {
                 PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                 String  number = clickItem.getMobile();
                 try {
                     // phone must begin with '+'
                     String currentLanguage = Locale.getDefault().getLanguage();
                     Phonenumber.PhoneNumber numberProto = phoneUtil.parse(PhoneNumberUtils.formatMobile(number),currentLanguage);
                     final int countryCode = numberProto.getCountryCode();
                     if (countryCode>-1){
                         mCCPhoneView.post(new Runnable() {
                             @Override
                             public void run() {
                                 mCCPhoneView.setCode("+"+countryCode);
                             }
                         });

                     }
                     number = numberProto.getNationalNumber()+"";
                 } catch (Exception e) {
                     System.err.println("NumberParseException was thrown: " + android.util.Log.getStackTraceString(e));
                 }
                final String mobile = number;
                 mCCPhoneView.post(new Runnable() {
                    @Override
                    public void run() {
                        mCCPhoneView.setInputNumber(mobile);
                    }
                });
             }
         }).start();

              CallDialog callDialog =  CallDialog.getInstance(clickItem.getMobile(),"", clickItem.getIcon_url());
              //  callDialog.show(getActivity().getFragmentManager(), "call_dialog");
                callDialog.makeCall(getActivity(), clickItem.getMobile(), null, clickItem.getIcon_url(),null, ChatBottomMenuPagerAdapter.IP2_PHONE_CALL);
                callDialog.setCallStartListener(new CallDialog.OnCallStartListener() {
                    @Override
                    public void go2Call() {
                       clearCallNumber = true;
                    }
                });

                if (keypad.isShowing()) {
                    keypad.dismiss();
                }

            }
        });
        countryInfos = CountryCodeStorageHelper.getInstance().getCountryCodeStorage(getActivity()).getAllCountryInfo();
        mCCPhoneView.setOnEventListener(this);
    }


    private void initKeypad() {
        if (getRootView() == null){
            Log.i(TAG,"root view is null, restore the state?");
            return;
        }

        showKeypad = bind(R.id.showKeypad);
        keypad = bind(R.id.keypad);


        bottomLeft = (ImageView) keypad.findViewById(R.id.bottomLeft);
        bottomCenter = (ImageView) keypad.findViewById(R.id.bottomCenter);
        bottomRight = (ImageView) keypad.findViewById(R.id.bottomRight);





//        popupWindow = new PopupWindow(keypad, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
//        popupWindow.setAnimationStyle(R.style.popwin_anim_style);
//        popupWindow.setOutsideTouchable(true);
        keypad.setOnKeyDownListener(new NumberKeyboard.OnKeyDownListener() {
            @Override
            public void onKeyDown(String tag) {
                mCCPhoneView.add(tag);
            }

            @Override
            public void onLongClick(View v) {
            }

            @Override
            public void onClick(View v) {
            }
        });

//        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
//            @Override
//            public void onDismiss() {
//                //showKeypad.setVisibility(View.VISIBLE);
//            }
//        });


    }



    boolean togge = false;


    public void toggleKeypad(boolean forceShow) {
        //display keypad by default.
        if (keypad!= null){
            Log.i(TAG,"keypad show:."+forceShow+";isShowing:"+keypad.isShowing());
            if (forceShow){
                keypad.show(false,dialer_container);
            }else{
                if (keypad.isShowing()) {
                    keypad.dismiss();
                }else {
                    displayKeyPad();
                }
            }
        }else{
            //keypad not exsit.
            Log.i(TAG,"keypad reinit it.");
            initKeypad();
            if (keypad!=null){
                keypad.show(false,dialer_container);
            }

        }
    }

    private void pressKeypad() {
        //display keypad by default.
        if (keypad == null){
            initKeypad();
        }

        if (keypad!= null && !keypad.isShowing()){
            displayKeyPad();
        }
    }

    boolean isKeypadShowing(){
        if (keypad!= null && keypad.isShowing()){

            return  true;
        }

        return false;

    }

    @Override
    public void onHidden(boolean isHidden) {
        super.onHidden(isHidden);
        if (!isHidden){
            //display keypad by default.
//            if (keypad!=null){
//                keypad.show(false,dialer_container);
//            }
            if (isKeypadShowing()){
                if (keypad!=null){
                    keypad.dismiss(false);
                }
            }


        }else {

        }
    }

    public void onWindowFocusChanged(boolean hasFocus) {

        if (hasFocus) {
            //display keypad by default.
       //     RxBus.getDefault().post(true);
        }

    }

    private void updateData() {
        Observable.create(new Observable.OnSubscribe<List<CallLog>>() {
            @Override
            public void call(Subscriber<? super List<CallLog>> subscriber) {
                List<CallLog> callLogs = getData();
                if (callLogs == null) {
                    Log.i(TAG, "call logs is null");
                } else if (callLogs.size() == 0) {
                    Log.i(TAG, "call logs size =0 ");
                }
                subscriber.onNext(callLogs);

            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<List<CallLog>>() {
                    @Override
                    public void call(List<CallLog> callLogs) {
                        if (callLogs == null) {
                            return;
                        } else if (callLogs.size() == 0) {
                            return;
                        }

                        if (adapter == null) {
                            adapter = new CallAdapter(getActivity(), R.layout.item_call_log, null);
                            callLog.setAdapter(adapter);
                        }
                        adapter.updateList(callLogs);
                    }
                });
    }


    private List<CallLog> getData() {
        SQLiteDatabase db = SqliteUtils.getInstance(getActivity()).getDb();
        List<CallLog> callLogs = null;
        Cursor cursor;
        db.beginTransaction();
        cursor = db.query("call_log", null, null, null, null, null, "call_endtime DESC");
        if (cursor != null) {
            callLogs = new ArrayList<>();
            cursor.moveToNext();
            while (!cursor.isAfterLast()) {
                CallLog callLog = new CallLog();
                callLog.setName(cursor.getString(cursor.getColumnIndex("call_name")));
                callLog.setMobile(cursor.getString(cursor.getColumnIndex("call_from")));
                callLog.setEnd_time(cursor.getString(cursor.getColumnIndex("call_endtime")));
                callLog.setDuration(cursor.getString(cursor.getColumnIndex("call_duration")));
                callLog.setIcon_url(cursor.getString(cursor.getColumnIndex("call_icon")));
                callLog.setType(cursor.getString(cursor.getColumnIndex("call_type")));
                callLogs.add(callLog);
                cursor.moveToNext();
            }

            cursor.close();

        } else {
            Log.e(TAG, "call_log query result cursor is null.");
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        return callLogs;
    }

     void chooseContacts(){
         startActivityForResult(new Intent(getActivity(), LocalContactActivity.class), REQUEST_CONTACT_CODE);
     }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                getActivity().finish();
                break;
            case R.id.call_rate:
//                if (isKeypadShowing()){
//                    return;
//                }
               // MobileBrowserActivity.actionStart(getActivity(),ApiManager.getBaseUrl().replace("api/","")+"static/call_rate/index.html",getString(R.string.call_rate));
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ApiManager.getBaseUrl().replace("api/","")+"static/call_rate/index.html")));
                break;
            case R.id.bottomRight:
                if (keypad!=null){
                    keypad.dismiss();
                }
                break;

            case R.id.call_from_contact: //隐藏键盘
//                if (isKeypadShowing()){
//                    return;
//                }
                chooseContacts();
                break;

            case R.id.showKeypad: //显示键盘
               pressKeypad();
                break;
            case R.id.bottomCenter://call
                String number = RegexValidateUtils.normalizeNumber(mCCPhoneView.getMobile());
                if (!TextUtils.isEmpty(number)) {

                    CallDialog callDialog = CallDialog.getInstance(number, "", "");
                   // callDialog.show(getActivity().getFragmentManager(), "call_dialog");
                    callDialog.makeCall(getActivity(),number, null, null,null, ChatBottomMenuPagerAdapter.IP2_PHONE_CALL);
                    callDialog.setCallStartListener(new CallDialog.OnCallStartListener() {
                        @Override
                        public void go2Call() {
                            clearCallNumber = true;
                        }
                    });
                } else {
                    showToast(R.string.check_mobile);
                }
                break;
        }
    }


    public static boolean checkDeviceHasNavigationBar(Context activity) {

        //通过判断设备是否有返回键、菜单键(不是虚拟键,是手机屏幕外的按键)来确定是否有navigation bar
        boolean hasMenuKey = ViewConfiguration.get(activity)
                .hasPermanentMenuKey();
        boolean hasBackKey = KeyCharacterMap
                .deviceHasKey(KeyEvent.KEYCODE_BACK);

        return !hasMenuKey && !hasBackKey;
    }


    @Override
    public void onPause() {
        super.onPause();
        if (clearCallNumber){
            mCCPhoneView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mCCPhoneView!=null)
                    mCCPhoneView.setInputNumber("");
                }
            },500);

            clearCallNumber = false;
        }
    }

    @Override
    public void onStop() {
        super.onStop();


    }

    public static int getNavigationBarHeight(Activity activity) {
        Resources resources = activity.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height",
                "dimen", "android");
        //获取NavigationBar的高度
        int height = resources.getDimensionPixelSize(resourceId);
        return height;
    }

    private void displayKeyPad() {
        keypad.show(dialer_container);
////        int nav_height = 0;
//        if (Build.VERSION.SDK_INT >= 21) {
//                    /*Resources resources = getResources();
//                    int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
//                    if (resourceId > 0) {
//                        nav_height += resources.getDimensionPixelSize(resourceId);
//                    }*/
//            popupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
//        }
//        showKeypad.setVisibility(View.GONE);
//
//        int offSetHegiht = ScreenUtils.getViewHeight(getView().getRootView());
//      //  if (checkDeviceHasNavigationBar(getActivity())){
//            offSetHegiht = offSetHegiht + getNavigationBarHeight(getActivity());
//       // }
//        //popupWindow.setWindowLayoutType();
//        popupWindow.showAtLocation(leftBack, Gravity.BOTTOM, 0, offSetHegiht);
    }

    Rect outRect = new Rect();
    int[] location = new int[2];

    protected boolean inViewBounds(View view, int x, int y) {
        view.getDrawingRect(outRect);
        view.getLocationOnScreen(location);
        outRect.offset(location[0], location[1]);
        return outRect.contains(x, y);
    }


    private boolean dispatchTouchEvent(MotionEvent ev) {


        if (keypad != null && keypad.isShowing() && !inViewBounds(mCCPhoneView,(int)ev.getX(),(int)ev.getY())) {//not contain edit
            View tabCall = getActivity().findViewById(R.id.bottom_menu);
            if (!inViewBounds(keypad,(int)ev.getX(),(int)ev.getY())){//not contain self.

                if (tabCall!=null){//not contain table

                    if (!inViewBounds(tabCall,(int)ev.getX(),(int)ev.getY())){
                        keypad.dismiss();
                        return  true;
                    }

                }else{
                    keypad.dismiss();

                    return  true;
                }


            }

            return  false;

        }
        return false;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        TCAgent.onPageEnd(getActivity(),"拨号页");
        if(rxKeypadDisplaySubscription!=null&&!rxKeypadDisplaySubscription.isUnsubscribed()) {
            rxKeypadDisplaySubscription.unsubscribe();
        }

        if (keypad != null && keypad.isShowing()) {
            keypad.dismiss();
            keypad = null;
        }
       try {
           getActivity().unregisterReceiver(notifyDataChanged);
       }catch (Exception e){
           e.printStackTrace();
           Log.i(TAG,"unregister call data changed receiver error:"+ android.util.Log.getStackTraceString(e));
       }
    }


    BroadcastReceiver notifyDataChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i(TAG, "notifyDataChanged");
            updateData();
        }
    };


    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");

    @Override
    public void onCountryCodeTouch(String code) {
        Intent intent = new Intent(getActivity(), CountryCodeChooseActivity.class);
        intent.putExtra("countryCode", code);
        startActivityForResult(intent, REQUEST_COUNTRY_CODE);
    }

    @Override
    public boolean onInputNumberTouch(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            pressKeypad();
        }
        return false;
    }

    @Override
    public void onCountryCodeTextChanged(Editable s) {
        CountryInfo result = null;
        String info = s.toString();
        for (CountryInfo countryInfo : countryInfos) {
            if (countryInfo.getCountryCode().equals(info)) {
                result = countryInfo;
                break;
            }
        }
        if (result != null) {
            mCCPhoneView.setCountryName(result.getFullName());
        } else {
            mCCPhoneView.setCountryName("");
        }
    }

    @Override
    public void onInputNumberTextChanged(Editable s) {
       // highLight(s);
    }

    private void highLight(Editable s){
        if(s.length()<=0){
            updateData();
            return;
        }
        final String keyWord = RegexValidateUtils.normalizeNumber((mCCPhoneView.getMobile()));
        Observable.create(new Observable.OnSubscribe<List<CallLog>>() {
            @Override
            public void call(Subscriber<? super List<CallLog>> subscriber) {
                List<CallLog> list = getData();
                List<CallLog> result = new ArrayList<CallLog>();
                for (CallLog callLog : list) {
                    if (callLog.getMobile().contains(keyWord)) {
                        result.add(callLog);
                    }
                }
                subscriber.onNext(result);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<List<CallLog>>() {

            @Override
            public void call(List<CallLog> callLogs) {
                if(callLogs.size()>0) {
                    adapter.setSearchStr(keyWord);
                    adapter.updateList(callLogs, true);
                }else{
                    adapter.updateList(callLogs);
                }
            }
        });
    }

    public void showKeypad() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                displayKeyPad();
            }
        },500);
    }


    class CallAdapter extends MyBaseAdapter<CallLog> {
        public CallAdapter(Context context, int resource, List<CallLog> list) {
            super(context, resource, list);
        }

        @Override
        public void setHolder(MyHolder holder, final CallLog callLog) {
            if (callLog == null)
                return;
            holder.getView(R.id.right_icon).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext,CallLogDetailActivity.class);
                    intent.putExtra("call_log",callLog);
                    startActivity(intent);
                }
            });
            holder.setText(R.id.tvCallName, TextUtils.isEmpty(callLog.getName()) ? getString(R.string.unknown) : callLog.getName());
            String mobile = callLog.getMobile();
            if(!isSearchMode()) {
                holder.setText(R.id.tvCallMobile, PhoneNumberUtils.formatMobile(mobile));
            }else{
                holder.setText(R.id.tvCallMobile, StringUtils.getSpanedStringText(mobile,getSearchStr()));
            }
            Log.i(TAG, callLog.getEnd_time());
            long time = 0;
            try {
                time = Long.valueOf(callLog.getEnd_time());
            } catch (Exception e) {
                e.printStackTrace();
            }

            String end_time = sdf.format(new Date(time));
            Log.i(TAG, "time  " + time);
            Log.i(TAG, "time  " + end_time);
            holder.setText(R.id.tvCallTime, end_time);
            holder.setImage(R.id.ivPhoto, callLog.getIcon_url());
            holder.setTextColor(R.id.tvCallName,mContext.getResources().getColor(R.color.color_37404c));
            if (TextUtils.isEmpty(callLog.getType())) {
                Log.i(TAG, "type is null");
                return;
            }

            ImageView callType = holder.getView(R.id.callType);
            switch (callLog.getType()) {
                case "in":
                    callType.setImageResource(R.mipmap.call_in);
                    break;
                case "out":
                    callType.setImageResource(R.mipmap.call_out);
                    break;
                case "miss":
                    holder.setTextColor(R.id.tvCallName,mContext.getResources().getColor(R.color.color_e93d3d));
                    callType.setImageResource(R.mipmap.call_miss);
                    break;
            }
        }


    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_COUNTRY_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                mCCPhoneView.setCodeAndName(data.getStringExtra(COUNTRY_CODE_KEY), data.getStringExtra(COUNTRY_NAME_KEY));
            }
        }
        if (requestCode == REQUEST_CONTACT_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                String  number = data.getStringExtra("number");
                try {
                    // phone must begin with '+'
                    String currentLanguage = Locale.getDefault().getLanguage();
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(number,currentLanguage);
                    int countryCode = numberProto.getCountryCode();
                    if (countryCode>-1){
                        mCCPhoneView.setCode("+"+countryCode);
                    }
                    number = numberProto.getNationalNumber()+"";
                } catch (Exception e) {
                    System.err.println("NumberParseException was thrown: " + android.util.Log.getStackTraceString(e));
                }

                mCCPhoneView.setInputNumber(number);
                if (keypad!=null){
                    keypad.show(false,dialer_container);
                }
            }
        }
    }
}
