package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.Context;
import android.database.Cursor;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.FriendContract;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.contract.StrangerContract;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.Conversation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ultralinked on 16/7/29.
 */
public class PeopleEntityQuery {

    public static PeopleEntityQuery instance;

    public static PeopleEntityQuery getInstance() {

        if (instance == null) {
            instance = new PeopleEntityQuery();
        }
        return instance;
    }


    private static final String TAG = "PeopleEntityQuery";
    private final Context mContext;
    private String mCol_Name, mCol_NickName, mCol_RemarkName, mCol_Mobile, mCol_Gender, mCol_Icon, mCol_Email, mCol_SUB_Id, mCol_Re_SUB_Id, mCol_Re_DEP_Id;
    private String mCol_Re_COM_Id, mCol_Re_DEP_NAME, mCol_Re_COM_NAME;


    private PeopleEntityQuery() {
        mContext = App.getInstance().getApplicationContext();
        getColumns(PersonnelContract.TABLE_NAME);
    }

    private void getColumns(String tableName) {
        mCol_Name = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.NAME);
        mCol_NickName = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.NICKNAME);
        mCol_RemarkName = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.REMARKNAME);
        mCol_Mobile = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.MOBILE);
        mCol_Icon = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.ICON);
        mCol_Gender = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.SEX);
        mCol_Email = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.EMAIL);
        mCol_SUB_Id = getPersonColumn(tableName, PersonnelContract.PersonnelColumn.SUBUSER_ID);

        mCol_Re_SUB_Id = getRelationColumn(RelationContract.RelationColumn.USER_ID);
        mCol_Re_DEP_Id = getRelationColumn(RelationContract.RelationColumn.DEPART_ID);
        mCol_Re_DEP_NAME = getRelationColumn(RelationContract.RelationColumn.DEPARTMENT_NAME);
        mCol_Re_COM_Id = getRelationColumn(RelationContract.RelationColumn.COMPANY_ID);
        mCol_Re_COM_NAME = getRelationColumn(RelationContract.RelationColumn.COMPANY_NAME);
    }


    private String getPersonColumn(String tableName, String colum) {

        return new StringBuilder(tableName).append(".").append(colum).toString();
    }

    private String getRelationColumn(String colum) {

        return new StringBuilder(RelationContract.TABLE_NAME).append(".").append(colum).toString();
    }


    public ArrayList<PeopleEntity> getByDeptID(String deptId) {

        if (TextUtils.isEmpty(deptId)) {

            return new ArrayList<>();
        }

        return querybyDeptID(deptId);
    }

    public static PeopleEntity readPeopleBaseColumnsByQuery(Cursor curor) {
        PeopleEntity entity = new PeopleEntity();
        entity.icon_url = curor.getString(curor.getColumnIndex("d1"));
        entity.name = curor.getString(curor.getColumnIndex("d2"));
        entity.nickname = curor.getString(curor.getColumnIndex("d3"));
        entity.remarkname = curor.getString(curor.getColumnIndex("d4"));
        entity.mobile = curor.getString(curor.getColumnIndex("d5"));
        entity.email = curor.getString(curor.getColumnIndex("d6"));
        entity.subuser_id = curor.getString(curor.getColumnIndex("d7"));

        entity.deparment_id = curor.getString(curor.getColumnIndex("d8"));
        entity.deparment_name = curor.getString(curor.getColumnIndex("d9"));
        entity.companyid = curor.getString(curor.getColumnIndex("d10"));
        entity.companyName = curor.getString(curor.getColumnIndex("d11"));

        entity.gender = curor.getString(curor.getColumnIndex("d12"));

        return entity;
    }

    private String getColsQueryStr() {
        StringBuilder subQuery = new StringBuilder();
        subQuery.append(mCol_Icon).append(" as d1, ")
                .append(mCol_Name).append(" as d2, ")
                .append(mCol_NickName).append(" as d3, ")
                .append(mCol_RemarkName).append(" as d4, ")
                .append(mCol_Mobile).append(" as d5, ")
                .append(mCol_Email).append(" as d6, ")
                .append(mCol_SUB_Id).append(" as d7, ")

                .append(mCol_Re_DEP_Id).append(" as d8,")

                .append(mCol_Re_DEP_NAME).append(" as d9,")
                .append(mCol_Re_COM_Id).append(" as d10,")
                .append(mCol_Re_COM_NAME).append(" as d11, ")
                .append(mCol_Gender).append(" as d12");

        return subQuery.toString();
    }

    /**
     * get by departmentID
     *
     * @param deptId
     * @return
     */
    private ArrayList<PeopleEntity> querybyDeptID(String deptId) {

        ArrayList<PeopleEntity> myListData = new ArrayList<>();

        getColumns(PersonnelContract.TABLE_NAME);

        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())
                .append("  FROM  ").append(PersonnelContract.TABLE_NAME)
                .append(" INNER JOIN ").append(RelationContract.TABLE_NAME)
                .append(" WHERE ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" AND ").append(mCol_Re_DEP_Id).append(" = ")
                .append(" '").append(deptId).append("'").toString();


        Cursor curor = SqliteUtils.getInstance(mContext.getApplicationContext()).getDb().rawQuery(sql, null);


        if (curor != null && curor.getCount() > 0) {

            Log.i(TAG, "curor   " + curor.getCount());

            curor.moveToFirst();

            do {
                PeopleEntity entity = readPeopleBaseColumnsByQuery(curor);


                myListData.add(entity);
            } while (curor.moveToNext());
        } else {
            Log.i(TAG, "sql is  " + sql);
        }

        if (curor != null && !curor.isClosed()) {
            curor.close();
        }

        return myListData;
    }


    public static String parseUserId(String subUserId) {
        int pos = subUserId.lastIndexOf("[");
        String props = null;
        if (pos > 0) {
            props = subUserId.substring(pos);
        }

        if (TextUtils.isEmpty(props)) {

            return subUserId;
        }

        String userID = subUserId.substring(0, pos);

        return userID;
    }


    /**
     * get by users's unique id
     *
     * @param subUserId
     * @return
     */
    public synchronized PeopleEntity getByID(String subUserId) {

        if (TextUtils.isEmpty(subUserId)) {

            return null;
        }

        subUserId = parseUserId(subUserId);

        getColumns(PersonnelContract.TABLE_NAME);

        PeopleEntity entity = queryPeopleFromTable(PersonnelContract.TABLE_NAME, subUserId);

        boolean hasFoundPeople = hasFoundPeople(entity);
        if (!hasFoundPeople) {//from the friend table.
            //copy friend to entity?

            getColumns(FriendContract.TABLE_NAME);

            entity = queryPeopleFromFriendTable(FriendContract.TABLE_NAME, subUserId);
            hasFoundPeople = hasFoundPeople(entity);
            if (hasFoundPeople) {
                entity.relation = PeopleEntity.FRIEND;
            }
        }

        if (!hasFoundPeople) {//from the strager table.
            //copy friend to entity?

            getColumns(StrangerContract.TABLE_NAME);

            entity = queryPeopleFromFriendTable(StrangerContract.TABLE_NAME, subUserId);
            hasFoundPeople = hasFoundPeople(entity);
            if (hasFoundPeople) {
                entity.relation = PeopleEntity.STRANGER;
            }
        }


        if (!hasFoundPeople) {

            List<PeopleEntity> assistant = SPUtil.getAssistant();
            if (assistant != null && assistant.size() > 0) {
                for (PeopleEntity custom : assistant
                        ) {
                    if (subUserId.equals(custom.subuser_id)) {

                        return custom;
                    }

                }
            }
            return null;
        }

        return entity;
    }


    /*
     *
     * @param subUserId
     * @return
     */
    public boolean isFriend(String subUserId) {

        if (TextUtils.isEmpty(subUserId)) {

            return false;
        }

        subUserId = parseUserId(subUserId);

        //copy friend to entity?

        getColumns(FriendContract.TABLE_NAME);

        PeopleEntity entity = queryPeopleFromFriendTable(FriendContract.TABLE_NAME, subUserId);

        return hasFoundPeople(entity);

    }


    private PeopleEntity queryPeopleFromFriendByMobileTable(String tableName, String mobile) {
        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())
                .append("  FROM  ").append(tableName)
                .append(" LEFT JOIN ").append(RelationContract.TABLE_NAME)
                .append(" ON ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" WHERE ").append(mCol_Mobile).append(" = ").append(" '").append(mobile).append("'")
                .toString();

        PeopleEntity entity = getPeopleEntity(sql);

        return entity;
    }


    private PeopleEntity queryPeopleFromFriendTable(String tableName, String userId) {
        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())

                .append("  FROM  ").append(tableName)
                .append(" LEFT JOIN ").append(RelationContract.TABLE_NAME)
                .append(" ON ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" WHERE ").append(mCol_SUB_Id).append(" = ").append(" '").append(userId).append("'")
                .toString();

        PeopleEntity entity = getPeopleEntity(sql);

        return entity;
    }


    private PeopleEntity queryPeopleFromTable(String tableName, String userId) {
        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())

                .append("  FROM  ").append(tableName)
                .append(" INNER JOIN ").append(RelationContract.TABLE_NAME)
                .append(" WHERE ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" AND ")
                .append(mCol_SUB_Id).append(" = ").append(" '").append(userId).append("'")
                .toString();

        PeopleEntity entity = getPeopleEntity(sql);

        return entity;
    }

    public static boolean hasFoundPeople(PeopleEntity entity) {
        return !(entity == null || TextUtils.isEmpty(entity.subuser_id));
    }


    /**
     * used in Incoming call page, bcoz the CacheByMobile is not init when incoming
     */

    public PeopleEntity queryFriendByMobileSql(String mobile) {

        if (TextUtils.isEmpty(mobile)) {

            return null;
        }
        getColumns(FriendContract.TABLE_NAME);


        if (mobile.length() > 8) {
            mobile = mobile.substring(mobile.length() - 8, mobile.length());
        }

        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())


                .append("  FROM  ").append(FriendContract.TABLE_NAME)
                .append(" LEFT JOIN ").append(RelationContract.TABLE_NAME)
                .append(" ON ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" WHERE ")
                .append(mCol_Mobile).append(" LIKE ").append(" '%").append(mobile).append("'")
                .toString();

        PeopleEntity entity = getPeopleEntity(sql);

        if (!hasFoundPeople(entity)) {//from the friend table.
            //copy friend to entity?
            Log.i(TAG, "has not find friend===" + mobile);
            return null;
        }


        if (entity == null) return null;

        return entity;
    }


    /**
     * used in Incoming call page, bcoz the CacheByMobile is not init when incoming
     */

    public PeopleEntity getByMobileSql(String mobile) {

        if (TextUtils.isEmpty(mobile)) {

            return null;
        }


        getColumns(FriendContract.TABLE_NAME);

        PeopleEntity entity = queryPeopleFromFriendByMobileTable(FriendContract.TABLE_NAME, mobile);
        if (entity != null) {
            entity.relation = PeopleEntity.FRIEND;
        }


        if (!hasFoundPeople(entity)) {//from the friend table.
            //copy friend to entity?

            getColumns(StrangerContract.TABLE_NAME);

            entity = queryPeopleFromFriendByMobileTable(StrangerContract.TABLE_NAME, mobile);
            if (entity != null) {
                entity.relation = PeopleEntity.STRANGER;
            }
        }



        if (!hasFoundPeople(entity)) {//from the friend table.
            //copy friend to entity?
            getColumns(PersonnelContract.TABLE_NAME);

            String sql = new StringBuilder("SELECT ")
                    .append(getColsQueryStr())

                    .append("  FROM  ").append(PersonnelContract.TABLE_NAME)
                    .append(" INNER JOIN ").append(RelationContract.TABLE_NAME)
                    .append(" WHERE ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                    .append(" AND ")
                    .append(mCol_Mobile).append(" = ").append(" '").append(mobile).append("'")
                    .toString();

            entity = getPeopleEntity(sql);

            if (entity != null) {
                entity.relation = PeopleEntity.STRANGER;
            }

        }



        if (entity == null) return null;


        return entity;
    }

    /**
     * search by contact name
     *
     * @param name
     * @return
     */

    public PeopleEntity getByNameSql(String name) {

        if (TextUtils.isEmpty(name)) {

            return null;
        }
        getColumns(PersonnelContract.TABLE_NAME);

        String sql = new StringBuilder("SELECT ")
                .append(getColsQueryStr())

                .append("  FROM  ").append(PersonnelContract.TABLE_NAME)
                .append(" INNER JOIN ").append(RelationContract.TABLE_NAME)
                .append(" WHERE ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                .append(" AND ")
                .append(mCol_NickName).append(" = ").append(" '").append(name).append("'")
                .toString();

        PeopleEntity entity = getPeopleEntity(sql);


        if (!hasFoundPeople(entity)) {//from the friend table.
            //copy friend to entity?

            getColumns(FriendContract.TABLE_NAME);
            sql = new StringBuilder("SELECT ")
                    .append(getColsQueryStr())

                    .append("  FROM  ").append(FriendContract.TABLE_NAME)
                    .append(" LEFT JOIN ").append(RelationContract.TABLE_NAME)
                    .append(" ON ").append(mCol_SUB_Id).append(" = ").append(mCol_Re_SUB_Id)
                    .append(" WHERE ").append(mCol_NickName).append(" = ").append(" '").append(mCol_NickName).append("'")
                    .toString();

            entity = getPeopleEntity(sql);
        }

        if (entity == null) return null;

        return entity;
    }

    @Nullable
    private PeopleEntity getPeopleEntity(String sql) {

        Cursor curor = null;
        try {
            curor = SqliteUtils.getInstance(mContext).getDb().rawQuery(sql, null);

        } catch (Exception e) {
            Log.i(TAG, "sql is  " + sql);
            Log.i(TAG, "query error:" + android.util.Log.getStackTraceString(e));
        }


        if (curor == null || curor.getCount() == 0) {
            Log.i(TAG, "curor is null");
            if (curor != null && !curor.isClosed()) {

                curor.close();
            }
            return null;
        }

        Log.i(TAG, "curor   " + curor.getCount());

        curor.moveToFirst();

        PeopleEntity entity = readPeopleBaseColumnsByQuery(curor);

        if (curor != null && !curor.isClosed()) {

            curor.close();
        }

        return entity;
    }

    public static String getDisplayName(PeopleEntity peopleEntity) {

        if (!TextUtils.isEmpty(peopleEntity.remarkname)) {
            return peopleEntity.remarkname;
        }

        String nickName = peopleEntity.nickname;

        if (TextUtils.isEmpty(nickName) || nickName.equals("null")) {

            String name = peopleEntity.name;

            if (TextUtils.isEmpty(name)) {
                name = "";
            }
            return name;
        }

        return nickName;
        //return peopleEntity.name;
    }

    public void getAllRegisterAccounts() {
        SqliteUtils mSqliteUtils = SqliteUtils.getInstance(App.getInstance());
        Cursor cursor = mSqliteUtils.getDb().rawQuery("SELECT * FROM " + PersonnelContract.TABLE_NAME + " UNION SELECT * FROM " + FriendContract.TABLE_NAME +
                        " UNION SELECT * FROM " + StrangerContract.TABLE_NAME,
                null);
        if (cursor == null || cursor.isClosed() || cursor.getCount() == 0) {
            Log.i(TAG, "not find any accounts in local");
            return;
        }
        Log.i(TAG, " find register accounts in local:" + cursor.getCount());
        cursor.moveToFirst();

        do {
            PeopleEntity peopleEntity = DbSQLHelper.readPeopleBaseColumns(cursor);
            SPUtil.updateRegisterAccount(peopleEntity);


        } while (cursor.moveToNext());

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();
        }

    }
}
