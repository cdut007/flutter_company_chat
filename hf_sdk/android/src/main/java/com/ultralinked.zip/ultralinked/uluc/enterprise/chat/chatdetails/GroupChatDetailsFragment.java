package com.ultralinked.uluc.enterprise.chat.chatdetails;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ultralinked.uluc.enterprise.MainActivity;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.BaseRecyclerAdapter;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.RecyclerViewHolder;
import com.ultralinked.uluc.enterprise.baseui.widget.MGridLayoutManager;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.chat.group.ChooseGroupMemberActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.RawMatchsFriendPerson;
import com.ultralinked.uluc.enterprise.contacts.tools.Save2MutliProvider;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.AddNewFriendActicity;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.contacts.ui.selectmember.SelectMemberActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.GroupConversation;
import com.ultralinked.voip.api.GroupMember;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import cn.bingoogolapple.qrcode.zxing.QRCodeEncoder;
import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by chenlu on 2016/7/29 0029.
 */
public class GroupChatDetailsFragment extends BaseChatDetailsFragment {
    //邀请新的群成员
    private static final int REQUEST_CODE_FOR_INVITE_NEW_MEMBER = 0x10;
    private RecyclerView recyclerView;
    private ArrayList<PeopleEntity> mDatas;
    private BaseRecyclerAdapter<PeopleEntity, RecyclerViewHolder> adapter;
    private List<GroupMember> groupMembers;
    private GroupConversation groupConversation;
    private static final int SPAN_COUNT = 4;

    private View exitGroupBtn, group_qr_code;

    @Override
    public int getRootLayoutId() {
        return R.layout.chat_detals_layout_group;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        recyclerView = bind(R.id.recycler_view);
        exitGroupBtn = bind(R.id.exit_group_btn);
        group_qr_code = bind(R.id.group_qr_code);
        initListener(this, exitGroupBtn, group_qr_code);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        if (mConversation == null) {
            activity.finish();
            Log.e(TAG, "mConversation is null.");
            return view;
        }
        groupConversation = (GroupConversation) mConversation;

        new Thread(new Runnable() {
            @Override
            public void run() {
                groupConversation.checkGroupMember();
            }
        }).start();

        initData(getArguments());

        registerReceiver();

        return view;
    }

    @Override
    public void onDestroyView() {
        unRegisterReceiver();

        super.onDestroyView();
    }

    private void registerReceiver() {
        IntentFilter groupMemberChangIntentFilter = new IntentFilter(MessagingApi.EVENT_GROUP_MEMBER_CHANGE);
        groupMemberChangIntentFilter.addAction(MessagingApi.EVENT_GROUP_INFO_CHANGED);

        LocalBroadcastManager.getInstance(activity).registerReceiver(groupMemberChangeReceiver, groupMemberChangIntentFilter);
    }

    private void unRegisterReceiver() {

        LocalBroadcastManager.getInstance(activity).unregisterReceiver(groupMemberChangeReceiver);

    }


    private BroadcastReceiver groupMemberChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (MessagingApi.EVENT_GROUP_INFO_CHANGED.equals(action) || MessagingApi.EVENT_GROUP_MEMBER_CHANGE.equals(action)) {


                String from = intent.getStringExtra(MessagingApi.PARAM_FROM_TO);
                String grouptitle = intent.getStringExtra(MessagingApi.PARAM_GROUP_TITLE);
                String groupId = intent.getStringExtra(MessagingApi.PARAM_GROUP);
                Log.i(TAG, "groupMemberChangeReceiver~~ from: " + from + "  grouptitle:" + grouptitle + " groupId:" + groupId);


                if (!TextUtils.isEmpty(groupId)) {

                    if (groupConversation!=null && groupId.equals(groupConversation.getGroupID())) {
                        //update groupconversation
                        groupConversation = GroupConversation.getConversationByGroupId(groupConversation.getGroupID());
                        refreshGroupMembersInfo();
                    } else {
                        Log.i(TAG, "not belong to current group. groupId:" + groupId + " groupName:" + grouptitle);
                    }

                } else {
                    Log.i(TAG, "groupMemberChangeReceiver~~ groupid is empty.");
                }


            }
        }
    };


    void reMesureSize(){
        int memberSize = groupMembers.size();

        if (isChairMan){
            memberSize = memberSize + 2;
        }else{
            memberSize = memberSize + 1;
        }
        //adjust recyclerview height
        ViewGroup.LayoutParams params = recyclerView.getLayoutParams();
        if (memberSize <= SPAN_COUNT) {
            params.height = activity.getResources().getDimensionPixelSize(R.dimen.px_100_0_dp);
        } else if (memberSize <= SPAN_COUNT * 2) {
            params.height = activity.getResources().getDimensionPixelSize(R.dimen.px_100_0_dp) * 2;
        } else {
            params.height = activity.getResources().getDimensionPixelSize(R.dimen.px_100_0_dp) * 3;
        }
        recyclerView.setLayoutParams(params);
    }
    //refresh group members
    private void refreshGroupMembersInfo() {
        if (groupConversation == null) {
            Log.i(TAG, "the group conversation is null.");
            return;
        }
        groupMembers = groupConversation.getGroupMember();
        if (groupMembers == null || groupMembers.isEmpty()) {
            Log.i(TAG, "the group member is only yourself.");
            return;
        }


        reMesureSize();

        titleCenter.setText(new StringBuffer(groupConversation.getGroupTopic()).append("(").append(groupMembers.size()).append(")"));

        Observable.create(new Observable.OnSubscribe<List<PeopleEntity>>() {
            @Override
            public void call(Subscriber<? super List<PeopleEntity>> subscriber) {
                List<PeopleEntity> peopleEntities = new ArrayList<PeopleEntity>();
                List<PeopleEntity> queryPeopleEntities = new ArrayList<PeopleEntity>();

                for (int i = 0; i < groupMembers.size(); i++) {
                    String userId = groupMembers.get(i).getMemberName();
                    PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByID(userId);

                    if (!PeopleEntityQuery.hasFoundPeople(peopleEntity)) {

                        if (peopleEntity == null) {
                            peopleEntity = new PeopleEntity();
                            peopleEntity.subuser_id = userId;
                        }

                        Message.PeerInfo peerInfo = groupMembers.get(i).getPeerInfo();
                        if (peerInfo != null && !TextUtils.isEmpty(peerInfo.userName)) {
                            peopleEntity.name = peerInfo.userName;
                            peopleEntity.nickname = peerInfo.nickName;
                        } else {
                            peopleEntity.name = userId;
                        }

                        //add to api query userInfos.
                        queryPeopleEntities.add(peopleEntity);
                    }


                    peopleEntities.add(peopleEntity);

                }

                callQueryStrangerMemberInfos(queryPeopleEntities);//update to persnal table.
                subscriber.onNext(peopleEntities);
            }
        }).compose(this.<List<PeopleEntity>>bindToLifecycle()).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<List<PeopleEntity>>() {
            @Override
            public void call(List<PeopleEntity> peopleEntities) {
                mDatas.clear();
                mDatas.addAll(peopleEntities);
                adapter.notifyDataSetChanged();
            }
        });


    }

    private void callQueryStrangerMemberInfos(List<PeopleEntity> queryPeopleEntities) {
        if (queryPeopleEntities.isEmpty()) {
            return;
        }

        List<String> userIds = new ArrayList<>();

        for (PeopleEntity people : queryPeopleEntities
                ) {
            userIds.add(people.subuser_id);
        }

        RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
            @Override
            public void onResultFriendList(final List<PeopleEntity> entities) {
                if (getActivity()!=null && !getActivity().isFinishing()){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mergeGroupMemberInfo(entities);
                        }
                    });
                }
            }
            @Override
            public void onQueryFailed(List<String> requestUserIds) {

            }
        });

        //
    }


    private void mergeGroupMemberInfo(List<PeopleEntity> queryPeoples) {


        for (PeopleEntity people : queryPeoples) {
            adapter.updateItem(people);
        }

    }

    boolean isChairMan = false;

    int ITEM_TYPE_NORMAL = 0x11;
    int ITEM_TYPE_INVITE = 0x12;
    int ITEM_TYPE_DELETE = 0x13;

    @Override
    protected void initData(Bundle data) {
        super.initData(data);

        mDatas = new ArrayList<>();

        String chairMan = groupConversation.getChairMan();
        if (SPUtil.getUserID().equals(chairMan)) {
            isChairMan = true;
        }

        adapter = new BaseRecyclerAdapter<PeopleEntity, RecyclerViewHolder>(activity, mDatas) {

            @Override
            public RecyclerViewHolder onCreateItemViewHolder(Context mContext, View itemView, int viewType) {
                return new RecyclerViewHolder(activity, LayoutInflater.from(activity).inflate(getItemLayoutId(viewType), null));
            }

            @Override
            public int getItemCount() {
                if (isChairMan) {
                    return mData.size() + 2;
                } else {
                    return mData.size() + 1;
                }

            }

            @Override
            public int getItemViewType(int position) {
                if (isChairMan) {
                    if (position == getItemCount() - 1) {
                        return ITEM_TYPE_DELETE;
                    } else if (position == getItemCount() - 2) {
                        return ITEM_TYPE_INVITE;
                    } else {
                        return ITEM_TYPE_NORMAL;
                    }

                } else {
                    return position == getItemCount() - 1 ? ITEM_TYPE_INVITE : ITEM_TYPE_NORMAL;
                }

            }

            @Override
            public int getItemLayoutId(int viewType) {
                return R.layout.group_member_item;
            }

            @Override
            public void bindData(RecyclerViewHolder holder, int position, PeopleEntity itemData) {
                ImageView header = holder.getImageView(R.id.header);
                TextView name = holder.getTextView(R.id.member_name);
                int ViewType = getItemViewType(position);
                if (ViewType == ITEM_TYPE_INVITE) {// add invite button
                    name.setVisibility(View.GONE);
                    header.setImageResource(R.mipmap.group_chat_add);

                } else if (ViewType == ITEM_TYPE_DELETE) {// add invite button
                    name.setVisibility(View.GONE);
                    header.setImageResource(R.mipmap.group_chat_delete);

                } else {
                    name.setVisibility(View.VISIBLE);
                    ImageUtils.loadCircleImage(activity, header, itemData.icon_url, ImageUtils.getDefaultContactImageResource(itemData.subuser_id));
                    name.setText(PeopleEntityQuery.getDisplayName(itemData));
                }

            }
        };

        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View itemView, int pos) {
                if (adapter.getItemViewType(pos) == ITEM_TYPE_INVITE) {
                    inviteNewMemberJoin();
                } else if (adapter.getItemViewType(pos) == ITEM_TYPE_DELETE) {
                    deleteMembers();
                } else {

                    PeopleEntity entity = mDatas.get(pos);
                    if (TextUtils.isEmpty(entity.subuser_id)) {
                        android.util.Log.i(TAG, "userid:" + entity.subuser_id);
                        return;
                    }

                    DetailPersonActivity.gotoDetailPersonActivity(getActivity(), entity);
                }
            }
        });

        recyclerView.setLayoutManager(new MGridLayoutManager(activity, SPAN_COUNT));
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(true);

        refreshGroupMembersInfo();

    }



    private  void deleteMembers(){
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("members", mDatas);
        bundle.putString("group_id",((GroupConversation)mConversation).getGroupID());
        ChooseGroupMemberActivity.startForResult(GroupChatDetailsFragment.this, ChooseGroupMemberActivity.REQUEST_DELETE_MEMBERS, bundle);

    }

    /**
     * 邀请新成员加入
     */
    private void inviteNewMemberJoin() {
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("members", mDatas);
        SelectMemberActivity.startForResult(GroupChatDetailsFragment.this, SelectMemberActivity.REQUEST_INVITE_MEMBERS, bundle);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SelectMemberActivity.REQUEST_INVITE_MEMBERS && data != null) {
                ArrayList<PeopleEntity> members = data.getParcelableArrayListExtra("invite_members");
                for (int i = 0; i < members.size(); i++) {
                    groupConversation.inviteToGroup(members.get(i).subuser_id);
                    Log.i(TAG, String.format("invite %s join in to group: %s .", members.get(i).subuser_id, groupConversation.getGroupTopic()));

                }

            }else if (requestCode == ChooseGroupMemberActivity.REQUEST_DELETE_MEMBERS && data != null) {
                ArrayList<String> members = data.getStringArrayListExtra("select_members");


            }
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.group_qr_code: {
                if (mConversation == null) {
                    return;
                }
                Intent intent = new Intent(activity, GroupQRCodeActivity.class);
                if (mConversation.isGroup()) {
                    intent.putExtra("conversation_id", ((GroupConversation) mConversation).getGroupID());

                } else {
                    intent.putExtra("conversation_id", mConversation.getContactNumber());
                }
                intent.putExtra("convType", mConversation.isGroup() ? Conversation.GROUP_CHAT : Conversation.SINGLE_CHAT);
                intent.putExtra("flag", mConversation.conversationFlag);

                startActivity(intent);
            }
            break;
            case R.id.exit_group_btn:
                String content = getActivity().getString(com.holdingfuture.flutterapp.hfsdk.R.string.delete_conversation_tips);
                String replaceMent = groupConversation.getGroupTopic();
                if (replaceMent == null) {
                    Log.i(TAG, "replaceMent is null.");
                    replaceMent = "";
                }
                content = content.replace("xxx", replaceMent);
                DialogManager.showOKCancelDialog(mContext, "", content, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.i(TAG, "delete conversation, conversationId:" + groupConversation.getConversationId() + " conversation name:" + groupConversation.getGroupTopic());

                        ChatModule.deleteConversation(groupConversation);
                        Intent mIntent = new Intent(activity, MainActivity.class);
                        mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        activity.startActivity(mIntent);
                    }
                }, null);

                break;

        }

    }
}
