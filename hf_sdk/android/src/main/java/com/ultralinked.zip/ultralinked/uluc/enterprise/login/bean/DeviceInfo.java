package com.ultralinked.uluc.enterprise.login.bean;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.ultralinked.uluc.enterprise.UpgrdeInfo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * Created by ultralinked on 16/10/11.
 */
//infoDic = @{@"device_id"   : uuid,
//@"device_type" : deviceType,
//@"device_name" : deviceName};
public class DeviceInfo implements Serializable{
    public static final int NORMAL = 0;
    public static final int DESTROYED = 2;
    public static final int PENDING = 1;
    public String device_id;
    public String device_name;
    public String device_type;
    public int status;//0 normal,1 pending, 2 destry


    @Override
    public String toString() {
        return "DeviceInfo{" +
                "device_id='" + device_id + '\'' +
                ", device_type='" + device_type + '\'' +
                ", device_name='" + device_name + '\'' +
                '}';
    }

    public static DeviceInfo getInfos() throws JSONException{
        DeviceInfo devicesInfo = new DeviceInfo();
        devicesInfo.device_id = UpgrdeInfo.getUUID();
        devicesInfo.device_type = UpgrdeInfo.getVendor();
        devicesInfo.device_name = UpgrdeInfo.getDeviceName();
        return  devicesInfo;
    }
}
