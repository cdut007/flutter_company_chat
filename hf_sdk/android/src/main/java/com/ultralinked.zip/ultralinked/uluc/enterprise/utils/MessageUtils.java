package com.ultralinked.uluc.enterprise.utils;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.os.Vibrator;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.SparseArray;

import com.google.gson.Gson;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.chat.bean.UrlInfo;
import com.ultralinked.uluc.enterprise.chat.chatim.BaseChatImFragment;
import com.ultralinked.uluc.enterprise.chat.chatim.ChatModule;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailHelper;
import com.ultralinked.uluc.enterprise.http.UserInfo;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.CustomMessage;
import com.ultralinked.voip.api.EventMessage;
import com.ultralinked.voip.api.FileMessage;
import com.ultralinked.voip.api.MLoginApi;
import com.ultralinked.voip.api.Message;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.SystemMessage;
import com.ultralinked.voip.api.TextMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import ezvcard.property.Url;

/**
 * Created by Administrator on 2016/8/19 0019.
 */
public class MessageUtils {

    private static final String TAG = "MessageUtils";

    public static SparseArray<String> getAllUnreadMessages(Context context) {

        SparseArray<String> unReadMsgs = new SparseArray<>();
        int unReadCount = MessagingApi.getAllUnreadMessageCounts();
        List<Conversation> allConversations = MessagingApi.getAllConversations();
        int conversationCount = allConversations.size();
        int unReadMsgCount = 0;
        for (Conversation conversation : allConversations) {
            int umsg = conversation.getUnReadMsgCount();

        }
        return null;
    }

    public static int getAllPrivateUnreadMessageCount(List<Conversation> conversations) {

        int unReadMsgCount = getAllPrivateUnreadMessageCount(getAllUnreadMessageCount(conversations));
        return unReadMsgCount;
    }

    public static int getAllPrivateUnreadMessageCount(int count) {

        int unReadMsgCount = MessagingApi.getAllUnreadMessageCounts() - count;
        return unReadMsgCount;
    }


    public static int getAllUnreadMessageCount(List<Conversation> conversations) {

        int unReadMsgCount = 0;
        for (Conversation conversation : conversations) {
            int umsg = conversation.getUnReadMsgCount();
            unReadMsgCount += umsg;

        }
        return unReadMsgCount;
    }


    public static String linkMyself(Message msg) {
        List<String> linkUserIds = msg.getLinkUserIds();
        if (linkUserIds != null && isAllowToLink(msg)) {
            if (linkUserIds.contains(MLoginApi.currentAccount.id)) {
                String name = MLoginApi.currentAccount.nickName;
                if (TextUtils.isEmpty(name)) {
                    name = MLoginApi.currentAccount.userName;
                }
                return ChatModule.formatLinkName(name);
            }
        }
        return null;
    }

    public static boolean isAllowToLink(Message msg) {
        return !(msg.getChatType() == Conversation.SINGLE_CHAT || msg.getSender().equals(MLoginApi.currentAccount.id));
    }


    public static String getMsgBody(Message message) {
        String msgBody = message.getBody();//
        int msgType = message.getType();

        if (message.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
            msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.burning_msg)).append("]").toString();
            return msgBody;
        }

        switch (msgType) {
            case Message.MESSAGE_TYPE_TEXT:
                try {
                    msgBody = ((TextMessage) message).getText();
                } catch (Exception e) {
                    Log.e(TAG, "parse message error:" + message.toString());
                }
                break;
            case Message.MESSAGE_TYPE_VOICE:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.voice)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_IMAGE:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.image)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_VCARD:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.vcard)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_VIDEO:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.video)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_FILE:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.file)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_LOCATION:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.location)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_CUSTOM:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.custom)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_TIPS:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.tips)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_STICKER:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.sticker)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_UNKNOWN:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.unknown)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_PUSH:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.push)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_DRAFT:
                msgBody = "";
                break;
            case Message.MESSAGE_TYPE_EVENT:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.system_message)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_VOIP:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(com.holdingfuture.flutterapp.hfsdk.R.string.call_message)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_SYSTEM:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(R.string.system_message)).append("]").toString();
                break;
            case Message.MESSAGE_TYPE_SUBSCRIBE:
                msgBody = new StringBuffer().append("[").append(App.getInstance().getString(R.string.subscribe_message)).append("]").toString();
                break;
            default:

                msgBody = new StringBuffer().append("[").append("type:").append(msgType).append("]").toString();
                Log.i(TAG, " msg type:" + msgType + " body:" + msgBody);
        }


        return msgBody;
    }

    public static String getMsgBody(String lastMsgUserName,Conversation conversation) {

        String msgBody;
        String draft = conversation.getDraft();
        if (!TextUtils.isEmpty(draft)) {
            msgBody = draft;
        }else{
            msgBody = getMsgBody(conversation.getLastMessage());
            msgBody = lastMsgUserName+msgBody;
        }
        return msgBody;
    }

    public static void read(Message itemData, boolean isReadFileMessage) {

        if (itemData == null) {
            Log.e(TAG, "Message to be set is null");
            return;
        }

        //..
        MessageUtils.bindUrl(itemData);

        switch (itemData.getType()) {
            case Message.MESSAGE_TYPE_IMAGE:
            case Message.MESSAGE_TYPE_VOICE:
                if (isReadFileMessage)
                    itemData.read();
                break;
            default:
                itemData.read();
                break;
        }

        if (itemData.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
            if (!hasStartBurning(itemData)) {

                if (itemData.getStatus() == Message.STATUS_READ) {
                    burning(itemData);
                }

            } else {
                checkBruningEnd(itemData, true);
            }

        }

    }


    private static List<Message> burningMsgList = new ArrayList<>();

    protected static void addBurningList(Message message) {

        if (!burningMsgList.contains(message) && message.getMessageFlag() == Message.MESSAGE_FLAG_BURNING) {
            burningMsgList.add(message);


        }

    }

    static Handler mBurningHandler;

    static int BURNING_TIME = 10 * 1000;

    public static void burning(Message msg) {
        if (msg == null) {
            return;
        }
        try {
            if (msg instanceof CustomMessage) {
                msg.burning();
            }

            addBurningList(msg);

            if (mBurningHandler == null) {
                HandlerThread mBruningThreadHandler = new HandlerThread("Burning");

                mBruningThreadHandler.start();
                mBurningHandler = new Handler(mBruningThreadHandler.getLooper());
            }
            mBurningHandler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    if (burningMsgList.isEmpty()) {
                        com.ultralinked.voip.api.Log.i(TAG, "burning_fire no added--> ");
                        if (mBurningHandler != null) {
                            mBurningHandler.getLooper().quit();
                            mBurningHandler = null;
                        }

                        return;
                    }

                    for (int i = burningMsgList.size() - 1; i >= 0; i--) {
                        Message msg = burningMsgList.get(i);
                        if (msg.burningTime <= 0) {
                            msg = MessagingApi.getMessageById(msg.getKeyId(), msg.getChatType() == Conversation.GROUP_CHAT);
                            if (msg != null) {
                                int pos = burningMsgList.indexOf(msg);
                                if (pos >= 0) {
                                    burningMsgList.set(pos, msg);
                                }

                            }
                        }

                        if (checkBruningEnd(msg, false)) {
                            Intent callHandlerIntent = new Intent(MessagingApi.EVENT_MESSAGE_STATUS_CHANGED);
                            com.ultralinked.voip.api.Log.i(TAG, "burning_fire sendMessageStatusChangeBroadcast--> " + msg.getStatus());
                            callHandlerIntent.putExtra(MessagingApi.PARAM_MESSAGE, msg);
                            LocalBroadcastManager.getInstance(App.getInstance()).sendBroadcast(callHandlerIntent);

                            burningMsgList.remove(msg);
                        }
                    }
                }
            }, getBurnTime(msg));


        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "burning_fire error===" + android.util.Log.getStackTraceString(e));
        }

    }


    public static boolean hasUrlLinkInfo(Message itemData) {
        UrlInfo info = (UrlInfo) itemData.tag;
        return info != null;
    }

    public static void saveUrl(Message itemData) {
        if (itemData.getType() == Message.MESSAGE_TYPE_TEXT) {
            if (itemData.tag != null && itemData.tag instanceof UrlInfo) {
                ACache aCache = ACache.get(App.getInstance());
                UrlInfo info = (UrlInfo) itemData.tag;
                Gson gson = new Gson();
                String urlInfoStr = gson.toJson(info);
                aCache.put(itemData.getConversationId() + "_" + itemData.getKeyId(), urlInfoStr, 30 * ACache.TIME_DAY);
            }
        }
    }

    private static void bindUrl(Message itemData) {
        if (itemData.getType() == Message.MESSAGE_TYPE_TEXT) {
            ACache aCache = ACache.get(App.getInstance());
            String info = aCache.getAsString(itemData.getConversationId() + "_" + itemData.getKeyId());
            if (!TextUtils.isEmpty(info)) {
                Gson gson = new Gson();
                UrlInfo urlInfo = gson.fromJson(info, UrlInfo.class);
                itemData.tag = urlInfo;
            }
        }
    }

    /**
     * for play vibrator when message comin from current chat person
     */
    public static void playMessageVibrator() {

        Vibrator vibrator = (Vibrator)
                App.getInstance().getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(new long[]{0, 300, 200, 300}, -1);

    }
    /**
     * for play vibrator when call comin from current chat person connected
     */
    public static void playCallVibratorOneTime() {

        Vibrator vibrator = (Vibrator)
                App.getInstance().getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(new long[]{0, 500,}, -1);

    }

    /**
     * for play vibrator when message comin from current chat person
     */
    public static void playMessageVibratorOneTime() {

        Vibrator vibrator = (Vibrator)
                App.getInstance().getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(new long[]{0, 300,}, -1);

    }


    public static boolean isEventMsg(Message msg) {
        return msg.getType() == Message.MESSAGE_TYPE_EVENT;
    }

    public static String getSystemMsgContent(SystemMessage systemMessage) {
        try {
            JSONObject jsonObject = new JSONObject(systemMessage.contet);
            String type = jsonObject.optString("systemType");
            if (type.equals("security")) {
                return App.getInstance().getString(R.string.security_msg_tips);
            } else if (type.equals("friend")) {
                return App.getInstance().getString(R.string.friend_added_msg_tips);
            } else if (type.equals("Block")) {
                return App.getInstance().getString(R.string.block_user_info);
            } else if (type.equals("limit")) {
                return App.getInstance().getString(R.string.limit_message_user_info);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public static Message insertSecurityTips(Conversation mConversation) {
        if (mConversation.isGroup()) {
            return null;
        }
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("systemType", "security");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return MessagingApi.insertSystemMessage(mConversation.getContactNumber(), "system", "system", jsonObject.toString(), Conversation.SINGLE_CHAT);

    }


    public static void insertFriendStartTips(String subuser_id) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("systemType", "friend");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        MessagingApi.insertSystemMessage(subuser_id, "system", "system", jsonObject.toString(), Conversation.SINGLE_CHAT);
        // MessagingApi.setUnread();


    }


    public static void notifyAcceptMsg(final EventMessage msg) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject eventJson = new JSONObject(msg.dataStr);
                    String event = eventJson.optString("event");
                    if ("accept_friend".equals(event)) {
                        PeopleEntity entity = GsonUtil.fromJson(eventJson.optJSONObject("user_info").toString(), PeopleEntity.class);
                        DetailHelper.save_FRIEND_(entity);
                        insertFriendStartTips(entity.subuser_id);
                        SingleChatImActivity.launchToSingleChatImWithIntentFlags(App.getInstance(), entity.subuser_id, Conversation.CONVERSATION_FLAG_NONE, Intent.FLAG_ACTIVITY_NEW_TASK);
                        entity.is_friend = true;
                        RxBus.getDefault().post(entity);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }).start();
    }

    public static void insertWelcomeTips() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                List<PeopleEntity> asistants = SPUtil.getAssistant();
                if (asistants != null && !asistants.isEmpty()) {
                    PeopleEntity entity = asistants.get(0);
                    String nickName = SPUtil.getNickname();
                    if (TextUtils.isEmpty(nickName)) {
                        //Init user's head portrait
                        UserInfo userInfo = SPUtil.getUserInfo();
                        if (userInfo != null) {
                            nickName = UserInfo.getDisplayName(userInfo);
                        }
                    }

                    MessagingApi.insertTextMessage(entity.subuser_id, entity.subuser_id, SPUtil.getUserID(), App.getInstance().getString(R.string.welcome_tips, nickName), Conversation.SINGLE_CHAT);
                } else {
                    Log.i(TAG, "insertWelcomeTips not found the user.");
                }
            }
        }, 3000);

    }

    public static boolean checkBruningEnd(Message msg, boolean delete) {
        long burningTime = msg.burningTime;

        Log.i(TAG, "time====" + (System.currentTimeMillis() - burningTime));

        if (hasStartBurning(msg) && ((System.currentTimeMillis() - burningTime) >= getBurnTime(msg))) {
            if (delete) {
                MessagingApi.deleteMessage(msg.getConversationId(), msg.getKeyId());
                Intent callHandlerIntent = new Intent(BaseChatImFragment.EVENT_MESSAGE_DELETED);
                com.ultralinked.voip.api.Log.i(TAG, "EVENT_MESSAGE_DELETED--> " + msg.getStatus());
                callHandlerIntent.putExtra(MessagingApi.PARAM_MESSAGE, msg);
                LocalBroadcastManager.getInstance(App.getInstance()).sendBroadcast(callHandlerIntent);
            }

            return true;
        }
        return false;
    }

    public static int getBurnTime(Message message) {
        return BURNING_TIME;
    }

    public static boolean hasStartBurning(Message msg) {
        return msg.burningTime > 0;
    }


    public static void checkIncomingMessage(Message msg) {
        if (msg != null) {
            if (msg.isSender()) {
                //add resent list .
                addResendList(msg);
            }
        }
    }

    //only call this function in app msg status for the first time.
    public static void checkMsgStatusChanged(Message msg) {
        if (msg != null) {
            if (msg.isSender()) {
                //check send ok or not .
                if (msg.getStatus() == Message.STATUS_OK ||
                        msg.getStatus() == Message.STATUS_READ
                        || msg.getStatus() == Message.STATUS_DELIVERY_OK
                        ) {
                    try {
                        if (resendMsgList.contains(msg)) {
                            resendMsgList.remove(msg);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (msg.getStatus() == Message.STATUS_FAILURE) {
                    //check reason.
                    String failedReason = msg.getErrorInfo();
                    if (msg.getChatType() == Message.CHAT_TYPE_SINGLE && !TextUtils.isEmpty(failedReason)) {
                        String serverErrorType = "";
                        if (failedReason.contains("406") && failedReason.contains("Your active privacy list")) {
                            serverErrorType = "Block";
                        } else if (failedReason.contains("500") && failedReason.contains("Your contact offline message queue is full. The message has been discarded.")) {
                            serverErrorType = "limit";
                        }

                        if (!TextUtils.isEmpty(serverErrorType)) {
                            //remove
                            try {
                                if (resendMsgList.contains(msg)) {
                                    resendMsgList.remove(msg);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put("systemType", serverErrorType);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            MessagingApi.insertSystemMessage(msg.getReceiver(), "system", "system", jsonObject.toString(), Conversation.SINGLE_CHAT);

                        }

                    }

                }
            }
        }
    }


    private static List<Message> resendMsgList = new ArrayList<>();

    protected static void addResendList(Message message) {

        try {
            if (!resendMsgList.contains(message)) {
                resendMsgList.add(message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static void resendAllFailedMsgs() {
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                    for (int i = resendMsgList.size() - 1; i >= 0; i--) {
                        Message msg = resendMsgList.get(i);
                        Message msgFromDb = MessagingApi.getMessageById(msg.getKeyId(), msg.getChatType() == Conversation.GROUP_CHAT);
                        if (msgFromDb == null) {
                            resendMsgList.remove(msg);
                            continue;
                        }

                        msg = msgFromDb;

                        if (msg.getStatus() != Message.STATUS_OK &&
                                msg.getStatus() != Message.STATUS_READ
                                && msg.getStatus() != Message.STATUS_DELIVERY_OK
                                ) {
                            Log.i(TAG, "try to resend failed messages:" + msg.getKeyId() + ";status=" + msg.getStatus() + ";info=" + msg.getBody());
                            MessagingApi.reSendMsg(msg.getConversationId(), msg.getKeyId(), msg instanceof FileMessage);
                        }
                        resendMsgList.remove(msg);
                    }
                }
            }).start();
        } catch (Exception e) {
            Log.i(TAG, "error when resend messages:" + android.util.Log.getStackTraceString(e));
        }
    }


    public static void resendMsg(Message msg) {

        if (MLoginApi.isLogin()) {
            if (msg instanceof FileMessage) {
                FileMessage fmsg = (FileMessage) msg;
                fmsg.reSend();
            } else {
                msg.reSend();
            }
        } else {

            Log.i(TAG, "add resending msg ,user not login, msg id is:" + msg.getKeyId());
            MessagingApi.updateMsgStatus(msg.getConversationId(), msg.getKeyId(), Message.STATUS_DRAFT);
            addResendList(msg);

            if (NetUtil.isNetworkAvailable(App.getInstance())) {
                MLoginApi.checkLoginStatus();
            } else {
                Log.i(TAG, "resed msg ,user not login, there is no network available.");
            }
        }


    }


}
