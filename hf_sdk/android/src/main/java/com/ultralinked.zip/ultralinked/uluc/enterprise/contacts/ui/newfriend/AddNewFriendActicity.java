package com.ultralinked.uluc.enterprise.contacts.ui.newfriend;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.contacts.tools.RawMatchsFriendPerson;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.chat.chatim.SingleChatImActivity;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.contract.PrivateContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailHelper;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailPersonActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.uluc.enterprise.utils.ShareUtils;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class AddNewFriendActicity extends BaseActivity {

    public static final String TAG = "AddNewFriendActicity";
    public static final String KEY_DETAIL_ENTITY = "AddNewFriendActicity";
    public static final String KEY_QUERY_DETAIL_ENTITY = "query";

    private TextView titleCenter;
    protected PeopleEntity mDetailEntity;
    private String shareInfo;


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_detail_person;
    }


    boolean query = false,querySucc =false;
    @Override
    public void initView(Bundle savedInstanceState) {

        mDetailEntity = getIntent().getParcelableExtra(KEY_DETAIL_ENTITY);
        if (mDetailEntity == null){
            finish();
            return;
        }
        initview();
        initTitleBar();


        boolean isFriend = PeopleEntityQuery.getInstance().isFriend(mDetailEntity.subuser_id);
        if (isFriend){
            DetailPersonActivity.gotoDetailPersonActivity(getActivity(), mDetailEntity);
            finish();
        }

        query = getIntent().getBooleanExtra(KEY_QUERY_DETAIL_ENTITY,false);
        if (query){
            queryContact(mDetailEntity,null);
        }
    }



    public  interface  QueryPeopleInfoListener{
        void querySuccess(boolean isRegistered);
    }

    public  void queryContact(final PeopleEntity peopleEntity,final QueryPeopleInfoListener queryPeopleInfoListener) {

        String phoneNum = PhoneNumberUtils.normalizeNumber(peopleEntity.mobile);

        if (phoneNum!=null && phoneNum.startsWith("00")){
            phoneNum = phoneNum.substring(2);
        }

        if (phoneNum!=null && phoneNum.startsWith("+")){
            phoneNum = phoneNum.substring(1);
        }

        Log.i(TAG,"query contact from add new:"+phoneNum);

        ApiManager.getInstance().queryUser(phoneNum)
                .subscribeOn(Schedulers.io())                   //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG,"QueryFriendComplted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        // showToast(eMsg+"");
                        Log.e(TAG, "Query error " + eMsg);
                    }
                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                querySucc = true;
                                RawMatchsFriendPerson rawFriendPerson = GsonUtil.fromJson(rs, RawMatchsFriendPerson.class);
                                if (rawFriendPerson!=null && rawFriendPerson.matchs!=null){
                                    if (rawFriendPerson.matchs.size() >= 1){

                                        if (queryPeopleInfoListener!=null){
                                            queryPeopleInfoListener.querySuccess(true);
                                        }

                                        PeopleEntity entity = rawFriendPerson.matchs.get(0);
                                        DetailHelper.save_STRANGER_(entity);
                                        // go to detail or add friend page.
                                        mDetailEntity = entity;
                                        initview();
                                        //   RequestFriendManager.getInstance().inviteFriend((BaseActivity) getActivity(),entity);

                                    }

                                }else{
                                    //not found. just share.
                                }

                            } else if(202 == object.optInt("code")){
                                querySucc = true;
                                shareInfo = object.optString("description");
                                //showToast(R.string.add_contact_invite_success);
                                String mobile = peopleEntity.mobile;
                                Log.i(TAG,"invite mobile info:"+mobile);
                                if (queryPeopleInfoListener!=null){
                                    queryPeopleInfoListener.querySuccess(false);
                                }

                            }else {

                            }

                        } catch (Exception e) {
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "Exception " + e.getMessage());
                        }

                        Log.i(TAG, "Query  " + rs);
                    }

                });

    }

    Button btnInvite;

    private void initInvite() {
        goneView(bind(R.id.titleRight));
        btnInvite = bind(R.id.btnCall);

        if (!TextUtils.isEmpty(mDetailEntity.subuser_id)){
            btnInvite.setText(R.string.add_contact_button_add);
            btnInvite.setBackgroundResource(R.drawable.button_selector);
        }else {
            btnInvite.setText(R.string.add_contact_button_invite);
            btnInvite.setBackgroundResource(R.drawable.button_invite_selector);
        }

        if (SPUtil.isAssistant(mDetailEntity.subuser_id)){
            goneView(btnInvite);
        }

        goneView(bind(R.id.btnChat));
        btnInvite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDetailEntity!=null){
                    if (shareInfo!=null){//not register.
                        ShareUtils.tellFriend(AddNewFriendActicity.this,shareInfo,mDetailEntity.mobile);
                    }else{
                        if (query){
                            if (querySucc){
                                RequestFriendManager.getInstance().inviteFriend(AddNewFriendActicity.this, mDetailEntity,inviteFriendListenr );
                            }else{
                                queryContact(mDetailEntity,new QueryPeopleInfoListener() {
                                    @Override
                                    public void querySuccess(boolean isRegistered) {
                                        if (isRegistered){
                                            RequestFriendManager.getInstance().inviteFriend(AddNewFriendActicity.this,mDetailEntity,inviteFriendListenr );
                                        }else {
                                            if (shareInfo!=null){
                                                ShareUtils.tellFriend(AddNewFriendActicity.this,shareInfo,mDetailEntity.mobile);
                                            }
                                        }
                                    }
                                });
                            }
                        }else{
                            RequestFriendManager.getInstance().inviteFriend(AddNewFriendActicity.this,mDetailEntity,inviteFriendListenr );
                        }

                    }

                }

            }
        });

    }



    FromContactAdapter.OnFriendClickListener inviteFriendListenr = new FromContactAdapter.OnFriendClickListener() {
        @Override
        public void onItemClickListener(PeopleEntity entity) {

        }

        @Override
        public void callFriendRequest(String action, PeopleEntity peopleEntity) {

        }

        @Override
        public void onFriendStatusChanged(PeopleEntity peopleEntity) {
                    finish();
        }
    };

    private ImageView detailHeadInput;

    private EditText detailNameInput, detailMobileInput, detailCompanyInput, detailDeptInput, detailEmailInput;


    private void initview() {
        initInvite();
        detailHeadInput = (ImageView) findViewById(R.id.detailHeadInput);
        detailNameInput = (EditText) findViewById(R.id.detailNameInput);
        detailMobileInput = (EditText) findViewById(R.id.detailMobileInput);
        detailCompanyInput = (EditText) findViewById(R.id.detailCompanyInput);
        detailDeptInput = (EditText) findViewById(R.id.detailDeptInput);
        detailEmailInput = (EditText) findViewById(R.id.detailEmailInput);

        ImageUtils.loadCircleImage(this, detailHeadInput, mDetailEntity.icon_url, ImageUtils.getDefaultContactImageResource(mDetailEntity.subuser_id));

        detailNameInput.setText(PeopleEntityQuery.getDisplayName(mDetailEntity));
        if (!TextUtils.isEmpty(mDetailEntity.subuser_id)){
            detailMobileInput.setText(PhoneNumberUtils.formatMobile(mDetailEntity.mobile));
        }else{
            detailMobileInput.setText(mDetailEntity.mobile);
        }

        detailCompanyInput.setText(mDetailEntity.companyName);
        //here show the current department name, not all
        detailDeptInput.setText(mDetailEntity.deparment_name);

        if (mDetailEntity.email == null||mDetailEntity.email.equals("null")){
            detailEmailInput.setText("");
        }else{
            if (!TextUtils.isEmpty(mDetailEntity.email)){
                detailEmailInput.setText(mDetailEntity.email);
            }else{
                detailEmailInput.setText("");
            }

        }
        //get all the depart name belongs to
        String sql = " SELECT * FROM " + RelationContract.TABLE_NAME +
                " WHERE  " + RelationContract.RelationColumn.USER_ID + " = '" + mDetailEntity.subuser_id
                + "' ";
        Cursor curor = SqliteUtils.getInstance(this).getDb().rawQuery(sql, null);
        if (curor == null || curor.getCount() == 0) {
            if (curor != null && !curor.isClosed()) {

                curor.close();
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        curor.moveToFirst();
        do {

            sb.append(curor.getString(curor.getColumnIndex(RelationContract.RelationColumn.DEPARTMENT_NAME)));
            sb.append(",");
        } while (curor.moveToNext());

        if (curor != null || !curor.isClosed()) {
            curor.close();
        }
        sb.deleteCharAt(sb.length() - 1);
        String multiple_departname = sb.toString();
        detailDeptInput.setText(multiple_departname);


        checkContactModel();
    }

    private void checkContactModel() {
        if (PeopleEntityQuery.hasFoundPeople(mDetailEntity) && SPUtil.getFindContactsSetting()){
            DetailPersonActivity.gotoDetailPersonActivity(getActivity(), mDetailEntity);
            overridePendingTransition(0,0);
        }
    }

    private void initTitleBar() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.detail_contact_contacts));


        InputControlEnable(false);
    }



    private void InputControlEnable(boolean enable) {

        detailNameInput.setEnabled(enable);
        detailMobileInput.setEnabled(enable);
        detailCompanyInput.setEnabled(enable);
        detailDeptInput.setEnabled(enable);
        detailEmailInput.setEnabled(enable);

        if (enable) {
            //显示虚拟键盘
            InputMethodManager imm = (InputMethodManager) detailNameInput.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

            imm.showSoftInput(detailNameInput, InputMethodManager.SHOW_FORCED);

            detailNameInput.requestFocus();
        } else {
            InputMethodManager imm = (InputMethodManager) detailNameInput.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm.isActive()) {
                imm.hideSoftInputFromWindow(detailNameInput.getApplicationWindowToken(), 0);
            }
        }
    }


}
