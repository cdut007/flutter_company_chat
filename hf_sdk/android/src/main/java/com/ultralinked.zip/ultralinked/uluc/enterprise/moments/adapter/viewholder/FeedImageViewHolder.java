package com.ultralinked.uluc.enterprise.moments.adapter.viewholder;

import android.view.View;
import android.view.ViewStub;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.widgets.MultiImageView;


/**
 * Created by suneee on 2016/8/16.
 */
public class FeedImageViewHolder extends FeedViewHolder {
    /** 图片*/
    public MultiImageView multiImageView;

    public TextView textView;

    public TextView photoCountView;

    public View contentView;

    public FeedImageViewHolder(View itemView){
        super(itemView, TYPE_IMAGE);
    }

    @Override
    public void initSubView(int viewType, ViewStub viewStub) {
        if(viewStub == null){
            throw new IllegalArgumentException("viewStub is null...");
        }
        viewStub.setLayoutResource(R.layout.feed_user_text_image_cell);
        contentView = viewStub.inflate();
        MultiImageView multiImageView = (MultiImageView) contentView.findViewById(R.id.cover);

        textView = (TextView) contentView.findViewById(R.id.text);

        photoCountView = (TextView) contentView.findViewById(R.id.photoCount);
        if(multiImageView != null){
            this.multiImageView = multiImageView;
            multiImageView.setCrop(true);
        }
    }
}
