package com.ultralinked.uluc.enterprise.contacts;

import android.content.Context;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.HashMap;
import java.util.List;

/**
 * Created by Chenlu on 2016/7/4 0004.
 */
public class ContactsExpandableAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> expandableListTitle;
    private HashMap<String, List<PeopleEntity>> expandableListDetail;

    public ContactsExpandableAdapter(Context context, List<String> expandableListTitle,
                                     HashMap<String, List<PeopleEntity>> expandableListDetail) {
        this.context = context;
        this.expandableListTitle = expandableListTitle;
        this.expandableListDetail = expandableListDetail;
        notifyDataSetChanged();
    }

    public void setData(List<String> expandableListTitle, HashMap<String, List<PeopleEntity>> expandableListDetail) {
        this.expandableListTitle = expandableListTitle;
        this.expandableListDetail = expandableListDetail;
        notifyDataSetChanged();
    }


    //        获取分组的个数
    @Override
    public int getGroupCount() {
        return expandableListTitle == null ? 0 : this.expandableListTitle.size();
    }

    //        获取指定分组中的子选项的个数
    @Override
    public int getChildrenCount(int listPosition) {
        return expandableListDetail == null ? 0 : this.expandableListDetail.get(this.expandableListTitle.get(listPosition)).size();
    }


    //        获取指定的分组数据
    @Override
    public Object getGroup(int listPosition) {
        return expandableListTitle == null ? null : this.expandableListTitle.get(listPosition);
    }

    //        获取指定分组中的指定子选项数据
    @Override
    public PeopleEntity getChild(int listPosition, int expandedListPosition) {
        return this.expandableListDetail.get(this.expandableListTitle.get(listPosition))
                .get(expandedListPosition);
    }


    //        获取指定分组的ID, 这个ID必须是唯一的
    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    //        获取子选项的ID, 这个ID必须是唯一的
    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    //        获取显示指定分组的视图
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        GroupViewHolder groupViewHolder;

        String listTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.expand_list_group, null);

            groupViewHolder = new GroupViewHolder();
            groupViewHolder.bind(convertView);
            convertView.setTag(groupViewHolder);

        } else {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        }

        ViewGroup.LayoutParams layoutParams = convertView.getLayoutParams();
        if (layoutParams == null){
            layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0);
        }
        convertView.setLayoutParams(layoutParams);

        groupViewHolder.tvTitle.setTypeface(null, Typeface.BOLD);
        groupViewHolder.tvTitle.setText(listTitle);

        //      把位置和图标添加到Map
        mIndicators.put(groupPosition, groupViewHolder.iv_indicator);
        //      根据分组状态设置Indicator
        setIndicatorState(groupPosition, isExpanded);

        return convertView;
    }


    //        获取显示指定分组中的指定子选项的视图
    @Override
    public View getChildView(int listPosition, final int expandedListPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        ChildViewHolder childViewHolder;

        PeopleEntity entity = getChild(listPosition, expandedListPosition);
        final String expandedListText = PeopleEntityQuery.getDisplayName(entity);

        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(com.holdingfuture.flutterapp.hfsdk.R.layout.expand_list_item_displaymore, null);

            childViewHolder = new ChildViewHolder();
            childViewHolder.bind(convertView);
            convertView.setTag(childViewHolder);

        } else {
            childViewHolder = (ChildViewHolder) convertView.getTag();
        }

        childViewHolder.tvTitle.setText(expandedListText);
        childViewHolder.subTitle.setText(entity.deparment_type);
        childViewHolder.subTitle.setVisibility(View.GONE);
        int defaultId = ImageUtils.getDefaultContactImageResource(entity.subuser_id);


        ImageUtils.loadCircleImage(context, childViewHolder.IvHead, entity.icon_url, defaultId);

        return convertView;
    }

    //        分组和子选项是否持有稳定的ID, 就是说底层数据的改变会不会影响到它们。
    @Override
    public boolean hasStableIds() {
        return true;
    }

    //        指定位置上的子元素是否可选中
    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }

    static class GroupViewHolder {
        TextView tvTitle;
        ImageView iv_indicator;

        public void bind(View convertView) {
            iv_indicator = (ImageView) convertView.findViewById(R.id.iv_indicator);
            tvTitle = (TextView) convertView.findViewById(R.id.listTitle);
        }
    }

    public static class ChildViewHolder {
        public  TextView tvTitle;
        public  ImageView IvHead;
        public  TextView subTitle;

        public void bind(View convertView) {
            tvTitle = (TextView) convertView.findViewById(R.id.title);
            IvHead = (ImageView) convertView.findViewById(R.id.header_img);
            subTitle = (TextView) convertView.findViewById(R.id.subtitle);
        }
    }

    //                用于存放Indicator的集合
    private SparseArray<ImageView> mIndicators = new SparseArray<>();

    //            根据分组的展开闭合状态设置指示器
    public void setIndicatorState(int groupPosition, boolean isExpanded) {
        if (isExpanded) {
            mIndicators.get(groupPosition).setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.triangle_down);
        } else {
            mIndicators.get(groupPosition).setImageResource(com.holdingfuture.flutterapp.hfsdk.R.mipmap.triangle_right);
        }
    }
}
