package com.ultralinked.uluc.enterprise.contacts.contract;

/**
 * Created by ultralinked on 16/7/11.
 */

import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentValues;
import android.content.OperationApplicationException;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.ultralinked.contact.contact.DbHelper;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract.RelationColumn;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;

import java.util.ArrayList;

/**
 * Created by ultralinked on 16/6/30.
 */
public class MultiProvider extends ContentProvider {

    static final int PERSONNEL = 100;
    static final int PERSONNEL_ID = 101;
    static final int PERSONNEL_WITH_COMPANY = 102;

    static final int PERSONNEL_WITH_ALL = 103;

    static final int RELATION = 400;
    static final int RELATION_ID = 401;


    static final int PRIVATE = 500;
    static final int PRIVATE_ID = 501;


    static final int FRIEND = 600;
    static final int FRIEND_ID = 601;



    static final int STRANGER = 700;
    static final int STRANGER_ID = 701;



    static final int LOCAL = 800;
    static final int LOCAL_ID = 801;


    public static final String authority = "com.ultralinked.uluc.enterprise.contacts";

    private static final UriMatcher sUriMatcher;
    private static final String TAG = "MultiProvider";

    static {

        sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        //使用addURI方法，将自定义的Uri添加，也就是注册吧。从WeatherContract中获取定义好的常量。(String authority , String path ,int code)
        sUriMatcher.addURI(authority, PersonnelContract.PATH_PERSONNEL, PERSONNEL);
        sUriMatcher.addURI(authority, PersonnelContract.PATH_PERSONNEL + "/#", PERSONNEL_ID);
        sUriMatcher.addURI(authority, PersonnelContract.PATH_PERSONNEL + "/company", PERSONNEL_WITH_COMPANY);
        sUriMatcher.addURI(authority, PersonnelContract.PATH_PERSONNEL + "/all", PERSONNEL_WITH_ALL);

        sUriMatcher.addURI(authority, RelationContract.PATH_RELATION, RELATION);
        sUriMatcher.addURI(authority, RelationContract.PATH_RELATION + "/#", RELATION_ID);

        sUriMatcher.addURI(authority, PrivateContract.PATH_PRIVATE, PRIVATE);
        sUriMatcher.addURI(authority, PrivateContract.PATH_PRIVATE + "/#", PRIVATE_ID);


        sUriMatcher.addURI(authority, FriendContract.PATH_FRIEND, FRIEND);
        sUriMatcher.addURI(authority, FriendContract.PATH_FRIEND + "/#", FRIEND_ID);


        sUriMatcher.addURI(authority, StrangerContract.PATH_STRANGER, STRANGER);
        sUriMatcher.addURI(authority, StrangerContract.PATH_STRANGER + "/#", STRANGER_ID);


        sUriMatcher.addURI(authority, LocalContactContract.PATH_LOCAL, LOCAL);
        sUriMatcher.addURI(authority, LocalContactContract.PATH_LOCAL + "/#", LOCAL_ID);
    }


    private SqliteUtils mSqliteUtils;

    @Override
    public boolean onCreate() {
        mSqliteUtils = SqliteUtils.getInstance(getContext());
        return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Log.i(TAG, " query uri == " + uri.toString());
        Cursor retCursor = null;

        switch (sUriMatcher.match(uri)) {

            // "person" // "person"
            case PERSONNEL:

                retCursor = mSqliteUtils.getDb().query(
                        PersonnelContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );

                break;
            case PERSONNEL_ID:
                retCursor = mSqliteUtils.getDb().query(
                        PersonnelContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;

            // "person with company"
            case PERSONNEL_WITH_COMPANY:

//                String joinables = "SELECT" +
//                        PersonnelColumn._ID +
//                        "FROM " +
//                        PersonnelContract.TABLE_NAME +
//                        " a INNER JOIN " +
//                        RelationContract.TABLE_NAME +
//                        " b ON a." +
//                        PersonnelContract.PersonnelColumn.SUBUSER_ID + " = b." + RelationContract.RelationColumn.SUBUSER_ID;
//
//                retCursor = mOpenHelper.getReadableDatabase().rawQuery(joinables, selectionArgs);
                String[] projections = DbSQLHelper.getPeopleWithCompanyColumns();

                if (!TextUtils.isEmpty(selection)) {

                    selection = "( a." + PersonnelContract.PersonnelColumn.SUBUSER_ID
                            + " = b."
                            + RelationColumn.USER_ID + ") AND " + selection;
                } else {

                    selection = "( a." + PersonnelContract.PersonnelColumn.SUBUSER_ID
                            + " = b."
                            + RelationColumn.USER_ID + ") ";
                }

                retCursor = mSqliteUtils.getDb().query(
                        PersonnelContract.TABLE_NAME + " AS a inner join  " + RelationContract.TABLE_NAME + " As b",
                        projections,
                        selection,
                        null,
                        null,
                        null,
                        "b." + RelationColumn.DEPARTMENT_TYPE + " DESC , a." + PersonnelContract.PersonnelColumn.NAME + " ASC "
                );
                Log.i(TAG, " query PERSONNEL_WITH_COMPANY");
                break;


//            // "person with all"
            case PERSONNEL_WITH_ALL:

                String querySql = null;
                if (TextUtils.isEmpty(selection)){
                    retCursor = mSqliteUtils.getDb().rawQuery(querySql="SELECT * FROM "+PersonnelContract.TABLE_NAME +" INNER JOIN "+RelationContract.TABLE_NAME+" ON personnel.subuser_id = relation.user_id " +
                                    "where relation.company_id = '"+ CompanySelector.getInstance(App.getInstance()).getCompanyID()+"' UNION SELECT * FROM "+FriendContract.TABLE_NAME+" LEFT JOIN "+RelationContract.TABLE_NAME+" ON friend.subuser_id = relation.user_id",
                            null);
                }else{

                    String searchWord = " '%" + selection + "%'";
                    String subCondition = " and "+ PersonnelContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.SUBUSER_ID + " LIKE " + searchWord
                    + " OR "+PersonnelContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.EMAIL + " LIKE " + searchWord
                    + " OR "+PersonnelContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.MOBILE + " LIKE " + searchWord
                    + " OR "+PersonnelContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.NICKNAME + " LIKE " + searchWord
                    + " OR "+PersonnelContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.REMARKNAME + " LIKE " + searchWord;


                    String subCondition2 = " where "+ FriendContract.TABLE_NAME+"." + PersonnelContract.PersonnelColumn.SUBUSER_ID + " LIKE " + searchWord
                            + " OR "+FriendContract.TABLE_NAME+"."+ PersonnelContract.PersonnelColumn.EMAIL + " LIKE " + searchWord
                            + " OR "+FriendContract.TABLE_NAME+"."+ PersonnelContract.PersonnelColumn.MOBILE + " LIKE " + searchWord
                            + " OR "+FriendContract.TABLE_NAME+"."+ PersonnelContract.PersonnelColumn.NICKNAME + " LIKE " + searchWord
                            + " OR "+FriendContract.TABLE_NAME+"."+ PersonnelContract.PersonnelColumn.REMARKNAME + " LIKE " + searchWord;

                    retCursor = mSqliteUtils.getDb().rawQuery(querySql="SELECT * FROM "+PersonnelContract.TABLE_NAME +" INNER JOIN "+RelationContract.TABLE_NAME+" ON personnel.subuser_id = relation.user_id " +
                                    "where relation.company_id = '"+ CompanySelector.getInstance(App.getInstance()).getCompanyID()+"' "+subCondition+" UNION SELECT * FROM "+FriendContract.TABLE_NAME+" LEFT JOIN "+RelationContract.TABLE_NAME+
                            " ON friend.subuser_id = relation.user_id "+subCondition2,
                            null);
                }

                Log.i(TAG, " query PERSONNEL_WITH_ALL "+selection);
                Log.i(TAG, " query SQL: "+querySql);
                break;

            case RELATION:
            case RELATION_ID:

                retCursor = mSqliteUtils.getDb().query(
                        RelationContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;

            case FRIEND:
            case FRIEND_ID:

                retCursor = mSqliteUtils.getDb().query(
                        FriendContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;


            case PRIVATE:
            case PRIVATE_ID:

                retCursor = mSqliteUtils.getDb().query(
                        PrivateContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            case STRANGER:
            case STRANGER_ID:

                retCursor = mSqliteUtils.getDb().query(
                        StrangerContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;

            case LOCAL:
            case LOCAL_ID:

                retCursor = mSqliteUtils.getDb().query(
                        LocalContactContract.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;


            default:
                Log.i(TAG, " query null and uri is " + uri);
                break;

        }

        retCursor.setNotificationUri(getContext().getContentResolver(), uri);
        return retCursor;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {

        final int match = sUriMatcher.match(uri);

        switch (match) {
            //personnel
            case PERSONNEL:
                return PersonnelContract.CONTENT_TYPE;

            case PERSONNEL_ID:
                return PersonnelContract.CONTENT_ITEM_TYPE;

            case PERSONNEL_WITH_COMPANY:
                return PersonnelContract.CONTENT_ITEM_TYPE;

            case PERSONNEL_WITH_ALL:
                return PersonnelContract.CONTENT_ITEM_TYPE;

            //relation

            case RELATION:
                return RelationContract.CONTENT_TYPE;

            case RELATION_ID:
                return RelationContract.CONTENT_ITEM_TYPE;

            case PRIVATE:

                return PrivateContract.CONTENT_TYPE;

            case PRIVATE_ID:

                return PrivateContract.CONTENT_ITEM_TYPE;

            case FRIEND:

                return FriendContract.CONTENT_TYPE;

            case FRIEND_ID:

                return FriendContract.CONTENT_ITEM_TYPE;

            case STRANGER:

                return StrangerContract.CONTENT_TYPE;

            case STRANGER_ID:

                return StrangerContract.CONTENT_ITEM_TYPE;


            case LOCAL:

                return LocalContactContract.CONTENT_TYPE;

            case LOCAL_ID:

                return LocalContactContract.CONTENT_ITEM_TYPE;

            default:
                Log.i(TAG, " getType null and uri is " + uri);
                throw new UnsupportedOperationException("Unknown uri:" + uri);
        }
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.i(TAG, " insert uri == " + uri.toString());
        SQLiteDatabase db = mSqliteUtils.getDb();

        final int match = sUriMatcher.match(uri);

        String table = null;

        switch (match) {

            case PERSONNEL:
            case PERSONNEL_ID:

                table = PersonnelContract.TABLE_NAME;

                break;

            case RELATION:
            case RELATION_ID:

                table = RelationContract.TABLE_NAME;

                break;

            case PRIVATE:
            case PRIVATE_ID:

                table = PrivateContract.TABLE_NAME;

                break;

            case STRANGER:
            case STRANGER_ID:

                table = StrangerContract.TABLE_NAME;

                break;

            case LOCAL:
            case LOCAL_ID:

                table = LocalContactContract.TABLE_NAME;

                break;


            case FRIEND:
            case FRIEND_ID:

                table = FriendContract.TABLE_NAME;

                break;
            default:
                Log.i(TAG, " insert null and uri is " + uri);
                return null;
        }


        long id = db.insert(table, null /* nullColumnHack */, values);

        notifyChange();

        return uri.buildUpon().appendEncodedPath(String.valueOf(id)).build();
    }


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        Log.i(TAG, " delete uri == " + uri.toString());
        SQLiteDatabase db = mSqliteUtils.getDb();

        final int match = sUriMatcher.match(uri);

        int count = 0;

        switch (match) {

            case PERSONNEL:
            case PERSONNEL_ID:

                count = db.delete(PersonnelContract.TABLE_NAME, selection, selectionArgs);

                notifyChange();

                break;
            case PRIVATE:
            case PRIVATE_ID:

                count = db.delete(PrivateContract.TABLE_NAME, selection, selectionArgs);

                notifyChange();
                break;

            case STRANGER:
            case STRANGER_ID:

                count = db.delete(StrangerContract.TABLE_NAME, selection, selectionArgs);

                notifyChange();
                break;

            case LOCAL:
            case LOCAL_ID:

                count = db.delete(LocalContactContract.TABLE_NAME, selection, selectionArgs);

                notifyChange();
                break;

            case FRIEND:
            case FRIEND_ID:

                count = db.delete(FriendContract.TABLE_NAME, selection, selectionArgs);

                notifyChange();
                break;

            default:
                Log.i(TAG, " delete null and uri is " + uri);
                return 0;
        }


        return count;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        SQLiteDatabase db = mSqliteUtils.getDb();

        final int match = sUriMatcher.match(uri);

        int count = 0;

        switch (match) {

            case PERSONNEL:
            case PERSONNEL_ID:

                count = db.update(PersonnelContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();

                break;

            case RELATION:
            case RELATION_ID:

                count = db.update(RelationContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();

                break;

            case PRIVATE:
            case PRIVATE_ID:

                count = db.update(PrivateContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();
                break;

            case STRANGER:
            case STRANGER_ID:

                count = db.update(StrangerContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();
                break;

            case LOCAL:
            case LOCAL_ID:

                count = db.update(LocalContactContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();
                break;

            case FRIEND:
            case FRIEND_ID:

                count = db.update(FriendContract.TABLE_NAME, values, selection, selectionArgs);

                notifyChange();
                break;

            default:
                Log.i(TAG, " update null and uri is " + uri);
                return 0;
        }


        return count;
    }


    @NonNull
    @Override
    public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> operations) throws OperationApplicationException {
        SQLiteDatabase db = mSqliteUtils.getDb();
        db.beginTransaction();
        try {
            ContentProviderResult[] results = super.applyBatch(operations);
            db.setTransactionSuccessful();

            return results;
        } catch (Exception e) {
            Log.i(TAG, " applyBatch Exception " + e.getMessage());
            return null;

        } finally {
            db.endTransaction();

        }
    }


    @Override
    public int bulkInsert(Uri uri, ContentValues[] values) {

        Log.i(TAG, " bulkInsert uri == " + uri.toString());

        SQLiteDatabase db = mSqliteUtils.getDb();

        String table = null;

        final int match = sUriMatcher.match(uri);


        switch (match) {

            case PERSONNEL:
            case PERSONNEL_ID:
                Log.i(TAG, " bulkInsert PERSONNEL");
                table = PersonnelContract.TABLE_NAME;

                break;

            case RELATION:
            case RELATION_ID:
                Log.i(TAG, " bulkInsert RELATION");
                table = RelationContract.TABLE_NAME;

                break;

            case PRIVATE:
            case PRIVATE_ID:
                Log.i(TAG, " bulkInsert PRIVATE");
                table = PrivateContract.TABLE_NAME;

                break;

            case STRANGER:
            case STRANGER_ID:
                Log.i(TAG, " bulkInsert Stranger");
                table = StrangerContract.TABLE_NAME;

                break;

            case LOCAL:
            case LOCAL_ID:
                Log.i(TAG, " bulkInsert local");
                table = LocalContactContract.TABLE_NAME;

                break;


            case FRIEND:
            case FRIEND_ID:
                Log.i(TAG, " bulkInsert FRIEND");
                table = FriendContract.TABLE_NAME;

                break;

            default:
                Log.i(TAG, " bulkInsert null and uri is " + uri);
                table = null;
                return 0;
        }


        int count = 0;
        //update maybe cause error. so  do not delete when necessary.
        if (table!= StrangerContract.TABLE_NAME){
            db.execSQL("delete from "+ table);
        }

        try {

            db.beginTransaction();

            for (ContentValues value : values) {

                long id = db.replace(table, null, value);

                if (id > 0) {
                    count++;
                }
            }

            Log.i(TAG, " bulkInsert count " + count);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            // Your error handling
            Log.i(TAG, " bulkInsert Exception " + e.getMessage());
        } finally {
            db.endTransaction();
            notifyChange();
        }

        return count;
    }

    private void notifyChange() {
        Log.i(TAG, "notifyChange ");
        getContext().getContentResolver().notifyChange(PersonnelContract.CONTENT_URI, null /* observer */);

        getContext().getContentResolver().notifyChange(RelationContract.CONTENT_URI, null /* observer */);

        getContext().getContentResolver().notifyChange(PrivateContract.CONTENT_URI, null /* observer */);

        getContext().getContentResolver().notifyChange(FriendContract.CONTENT_URI, null /* observer */);

        getContext().getContentResolver().notifyChange(StrangerContract.CONTENT_URI, null /* observer */);

        getContext().getContentResolver().notifyChange(LocalContactContract.CONTENT_URI, null /* observer */);


    }

}

