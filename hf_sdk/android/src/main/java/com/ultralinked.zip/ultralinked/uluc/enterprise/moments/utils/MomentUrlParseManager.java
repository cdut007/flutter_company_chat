package com.ultralinked.uluc.enterprise.moments.utils;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.moments.bean.CircleItem;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.utils.Log;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by ultralinked on 2016/6/16 0016.
 */

public class MomentUrlParseManager {

    private static MomentUrlParseManager urlParseManager;
    private final String TAG = getClass().getSimpleName();

    private MomentUrlParseManager() {
    }


    public static final String ZHIHU_NEWS = "http://news.at.zhihu.com";
    public static final String ZHIHU_DAILY_NEWS_CONTENT = "http://daily.zhihu.com/story";

    public static final String ZCOOL_URL = "http://m.zcool.com.cn/works/";
    public static final String NG_BASE_URL = "http://m.nationalgeographic.com.cn";
    public static final String MOMENT_URL = "http://moment.douban.com/app/";

    // TODO replace page with number
    public static final String BAIDU = "http://image.baidu.com/";

    public static final String GANK = "http://gank.io/";

    public static final String HEAD_BASE_URL = "http://image.baidu.com/channel?c=%E6%91%84%E5%BD%B1&t=%E5%9B%BD%E5%AE%B6%E5%9C%B0%E7%90%86&s=0";


    protected String pass(String string) {
        if (string == null) string = "";
        return string;
    }

    public interface  IFetchMomentLister{
       void momentListResult(int pageNum, List<CircleItem> fetchMomentList);
    }

    public  void  requestMoment(final int pageNum,final IFetchMomentLister fetchMomentLister) {

        try{


            Observable.create(new Observable.OnSubscribe<List<CircleItem>>() {


                @Override
                public void call(Subscriber<? super List<CircleItem>> subscriber) {
                    try {


//                        Calendar dateToGetUrl = Calendar.getInstance();
//                        dateToGetUrl.add(Calendar.DAY_OF_YEAR, 1);
//                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd", Locale.US);
//                        String date = simpleDateFormat.format(dateToGetUrl.getTime());
                        //+"/api/4/news/before/"+date
                        String requestUrl = NG_BASE_URL;

                        Document doc = Jsoup.connect(requestUrl).timeout(10000).get();
                        Log.i(TAG,"html:" +doc.toString());
                        String result = null;

                        Element contents = doc.getElementById("ajaxBox");
                        Elements list = contents.getElementsByClass("ajax_list");
                        List<CircleItem> circleItems = new ArrayList<CircleItem>();
                        for (int i = 0; i < 10 && i < list.size(); i++) {
                            Element element = list.get(i);
                            Element imageA = element.select("dd").first().select("a").first();
                            String url = pass(imageA.attr("href"));
                            Element info = imageA.select("img").first();
                            String title = pass(info.attr("alt"));
                            String imgUrl = pass(info.absUrl("src"));
                            String content = pass(element.getElementsByClass("ajax_dd_text").first().ownText());

                            android.util.Log.i("xyz ", "ngfragment " +content +"@@@"+ imgUrl  +"@@@"+  url +"@@@"+ title);

                            CircleItem item = new CircleItem();
                            User user = DatasUtil.getUser();
                            item.setId(String.valueOf(i));
                            item.setUser(user);
                            item.setContent(content);
                            item.setCreateTime(App.getInstance().getString(R.string.date_info));

                            //item.setFavorters(DatasUtil.createFavortItemList(jsonObject.optJSONArray("like")));
                            int type =0;
                            if (type == 0) {
                                item.setType("1");// 链接
                                item.setLinkImg(DatasUtil.createPhoto());
                                item.setLinkTitle(title);
                                item.setLinkUrl(NG_BASE_URL+url);
                            } else if(type == 1){
                                item.setType("2");// 图片
                                item.setPhotos(DatasUtil.createPhotos(imgUrl));
                            }else {
                                item.setType("3");// 视频
                                String videoUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.mp4";
                                String videoImgUrl = "http://yiwcicledemo.s.qupai.me/v/80c81c19-7c02-4dee-baca-c97d9bbd6607.jpg";
                                item.setVideoUrl(videoUrl);
                                item.setVideoImgUrl(videoImgUrl);
                            }
                            circleItems.add(item);
                        }


                        subscriber.onNext(circleItems);
                    } catch (Exception e) {
                        e.printStackTrace();
                        subscriber.onNext(new ArrayList<CircleItem>());
                    }






                }

            })
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<List<CircleItem>>() {
                        @Override
                        public void call(List<CircleItem> info) {
                                if (fetchMomentLister!=null){
                                    fetchMomentLister.momentListResult(pageNum,info);
                                }

                        }

                    });

        }catch (Exception e){
            e.printStackTrace();
        }

    }


    public static MomentUrlParseManager getInstance() {
        if (urlParseManager == null){
            urlParseManager = new MomentUrlParseManager();
        }
        return urlParseManager;
    }




}
