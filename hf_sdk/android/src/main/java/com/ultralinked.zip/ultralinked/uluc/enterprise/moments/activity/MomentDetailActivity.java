package com.ultralinked.uluc.enterprise.moments.activity;

import android.os.Bundle;

import com.ultralinked.uluc.enterprise.baseui.BaseActivity;

/**
 * Created by mac on 17/1/24.
 */

public class MomentDetailActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return 0;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
