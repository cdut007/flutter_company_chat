package com.ultralinked.uluc.enterprise.utils;

import java.util.HashSet;
import java.util.Set;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import com.holdingfuture.flutterapp.hfsdk.R;

public class ProximityUtil {


    public static Boolean isProximitySensorNearby(final SensorEvent event) {
        float threshold = 4.001f; // <= 4 cm is near

        final float distanceInCm = event.values[0];
        final float maxDistance = event.sensor.getMaximumRange();


        if (maxDistance <= threshold) {
            // Case binary 0/1 and short sensors
            threshold = maxDistance;
        }

        return distanceInCm < threshold;
    }


    private static boolean sLastProximitySensorValueNearby;

    /**
     * @return the sProximityDependentActivities
     */
    public static Set<Activity> getsProximityDependentActivities() {
        return sProximityDependentActivities;
    }


    private static Set<Activity> sProximityDependentActivities = new HashSet<Activity>();
    private static SensorEventListener sProximitySensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.timestamp == 0) return; //just ignoring for nexus 1
            sLastProximitySensorValueNearby = isProximitySensorNearby(event);
            proximityNearbyChanged();
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };


    private static void simulateProximitySensorNearby(Activity activity, boolean nearby) {
        final Window window = activity.getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        View view = ((ViewGroup) window.getDecorView().findViewById(android.R.id.content)).getChildAt(0);
       // View  callView = view.findViewById(R.id.call_layout);
        if (nearby) {
            params.screenBrightness = 0.1f;


        } else {
            params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;


        }
        window.setAttributes(params);
    }

    private static void proximityNearbyChanged() {
        boolean nearby = sLastProximitySensorValueNearby;
        for (Activity activity : sProximityDependentActivities) {
            simulateProximitySensorNearby(activity, nearby);
        }
    }

    public static synchronized void startProximitySensorForActivity(Activity activity) {
        //"SPH-L720: Build.MODEL
        if ("SPH-L720".equalsIgnoreCase(Build.MODEL) || "MI 2S".equalsIgnoreCase(Build.MODEL)) {
            return;
        }
        if (sProximityDependentActivities.contains(activity)) {
            return;
        }
        if (sProximityDependentActivities.isEmpty()) {
            SensorManager sm = (SensorManager) activity.getSystemService(Context.SENSOR_SERVICE);
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            if (s != null) {
                sm.registerListener(sProximitySensorListener, s, SensorManager.SENSOR_DELAY_UI);

            }
        } else if (sLastProximitySensorValueNearby) {
            simulateProximitySensorNearby(activity, true);
        }

        sProximityDependentActivities.add(activity);
    }

    public static synchronized void stopProximitySensorForActivity(Activity activity) {

        if ("SPH-L720".equalsIgnoreCase(Build.MODEL) || "MI 2S".equalsIgnoreCase(Build.MODEL)) {
            return;
        }
        sProximityDependentActivities.remove(activity);
        simulateProximitySensorNearby(activity, false);
        if (sProximityDependentActivities.isEmpty()) {
            SensorManager sm = (SensorManager) activity.getSystemService(Context.SENSOR_SERVICE);
            sm.unregisterListener(sProximitySensorListener);
            sLastProximitySensorValueNearby = false;
        }

        Log.i("ProximityUtil", "sProximityDependentActivities size:" + sProximityDependentActivities.size());
    }

}

