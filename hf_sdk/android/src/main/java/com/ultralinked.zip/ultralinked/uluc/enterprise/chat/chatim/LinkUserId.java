package com.ultralinked.uluc.enterprise.chat.chatim;

/**
 * Created by mac on 16/11/15.
 */

public class LinkUserId {


    public  String linkName,id;

    @Override
    public boolean equals(Object obj) {
        LinkUserId linkUserId = (LinkUserId) obj;
        if (id!=null && id.equals(linkUserId.id)){
            return true;
        }
        return super.equals(obj);
    }
}
