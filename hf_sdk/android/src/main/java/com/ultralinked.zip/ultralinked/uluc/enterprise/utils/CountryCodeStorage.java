package com.ultralinked.uluc.enterprise.utils;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CountryCodeStorage {


    public class DBConstant {


        public static final String DB_DBNAME = "accountdb";

        public static final String DB_ACCOUNT_TABLENAME = "account";
        public final static String ID = "_id";
        public final static String USERNAME = "username";
        public final static String MD5_PASSWORD = "password";

        public final static String BALANCE = "balance";
        public final static String LAST_UPDATE_TIME = "lastupdatetime";
        public final static String COUNTRY_CODE = "countrycode";
        public final static String CALL_DISPLAYNAME = "calldisplaynum";
        public final static String CALLERNUM = "callernum";
        public final static String ABROADNUM = "abroadnum";

        public static final String DB_COUNTRY_DBNAME = "countrydb";
        public static final String DB_COUNTRY_TABLENAME = "country";
        public static final String COUNTRY_FULL_NAME = "full_name";
        public static final String COUNTRY_SHORT_NAME = "short_name";


    }


    private Context context;
    private final static String TAG = "CountryCodeStorage";

    public CountryCodeStorage(Context c) {

        this.context = c;

    }

    public void close() {
        contentStr = null;
    }

    private ContentValues mappingContact2ContentValues(CountryInfo countryInfo) {

        ContentValues values = new ContentValues();

        values.put(DBConstant.COUNTRY_SHORT_NAME, countryInfo.getShortName());
        values.put(DBConstant.COUNTRY_FULL_NAME, countryInfo.getFullName());
        values.put(DBConstant.COUNTRY_CODE, countryInfo.getCountryCode());

        return values;
    }

    private CountryInfo mappingCurse2Contact(Cursor cursor) {
        CountryInfo info = new CountryInfo();
        info.setFullName(cursor.getString(cursor
                .getColumnIndex(DBConstant.COUNTRY_FULL_NAME)));
        info.setShortName(cursor.getString(cursor
                .getColumnIndex(DBConstant.COUNTRY_SHORT_NAME)));
        info.setCountryCode(cursor.getString(cursor
                .getColumnIndex(DBConstant.COUNTRY_CODE)));

        return info;
    }

    String contentStr = null;

    String lastCheckLanguage = null;

    private String getCountryString() {

        String currentLanguage = Locale.getDefault().getLanguage();
        if (contentStr != null && currentLanguage != null && currentLanguage.equals(lastCheckLanguage)) {
            return contentStr;
        }
        try {
            lastCheckLanguage = currentLanguage;
            Log.i(TAG, "currentLanguage = " + currentLanguage);
            String country_info = "country_info_en.txt";
            if ("zh".equalsIgnoreCase(currentLanguage)) {
                country_info = "country_info_zn.txt";

            }
            InputStream is = context.getAssets().open(country_info);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "utf-8"));

            StringBuffer stringBuffer = new StringBuffer();
            String line;
            while ((line = br.readLine()) != null) {
                stringBuffer.append(line);
            }
            br.close();
            is.close();
            contentStr = stringBuffer.toString();
            return contentStr;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    Gson sGson = new Gson();

    ArrayList<CountryInfo> list = new ArrayList<CountryInfo>();
    String lastCountryStr ;
    public ArrayList<CountryInfo> getAllCountryInfo() {

        if (list.isEmpty()){
            lastCountryStr = getCountryString();
            list = sGson.fromJson(lastCountryStr, new TypeToken<List<CountryInfo>>() {
            }.getType());
        }else{
            if (getCountryString()!=null&& !getCountryString().equals(lastCountryStr)){
                lastCountryStr = getCountryString();
                list = sGson.fromJson(lastCountryStr, new TypeToken<List<CountryInfo>>() {
                }.getType());
            }
        }


        return list;
    }


    public List<CountryInfo> getHotReginsCountryInfo() {

        List<CountryInfo> hotRegions = new ArrayList<>();
        Resources res = context.getResources () ;
        String [] regions = res.getStringArray(R.array.hot_regions);

        String [] regionsShortName = res.getStringArray(R.array.hot_regions_shortname);


        String [] regionsCode = res.getStringArray(R.array.hot_regions_code);

        for (int i = 0; i < regions.length; i++) {
            CountryInfo country = new CountryInfo();
            country.setCountryCode("+"+regionsCode[i]);
            country.setFullName(regions[i]);
            country.setShortName(regionsShortName[i]);
            country.setSortLetter("#");
            hotRegions.add(country);
        }

        return hotRegions;
    }


}
