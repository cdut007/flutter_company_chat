package com.ultralinked.uluc.enterprise.pay;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonSyntaxException;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.EditViewPlus;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity;
import com.ultralinked.uluc.enterprise.utils.DialogManager;
import com.ultralinked.uluc.enterprise.utils.KeyBoardUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by ulpc1 on 2016/11/2.
 */

public class BalanceTransferActivity extends BaseActivity implements View.OnClickListener {


    EditText mEditAmount;
    EditViewPlus mEditNumber;
    View confirmButton;


    @Override
    public int getRootLayoutId() {
        return R.layout.activity_blancetransfer;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        initListener(this, R.id.left_back);
        mEditAmount = bind(R.id.edit_recharge_amount);
        mEditNumber = bind(R.id.etUserAccount);
        mEditNumber.setHint(getString(R.string.transfer_number_prompt));
        mEditNumber.setCodeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BalanceTransferActivity.this, CountryCodeChooseActivity.class);
                startActivityForResult(intent,CountryCodeChooseActivity.REQUEST_COUNTRY_CODE);
            }
        });
        confirmButton = bind(R.id.btConfirmTransfer);
        confirmButton.setOnClickListener(this);

    }


    private void sendTransferSuccessMessage() {
        RxBus.getDefault().post(PaymentActivity.PAYMENT_SUCCESS);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG,requestCode+"  "+resultCode);
        if(data!=null)
        {
            mEditNumber.setCountryCode(data.getStringExtra(CountryCodeChooseActivity.COUNTRY_CODE_KEY));
        }
    }

    @Override
    protected void setTopBar() {
        ((TextView) bind(R.id.titleCenter)).setText(R.string.blance_transfer);
        goneView(bind(R.id.titleRight));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        KeyBoardUtils.closeInputMethod(this);
        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                this.finish();
                break;

            case R.id.btConfirmTransfer:
                final String amount = mEditAmount.getText().toString();
                if (TextUtils.isEmpty(amount)) {
                    showToast(R.string.transfer_no_amount_prompt);
                } else {
                    final String number = mEditNumber.getTextAll();
                    if (!RegexValidateUtils.checkCellphone(number)) {
                        showToast(R.string.check_mobile);
                        return;
                    }

                    if (SPUtil.getLoginModel()==SPUtil.LOGIN_BY_OTP && !SPUtil.getUserHasPsd() || !SPUtil.getUserHasPsd()){
                        showToast(R.string.set_user_password);
                        return;
                    }


                    String infoTips = getString(R.string.transfer_amount_prompt,amount);
                    infoTips = infoTips.replace("#",PhoneNumberUtils.formatMobile(number));
                    DialogManager.showOKCancelDialog(this, "", infoTips, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            displayInputPsdDialog(amount,number);
                        }
                    },null);

                }
                break;
        }
    }

    private void displayInputPsdDialog(final String amount, final String number) {
        DialogManager.showBalancePayDialog(getActivity(), amount, new DialogManager.OnDialogListener() {

            @Override
            public void onCancelClick(View v) {
            }

            @Override
            public void onOkClick(View v, CharSequence[] items, Dialog dialog) {
                requestTransferToServer(items[0].toString(),amount, number);
                dialog.dismiss();
            }
        });
    }

    private void requestTransferToServer(String password,String amount, String transferNumber) {

        if (TextUtils.isEmpty(password)) {
            showToast(getString(R.string.check_password));
            return;
        }

        if (!NetUtil.isNetworkAvailable(this)) {
            showToast(getString(R.string.check_network));
            return;
        }

        showDialog(getString(R.string.loading));
       String number =  PhoneNumberUtils.normalizeNumber(transferNumber);
        Log.i(TAG,"amount="+amount+";transferNumber="+number);

        ApiManager.getInstance().requestBalanceTransfer(password,amount,number)
                .subscribeOn(Schedulers.io())        //子线程
                .compose(this.<ResponseBody>bindToLifecycle())  //绑定生命周期

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "requestTransferToServerComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        closeDialog();
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        showToast(" " + eMsg);

                        Log.e(TAG, "requestTransferToServer  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        closeDialog();
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                showToast(object.optString("result"));
                                sendTransferSuccessMessage();
                                finish();
                            } else {
                                showToast("errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                                Log.i(TAG, "requestTransferToServer error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));
                            }
                        } catch (JsonSyntaxException e) {
                            showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        Log.i(TAG, "get requestTransferToServer:  " + rs);
                    }         //请求成功
                });
    }
}
