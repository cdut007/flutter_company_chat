/*
 * libjingle
 * Copyright 2015 Google Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * specified, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ultralinked.uluc.enterprise.call;


import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.content.LocalBroadcastManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Chronometer;
import android.widget.Toast;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.MediaManger;
import com.ultralinked.voip.api.MessagingApi;
import com.ultralinked.voip.api.PeerConnectionClient;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.EglBase;
import org.webrtc.RendererCommon.ScalingType;
import org.webrtc.SurfaceViewRenderer;

/**
 * Activity for peer connection call setup, call waiting
 * and call view.
 */
public class VideoCallActivity extends BaseActivity
        implements CallControlFragment.OnCallEvents {


    public static final String EXTRA_ROOMID =
            "org.appspot.apprtc.ROOMID";
    public static final String EXTRA_LOOPBACK =
            "org.appspot.apprtc.LOOPBACK";
    public static final String EXTRA_VIDEO_CALL =
            "org.appspot.apprtc.VIDEO_CALL";
    public static final String EXTRA_VIDEO_WIDTH =
            "org.appspot.apprtc.VIDEO_WIDTH";
    public static final String EXTRA_VIDEO_HEIGHT =
            "org.appspot.apprtc.VIDEO_HEIGHT";
    public static final String EXTRA_VIDEO_FPS =
            "org.appspot.apprtc.VIDEO_FPS";
    public static final String EXTRA_VIDEO_CAPTUREQUALITYSLIDER_ENABLED =
            "org.appsopt.apprtc.VIDEO_CAPTUREQUALITYSLIDER";
    public static final String EXTRA_VIDEO_BITRATE =
            "org.appspot.apprtc.VIDEO_BITRATE";
    public static final String EXTRA_VIDEOCODEC =
            "org.appspot.apprtc.VIDEOCODEC";
    public static final String EXTRA_HWCODEC_ENABLED =
            "org.appspot.apprtc.HWCODEC";
    public static final String EXTRA_CAPTURETOTEXTURE_ENABLED =
            "org.appspot.apprtc.CAPTURETOTEXTURE";
    public static final String EXTRA_AUDIO_BITRATE =
            "org.appspot.apprtc.AUDIO_BITRATE";
    public static final String EXTRA_AUDIOCODEC =
            "org.appspot.apprtc.AUDIOCODEC";
    public static final String EXTRA_NOAUDIOPROCESSING_ENABLED =
            "org.appspot.apprtc.NOAUDIOPROCESSING";
    public static final String EXTRA_AECDUMP_ENABLED =
            "org.appspot.apprtc.AECDUMP";
    public static final String EXTRA_OPENSLES_ENABLED =
            "org.appspot.apprtc.OPENSLES";
    public static final String EXTRA_DISPLAY_HUD =
            "org.appspot.apprtc.DISPLAY_HUD";
    public static final String EXTRA_TRACING = "org.appspot.apprtc.TRACING";
    public static final String EXTRA_CMDLINE =
            "org.appspot.apprtc.CMDLINE";
    public static final String EXTRA_RUNTIME =
            "org.appspot.apprtc.RUNTIME";

    // List of mandatory application permissions.
    private static final String[] MANDATORY_PERMISSIONS = {
            "android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.RECORD_AUDIO",
            "android.permission.INTERNET"
    };


    // Peer connection statistics callback period in ms.
    private static final int STAT_CALLBACK_PERIOD = 1000;
    // Local preview screen position before call is connected.
    private static final int LOCAL_X_CONNECTING = 0;
    private static final int LOCAL_Y_CONNECTING = 0;
    private static final int LOCAL_WIDTH_CONNECTING = 100;
    private static final int LOCAL_HEIGHT_CONNECTING = 100;
    // Local preview screen position after call is connected.
    private static final int LOCAL_X_CONNECTED = 72;
    private static final int LOCAL_Y_CONNECTED = 72;
    private static final int LOCAL_WIDTH_CONNECTED = 25;
    private static final int LOCAL_HEIGHT_CONNECTED = 25;
    // Remote video screen position
    private static final int REMOTE_X = 0;
    private static final int REMOTE_Y = 0;
    private static final int REMOTE_WIDTH = 100;
    private static final int REMOTE_HEIGHT = 100;
    private PercentFrameLayout localRenderLayout;
    private PercentFrameLayout remoteRenderLayout;
    private ScalingType scalingType;
    private Toast logToast;
    private boolean commandLineRun;
    private int runTimeMs;
    private boolean activityRunning;
    private PeerConnectionClient.PeerConnectionParameters peerConnectionParameters;
    private boolean iceConnected;
    private boolean isError;
    private boolean callControlFragmentVisible = true;
    private long callStartedTimeMs = 0;
    private Chronometer callTimer;
    // Controls
    CallControlFragment callFragment;

    boolean isMute;
    private AudioManager audioManamger;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_video_call;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        // Set window styles for fullscreen-window size. Needs to be done before
        // adding content.
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(
                LayoutParams.FLAG_FULLSCREEN
                        | LayoutParams.FLAG_KEEP_SCREEN_ON
                        | LayoutParams.FLAG_DISMISS_KEYGUARD
                        | LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);

        callTimer = (Chronometer) findViewById(R.id.chronometer);

        Log.i(TAG, "~ onCreate ~");

        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(callStatusChangedReceiver, new IntentFilter(CallApi.EVENT_CALL_STATUS_CHANGE));

        scalingType = ScalingType.SCALE_ASPECT_FILL;
        iceConnected = false;

        Intent intent = getIntent();

        String action = intent.getAction();

        calleeNumber = getIntent().getStringExtra("callee_number");

        isIncoming = getIntent().getBooleanExtra("is_incoming", false);

        if (!isIncoming){
            CallModel.stopTerminateTone();
        }

//        Uri data = intent.getData();
//
//        if (data != null) {
//
//            Log.i(TAG, "data : " + data.toString());
//
//            String info = data.toString().substring(data.toString().indexOf(":") + 1);
//
//            Log.i(TAG, "info : " + info);
//
//            JSONObject jsonObject = null;
//
//            try {
//                jsonObject = new JSONObject(info);
//
//                calleeNumber = (String) jsonObject.get("name");
//
//                isIncoming = (boolean) jsonObject.get("incoming");
//
//                Log.i(TAG, "from web url : caller : " + calleeNumber + "is incoming : " + isIncoming);
//
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//        }


        boolean loopback = intent.getBooleanExtra(EXTRA_LOOPBACK, false);
        boolean tracing = intent.getBooleanExtra(EXTRA_TRACING, false);
        peerConnectionParameters = new PeerConnectionClient.PeerConnectionParameters(
                intent.getBooleanExtra(EXTRA_VIDEO_CALL, true),
                loopback,
                tracing,
                intent.getIntExtra(EXTRA_VIDEO_WIDTH, 0),
                intent.getIntExtra(EXTRA_VIDEO_HEIGHT, 0),
                intent.getIntExtra(EXTRA_VIDEO_FPS, 15),
                intent.getIntExtra(EXTRA_VIDEO_BITRATE, 0),
                intent.getStringExtra(EXTRA_VIDEOCODEC),
                intent.getBooleanExtra(EXTRA_HWCODEC_ENABLED, true),
                intent.getBooleanExtra(EXTRA_CAPTURETOTEXTURE_ENABLED, false),
                intent.getIntExtra(EXTRA_AUDIO_BITRATE, 0),
                intent.getStringExtra(EXTRA_AUDIOCODEC),
                intent.getBooleanExtra(EXTRA_NOAUDIOPROCESSING_ENABLED, false),
                intent.getBooleanExtra(EXTRA_AECDUMP_ENABLED, false),
                intent.getBooleanExtra(EXTRA_OPENSLES_ENABLED, false));

        // Create UI controls.
        CallApi.mLocalRender = (SurfaceViewRenderer) findViewById(R.id.local_video_view);
        CallApi.mRemoteRender = (SurfaceViewRenderer) findViewById(R.id.remote_video_view);
        localRenderLayout = (PercentFrameLayout) findViewById(R.id.local_video_layout);
        remoteRenderLayout = (PercentFrameLayout) findViewById(R.id.remote_video_layout);
        callFragment = new CallControlFragment();
        // Create video renderers.

        CallApi.setVideoICEEnable(true);
        CallApi.rootEglBase = EglBase.create();
        CallApi.mLocalRender.init(CallApi.rootEglBase.getEglBaseContext(), null);
        CallApi.mRemoteRender.init(CallApi.rootEglBase.getEglBaseContext(), null);
        CallApi.mLocalRender.setZOrderMediaOverlay(true);

        callSession = CallApi.initiateVideoCall(VideoCallActivity.this, calleeNumber, isIncoming, peerConnectionParameters);


        // Show/hide call control fragment on view click.
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleCallControlFragmentVisibility();
            }
        };

        CallApi.mLocalRender.setOnClickListener(listener);
        CallApi.mRemoteRender.setOnClickListener(listener);


        // Check for mandatory permissions.
        for (String permission : MANDATORY_PERMISSIONS) {
            if (checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                logAndToast("Permission " + permission + " is not granted");
                setResult(RESULT_CANCELED);
                finish();
                return;
            }
        }

        audioManamger = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // Send intent arguments to fragments.

        // Activate call and HUD fragments and start the call.
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.add(R.id.call_fragment_container, callFragment);
        ft.commit();

        // For command line execution run connection for <runTimeMs> and exit.
        if (commandLineRun && runTimeMs > 0) {
            (new Handler()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    disconnect();
                }
            }, runTimeMs);
        }


    }

    // Activity interfaces
    @Override
    public void onPause() {
        super.onPause();
        activityRunning = false;
        if (CallApi.peerConnectionClient != null) {
            CallApi.peerConnectionClient.stopVideoSource();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        activityRunning = true;
        if (CallApi.peerConnectionClient != null) {
            CallApi.peerConnectionClient.startVideoSource();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) { //监控/拦截/屏蔽返回键

            return false;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        CallApi.setVideoICEEnable(false);

        activityRunning = false;
        if (CallApi.rootEglBase != null) {
            try {
                CallApi.rootEglBase.release();
            }catch (Exception e){
                e.printStackTrace();
            }

        }

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                disconnect();
            }
        }, 1500);

        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(callStatusChangedReceiver);
        if (logToast != null) {
            logToast.cancel();
        }
        super.onDestroy();
    }

    // CallFragment.OnCallEvents interface implementation.
    boolean endCall = false;
    @Override
    public void onCallHangUp() {
        if (endCall){
            Log.i(TAG,"alreadyCall endCall");
            return;
        }
        endCall = true;
        Log.i(TAG, "~ onCallHangUp callSession : " + callSession);
        MediaManger.getInstance(this).stopAlarmRing();
        callSession.terminate();
        disconnect();
    }

    @Override
    public void onCameraSwitch() {
        if (CallApi.peerConnectionClient != null) {
            CallApi.peerConnectionClient.switchCamera();
        }
    }

    @Override
    public void onVideoScalingSwitch(ScalingType scalingType) {
        this.scalingType = scalingType;
        updateVideoView();
    }

    @Override
    public void onCaptureFormatChange(int width, int height, int framerate) {
        if (CallApi.peerConnectionClient != null) {
            CallApi.peerConnectionClient.changeCaptureFormat(width, height, framerate);
        }
    }


    @Override
    public boolean onSpeaker() {
        boolean isSpeaker = audioManamger.isSpeakerphoneOn();
        audioManamger.setSpeakerphoneOn(!isSpeaker);
        CallApi.setAudioAECMode(isSpeaker ? CallApi.MODE_MICROPHONE : CallApi.MODE_SPEAKER);
        return audioManamger.isSpeakerphoneOn();
    }

    @Override
    public boolean onMute() {

        audioManamger.setMicrophoneMute(!audioManamger.isMicrophoneMute());

        return audioManamger.isMicrophoneMute();
    }

    // Helper functions.
    private void toggleCallControlFragmentVisibility() {
        if (!iceConnected || !callFragment.isAdded()) {
            return;
        }
        // Show/hide call control fragment
        callControlFragmentVisible = !callControlFragmentVisible;
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        if (callControlFragmentVisible) {
            ft.show(callFragment);
        } else {
            ft.hide(callFragment);
        }
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    private void updateVideoView() {


        callTimer.setBase(SystemClock.elapsedRealtime());

        callTimer.setVisibility(View.VISIBLE);

        callTimer.start();

        remoteRenderLayout.setPosition(REMOTE_X, REMOTE_Y, REMOTE_WIDTH, REMOTE_HEIGHT);
        CallApi.mRemoteRender.setScalingType(scalingType);
        CallApi.mRemoteRender.setMirror(false);

        if (iceConnected) {
            localRenderLayout.setPosition(
                    LOCAL_X_CONNECTED, LOCAL_Y_CONNECTED, LOCAL_WIDTH_CONNECTED, LOCAL_HEIGHT_CONNECTED);
            CallApi.mLocalRender.setScalingType(ScalingType.SCALE_ASPECT_FIT);
        } else {
            localRenderLayout.setPosition(
                    LOCAL_X_CONNECTING, LOCAL_Y_CONNECTING, LOCAL_WIDTH_CONNECTING, LOCAL_HEIGHT_CONNECTING);
            CallApi.mLocalRender.setScalingType(scalingType);
        }
        CallApi.mLocalRender.setMirror(true);

        CallApi.mLocalRender.requestLayout();
        CallApi.mRemoteRender.requestLayout();
    }


    // Should be called from UI thread
    private void callConnected() {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;
        Log.i(TAG, "Call connected: delay=" + delta + "ms");
        if (CallApi.peerConnectionClient == null || isError) {
            Log.w(TAG, "Call is connected in closed or error state");
            return;
        }
        // Update video view.
        updateVideoView();
        // Enable statistics callback.
        CallApi.peerConnectionClient.enableStatsEvents(true, STAT_CALLBACK_PERIOD);

        audioManamger.setMode(AudioManager.MODE_IN_COMMUNICATION);
        audioManamger.setMicrophoneMute(false);
    }

    private void onAudioManagerChangedState() {
        // TODO(henrika): disable video if AppRTCAudioManager.AudioDevice.EARPIECE
        // is active.
    }

    // Disconnect from remote resources, dispose of local resources, and exit.
    private void disconnect() {
        activityRunning = false;

        if (iceConnected && !isError) {
            setResult(RESULT_OK);
        } else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    private void disconnectWithErrorMessage(final String errorMessage) {
        if (commandLineRun || !activityRunning) {
            Log.e(TAG, "Critical error: " + errorMessage);
            disconnect();
        } else {

        }
    }

    // Log |msg| and Toast about it.
    private void logAndToast(String msg) {
        Log.d(TAG, msg);
        if (logToast != null) {
            logToast.cancel();
        }
        logToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
        logToast.show();
    }

    private void reportError(final String description) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (!isError) {
                    isError = true;
                    disconnectWithErrorMessage(description);
                }
            }
        });
    }


    private static final String TAG = "VideoCallActivity";


    private String calleeNumber;

    private CallSession callSession;

    private boolean isIncoming;

    private Handler mHandler = new Handler();

    public static void launch(Context context, String contact) {
        launch(context, contact, false);
    }


    public static void launch(Context context, String contact, boolean isIncomingCall) {

        Intent intentVideo = new Intent(context, VideoCallActivity.class);
        intentVideo.putExtra("callee_number", contact);
        intentVideo.putExtra("is_incoming", isIncomingCall);
        context.startActivity(intentVideo);
    }

    public static void launch(Context context, boolean isIncomingCall) {
        launch(context, "", isIncomingCall);
    }


    private BroadcastReceiver callStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            CallSession session = (CallSession) intent.getSerializableExtra(CallApi.PARAM_CALL_SESSION);

            callSession = session;

            int newStatus = session.callState;

            Log.i(TAG, "call state change new state : " + newStatus + " type : " + callSession.type);
            switch (newStatus) {


                case CallSession.STATUS_RECORD_FAIL:
                    if (callSession!=null){
                        callSession.terminate();
                    }
                    showToast(R.string.chat_recording_voice_failed);
                    break;

                case CallSession.STATUS_ALERTING:


                    break;


                case CallSession.SATTUS_ICE_CONNECTED:

                    // video stream is connected should update the video view
                    if (CallSession.TYPE_VIDEO == callSession.type) {
                        iceConnected = true;
                        callConnected();
                    }
                    break;
                case CallSession.STATUS_IDLE:
                    disconnect();
                    String releaseReason = (String) intent.getSerializableExtra(CallApi.PARAM_SIP_REASON_TEXT);
                    Log.i(TAG, TAG + " idle releaseReason=" + releaseReason);
                    CallModel.queryIdleReasonInfo(releaseReason,true);

                    int time = (int) (SystemClock.elapsedRealtime() - callTimer.getBase()) / 1000;
                    if (isIncoming) {
                        if (calleeNumber!=null && !calleeNumber.startsWith("subusr")){
                            return;
                        }
                        MessagingApi.insertVoipCallLogMessage(calleeNumber, calleeNumber, SPUtil.getUserID(), time, CallSession.TYPE_VIDEO, Conversation.SINGLE_CHAT);
                    } else {
                        MessagingApi.insertVoipCallLogMessage(calleeNumber, SPUtil.getUserID(), calleeNumber, time, CallSession.TYPE_VIDEO, Conversation.SINGLE_CHAT);

                    }

                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}

