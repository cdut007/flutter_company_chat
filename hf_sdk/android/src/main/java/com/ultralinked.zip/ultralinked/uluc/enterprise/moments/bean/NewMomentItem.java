package com.ultralinked.uluc.enterprise.moments.bean;

/**
 * Created by mac on 17/1/24.
 */

public class NewMomentItem {

    public  String comment_id;
    public  String moments_event_id;
    public  String comment_time;
    public  String icon_url;
    public  String nickname;
    public  String remarkname;
    public  String comment_content;
    public  String reply_nickname;
    public  String reply_user_id;
    public  String type;


//    "comment_content": "aaaaaa",
//            "comment_id": "ksjfk",
//            "comment_time": "",
//            "icon_url": "https://ucstage.sealedchat.com/icons/0743ca0666be856a75d9be8b407a38c9.jpeg",
//            "nickname": "test",
//            "remarkname": "test_remarkname",
//            "reply_nickname": "",
//            "reply_user_id": "",
//            "type": "comment"
}
