package com.ultralinked.uluc.enterprise.call;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jude.swipbackhelper.SwipeBackHelper;
import com.skyfishjy.library.RippleBackground;
import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.widget.DTMFKeyboard;
import com.ultralinked.uluc.enterprise.baseui.widget.NumberKeyboard;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.MessageUtils;
import com.ultralinked.uluc.enterprise.utils.NetUtil;
import com.ultralinked.uluc.enterprise.utils.PhoneNumberUtils;
import com.ultralinked.uluc.enterprise.utils.ProximityUtil;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.CallApi;
import com.ultralinked.voip.api.CallSession;
import com.ultralinked.voip.api.Conversation;
import com.ultralinked.voip.api.LoginApi;
import com.ultralinked.voip.api.MediaManger;
import com.ultralinked.voip.api.MessagingApi;

import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class IncallActivity extends BaseActivity implements View.OnClickListener {
    String callMobile, callName, iconUrl, callSubid;
    boolean isIncoming;
    ImageView ivCallIcon, ivMute, ivSpeaker, ivKeyboard;
    TextView tvCallName;
    TextView tvshowquality;
    TextView tvCallCandidateInfo;
    Chronometer callTime;
    ImageView btEndCall;
    RippleBackground rippleBackground;
    private CallSession callSession;
    private boolean isMute, isSpeaker;
    private boolean isMissCall;
    AudioManager audioManager;


    DTMFKeyboard dtmfKeyboard;
    View dtmf_dialer_layout,call_layout;
    TextView dtmf_phone_number;

    private Subscription rxNetworkChangeSubscription;

    private int callModel;
    public static int IP2IP = 9001;
    public static int IP2Phone = 9002;
    public static int VIDEO_call = 9003;

    boolean displayCandidate;

    boolean outGoingCallRingingWhenNetworkChange = false;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        //..
        initIntent(intent);
        if (intent.getBooleanExtra("from_notification", false)) {
            Log.i(TAG, "from the notification intent onNewIntent");
            initCallFromNotifation();
        } else {
            initCall();
        }
    }


    static long duringTime;

    public static boolean hasCall;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        duringTime = SystemClock.elapsedRealtime() - callTime.getBase();
        outState.putLong("during", duringTime);
        outState.putBoolean("insert_call", insertCallLog);
        outState.putInt("callModel", callModel);
        outState.putBoolean("incoming", isIncoming);
    }


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        duringTime = savedInstanceState.getLong("during");
        insertCallLog = savedInstanceState.getBoolean("insert_call");
        callModel = savedInstanceState.getInt("callModel");
        isIncoming = savedInstanceState.getBoolean("incoming");

    }

    private void initCallFromNotifation() {

        ImageUtils.loadCircleImage(this, ivCallIcon, iconUrl, ImageUtils.getDefaultContactImageResource(callSubid));

        callSession = CallApi.getFgCallSession();

        if (callSession == null) {
            Log.i(TAG, "initCallFromNotifation call but the callsession is null.");
            finish();
            return;
        }

        if (isIncoming) {//incoming call
            isConnected = callSession.callState == CallSession.STATUS_CONNECTED;
            mediaConnected = callSession.callState == CallSession.SATTUS_ICE_CONNECTED;
            tvCallName.setText(callName);
            callModel = callSession.type;
            //re count time
            setTimerCountinue(duringTime);
            displayCallNotifacation();
        } else {
            //re count time
            setTimerCountinue(duringTime);

            if (callModel == IP2Phone) {

                //if from contact ,show contact name.
                if (TextUtils.isEmpty(callName)) {

                    tvCallName.setText(PhoneNumberUtils.formatMobile(callMobile));

                    //async.
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            calleeName = CallModel.queryPhoneNameFromLocalContact(IncallActivity.this, callMobile);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (!TextUtils.isEmpty(calleeName)) {
                                        tvCallName.setText(calleeName);
                                    }
                                }
                            });

                        }
                    }).start();

                } else {

                    tvCallName.setText(callName);
                }


                callMobile = RegexValidateUtils.normalizeNumber(callMobile);

            } else if (callModel == IP2IP) {

                tvCallName.setText(callName);

            } else if (callModel == VIDEO_call) {
                // TODO:  还没有做
            }
        }
    }

    /**
     * @param context
     * @param mobile     name or number
     * @param iconUrl    url
     * @param isIncoming
     * @param callModel  model like{@link #IP2Phone} or {@link #IP2IP} or {@link #VIDEO_call} or{callSession.TYPE}
     */
    public static void lunch(Context context, String mobile, String name, String iconUrl, boolean isIncoming, int callModel) {
        if (context == null)//不能启动
            return;
        Log.i("", "call mobile:===" + mobile + ";call name=" + name);
        if (TextUtils.isEmpty(mobile) && TextUtils.isEmpty(name)) {  //||

            Toast.makeText(context, context.getString(R.string.check_mobile), Toast.LENGTH_SHORT).show();
            return;
        }

        boolean networkStatus = NetUtil.isNetworkAvailable(context);
        if (!networkStatus) {
            Log.i("", "network not Available status:===false");
            Toast.makeText(context, context.getString(R.string.check_network), Toast.LENGTH_LONG).show();
            return;
        }


        if (!LoginApi.isLogin()) {
            Log.i("", "login status:===false");
            // Toast.makeText(context, context.getString(R.string.make_call_failed), Toast.LENGTH_SHORT).show();
            App.grLogin(false);
            //  return;
        }

        Intent intent = new Intent(context, IncallActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("call_model", callModel);
        intent.putExtra("call_name", name);
        intent.putExtra("call_mobile", mobile);
        intent.putExtra("call_is_incoming", isIncoming);
        intent.putExtra("call_icon_url", iconUrl);
        context.startActivity(intent);
        if (isIncoming) {
            if (context instanceof Activity) {
                ((Activity) context).overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }

        } else {
            CallModel.stopTerminateTone();
        }

    }

    public void initIntent(Intent intent) {

        callMobile = intent.getStringExtra("call_mobile");
        if (!TextUtils.isEmpty(callMobile) && callMobile.startsWith("+")) {
            callMobile = callMobile.substring(1);
        }
        callName = intent.getStringExtra("call_name");
        callModel = intent.getIntExtra("call_model", -1);
        isIncoming = intent.getBooleanExtra("call_is_incoming", false);
        iconUrl = intent.getStringExtra("call_icon_url");


        PeopleEntity peopleEntity = PeopleEntityQuery.getInstance().getByMobileSql(callMobile);

        if (peopleEntity != null) {
            callSubid = peopleEntity.subuser_id;
            callName = PeopleEntityQuery.getDisplayName(peopleEntity);
            iconUrl = peopleEntity.icon_url;
        }
        Log.i(TAG, callMobile + " isIncoming= " + isIncoming + " call name=" + callName + " url= " + iconUrl);

    }

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_incall;
    }


    @Override
    public void initView(Bundle savedInstanceState) {
        rippleBackground = bind(R.id.ripple_content);
        ivCallIcon = bind(R.id.ivCallPhoto);
        ivMute = bind(R.id.ivMute);
        ivSpeaker = bind(R.id.ivSpeaker);
        tvCallName = bind(R.id.tvCallName);
        ivKeyboard = bind(R.id.ivKeypad);
        tvshowquality = bind(R.id.tvCallQuality);
        tvCallCandidateInfo = bind(R.id.tvCallCandidateInfo);
        callTime = bind(R.id.callTime);
        btEndCall = bind(R.id.btEnd);

        dtmfKeyboard = bind(R.id.dtmf_keypad);
        dtmf_dialer_layout = bind(R.id.dtmf_dialer_layout);
        call_layout = bind(R.id.call_layout);
        dtmf_phone_number = bind(R.id.dtmf_phone_number);

        dtmfKeyboard.setOnKeyDownListener(new DTMFKeyboard.OnKeyDownListener() {
            @Override
            public void onKeyDown(String tag) {
                CharSequence number = dtmf_phone_number.getText();
                dtmf_phone_number.setText(number+tag);
                callSession.sendDTMF(tag.charAt(0));
            }

            @Override
            public void onLongClick(View v) {
            }

            @Override
            public void onClick(View v) {
            }
        });

        bind(R.id.bottomCenter).setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 displayKeyboard(false);
             }
         });

        initListener(this, ivMute, ivSpeaker, btEndCall, ivCallIcon, ivKeyboard);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }


        super.onCreate(savedInstanceState);

        hasCall = true;

        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
        rxNetworkChangeSubscription = RxBus.getDefault().toObservable(CallModel.class)
                .subscribe(new Action1<CallModel>() {
                               @Override
                               public void call(CallModel callModel) {
                                   Log.i(TAG, "update the network~~~~" + callModel.networkStatus);
                                   if ("reconnected".equals(callModel.networkStatus)) {
                                       checkIfNeedOutgoingCallReconnect();
                                   }

                               }
                           },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                // TODO: 处理异常
                                Log.i(TAG, "update the subscribe error:" + android.util.Log.getStackTraceString(throwable));
                            }
                        });

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        registerReceivers();
        initIntent(getIntent());
        if (getIntent().getBooleanExtra("from_notification", false)) {
            Log.i(TAG, "from the notification intent on create");
            initCallFromNotifation();
        } else {
            initCall();
        }


    }

    private void checkIfNeedOutgoingCallReconnect() {
        if (!isIncoming && (callModel != IP2Phone) && callSession != null) {
            if (callSession.callState == CallSession.STATUS_ALERTING ||
                    callSession.callState == CallSession.STATUS_PROCESSING
                    ) {
                //outgoing call still connected. So we  recall it.
                // outGoingCallRingingWhenNetworkChange = true;
                Log.i(TAG, "checkIfNeedOutgoingCallReconnect  cancel current call true");
                terminateCall();

            }

        }
    }

    private void terminateCall() {
        duringTime = 0;
        callSession.terminate();
    }


    @Override
    protected void onResume() {
        super.onResume();

        ProximityUtil.startProximitySensorForActivity(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ProximityUtil.stopProximitySensorForActivity(this);
    }

    @Override
    protected void onStop() {
        super.onStop();

        Set<Activity> activities = ProximityUtil.getsProximityDependentActivities();
        if (activities != null && !activities.isEmpty()) {
            activities.clear();
        }
    }

    String calleeName;

    public void initCall() {
        Log.i(TAG, "current call model:" + callModel);
        ImageUtils.loadCircleImage(this, ivCallIcon, iconUrl, ImageUtils.getDefaultContactImageResource(callSubid));

        if (isIncoming) {//incoming call
            tvCallName.setText(callName);
            callSession = CallApi.getFgCallSession();
            if (callSession == null) {
                Log.i(TAG, "incoming call but the callsession is null.");
                finish();
                return;
            }
            isConnected = callSession.callState == CallSession.STATUS_CONNECTED;
            mediaConnected = callSession.callState == CallSession.SATTUS_ICE_CONNECTED;
            callModel = callSession.type;
            setTimer(true);
            displayCallNotifacation();
            if (callSession.callState == CallSession.SATTUS_ICE_CONNECTED) {
                MessageUtils.playCallVibratorOneTime();
            }
        } else {

            callTime.setText(getString(R.string.calling));
            if (callModel == IP2Phone) {

                if (TextUtils.isEmpty(callMobile) || !RegexValidateUtils.checkCellphone(callMobile)) {
                    showToast(R.string.check_mobile);
                    finish();
                    return;
                }
                MediaManger.getInstance(this).playLocalEarlyMedia();
                //out going call

                //if from contact ,show contact name.
                if (TextUtils.isEmpty(callName)) {

                    tvCallName.setText(PhoneNumberUtils.formatMobile(callMobile));

                    //async.
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            calleeName = CallModel.queryPhoneNameFromLocalContact(IncallActivity.this, callMobile);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (!TextUtils.isEmpty(calleeName)) {
                                        tvCallName.setText(calleeName);
                                    }
                                }
                            });

                        }
                    }).start();

                } else {

                    tvCallName.setText(callName);
                }


                callMobile = RegexValidateUtils.normalizeNumber(callMobile);
                callSession = CallApi.initiateIp2PhoneCall(callMobile);

            } else if (callModel == IP2IP) {
                if (TextUtils.isEmpty(callSubid)) {
                    showToast(R.string.check_mobile);
                    finish();
                    return;
                }
                MediaManger.getInstance(this).playLocalEarlyMedia();
                //out going call
                callSession = CallApi.initiateAudioCall(callSubid);
                tvCallName.setText(callName);

            } else if (callModel == VIDEO_call) {
                // TODO:  还没有做
            }
        }

        // Enable statistics callback.
        if (CallApi.peerConnectionClient != null) {
            CallApi.peerConnectionClient.enableStatsEvents(true, 1000/*STAT_CALLBACK_PERIOD*/);
        }

    }

    boolean insertCallLog = false;

    long downTime = 0;
    int clickTime = 0;

    boolean isConnected, mediaConnected;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.ivCallPhoto: {
                if (System.currentTimeMillis() - downTime > 1000) {
                    clickTime = 0;
                    downTime = System.currentTimeMillis();
                    return;
                }
                Log.i(TAG, "display the call candidate info,click count:" + clickTime);
                clickTime++;
                if (clickTime == 7) {
                    Log.i(TAG, "display the call candidate info");
                    displayCandidateInfo();
                }
                downTime = System.currentTimeMillis();
            }
            break;
            case R.id.ivMute:
                isMute = !isMute;
                ivMute.setSelected(isMute);
                setMute(isMute);
                break;
            case R.id.ivSpeaker:
                isSpeaker = !isSpeaker;
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audioManager.setSpeakerphoneOn(isSpeaker);
                ivSpeaker.setSelected(isSpeaker);
                break;
            case R.id.ivKeypad: {
                displayKeyboard(true);
            }
            break;
            case R.id.btEnd:
                setTimer(false);
                outGoingCallRingingWhenNetworkChange = false;
                if (callSession != null) {
                    MediaManger.getInstance(this).stopAlarmRing();
                    MediaManger.getInstance(this).stopLocalEarlyMedia();
                    terminateCall();
                }

                final String name = getSavedCallName();
                insertCallLog = true;
                if (callModel == IP2IP || isIncoming) {
                    int time = (int) (SystemClock.elapsedRealtime() - callTime.getBase()) / 1000;
                    if (isIncoming) {
                        if (callSubid!=null && !callSubid.startsWith("subusr")){
                            return;
                        }
                        MessagingApi.insertVoipCallLogMessage(callSubid, callSubid, SPUtil.getUserID(), time, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);
                    } else {
                        if (isConnected) {
                            MessagingApi.insertVoipCallLogMessage(callSubid, SPUtil.getUserID(), callSubid, time, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);
                        } else {
                            Log.i(TAG, "not connected when hangup , just set the during to 0");
                            MessagingApi.insertVoipCallLogMessage(callSubid, SPUtil.getUserID(), callSubid, 0, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);

                        }

                    }
                } else {
                    Observable.just(" end call").compose(this.<String>bindToLifecycle())
                            .delay(2, TimeUnit.SECONDS).subscribe(new Action1<String>() {
                        @Override
                        public void call(String s) {
                            if (isMissCall) {
                                saveCallLog(name, callMobile, "miss", iconUrl);
                            } else if (isIncoming) {
                                saveCallLog(name, callMobile, "in", iconUrl);
                            } else {
                                saveCallLog(name, callMobile, "out", iconUrl);
                            }
                            finish();
                        }
                    });
                }

                break;
        }
    }


    private void displayKeyboard(boolean show) {
        if (show){
            dtmf_dialer_layout.setVisibility(View.VISIBLE);
            call_layout.setVisibility(View.GONE);
        }else{
            dtmf_dialer_layout.setVisibility(View.GONE);
            call_layout.setVisibility(View.VISIBLE);
        }

    }

    boolean changeMuteFlag;

    private void setMute(boolean isMute) {

        if (callModel == IP2Phone) {
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.setMicrophoneMute(isMute);
            Log.i(TAG, "set ip2phone mute Enable " + audioManager.isMicrophoneMute());
            return;
        }


        if (isConnected) {
            changeMuteFlag = false;
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.setMicrophoneMute(isMute);
            Log.i(TAG, "set mute Enable " + audioManager.isMicrophoneMute() + ";isMediaConneted:" + mediaConnected);
        } else {
            changeMuteFlag = true;
            Log.i(TAG, "media not connected no flag need set. is conneted:" + isConnected + ";isMediaConneted:" + mediaConnected);
        }


    }

    private String getSavedCallName() {

        if (TextUtils.isEmpty(callName)) {
            if (!TextUtils.isEmpty(calleeName)) {
                return calleeName;
            }
        }

        return callName;
    }


    /**
     * broadcast has registered that call status & call qos
     */
    private void registerReceivers() {

        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(
                callStatusChangedReceiver,
                new IntentFilter(CallApi.EVENT_CALL_STATUS_CHANGE));

        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(
                callQosReportReceiver,
                new IntentFilter(CallApi.EVENT_CALL_QOS_REPORT));
    }


    @Override
    protected void onDestroy() {
        hasCall = false;
        Log.i(TAG, "incall onDestroy ui,duringTime,if duringTime not 0,maybe recycle by System ===~~" + duringTime);
        stopService(new Intent(this, CallService.class));
        if (rxNetworkChangeSubscription != null && !rxNetworkChangeSubscription.isUnsubscribed()) {
            rxNetworkChangeSubscription.unsubscribe();
        }

        rippleBackground.stopRippleAnimation();
        unRegisterReceivers();
        super.onDestroy();
    }

    /**
     * broadcast has unregistered that call status & call qos after end call
     */
    private void unRegisterReceivers() {

        LocalBroadcastManager.getInstance(getApplicationContext())
                .unregisterReceiver(callStatusChangedReceiver);

        LocalBroadcastManager.getInstance(getApplicationContext())
                .unregisterReceiver(callQosReportReceiver);
    }

    private BroadcastReceiver callStatusChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final CallSession session = (CallSession) intent.getSerializableExtra(CallApi.PARAM_CALL_SESSION);
            callSession = session;
            int newStatus = callSession.callState;

            //showIncallNotification(session);
            Log.i(TAG, "call state change new state : " + newStatus);
            switch (newStatus) {

                case CallSession.STATUS_RECORD_FAIL:
                    if (callSession != null) {
                        duringTime = 0;
                        callSession.terminate();
                    }
                    showToast(R.string.chat_recording_voice_failed);
                    break;
                case CallSession.STATUS_RECONNECTING: {
                    tvshowquality.setVisibility(View.VISIBLE);
                    tvshowquality.setText(R.string.reconnecting);
                    MediaManger.getInstance(IncallActivity.this).playLocalEarlyMedia(R.raw.ringbacktone);
                }
                break;

                case CallSession.SATTUS_ICE_CONNECTED: {
                    mediaConnected = true;

                    if (isConnected && !mediaConnected) {
                        MessageUtils.playCallVibratorOneTime();
                    }

                    if (changeMuteFlag) {
                        Log.i(TAG, "mute flag has changed when media before connected.->ice connected");
                        setMute(isMute);

                    }


                    tvshowquality.setVisibility(View.INVISIBLE);

                    if (isConnected && mediaConnected) {//for outgoing caller.

                        MediaManger.getInstance(IncallActivity.this).stopLocalEarlyMedia();
                    }
                }
                break;

                case CallSession.STATUS_PROCESSING:// begain ringing
                case CallSession.STATUS_ALERTING: {

                    rippleBackground.startRippleAnimation();
//                    if (callModel == IP2Phone){
//                        rtcapij.grrtc_call_startaudio(callSession.callId);
//                    }
                }
                break;
                case CallSession.STATUS_CONNECTED:
                    isConnected = true;

                    if (isConnected && !mediaConnected || callModel == IP2Phone) {
                        //first or last we can not control.
                        MessageUtils.playCallVibratorOneTime();
                    }


                    if (changeMuteFlag) {
                        Log.i(TAG, "mute flag has changed when media before connected.->connected");
                        setMute(isMute);

                    }
                    displayCallNotifacation();
                    if (!CallApi.isICEEnalbe()) {
                        mediaConnected = true;//non-ice mode.
                        Log.i(TAG, "currently we should not go here, if change call mode to non-ice ,must something wrong.");
                    }
                    outGoingCallRingingWhenNetworkChange = false;
                    if (rippleBackground != null) {
                        rippleBackground.stopRippleAnimation();
                    }
                    if (!isIncoming) {
                        setTimer(true);
                    }
                    tvshowquality.setVisibility(View.INVISIBLE);
                    Log.i("STATUS_CONNECTED");
                    break;
                case CallSession.STATUS_IDLE:

                    Log.i(TAG, "STATUS_IDLE outGoingCallRingingWhenNetworkChange :" + outGoingCallRingingWhenNetworkChange + ";isFinishing=" + isFinishing());
                    if (!isFinishing() && outGoingCallRingingWhenNetworkChange) {
                        outGoingCallRingingWhenNetworkChange = false;
                        Log.i(TAG, "STATUS_outGoingCallRingingWhenNetworkChange need recall:" + callSubid);
                        //out going call
//                        if (btEndCall.isEnabled()){
//                            initCall();
//                        }
                        return;
                    }

                    setTimer(false);
                    String releaseReason = (String) intent.getSerializableExtra(CallApi.PARAM_SIP_REASON_TEXT);
                    if (!TextUtils.isEmpty(releaseReason) && releaseReason.contains("timeout")) {
                        isMissCall = true;
                    }
                    CallModel.queryIdleReasonInfo(releaseReason, isSpeaker);

                    final String name = getSavedCallName();
                    if (callModel == IP2Phone) {
                        if (isMissCall) {
                            saveCallLog(name, callMobile, "miss", iconUrl);
                        } else if (isIncoming) {
                            saveCallLog(name, callMobile, "in", iconUrl);
                        } else {
                            saveCallLog(name, callMobile, "out", iconUrl);
                        }
                        sendBroadcast(new Intent("update_call_log"));
                    } else if (callModel == IP2IP || isIncoming) {

                        if (!insertCallLog) {
                            int time = (int) (SystemClock.elapsedRealtime() - callTime.getBase()) / 1000;
                            if (isIncoming) {
                                if (callSubid!=null && !callSubid.startsWith("subusr")){
                                    return;
                                }
                                MessagingApi.insertVoipCallLogMessage(callSubid, callSubid, SPUtil.getUserID(), time, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);
                            } else {
                                if (isConnected) {
                                    MessagingApi.insertVoipCallLogMessage(callSubid, SPUtil.getUserID(), callSubid, time, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);

                                } else {
                                    Log.i(TAG, "not connected when hangup , just set the during to 0");
                                    MessagingApi.insertVoipCallLogMessage(callSubid, SPUtil.getUserID(), callSubid, 0, CallSession.TYPE_AUDIO, Conversation.SINGLE_CHAT);

                                }

                            }
                        }

                    } else {
                        Log.i(TAG, "other  callModel: " + callModel);
                    }

                    Log.i(TAG, "releaseReason Call " + releaseReason);
                    finish();
                    break;
            }
        }
    };

    private void displayCallNotifacation() {
        Intent callIntent = new Intent(getIntent());
        callIntent.setClass(IncallActivity.this, CallService.class);
        try {
            callIntent.putExtra("displayName", tvCallName.getText().toString());
            callIntent.putExtra("display_icon_url", iconUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }
        startService(callIntent);
    }


    void displayCandidateInfo() {
        displayCandidate = true;
        tvCallCandidateInfo.setVisibility(View.VISIBLE);
        tvCallCandidateInfo.setText("please wait...");

    }


    private BroadcastReceiver callQosReportReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int quality = intent.getIntExtra(CallApi.PARAM_CALL_QOS, 5);


            if (displayCandidate && tvCallCandidateInfo != null) {
                if (quality == CallApi.QOS_QUALITY_INVALID) {
                    tvCallCandidateInfo.setVisibility(View.VISIBLE);
                    tvCallCandidateInfo.setText(intent.getStringExtra(CallApi.PARAM_CANDIDATE_PAIR));
                    return;
                }

                if (CallApi.NON_ICE_TAG.equals(CallApi.PARAM_REPORT_TYPE)) {
                    tvCallCandidateInfo.setVisibility(View.VISIBLE);
                    tvCallCandidateInfo.setText("Current call is not in ICE mode");
                }

            }


            Log.i(TAG, "     quality      " + quality);

            if (callModel != IP2Phone) {
                updateCallQuality(quality);
            }
        }
    };


    /**
     * 更新通话质量
     * The network connection is not stable
     *
     * @param quality
     */

    long checkCallTime;
    int count = 1;

    public void updateCallQuality(float quality) {

        if (tvshowquality == null) {
            return;
        }

        if (quality < 0) {
//            checkCallTime = System.currentTimeMillis();
//            if (System.currentTimeMillis() - checkCallTime < 1000 * 8) {
//                Log.i(TAG, TAG + " updateCallQuality=" + quality + "  record count=" + count);
//                if (count == 2) {
//                   // callAnimation.setImageResource(R.mipmap.circle1);
//                    tvVoiceQuality.setText(R.string.anotherNetworkPool);
//                    tvshowquality.setVisibility(View.GONE);
//                } else if (count > 3) {
//                    Log.i(TAG, TAG + " disable connection count=" + count + ", app invoke terminate");
//                    callSession.terminate();
//                }
//                count++;
//            }
        } else {
            count = 1;
        }


        tvshowquality.setVisibility(View.INVISIBLE);
        // callAnimation.setVisibility(View.VISIBLE);

        if (quality >= CallApi.QOS_QUALITY_GOOD) // Good Quality
        {
            tvshowquality.setText("Excellent");
            //   callAnimation.setImageResource(R.mipmap.circlue3);

        } else if (quality >= CallApi.QOS_QUALITY_AVERAGE) // Average quality
        {
            // callAnimation.setImageResource(R.mipmap.circle2);
            tvshowquality.setText("Good");

        } else if (quality >= CallApi.QOS_QUALITY_VERY_LOW) {
            //    callAnimation.setImageResource(R.mipmap.circle1);
            tvshowquality.setVisibility(View.VISIBLE);
            tvshowquality.setText(R.string.quality_poor);
        } else if (quality >= CallApi.QOS_QUALITY_WORST) {
            //   callAnimation.setImageResource(R.mipmap.circle1);
            tvshowquality.setVisibility(View.VISIBLE);
            tvshowquality.setText(R.string.quality_failed);
        } else {
            //  callAnimation.setImageResource(R.mipmap.circle1);
            int time = (int) (SystemClock.elapsedRealtime() - callTime.getBase()) / 1000;

            if (time > 5) {//after 5 sec for check.
                tvshowquality.setVisibility(View.VISIBLE);
                tvshowquality.setText(R.string.quality_failed);
            }
        }


    }


    private void saveCallLog(final String callName, final String callMobile, final String callType, final String iconUrl) {

        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
//                         "call_from"  "call_name"  "call_endtime"  "call_duration"  "call_icon" "call_type"
                String sql = " insert into call_log (call_from, call_name, call_endtime, call_duration, call_icon,call_type) values (?,?,?,?,?,?)";
                SQLiteDatabase db = SqliteUtils.getInstance(IncallActivity.this).getDb();
                if (db != null) {
                    db.beginTransaction();
                    db.execSQL(sql, new Object[]{
                            callMobile,
                            callName,
                            System.currentTimeMillis(),
                            callTime.getText().toString(),
                            iconUrl,
                            callType});
                    db.setTransactionSuccessful();
                    db.endTransaction();
                    subscriber.onNext("save ok!");
                } else {
                    subscriber.onNext("save error!");
                    Log.i(TAG, "db is null");
                }
            }
        }).subscribeOn(Schedulers.io())
                .compose(this.<String>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        finish();
                        Log.i(TAG, "Call " + s);
                    }
                });
    }


    private void setTimerCountinue(long elaspedTime) {
        tvCallName.setVisibility(View.VISIBLE);
        callTime.setBase(SystemClock.elapsedRealtime() - elaspedTime);//复位计时器，停止计时
        callTime.start();
        duringTime = SystemClock.elapsedRealtime() - callTime.getBase();
        Log.i(TAG, "setTimerCountinue is start " + callTime.getText());
    }


    private void setTimer(boolean isStart) {
        if (isStart) {

            tvCallName.setVisibility(View.VISIBLE);
            callTime.setBase(SystemClock.elapsedRealtime() - duringTime);//复位计时器，停止计时
            callTime.start();
            duringTime = SystemClock.elapsedRealtime() - callTime.getBase();

            Log.i(TAG, "time is start " + callTime.getText());
        } else {
            duringTime = 0;
            callTime.stop();//复位计时器，停止计时
            Log.i(TAG, "time is stop");
        }
    }

    @Override
    public void onBackPressed() {

    }
}
