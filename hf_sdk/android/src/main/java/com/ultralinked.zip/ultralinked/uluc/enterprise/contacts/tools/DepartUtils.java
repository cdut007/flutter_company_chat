package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import com.ultralinked.uluc.enterprise.utils.Log;

import com.ultralinked.uluc.enterprise.App;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ultralinked on 16/7/21.
 */
public class DepartUtils {
    //departmend id is unique
    static HashMap<String, CompanyElement> searchCache = new HashMap<>();
    private static final String TAG = "DepartUtils";
    private static DepartUtils instance;

    public static DepartUtils getInstance() {
        if (instance == null) {
            instance = new DepartUtils();
        }
        return instance;
    }

    private Context context;

    private DepartUtils() {
        this.context = App.getInstance().getApplicationContext();

    }

    static String RootStringCache;

    private String getRootString() {
        if (TextUtils.isEmpty(RootStringCache)) {
            RootStringCache = read_DEPARMENT_COMPANY_JSON_STRING();
        }
        return RootStringCache;
    }

    //used in save department via http request
    public static final String KEY_DEPARMENT_COMPANY_JSON_STRING = "saveDepartment";

    public void save_DEPARMENT_COMPANY_JSON_STRING(String jsonstr) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString(KEY_DEPARMENT_COMPANY_JSON_STRING+"_"+SPUtil.getUserID(), jsonstr).commit();
        RootStringCache = jsonstr;
        searchCache = new HashMap<>();
        initSearchCache();
    }

    public static  void clear_cache_DEPARMENT_COMPANY_JSON_STRING() {
        RootStringCache = null;
    }

    private String read_DEPARMENT_COMPANY_JSON_STRING() {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(KEY_DEPARMENT_COMPANY_JSON_STRING+"_"+SPUtil.getUserID(), "");
    }


    /**
     * show company
     *
     * @return
     */
    public ArrayList<CompanyElement> getCompanyMap() {

        ArrayList<CompanyElement> data = new ArrayList<>();

        String rootString = getRootString();

        if (TextUtils.isEmpty(rootString)) {

            return data;
        }

        //tranfer into json

        try {

            JSONObject jsonObject = new JSONObject(rootString);

            JSONArray jsonArray = (JSONArray) jsonObject.opt("result");

            if (isEmpty(jsonArray)) {
                return data;
            }

            int size = jsonArray.length();

            for (int i = 0; i < size; i++) {

                JSONObject object = jsonArray.getJSONObject(i);

                String name = object.optString("name");
                String _id = object.optString("_id");
                String company = object.optString("company");
                String type = object.optString("type");
                JSONArray children2 = object.optJSONArray("children2");
                Log.i(TAG, "getCompanyMap name = " + name + " ; ");
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(_id)) {
                    data.add(new CompanyElement(name, _id, company, type, children2));
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSONException = " + e.getMessage());
        } finally {
            return data;
        }
    }

    /**
     * when onclick, pass the right jsonArray into this method, read a new ArrayList<CompanyElement>
     *
     * @param jsonArray
     */

    public ArrayList<CompanyElement> readCompanyStructure(JSONArray jsonArray) {

        return  readCompanyStructure(false,jsonArray);
    }
    public ArrayList<CompanyElement> readCompanyStructure(boolean hasInviteOrg,JSONArray jsonArray) {

        ArrayList<CompanyElement> data = new ArrayList<>();

        if (isEmpty(jsonArray)) {

            return data;
        }

        int size = jsonArray.length();

        for (int i = 0; i < size; i++) {

            JSONObject object = null;

            object = jsonArray.optJSONObject(i);

            if (object != null) {

                String name = object.optString("name");
                String _id = object.optString("_id");
                String company = object.optString("company");
                String type = object.optString("type");
                JSONArray children2 = object.optJSONArray("children2");
                Log.i(TAG, "readCompanyStructure name = " + name+";_id="+_id+";company="+company+";type="+type+";children2="+children2);
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(_id)) {
                    data.add(new CompanyElement(name, _id, company, type, children2));
                }
            }

        }

        //for the default org pending info
        if (hasInviteOrg){
            data.add(0,new CompanyElement(App.getInstance().getString(R.string.organization_pending_invite),INVITE_ORG_FLAG , null, "internal", null));
        }

        return data;
    }

    public  static  final String INVITE_ORG_FLAG="invite_org_id";

    public static class CompanyElement implements Parcelable {

        /**
         * children2 :
         * name : ultralinked
         * root : 1
         * company : DEPART129d4814-36ad-11e6-b191-22000aae16d4
         * _id : DEPART129d4814-36ad-11e6-b191-22000aae16d4
         * type : internal
         */


        public CompanyElement(String name, String _id, String company, String type, JSONArray children2) {
            this.name = name;
            this._id = _id;
            this.company = company;
            this.type = type;
            this.children2 = children2;
            children2Str = (children2 == null ? "" : children2.toString());
        }

        public String name;
        public String _id;
        public String company;
        public String type;
        public JSONArray children2;
        private String children2Str;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.name);
            dest.writeString(this._id);
            dest.writeString(this.company);
            dest.writeString(this.type);
            dest.writeString(this.children2Str);
            if (TextUtils.isEmpty(children2Str)) {
                children2 = null;
            } else {

                try {
                    children2 = new JSONArray(children2Str);
                } catch (JSONException e) {
                    Log.i("CompanyElement", "writeToParcel error " + e.getMessage());
                }
            }
        }

        protected CompanyElement(Parcel in) {
            this.name = in.readString();
            this._id = in.readString();
            this.company = in.readString();
            this.type = in.readString();
            this.children2Str = in.readString();
        }

        public static final Parcelable.Creator<CompanyElement> CREATOR = new Parcelable.Creator<CompanyElement>() {
            @Override
            public CompanyElement createFromParcel(Parcel source) {
                return new CompanyElement(source);
            }

            @Override
            public CompanyElement[] newArray(int size) {
                return new CompanyElement[size];
            }
        };
    }

    private boolean isEmpty(JSONArray jsonArray) {

        return jsonArray == null || 0 == jsonArray.length();
    }


    /**
     * search by id , return companyelement
     *
     * @param deparment_id
     */

    public CompanyElement getFromSearchCache(String deparment_id) {

        if (searchCache.containsKey(deparment_id)) {

            return searchCache.get(deparment_id);
        }

        return null;
    }

    private void initSearchCache() {

        ArrayList<CompanyElement> companys = getCompanyMap();

        for (CompanyElement company : companys) {

            searchCache.put(company._id, company);

            if (!isEmpty(company.children2)) {

                searchChildredn(company.children2);

            }

        }
    }


    private void searchChildredn(JSONArray children2) {

        ArrayList<CompanyElement> subchildren = readCompanyStructure(children2);

        for (CompanyElement company : subchildren) {

            searchCache.put(company._id, company);

            if (!isEmpty(company.children2)) {

                searchChildredn(company.children2);

            }

        }
    }


}
