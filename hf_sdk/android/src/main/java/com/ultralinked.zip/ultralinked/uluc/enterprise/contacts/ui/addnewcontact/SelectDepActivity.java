package com.ultralinked.uluc.enterprise.contacts.ui.addnewcontact;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.contacts.ChoicePopWindow;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils.CompanyElement;
import com.ultralinked.uluc.enterprise.contacts.tools.GsonUtil;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * add new user, click company/department to open this activity to choose
 */

public class SelectDepActivity extends AppCompatActivity {

    private static final String TAG = "SelectDepActivity";
    public static final String ADD = "select_a_department_for_add_new";

    private HashMap<Integer, ArrayList<CompanyElement>> UserClickPath = new HashMap<>();

    private int currentStep = 0;
    //
    private ListView mListView;
    //
    private DepartBaseAdapter mAdapter;

    private int mInterl_OR_External;

    public String mSelectCompanyName;
    private TextView mNodepartView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.activity_select_dep);

        initTitle();

        mInterl_OR_External = getIntent().getIntExtra("Interl_OR_External", -2);

        mListView = (ListView) findViewById(R.id.container_departs);

        mNodepartView = (TextView) findViewById(R.id.tv_no_depart);

        mAdapter = new DepartBaseAdapter(this);

        mListView.setAdapter(mAdapter);

        mNodepartView.setText(getString(R.string.add_contact_no_deprtment));

        mListView.setEmptyView(mNodepartView);

        //all these companys are stored
        ArrayList<CompanyElement> data = DepartUtils.getInstance().getCompanyMap();


        UserClickPath.put(currentStep, data);

        mAdapter.setData(data);
        mAdapter.notifyDataSetChanged();

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DepartUtils.CompanyElement element = (DepartUtils.CompanyElement) parent.getAdapter().getItem(position);

                if (currentStep == 0) {
                    //find out the choosed companyname
                    mSelectCompanyName = element.name;
                }

                if (element.children2 == null || element.children2.length() == 0) {// it is a leaf, open detail page
                    Log.i(TAG, "I am a leaf with name " + element.name + "; id =" + element._id);

                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    String eleStr = GsonUtil.toJson(element);

                    bundle.putString(FragmentAddContactMannual.KEY_ADDNEW_COM_NAME, mSelectCompanyName);
                    bundle.putString(FragmentAddContactMannual.KEY_ADDNEW_DEPART_NAME, element.name);
                    bundle.putString(FragmentAddContactMannual.KEY_ADDNEW_DEPART_ID, element._id);

                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
                    close();
                    return;

                } else {// has child
                    Log.i(TAG, " children2 " + element.children2.length());
                    ArrayList<DepartUtils.CompanyElement> subChildren = DepartUtils.getInstance().readCompanyStructure(element.children2);
                    Log.i(TAG, " subChildren " + subChildren.size());
                    currentStep += 1;
                    UserClickPath.put(currentStep, subChildren);
                    mAdapter.setData(subChildren);
                    mAdapter.notifyDataSetChanged();
                    Log.i(TAG, "notifyDataSetChanged ");
                }
            }
        });
    }

    private void initTitle() {

        ImageView left_back = (ImageView) findViewById(R.id.left_back);
        left_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView titleCenter = (TextView) findViewById(R.id.titleCenter);
        titleCenter.setText(getString(R.string.add_contact_select_depart));


        TextView titleRight = (TextView) findViewById(R.id.titleRight);
        titleRight.setVisibility(View.INVISIBLE);

    }


    private class DepartBaseAdapter extends BaseAdapter {

        List<CompanyElement> elements = new ArrayList<>();
        LayoutInflater mInflater;


        public void setData(List<DepartUtils.CompanyElement> data) {

            elements.clear();

            if (currentStep == 0) {
                // 0 stand for company, no need to tell internal or external
                elements = new ArrayList<>(data);

                return;
            }

            for (DepartUtils.CompanyElement element : data) {

                if (mInterl_OR_External == ChoicePopWindow.CHOOSE_INTERNAL) {

                    if ("internal".equalsIgnoreCase(element.type)) {

                        elements.add(element);
                    }
                } else if (mInterl_OR_External == ChoicePopWindow.CHOOSE_EXTERNAL) {

                    if ("external".equalsIgnoreCase(element.type)) {

                        elements.add(element);
                    }
                }

            }

        }

        public DepartBaseAdapter(Context context) {

            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return elements == null ? 0 : elements.size();
        }

        @Override
        public Object getItem(int position) {
            return elements == null ? null : elements.get(position);
        }

        @Override
        public long getItemId(int position) {
            return elements == null ? 0 : position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder;

            if (convertView != null) {
                holder = (ViewHolder) convertView.getTag();//取出ViewHolder对象

            } else {

                convertView = mInflater.inflate(R.layout.depart_list_item, null);
                holder = new ViewHolder();
                holder.bind(convertView);
                convertView.setTag(holder);//绑定ViewHolder对象
            }


            CompanyElement source = elements.get(position);

            holder.title.setText(source.name);
            holder._Id = source._id;


            int defaultId = -1;

            switch (position % 4) {

                case 1:
                    defaultId = R.mipmap.orgnanization_1;
                    break;
                case 2:
                    defaultId = R.mipmap.orgnanization_2;
                    break;
                case 3:
                    defaultId = R.mipmap.orgnanization_3;
                    break;
                default:
                    defaultId = R.mipmap.orgnanization_4;
                    break;
            }


            ImageUtils.loadCircleImage(convertView.getContext(), holder.head, defaultId);

            if (isLeaf(source)) {
                holder.detail.setImageResource(R.mipmap.detail);
            }
            return convertView;
        }

        public final class ViewHolder {
            public TextView title;
            public ImageView head;
            public ImageView detail;
            public String _Id;

            public void bind(View view) {

                this.title = (TextView) view.findViewById(R.id.Orgtitle);
                this.head = (ImageView) view.findViewById(R.id.Orgimage);
                this.detail = (ImageView) view.findViewById(R.id.OrgDetail);
            }
        }

        public boolean isLeaf(DepartUtils.CompanyElement object) {

            return object.children2 == null || object.children2.length() == 0;

        }
    }

    private void close() {
        finish();
    }

    @Override
    public void onBackPressed() {

        goBack();

    }

    private void goBack() {
        if (currentStep == 0) {

            UserClickPath.clear();
            UserClickPath = null;
            finish();

        } else {
            UserClickPath.put(currentStep, null);
            currentStep -= 1;
            mAdapter.setData(UserClickPath.get(currentStep));
            mAdapter.notifyDataSetChanged();
        }
    }
}
