package com.ultralinked.uluc.enterprise.moments.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.gson.JsonSyntaxException;
import com.ultralinked.uluc.enterprise.chat.Conversation;
import com.ultralinked.uluc.enterprise.chat.chatim.PaintModel;
import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;
import com.ultralinked.uluc.enterprise.contacts.tools.PeopleEntityQuery;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.QueryFriendListener;
import com.ultralinked.uluc.enterprise.contacts.ui.newfriend.RequestFriendManager;
import com.ultralinked.uluc.enterprise.game.GameModel;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.moments.listener.RecycleViewItemListener;
import com.ultralinked.uluc.enterprise.utils.Log;

import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.malinskiy.superrecyclerview.OnMoreListener;
import com.malinskiy.superrecyclerview.SuperRecyclerView;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.moments.adapter.CircleAdapter;
import com.ultralinked.uluc.enterprise.moments.adapter.FeedAdapter;
import com.ultralinked.uluc.enterprise.moments.bean.CircleItem;
import com.ultralinked.uluc.enterprise.moments.bean.CommentConfig;
import com.ultralinked.uluc.enterprise.moments.bean.FeedUserLineItem;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.moments.utils.DatasUtil;
import com.ultralinked.uluc.enterprise.moments.widgets.DivItemDecoration;
import com.ultralinked.uluc.enterprise.moments.widgets.dialog.UpLoadDialog;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.MessagingApi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class UserFeedActivity extends BaseActivity implements View.OnClickListener {

    @Override
    public int getRootLayoutId() {
        return R.layout.feed_activity_main;
    }


    private ImageView leftBack;

    User circleItem;

    @Override
    public void initView(Bundle savedInstanceState) {

        leftBack = bind(R.id.left_back);

        bind(R.id.titleRight).setVisibility(View.GONE);


        circleItem = (User) getIntent().getSerializableExtra("user");
        if (circleItem != null) {
            ((TextView) bind(R.id.titleCenter)).setText(circleItem.getName());
            PeopleEntity  peopleEntity = PeopleEntityQuery.getInstance().getByID(circleItem.getId());
            if (peopleEntity!=null){
                circleItem.setHeadUrl(peopleEntity.icon_url);
            }

        }

        initListener(this, leftBack);



        //query user  by id.
        queryUserInfo();
    }

    private void queryUserInfo() {
        List<String> userIds = new ArrayList<>();
        userIds.add(circleItem.getId());
        RequestFriendManager.getInstance().queryPeople(userIds, new QueryFriendListener() {
            @Override
            public void onResultFriendList(final List<PeopleEntity> entities) {
                if (getActivity()!=null && !getActivity().isFinishing()){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (entities!=null && !entities.isEmpty()){
                                updateBackgourd(null,null,entities.get(0).icon_url);
                            }

                        }
                    });
                }
            }
            @Override
            public void onQueryFailed(List<String> requestUserIds) {

            }
        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left_back:
                finish();
                break;

            default:
        }
    }

    protected static final String TAG = UserFeedActivity.class.getSimpleName();
    private FeedAdapter feedAdapter;


    private SuperRecyclerView recyclerView;
    private RelativeLayout bodyLayout;
    private LinearLayoutManager layoutManager;

    private final static int TYPE_PULLREFRESH = 1;
    private final static int TYPE_UPLOADREFRESH = 2;
    private UpLoadDialog uploadDialog;
    private SwipeRefreshLayout.OnRefreshListener refreshListener;


    public static  void startChessGame(BaseActivity baseActivity,String id) {
//        if (SPUtil.getUserID().equals(circleItem.getId())){
//            return;
//        }
        com.ultralinked.voip.api.Conversation conversation = MessagingApi.getConversation(id);
        GameModel gameModel = new GameModel();
        conversation.sendCustomBroadcast(GameModel.TYPE_CHESS, gameModel.request());
        baseActivity.showToast(R.string.request_wait_play_game);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //presenter = new CirclePresenter(this);

        setHeader();
        addItems();

        initView();

        //实现自动下拉刷新功能
        recyclerView.getSwipeToRefresh().post(new Runnable() {
            @Override
            public void run() {
                recyclerView.setRefreshing(true);//执行下拉刷新的动画
                refreshListener.onRefresh();//执行数据加载操作
            }
        });
    }


    private void setHeader() {
//        String coverUrl = String.format("http://file-cdn.datafans.net/temp/12.jpg_%dx%d.jpeg", coverWidth, coverHeight);
//        setCover(coverUrl);
//
//
//        String userAvatarUrl = String.format("http://file-cdn.datafans.net/avatar/1.jpeg_%dx%d.jpeg", userAvatarSize, userAvatarSize);
//        setUserAvatar(userAvatarUrl);
//
//
//        setUserNick("Allen");
//
//        setUserSign("梦想还是要有的 万一实现了呢");
//
//        setUserId(123456);
    }


    private void addItems() {


    }


    @Override
    protected void onDestroy() {

        super.onDestroy();
    }

    @SuppressLint({"ClickableViewAccessibility", "InlinedApi"})
    private void initView() {
        initUploadDialog();

        recyclerView = (SuperRecyclerView) findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new DivItemDecoration(2, true));
        recyclerView.getMoreProgressView().getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;

        recyclerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                return false;
            }
        });

        refreshListener = new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchOtherUserMoments(true, "-1");
            }
        };
        recyclerView.setRefreshListener(refreshListener);

        recyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (isDestroyed() || isFinishing()) {
                    return;
                }
//                if(newState == RecyclerView.SCROLL_STATE_IDLE){
//                    Glide.with(UserFeedActivity.this).resumeRequests();
//                }else{
//                    Glide.with(UserFeedActivity.this).pauseRequests();
//                }

            }
        });

        feedAdapter = new FeedAdapter(this);
        if (circleItem != null) {
            feedAdapter.setHeadInfo(circleItem);
        }

        feedAdapter.setItemListener(new RecycleViewItemListener() {
            @Override
            public void onItemClick(int position) {
                FeedUserLineItem feedUserLineItem = (FeedUserLineItem) feedAdapter.getDatas().get(position);
                if (feedUserLineItem.type.equals(FeedUserLineItem.TYPE_GAME)) {
                    startChessGame(UserFeedActivity.this,circleItem.getId());
                }
            }

            @Override
            public boolean onItemLongClick(int position) {
                return false;
            }
        });

        recyclerView.setAdapter(feedAdapter);
        queryUserMomentBackgroudInfo();
    }


    private void queryUserMomentBackgroudInfo() {
        List<String> backgroud = new ArrayList<>();
        backgroud.add("backgroud_url");
        backgroud.add("signature");
        ApiManager.getInstance().queryUserMomentProfile(circleItem.getId(), backgroud)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryUserMomentBackgroudInfoComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                JSONObject result = object.optJSONObject("result");
                                updateBackgourd(result.optString("backgroud_url"), result.optString("signature"),null);

                            }
                        } catch (Exception e) {
                            Log.e(TAG, "parse queryUserMomentBackgroudInfo error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "queryUserMomentBackgroudInfo result:" + rs);
                    }
                });
    }


    private void updateBackgourd(String url, String signature,String iconUrl) {
        User user = SPUtil.getMomentInfo(circleItem.getId());

        if (!TextUtils.isEmpty(url)){
            user.cover = url;
        }

        if (!TextUtils.isEmpty(signature)) {
            user.signature = signature;
        }

        if (!TextUtils.isEmpty(iconUrl)){
            user.setHeadUrl(iconUrl);
        }

        SPUtil.saveMomentInfo(user);
        if (feedAdapter != null) {
            feedAdapter.notifyDataSetChanged();
        }

    }

    private void fetchOtherUserMoments(final boolean firstPage, String pageCursor) {


        ApiManager.getInstance().queryOtherUserMoments("10", circleItem.getId(), pageCursor)
                .subscribeOn(Schedulers.io())        //子线程

                //                .delay(3,TimeUnit.SECONDS)  延迟三秒执行

                .throttleFirst(3, TimeUnit.SECONDS)              //三秒执行一次
                .observeOn(AndroidSchedulers.mainThread())      //结果处理在主线程
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "queryOtherUserMomentsComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        List<FeedUserLineItem> datas = new ArrayList<FeedUserLineItem>();
                        update2loadData(TYPE_PULLREFRESH, datas);

                        Log.e(TAG, "queryOtherUserMoments  error " + eMsg);
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {

                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);
                            if (200 == object.optInt("code")) {
                                JSONArray result = object.optJSONArray("result");

                                List<FeedUserLineItem> datas = DatasUtil.createFeedUserLineItem(result);
                                update2loadData(firstPage ? TYPE_PULLREFRESH : TYPE_UPLOADREFRESH, datas);
                            } else {
                                Log.i(TAG, "queryOtherUserMoments error:" + "errorcode:" + object.optInt("code") + "\n" + object.optString("description"));


                            }


                        } catch (JsonSyntaxException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JsonSyntaxException " + e.getMessage());
                        } catch (JSONException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "JSONException " + e.getMessage());
                        } catch (IOException e) {
                            //showToast(getString(R.string.blance_transfer_failed));
                            com.ultralinked.uluc.enterprise.utils.Log.e(TAG, "IOException " + e.getMessage());
                        }

                        Log.i(TAG, "get queryOtherUserMoments:  " + rs);
                    }         //请求成功

                });

    }

    private void initUploadDialog() {
        uploadDialog = new UpLoadDialog(this);
    }


    public void update2loadData(int loadType, List<FeedUserLineItem> datas) {
        if (loadType == TYPE_PULLREFRESH) {
            recyclerView.setRefreshing(false);
            feedAdapter.setDatas(datas);
        } else if (loadType == TYPE_UPLOADREFRESH) {
            feedAdapter.getDatas().addAll(datas);
        }
        feedAdapter.notifyDataSetChanged();

        if (feedAdapter.getDatas().size() < 45 + CircleAdapter.HEADVIEW_SIZE) {
            recyclerView.setupMoreListener(new OnMoreListener() {
                @Override
                public void onMoreAsked(int overallItemsCount, int itemsBeforeMore, int maxLastVisiblePosition) {
                    try {
                        String pageCursor = ((FeedUserLineItem) feedAdapter.getDatas().get(feedAdapter.getItemCount() - 2)).post_id;//ignore head
                        fetchOtherUserMoments(false, pageCursor);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }, 1);
        } else {
            recyclerView.removeMoreListener();
            recyclerView.hideMoreProgress();
        }

    }


    String videoFile;
    String[] thum;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {


        } else {
            if (resultCode == RESULT_CANCELED) {

            }
        }
    }


    public static void go2FeedPage(Context context, PeopleEntity peopleEntity) {
        User user = new User();
        user.setName(PeopleEntityQuery.getDisplayName(peopleEntity));
        user.setId(peopleEntity.subuser_id);
        user.setHeadUrl(peopleEntity.icon_url);
        go2FeedPage(context, user);
    }


    public static void go2FeedPage(Context context, User user) {
        Intent intent = new Intent(context, UserFeedActivity.class);
        if (context instanceof Activity) {

        } else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.putExtra("user", user);
        context.startActivity(intent);
    }
}
