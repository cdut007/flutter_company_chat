package com.ultralinked.uluc.enterprise.login.bean;

/**
 * Created by Administrator on 2016/8/1 0001.
 */
public class ContactInfo {
    private String userId;
    private String name;
    private String url;

    public ContactInfo(){

    }
    public ContactInfo(String userId, String name) {
        this.userId = userId;
        this.name = name;
    }

    public ContactInfo(String userId, String name, String url) {
        this.userId = userId;
        this.name = name;
        this.url = url;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ContactInfo that = (ContactInfo) o;

        return userId != null ? userId.equals(that.userId) : that.userId == null;

    }

}
