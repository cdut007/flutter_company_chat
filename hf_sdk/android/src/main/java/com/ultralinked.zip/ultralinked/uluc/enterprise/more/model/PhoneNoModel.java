package com.ultralinked.uluc.enterprise.more.model;

import android.text.TextUtils;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lly on 2016/12/13.
 */

public class PhoneNoModel{

    private String country_code;
    private String country_name;
    private List<PhoneProduct> phone_nos;

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCountry_name() {
        return TextUtils.isEmpty(country_name)?"":country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public List<PhoneProduct> getPhone_nos() {
        return phone_nos;
    }

    public void setPhone_nos(List<PhoneProduct> phone_nos) {
        this.phone_nos = phone_nos;
    }

}
