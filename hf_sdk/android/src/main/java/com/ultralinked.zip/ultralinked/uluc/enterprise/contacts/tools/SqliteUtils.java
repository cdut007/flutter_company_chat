package com.ultralinked.uluc.enterprise.contacts.tools;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.ultralinked.uluc.enterprise.App;
import com.ultralinked.uluc.enterprise.contacts.contract.DbSQLHelper;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;
import com.ultralinked.voip.api.utils.CommonUtils;

/**
 * Created by ultralinked on 16/7/18.
 */
public class SqliteUtils {


    private static volatile SqliteUtils instance;

    private DbSQLHelper dbHelper;
    private SQLiteDatabase db;

    private SqliteUtils(Context context) {
        dbHelper = new DbSQLHelper(context);
        db = dbHelper.getWritableDatabase();

    }


    private void resetDB(Context context) {
        if (App.getInstance() == null) {
            //fix the provider need context issue.
            return;
        }
        String userId = SPUtil.getUserID();
        if (!TextUtils.isEmpty(userId)) {
            if (!DbSQLHelper.DATABASE_NAME.contains(userId)) {
                DbSQLHelper.DATABASE_NAME = "ulucenterprise_" + userId + ".db";
                Log.i("SQL_ULUC", "database_name:" + DbSQLHelper.DATABASE_NAME);
                if (dbHelper != null) {
                    dbHelper.close();
                }
                dbHelper = new DbSQLHelper(context);
                db = dbHelper.getWritableDatabase();
            }

        }


    }


    public static void init(Context context) {
        if (!CommonUtils.isMainPid(context)){
            Log.i("app", "database is not in main progess");
            return;
        }

          getInstance(context);
          SPUtil.initCountryCode(context);
    }



    public static SqliteUtils getInstance(Context context) {
        if (instance == null) {
            synchronized (SqliteUtils.class) {
                if (instance == null) {
                    instance = new SqliteUtils(context);
                }
            }
        }
        instance.resetDB(context);
        return instance;
    }


    public SQLiteDatabase getDb() {
        return db;
    }
}



