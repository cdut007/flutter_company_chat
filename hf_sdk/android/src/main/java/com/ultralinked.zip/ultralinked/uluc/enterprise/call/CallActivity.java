package com.ultralinked.uluc.enterprise.call;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.ultralinked.uluc.enterprise.Constants;
import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.baseui.BaseTextWatcher;
import com.ultralinked.uluc.enterprise.baseui.baseadapter.MyBaseAdapter;
import com.ultralinked.uluc.enterprise.baseui.widget.CCPhoneView;
import com.ultralinked.uluc.enterprise.baseui.widget.NumberKeyboard;
import com.ultralinked.uluc.enterprise.chat.chatdetails.GroupChatDetailsFragment;
import com.ultralinked.uluc.enterprise.chat.chatdetails.SingleChatDetailsFragment;
import com.ultralinked.uluc.enterprise.contacts.tools.SqliteUtils;
import com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity;
import com.ultralinked.uluc.enterprise.login.bean.CountryInfo;
import com.ultralinked.uluc.enterprise.utils.CallDialog;
import com.ultralinked.uluc.enterprise.utils.CountryCodeStorageHelper;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RegexValidateUtils;
import com.ultralinked.uluc.enterprise.utils.StringUtils;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.COUNTRY_CODE_KEY;
import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.COUNTRY_NAME_KEY;
import static com.ultralinked.uluc.enterprise.login.CountryCodeChooseActivity.REQUEST_COUNTRY_CODE;


public class CallActivity extends BaseFragmentActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.getCurrentPage(this).setSwipeBackEnable(false);
    }

    @Override
    public void initView(Bundle savedInstanceState) {

        Class<?> className = CallFragment.class;
        setFragment(className, null);

    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        CallFragment callFragment = (CallFragment) getFragment();
        if (callFragment!=null) {
            callFragment.onWindowFocusChanged(hasFocus);
        }

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
//        CallFragment callFragment = (CallFragment) getFragment();
//        if (callFragment!=null) {
//            callFragment.dispatchTouchEvent(ev);
//        }

        return super.dispatchTouchEvent(ev);
    }


    @Override
    public void onBackPressed() {

        CallFragment callFragment = (CallFragment) getFragment();
        if (callFragment!=null) {
            boolean onback = callFragment.onBackPressed();
            if (!onback){
                super.onBackPressed();
            }

        }else{
            super.onBackPressed();
        }

    }
}
