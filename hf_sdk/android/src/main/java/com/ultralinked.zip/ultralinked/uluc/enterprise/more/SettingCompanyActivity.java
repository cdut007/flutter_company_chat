package com.ultralinked.uluc.enterprise.more;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.baseui.MobileBrowserActivity;
import com.ultralinked.uluc.enterprise.call.FragmentTools;
import com.ultralinked.uluc.enterprise.contacts.FragmentCompanyContacts;
import com.ultralinked.uluc.enterprise.contacts.FragmentContacts;
import com.ultralinked.uluc.enterprise.contacts.contract.PersonnelContract;
import com.ultralinked.uluc.enterprise.contacts.contract.RelationContract;
import com.ultralinked.uluc.enterprise.contacts.tools.CompanySelector;
import com.ultralinked.uluc.enterprise.contacts.tools.DepartUtils;
import com.ultralinked.uluc.enterprise.contacts.ui.detail.DetailListActivity;
import com.ultralinked.uluc.enterprise.login.SignupActivity;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.RxBus;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import java.util.ArrayList;
import java.util.Objects;

public class SettingCompanyActivity extends BaseActivity implements View.OnClickListener {

    private DepartmentChangeObserver departmentChangeObserver;

    @Override
    public int getRootLayoutId() {
        return R.layout.activity_setting_company;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    boolean refreshCompany = false;
    @Override
    public void initView(Bundle savedInstanceState) {
        ((TextView)bind(R.id.titleCenter)).setText(R.string.my_company);
        bind(R.id.titleRight).setVisibility(View.GONE);
        bind(R.id.left_back).setOnClickListener(this);
       // goneView(bind(R.id.btRequest));
        bind(R.id.btRequest).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingCompanyActivity.this, SignupActivity.class);
                intent.putExtra("company",true);
                startActivity(intent);
                refreshCompany= true;
            }
        });
        Uri uri = RelationContract.CONTENT_URI;
        departmentChangeObserver = new DepartmentChangeObserver(new Handler());
        getActivity().getContentResolver().registerContentObserver(uri,true,departmentChangeObserver);

        initCompanyChooseView();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (departmentChangeObserver!=null){
            getContentResolver().unregisterContentObserver(departmentChangeObserver);
        }
    }

    private class DepartmentChangeObserver extends ContentObserver {
        public DepartmentChangeObserver(Handler handler) {
            super(handler);
        }
        @Override
        public void onChange(boolean selfChange) {

            super.onChange(selfChange);
            Log.i(TAG,"DepartmentChangeObserver hasChanged..");
            initCompanyChooseView();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (refreshCompany){
            initCompanyChooseView();
            refreshCompany = false;
        }
    }

    private LinearLayout mRadioGroup;

    private void initCompanyChooseView() {

        mRadioGroup = (LinearLayout) findViewById(R.id.root_container);

        mRadioGroup.removeAllViews();

        ArrayList<DepartUtils.CompanyElement> rootdata = DepartUtils.getInstance().getCompanyMap();

        final DepartUtils.CompanyElement[] arrString = rootdata.toArray(new DepartUtils.CompanyElement[rootdata.size()]);

        final String[] Items = new String[arrString.length];
        String companyName = FragmentContacts.firstLetterToUpper(CompanySelector.getInstance(getActivity()).getCompanyName());
        for (int i = 0; i < arrString.length; i++) {

            Items[i] = FragmentContacts.firstLetterToUpper(arrString[i].name);

            ViewGroup item  = (ViewGroup) getLayoutInflater().inflate(R.layout.item_company,null);
            item.findViewById(R.id.admin_pms_btn).setVisibility(View.GONE);
            ((TextView)((ViewGroup)item.findViewById(R.id.item_layout)).getChildAt(1)).setText(Items[i]);

            (item.findViewById(R.id.check_company)).setTag(Items[i]);
            item.setTag(Items[i]);
            final String diplayCompany = Items[i];
            View pmsBtn = item.findViewById(R.id.admin_pms_btn);
            pmsBtn.setTag(Items[i]);
            pmsBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String name = String.valueOf(v.getTag());
                    DepartUtils.CompanyElement item = null;
                    for (int i = 0; i < arrString.length; i++) {
                        if (arrString[i].name.equalsIgnoreCase(name)){
                            item = arrString[i];
                            break;
                        }
                    }
                    if (item == null){
                        Log.i(TAG,"can not find right index..");
                        return;
                    }

                    Intent intent = new Intent(SettingCompanyActivity.this,CompanyDetailActivity.class);
                    intent.putExtra(FragmentTools.KEY_DETAIL, item);
                    intent.putExtra(FragmentTools.KEY_COMPANY_NAME, item.name);
                    startActivity(intent);
                   // MobileBrowserActivity.actionStart(SettingCompanyActivity.this,SPUtil.getWebManagerUrl(),diplayCompany);
                }
            });

            mRadioGroup.addView(item);

            if (Items[i].equals(companyName)){
                //for default.
                check(mRadioGroup,item.getTag());
            }
        }

        // test listening to checked change events

        int childCount = mRadioGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            mRadioGroup.getChildAt(i).setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    String name = String.valueOf(v.getTag());
                    DepartUtils.CompanyElement item = null;
                    for (int i = 0; i < arrString.length; i++) {
                        if (arrString[i].name.equalsIgnoreCase(name)){
                            item = arrString[i];
                            break;
                        }
                    }
                  if (item == null){
                      Log.i(TAG,"can not find right index..");
                      return;
                  }
                    CompanySelector.getInstance(getActivity()).setChoosedCompany(item.name, item._id);
                    onCheckedChanged( name);
                    RxBus.getDefault().post(new Object());

                }
            });
        }



    }



    private void check(ViewGroup view,Object viewId) {
        int count = view.getChildCount();
        for (int i = 0; i < count; i++) {
            View childView = view.getChildAt(i);
            if (childView instanceof ViewGroup) {
                ViewGroup subViewGroup = (ViewGroup) childView;
                check(subViewGroup,viewId);
            } else {
                if (childView instanceof CheckBox) {

                    if ((String.valueOf(childView.getTag()).equals(String.valueOf(viewId)))) {
                        ((CheckBox) childView).setChecked(true);
                    } else {
                        ((CheckBox) childView).setChecked(false);
                    }
                }
            }
        }

    }

    public void onCheckedChanged(Object checkedId) {
        Log.i(TAG,"select current id :"+checkedId);

        check(mRadioGroup, checkedId);

        //setResult(RESULT_OK);


    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;

        }
    }
}
