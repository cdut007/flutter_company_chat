package com.ultralinked.uluc.enterprise.more;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;

public class RecoverySettingActivity extends BaseActivity implements View.OnClickListener{

    @Override
    public int getRootLayoutId() {
        return com.holdingfuture.flutterapp.hfsdk.R.layout.activity_recovery_setting;
    }

    @Override
    public void initView(Bundle savedInstanceState) {
        initListener(this, R.id.btRecovery);
    }

    @Override
    protected void setTopBar() {
        super.setTopBar();
        bind(R.id.left_back).setOnClickListener(this);
        ((TextView)bind(R.id.titleCenter)).setText(com.holdingfuture.flutterapp.hfsdk.R.string.recovery_settings);
        bind(R.id.titleRight).setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.left_back:
                finish();
                break;
            case R.id.btRecovery:
                // TODO: 2016/8/4 0004 密码恢复
                break;
        }
    }
}
