package com.ultralinked.uluc.enterprise.moments.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.holdingfuture.flutterapp.hfsdk.R;
import com.ultralinked.uluc.enterprise.baseui.BaseActivity;
import com.ultralinked.uluc.enterprise.http.ApiManager;
import com.ultralinked.uluc.enterprise.http.HttpErrorException;
import com.ultralinked.uluc.enterprise.moments.bean.User;
import com.ultralinked.uluc.enterprise.utils.ImageUtils;
import com.ultralinked.uluc.enterprise.utils.Log;
import com.ultralinked.uluc.enterprise.utils.SPUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


/**
 * Created by mac on 17/1/12.
 */

public class SignatureActivity extends BaseActivity {
    @Override
    public int getRootLayoutId() {
        return R.layout.activity_moment_user_signature_input;
    }

    EditText signatureEdit;
    User user;

    @Override
    public void initView(Bundle savedInstanceState) {


        user = (User) getIntent().getSerializableExtra("user");

        signatureEdit = bind(R.id.common_user_input_item_content);

        if (user != null) {
            if (!TextUtils.isEmpty(user.signature)) {
                if (user.signature.equals("null")) {
                    user.signature = null;
                } else {
                    signatureEdit.setText(user.signature);
                    signatureEdit.setSelection(user.signature.length());
                }

            }

        }


        bind(R.id.left_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView signatureText = bind(R.id.titleCenter);
        signatureText.setText(R.string.signature);
        TextView signatureDone = bind(R.id.titleRight);
        signatureDone.setText(R.string.select_member_done);
        ImageUtils.buttonEffect(signatureDone);
        signatureDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence info = signatureEdit.getText();
                if (!TextUtils.isEmpty(info)) {
                    if (user != null && !info.toString().equals(user.signature)) {
                        requestSignature(info.toString());
                    } else {
                        finish();//nothing has changed.
                    }

                }

            }
        });


    }


    public static void go2FeedPage(Context context, User user) {
        Intent intent = new Intent(context, SignatureActivity.class);
        if (context instanceof Activity) {

        } else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.putExtra("user", user);
        context.startActivity(intent);
    }

    private void requestSignature(String signature) {

        ApiManager.getInstance().requestSignature(signature)
                .subscribeOn(Schedulers.io())
                .compose(this.<ResponseBody>bindToLifecycle())
                .throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {
                        Log.i(TAG, "requestSignatureComplted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        String eMsg = HttpErrorException.handErrorMessage(e);
                        Log.e(TAG, eMsg);
                        showToast("" + eMsg);
                        //if set failed , just reset the status to back
                    }

                    @Override
                    public void onNext(ResponseBody responseBody) {
                        Log.i(TAG);
                        String rs = "";
                        try {
                            rs = responseBody.string();

                            JSONObject object = new JSONObject(rs);

                            if (200 == object.optInt("code")) {
                                //if request. success ,update the lastest info
                                JSONObject result = object.optJSONObject("result");
                                if (result != null) {
                                    String signature = result.optString("signature");
                                    updateBackgourd(signature);
                                } else {
                                    //if set failed , just reset the status to back

                                }

                            } else {
                                //if set failed , just reset the status to back

                            }

                        } catch (Exception e) {
                            //if set failed , just reset the status to back

                            Log.e(TAG, "parse requestSignature error:" + android.util.Log.getStackTraceString(e));
                        }

                        Log.i(TAG, "requestSignature result:" + rs);
                    }
                });


    }

    private void updateBackgourd(String signature) {
        User user = SPUtil.getMomentInfo(SPUtil.getUserID());

        if (!TextUtils.isEmpty(signature)) {
            user.signature = signature;
        }
        SPUtil.saveMomentInfo(user);
        finish();

    }
}
