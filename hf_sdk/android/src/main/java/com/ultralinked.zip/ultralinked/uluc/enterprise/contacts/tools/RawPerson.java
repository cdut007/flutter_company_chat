package com.ultralinked.uluc.enterprise.contacts.tools;

import com.ultralinked.uluc.enterprise.contacts.contract.PeopleEntity;

import java.util.List;

/**
 * Created by ultralinked on 16/7/1.
 * parse the getuser api respoonse
 */
public class RawPerson {


    /**
     * code : 200
     * result : [{"type":"internal","company":"DEPART129d4814-36ad-11e6-b191-22000aae16d4","data":[{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983467005","name":"yajun","mobile":"8613880477037","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yajun@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983471004","name":"fafu","mobile":"8613980005614","icon_url":null,"created_at":"2016-07-20 02:57:51","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"fafu@ultralinked.com"},{"enable":true,"updated_at":"2016-07-28 01:08:11","active":true,"deleted_at":"None","nickname":"?????????????????:(? ??????????????? ?):( ?° ?? ?°)","id":"subusr1468983474001","name":"qingquan","mobile":"8617761261689","icon_url":"http://gruc.gnum.com/icons/2ffc969601cfc3d09b5da5002dc89503.jpg","created_at":"2016-07-20 02:57:54","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"qingquan@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983476005","name":"daolei","mobile":"8618224032891","icon_url":null,"created_at":"2016-07-20 02:57:57","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"daolei@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983480002","name":"wanghuan","mobile":"8613219950077","icon_url":null,"created_at":"2016-07-20 02:58:00","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"wanghuan@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983481000","name":"yanxi","mobile":"8613551856640","icon_url":null,"created_at":"2016-07-20 02:58:01","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yanxi@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983482002","name":"chenlu","mobile":"8618200394453","icon_url":null,"created_at":"2016-07-20 02:58:02","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"chenlu@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":"yaomin","id":"subusr1469514871000","name":"yaomin","mobile":"8618428357708","icon_url":null,"created_at":"2016-07-26 06:34:31","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yaomin@ultralinked.com"}],"name":"ultralinked","department_id":"DEPART129d4814-36ad-11e6-b191-22000aae16d4"},{"type":"internal","company":"DEPART129d4814-36ad-11e6-b191-22000aae16d4","data":[{"enable":true,"updated_at":"2016-07-21 06:22:01","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983471000","name":"guangneng","mobile":"8618260856221","icon_url":"http://gruc.gnum.comhttp://ww2.sinaimg.cn/large/610dc034jw1f5qyx2wpohj20xc190tr7.jpg","created_at":"2016-07-20 02:57:51","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"guangneng@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983475007","name":"xiexing","mobile":"8615228968831","icon_url":null,"created_at":"2016-07-20 02:57:56","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"xiexing@ultralinked.com"}],"name":"Marketing","department_id":"DEPARTb614b82e-3d0b-11e6-91d3-22000aae16d4"},{"type":"internal","company":"DEPART129d4814-36ad-11e6-b191-22000aae16d4","data":[{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983468000","name":"yili","mobile":"8618583660897","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yili@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983471004","name":"fafu","mobile":"8613980005614","icon_url":null,"created_at":"2016-07-20 02:57:51","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"fafu@ultralinked.com"}],"name":"Chengdu","department_id":"DEPART1bce9ab8-3d0c-11e6-91d3-22000aae16d4"},{"type":"external","company":"DEPART129d4814-36ad-11e6-b191-22000aae16d4","data":[{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983468000","name":"yili","mobile":"8618583660897","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yili@ultralinked.com"}],"name":"liudehua","department_id":"DEPART2d531a70-4fd1-11e6-8697-22000aae16d4"},{"type":"external","company":"DEPART129d4814-36ad-11e6-b191-22000aae16d4","data":[{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983468000","name":"yili","mobile":"8618583660897","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yili@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983475007","name":"xiexing","mobile":"8615228968831","icon_url":null,"created_at":"2016-07-20 02:57:56","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"xiexing@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":"yaomin","id":"subusr1469514871000","name":"yaomin","mobile":"8618428357708","icon_url":null,"created_at":"2016-07-26 06:34:31","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yaomin@ultralinked.com"}],"name":"zhoujielun","department_id":"DEPART5b126a06-4fd1-11e6-8697-22000aae16d4"},{"type":"internal","company":"DEPARTde601dd2-3d0b-11e6-91d3-22000aae16d4","data":[{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983468000","name":"yili","mobile":"8618583660897","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yili@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983475007","name":"xiexing","mobile":"8615228968831","icon_url":null,"created_at":"2016-07-20 02:57:56","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"xiexing@ultralinked.com"}],"name":"Gnum","department_id":"DEPARTde601dd2-3d0b-11e6-91d3-22000aae16d4"}]
     */

    public int code;
    /**
     * type : internal
     * company : DEPART129d4814-36ad-11e6-b191-22000aae16d4
     * data : [{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983467005","name":"yajun","mobile":"8613880477037","icon_url":null,"created_at":"2016-07-20 02:57:48","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yajun@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983471004","name":"fafu","mobile":"8613980005614","icon_url":null,"created_at":"2016-07-20 02:57:51","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"fafu@ultralinked.com"},{"enable":true,"updated_at":"2016-07-28 01:08:11","active":true,"deleted_at":"None","nickname":"?????????????????:(? ??????????????? ?):( ?° ?? ?°)","id":"subusr1468983474001","name":"qingquan","mobile":"8617761261689","icon_url":"http://gruc.gnum.com/icons/2ffc969601cfc3d09b5da5002dc89503.jpg","created_at":"2016-07-20 02:57:54","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"qingquan@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983476005","name":"daolei","mobile":"8618224032891","icon_url":null,"created_at":"2016-07-20 02:57:57","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"daolei@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983480002","name":"wanghuan","mobile":"8613219950077","icon_url":null,"created_at":"2016-07-20 02:58:00","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"wanghuan@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983481000","name":"yanxi","mobile":"8613551856640","icon_url":null,"created_at":"2016-07-20 02:58:01","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yanxi@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":null,"id":"subusr1468983482002","name":"chenlu","mobile":"8618200394453","icon_url":null,"created_at":"2016-07-20 02:58:02","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"chenlu@ultralinked.com"},{"enable":true,"updated_at":"None","active":true,"deleted_at":"None","nickname":"yaomin","id":"subusr1469514871000","name":"yaomin","mobile":"8618428357708","icon_url":null,"created_at":"2016-07-26 06:34:31","domain_id":"DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed","email":"yaomin@ultralinked.com"}]
     * name : ultralinked
     * department_id : DEPART129d4814-36ad-11e6-b191-22000aae16d4
     */

    public List<ResultBean> result;

    public static class ResultBean {
        public String type;
        public String company;
        public String name;
        public String department_id;
        /**
         * enable : true
         * updated_at : None
         * active : true
         * deleted_at : None
         * nickname : null
         * id : subusr1468983467005
         * name : james
         * mobile : 86138xxxxxxxx
         * icon_url : null
         * created_at : 2016-07-20 02:57:48
         * domain_id : DOMAIN8b782912-3116-11e6-8b82-fa163e17f4ed
         * email : james@ultralinked.com
         */

        public List<PeopleEntity> data;

    }
}
