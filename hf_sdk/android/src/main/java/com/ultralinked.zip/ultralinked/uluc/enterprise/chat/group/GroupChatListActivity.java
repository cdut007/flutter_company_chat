package com.ultralinked.uluc.enterprise.chat.group;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.ultralinked.uluc.enterprise.Constants;
import com.ultralinked.uluc.enterprise.baseui.BaseFragmentActivity;
import com.ultralinked.uluc.enterprise.chat.ChatListFragment;

/**
 * Created by chenlu on 2016/8/5 0005.
 */
public class GroupChatListActivity extends BaseFragmentActivity {
    @Override
    public void initView(Bundle savedInstanceState) {

        Bundle bundle = getIntent().getBundleExtra(Constants.DATA_KEY);

        setFragment(ChatListFragment.class, bundle);

    }

    public static void launchActivity(Activity activity) {
        Intent i = new Intent(activity, GroupChatListActivity.class);
        Bundle data = new Bundle();
        data.putBoolean("group_chats", true);
        i.putExtra(Constants.DATA_KEY, data);
        activity.startActivity(i);

    }
}
